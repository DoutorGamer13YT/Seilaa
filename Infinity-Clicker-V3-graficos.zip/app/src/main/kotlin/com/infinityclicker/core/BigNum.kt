package com.infinityclicker.core

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

/**
 * Número real não negativo de magnitude praticamente ilimitada:
 * valor = mantissa × 10^expoente, com mantissa em [1, 10) (ou zero).
 *
 * O expoente é um Long, então o intervalo vai muito além do Double (~1e308).
 * A precisão é a da mantissa (~15 dígitos), suficiente para um jogo incremental.
 * Valores negativos não existem: [minus] é saturada em zero.
 */
class BigNum private constructor(val mantissa: Double, val exponent: Long) : Comparable<BigNum> {

    val isZero: Boolean get() = mantissa == 0.0

    operator fun plus(other: BigNum): BigNum {
        if (isZero) return other
        if (other.isZero) return this
        val hi = if (this >= other) this else other
        val lo = if (this >= other) other else this
        val diff = saturatedSubtract(hi.exponent, lo.exponent)
        if (diff > MAX_EXPONENT_GAP) return hi
        return normalize(hi.mantissa + lo.mantissa * 10.0.pow(-diff.toInt()), hi.exponent)
    }

    /** Subtração saturada: nunca retorna menos que zero. */
    operator fun minus(other: BigNum): BigNum {
        if (other.isZero) return this
        if (this <= other) return ZERO
        val diff = saturatedSubtract(exponent, other.exponent)
        if (diff > MAX_EXPONENT_GAP) return this
        return normalize(mantissa - other.mantissa * 10.0.pow(-diff.toInt()), exponent)
    }

    operator fun times(other: BigNum): BigNum {
        if (isZero || other.isZero) return ZERO
        return normalize(mantissa * other.mantissa, saturatedAdd(exponent, other.exponent))
    }

    operator fun times(d: Double): BigNum = times(of(d))

    operator fun div(other: BigNum): BigNum {
        if (other.isZero) throw ArithmeticException("Divisão por zero")
        if (isZero) return ZERO
        return normalize(mantissa / other.mantissa, saturatedSubtract(exponent, other.exponent))
    }

    /** this^x para x real. 0^x = 0 (x ≠ 0) e y^0 = 1. */
    fun pow(x: Double): BigNum {
        if (x == 0.0) return ONE
        if (isZero) return ZERO
        if (this == ONE) return ONE
        if (exponent in -290L..290L && abs(x) < 1e7) {
            val r = toDouble().pow(x)
            if (r.isFinite() && r > 1e-290 && r < 1e290) return of(r)
        }
        val lg = log10() * x
        if (lg.isNaN()) return ZERO
        if (lg == Double.POSITIVE_INFINITY) return BigNum(9.999_999_999_999_999, Long.MAX_VALUE)
        if (lg == Double.NEGATIVE_INFINITY) return BigNum(1.0, Long.MIN_VALUE)
        val e = floor(lg)
        val exponent = when {
            e >= Long.MAX_VALUE.toDouble() -> Long.MAX_VALUE
            e <= Long.MIN_VALUE.toDouble() -> Long.MIN_VALUE
            else -> e.toLong()
        }
        return normalize(10.0.pow(lg - e), exponent)
    }

    /** log10 do valor; só definido para valores positivos. */
    fun log10(): Double {
        require(!isZero) { "log10 de zero" }
        return exponent.toDouble() + log10(mantissa)
    }

    fun toDouble(): Double {
        if (isZero) return 0.0
        if (exponent > 308) return Double.POSITIVE_INFINITY
        if (exponent < -323) return 0.0
        return mantissa * 10.0.pow(exponent.toInt())
    }

    /** Converte para Long saturando em Long.MAX_VALUE (parte inteira). */
    fun toLongSaturated(): Long {
        if (isZero) return 0L
        if (exponent >= 18) return Long.MAX_VALUE
        return toDouble().toLong()
    }

    override fun compareTo(other: BigNum): Int {
        if (isZero) return if (other.isZero) 0 else -1
        if (other.isZero) return 1
        if (exponent != other.exponent) return if (exponent > other.exponent) 1 else -1
        return mantissa.compareTo(other.mantissa)
    }

    override fun equals(other: Any?): Boolean = other is BigNum && compareTo(other) == 0

    override fun hashCode(): Int = 31 * mantissa.hashCode() + exponent.hashCode()

    /** Forma estável para salvar em disco: "mantissa:expoente". */
    fun serialize(): String = "$mantissa:$exponent"

    override fun toString(): String = if (isZero) "0" else "${mantissa}e$exponent"

    companion object {
        /** Acima desta diferença de expoentes o menor termo some na precisão da mantissa. */
        private const val MAX_EXPONENT_GAP = 17L
        private const val HUGE_EXPONENT = 1_000_000_000_000_000L

        val ZERO = BigNum(0.0, 0L)
        val ONE = BigNum(1.0, 0L)

        fun of(v: Double): BigNum {
            if (v.isNaN() || v <= 0.0) return ZERO
            if (v.isInfinite()) return BigNum(1.0, HUGE_EXPONENT)
            return normalize(v, 0L)
        }

        fun of(v: Long): BigNum = if (v <= 0L) ZERO else normalize(v.toDouble(), 0L)

        fun of(v: Int): BigNum = of(v.toLong())

        fun parse(text: String): BigNum? {
            val i = text.indexOf(':')
            if (i <= 0) return null
            val m = text.substring(0, i).toDoubleOrNull() ?: return null
            val e = text.substring(i + 1).toLongOrNull() ?: return null
            if (m.isNaN() || m.isInfinite() || m < 0.0) return null
            if (m == 0.0) return ZERO
            return normalize(m, e)
        }

        fun max(a: BigNum, b: BigNum): BigNum = if (a >= b) a else b
        fun min(a: BigNum, b: BigNum): BigNum = if (a <= b) a else b

        private fun normalize(m: Double, e: Long): BigNum {
            if (m.isNaN() || m <= 0.0) return ZERO
            if (m.isInfinite()) return BigNum(1.0, saturatedAdd(e, 308L))
            if (m >= 1.0 && m < 10.0) return BigNum(m, e)
            val l = floor(log10(m)).toLong()
            var nm = m / 10.0.pow(l.toInt())
            var ne = saturatedAdd(e, l)
            if (nm >= 10.0) {
                nm /= 10.0
                ne = saturatedAdd(ne, 1L)
            } else if (nm < 1.0) {
                nm *= 10.0
                ne = saturatedSubtract(ne, 1L)
            }
            return BigNum(nm, ne)
        }

        /** Soma/subtração de expoentes não pode voltar de sinal por overflow de Long. */
        private fun saturatedAdd(a: Long, b: Long): Long {
            if (b == Long.MIN_VALUE) return if (a < 0L) Long.MIN_VALUE else a + b
            if (b > 0L && a > Long.MAX_VALUE - b) return Long.MAX_VALUE
            if (b < 0L && a < Long.MIN_VALUE - b) return Long.MIN_VALUE
            return a + b
        }

        private fun saturatedSubtract(a: Long, b: Long): Long {
            if (b == Long.MIN_VALUE) return if (a >= 0L) Long.MAX_VALUE else a - b
            if (b > 0L && a < Long.MIN_VALUE + b) return Long.MIN_VALUE
            if (b < 0L && a > Long.MAX_VALUE + b) return Long.MAX_VALUE
            return a - b
        }
    }
}
