package com.infinityclicker.game

enum class Rarity(val label: String) {
    COMUM("Comum"),
    INCOMUM("Incomum"),
    RARO("Raro"),
    EPICO("Épico"),
    LENDARIO("Lendário"),
    MITICO("Mítico"),
    COSMICO("Cósmico"),
    TRANSCENDENTAL("Transcendental")
}
