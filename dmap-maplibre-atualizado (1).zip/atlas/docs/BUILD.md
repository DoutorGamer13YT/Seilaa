# Configuração e compilação do Atlas

## Estado real desta entrega

A configuração foi escrita e inspecionada estaticamente. **Nenhuma compilação foi executada, nenhum APK foi gerado e nenhum teste Kotlin/Android foi executado neste ambiente.** A instrução mais recente do usuário suspendeu compilações e downloads de ferramentas. Os comandos abaixo são um procedimento para execução futura, não resultados já obtidos.

O ambiente disponibilizava Java 21, mas não Android SDK, Gradle, adb, emulador ou `/dev/kvm`. As tentativas iniciais de download não transferiram arquivos; o acesso ao proxy falhou e uma solicitação posterior de rede foi interrompida. `/workspace/tooling` contém somente diretórios de preparação. O projeto ainda não contém `gradlew`, `gradlew.bat` ou o JAR/properties do Gradle Wrapper. Não há script falso que simule essas ferramentas.

## Versões fixadas

| Componente | Versão/configuração |
| --- | --- |
| Android Gradle Plugin | 8.7.3 |
| Gradle recomendado | 8.9 |
| JDK recomendado | 17; bytecode Java/Kotlin 17 |
| Kotlin e plugin Compose | 2.0.21 |
| KSP | 2.0.21-1.0.28 |
| Compose BOM | 2024.12.01 |
| SDK Android | compile/target 35, mínimo 26 |
| Build Tools para instalação | 35.0.0; seleção efetiva é gerenciada pelo AGP |
| MapLibre Android | 11.8.0 |
| Room | 2.6.1, esquemas em `app/schemas` |
| DataStore Preferences | 1.1.1 |
| Navigation Compose | 2.8.5 |
| Lifecycle | 2.8.7 |
| Coroutines | 1.9.0 |
| OkHttp | 4.12.0 |

As versões estão declaradas, mas resolução Maven e compatibilidade binária ainda precisam ser verificadas por um build real. Não existe lockfile ou verification metadata obtido por resolução de dependências nesta entrega.

## Preparação em uma máquina Android de desenvolvimento

1. Instale Android Studio com JDK 17 e o Android SDK. Pelo SDK Manager, selecione Android SDK Platform 35, Android SDK Build-Tools 35.0.0, Platform-Tools e Command-line Tools. Pela linha de comando, os pacotes equivalentes são:

   ```sh
   sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"
   sdkmanager --licenses
   ```

2. Copie `local.properties.example` para `local.properties` e configure `sdk.dir` com o caminho absoluto do SDK. O arquivo é ignorado pelo Git. Alternativamente configure `ANDROID_HOME`. Não publique chaves privadas ou arquivos de assinatura.

3. Instale a distribuição oficial **Gradle 8.9**, verificando o SHA-256 publicado em [Gradle Releases](https://gradle.org/releases/). Com esse executável no `PATH`, gere o Wrapper autêntico em uma pasta temporária vazia, evitando avaliar o projeto Android antes de o SDK estar preparado:

   ```sh
   mkdir -p /tmp/atlas-gradle-wrapper-bootstrap
   cd /tmp/atlas-gradle-wrapper-bootstrap
   printf 'rootProject.name = "wrapper-bootstrap"\n' > settings.gradle.kts
   gradle wrapper --gradle-version 8.9 --distribution-type bin
   ```

   Copie `gradlew`, `gradlew.bat` e a pasta `gradle/wrapper` produzidos para a raiz do projeto Atlas. Acrescente `distributionSha256Sum` em `gradle/wrapper/gradle-wrapper.properties` com o SHA-256 oficial da distribuição binária 8.9. Verifique o checksum do próprio `gradle-wrapper.jar` pelos valores oficiais do Gradle antes de versioná-lo. Em Unix, execute `chmod +x gradlew`. Os arquivos do Wrapper devem ser versionados depois dessa verificação.

4. Quando a execução de builds estiver autorizada, na raiz do projeto:

   ```sh
   ./gradlew --version
   ./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
   ```

   O primeiro build exige acesso a Google Maven, Maven Central e Gradle Plugin Portal. Configure proxy e CA conforme a rede usada; não desative verificação TLS. Esses comandos não foram executados nesta sessão.

5. O APK de depuração esperado após um build bem-sucedido fica em `app/build/outputs/apk/debug/app-debug.apk`. Com um Android 8.0+ autorizado para depuração USB:

   ```sh
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   adb shell am start -n dev.atlas/.MainActivity
   ./gradlew :app:connectedDebugAndroidTest
   ```

   Testes instrumentados exigem aparelho/emulador real disponível. Para restauração após parada forçada, siga também `docs/PERSISTENCE.md`. Um emulador sem aceleração não foi instalado ou executado.

## Provedores e chaves

As variáveis de ambiente têm precedência sobre propriedades de mesmo nome em `local.properties`. Os valores são inseridos em `BuildConfig` durante o build. Endpoints personalizados precisam usar HTTPS e fornecer o protocolo do provedor correspondente.

| Propriedade | Padrão/finalidade |
| --- | --- |
| `PHOTON_BASE_URL` | `https://photon.komoot.io/` — geocodificação |
| `OVERPASS_URL` | `https://overpass-api.de/api/interpreter` — POIs OSM |
| `OSRM_BASE_URL` | `https://router.project-osrm.org/` — rotas de carro |
| `ORS_BASE_URL` | `https://api.heigit.org/openrouteservice/` — rotas OpenRouteService |
| `ORS_API_KEY` | vazio — habilita OpenRouteService quando configurada |

Obtenha uma chave OpenRouteService pelo painel oficial em [openrouteservice.org](https://openrouteservice.org/dev/#/signup); consulte limites e licença antes de distribuição. Uma chave de cliente embutida no APK **não é secreta**: aplique restrições oferecidas pelo serviço e use um backend próprio quando precisar proteger credenciais. Não inclua uma chave administrativa no APK. Repositórios e UI devem indicar capacidades reais disponíveis quando a chave estiver ausente.

Photon, Overpass e OSRM públicos não fornecem contrato de capacidade ou disponibilidade para produção. Uso amplo exige instância própria ou provedor contratado. Mapas usam estilos locais em `app/src/main/assets/styles`; a fonte e atribuições estão nesses arquivos. Alterar apenas uma chave não troca essa fonte cartográfica. O campo preliminar `MAPTILER_API_KEY` foi removido porque não havia consumidor implementado.

## Manifesto e distribuição

- `dev.atlas`, versão 1.0.0/1, activity `singleTop`; os esquemas `geo:` e `atlas://` passam por validação explícita em `DeepLinks`.
- Localização aproximada/precisa é solicitada em contexto. Não existe permissão `ACCESS_BACKGROUND_LOCATION`, receiver de boot ou reinício automático da navegação após morte do processo.
- Serviço de navegação privado com tipo `location`, permissões `FOREGROUND_SERVICE` e `FOREGROUND_SERVICE_LOCATION`; sua inicialização deve ocorrer a partir da tela visível. Android 13+ tem permissão de notificações solicitada pela UI.
- Consulta de visibilidade `TTS_SERVICE` permite encontrar mecanismo de voz no Android 11+.
- Internet e estado da rede são necessários para provedores. HTTP sem TLS está desabilitado. Backup do banco de localização está desabilitado. OpenGL ES 2.0 é requisito do motor de mapa.
- Ícone adaptativo original e tema inicial claro/escuro disponíveis para Android 8.0+. Tema Compose controla aparência interna; barras e insets precisam ser revisados em execução no target 35.
- `release` ativa R8 e redução de recursos, mas não define uma chave de assinatura. A assinatura final, testes R8/JNI, ABI, alinhamento de bibliotecas nativas para páginas de 16 KB e requisitos atuais da loja precisam ser verificados antes de distribuição. `assembleDebug` não é aprovação de produção.

## Verificação estática permitida sem compilar

```sh
python3 scripts/validate_static.py
python3 scripts/validate_static.py --json
```

O script lê XML, estilos JSON, referências locais, campos `BuildConfig`, permissões e componentes do Manifest. Não chama Gradle, não compila Kotlin, não faz download e não executa Android. Sucesso nessa verificação não prova que o APK compila ou que mapas, GPS, animações e acessibilidade funcionam em um aparelho.
