package com.w2a.nzuz

import android.content.Context
import android.os.StatFs
import androidx.work.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.*
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.*

 data class RegionItem(
    val id: Long, val name: String, val definition: OfflineTilePyramidRegionDefinition,
    val credit: String, val bytes: Long = 0, val count: Long = 0, val required: Long = 0,
    val precise: Boolean = false, val complete: Boolean = false, val message: String = "Pausado"
) {
    val fraction: Float? get() = if (precise && required > 0) (count.toFloat() / required).coerceIn(0f, 1f) else null
}

data class AreaEstimate(val tiles: Long, val lowBytes: Long, val highBytes: Long)

object RegionMath {
    const val MAX_TILES = 20_000L
    const val RESERVE = 256L * 1024 * 1024
    fun estimate(b: LatLngBounds, maxZoom: Int): AreaEstimate {
        require(maxZoom in 2..16)
        require(b.longitudeEast > b.longitudeWest && b.longitudeEast - b.longitudeWest < 180) {
            "Selecione uma área menor, sem cruzar o meridiano de 180°."
        }
        var count = 0L
        for (z in 0..maxZoom) {
            val n = 1 shl z
            fun x(lon: Double) = floor((lon + 180) / 360 * n).toInt().coerceIn(0, n - 1)
            fun y(lat: Double): Int {
                val r = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
                return floor((1 - ln(tan(r) + 1 / cos(r)) / PI) / 2 * n).toInt().coerceIn(0, n - 1)
            }
            count += (x(b.longitudeEast) - x(b.longitudeWest) + 1L) * (y(b.latitudeSouth) - y(b.latitudeNorth) + 1L)
        }
        return AreaEstimate(count, count * 16_384 + 2_097_152, count * 131_072 + 16_777_216)
    }
}

class OfflineRepository(private val context: Context, private val prefs: Preferences) {
    private val manager = OfflineManager.getInstance(context)
    private val native = mutableMapOf<Long, OfflineRegion>()
    private val data = MutableStateFlow<List<RegionItem>>(emptyList())
    val regions = data.asStateFlow()
    private val loading = Mutex()
    private val edits = Mutex()
    private var loaded = false
    private val active = mutableSetOf<Long>()
    private val work = WorkManager.getInstance(context)

    init { manager.setMaximumAmbientCacheSize(32L * 1024 * 1024, null) }

    suspend fun load() = withContext(Dispatchers.Main.immediate) {
        loading.withLock {
            if (loaded) return@withLock
            val found = suspendCancellableCoroutine<Array<OfflineRegion>> { c ->
                manager.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
                    override fun onList(offlineRegions: Array<OfflineRegion>?) { if (c.isActive) c.resume(offlineRegions ?: emptyArray()) }
                    override fun onError(error: String) { if (c.isActive) c.resumeWithException(IllegalStateException(error)) }
                })
            }
            found.forEach { attach(it) }
            loaded = true
        }
    }

    private fun attach(region: OfflineRegion) {
        if (native.containsKey(region.id)) return
        val def = region.definition as? OfflineTilePyramidRegionDefinition ?: return
        val meta = runCatching { JSONObject(String(region.metadata, Charsets.UTF_8)) }.getOrDefault(JSONObject())
        native[region.id] = region
        data.value = data.value + RegionItem(region.id, meta.optString("name", "Região ${region.id}"), def,
            meta.optString("credit", "Consulte a fonte configurada"), message = prefs.regionMessage(region.id))
        region.getStatus(object : OfflineRegion.OfflineRegionStatusCallback {
            override fun onStatus(status: OfflineRegionStatus?) { status?.let { update(region.id, it) } }
            override fun onError(error: String?) { message(region.id, "Falha ao ler região; tente reabrir o app.") }
        })
    }

    fun update(id: Long, status: OfflineRegionStatus) {
        data.value = data.value.map { r -> if (r.id != id) r else r.copy(
            bytes = status.completedResourceSize, count = status.completedResourceCount,
            required = status.requiredResourceCount, precise = status.isRequiredResourceCountPrecise,
            complete = status.isComplete, message = if (status.isComplete) "Disponível offline" else r.message
        ) }
    }

    fun message(id: Long, message: String) {
        prefs.setRegionMessage(id, message)
        data.value = data.value.map { if (it.id == id) it.copy(message = message) else it }
    }

    suspend fun create(name: String, bounds: LatLngBounds, zoom: Int): Long = withContext(Dispatchers.Main.immediate) {
        load()
        edits.withLock {
            val config = prefs.state.value
            validateSource(config.styleUrl, config.attribution, config.authorized)?.let { error(it) }
            require(name.isNotBlank()) { "Dê um nome à região." }
            val estimate = RegionMath.estimate(bounds, zoom)
            require(estimate.tiles <= RegionMath.MAX_TILES) { "Área muito grande. Reduza o zoom ou a região." }
            require(estimate.highBytes + RegionMath.RESERVE < freeBytes()) { "Espaço livre insuficiente para a estimativa." }
            val existing = data.value.firstOrNull {
                val b = it.definition.bounds ?: return@firstOrNull false
                it.definition.styleURL == config.styleUrl && it.definition.maxZoom >= zoom &&
                    b.latitudeNorth >= bounds.latitudeNorth && b.latitudeSouth <= bounds.latitudeSouth &&
                    b.longitudeWest <= bounds.longitudeWest && b.longitudeEast >= bounds.longitudeEast
            }
            if (existing != null) return@withLock existing.id
            require(data.value.size < 50) { "Limite de 50 regiões; exclua uma antes de continuar." }
            val definition = OfflineTilePyramidRegionDefinition(config.styleUrl, bounds, 0.0, zoom.toDouble(), 1f, true)
            val metadata = JSONObject().put("name", name.trim().take(80)).put("credit", config.attribution)
                .put("createdAt", System.currentTimeMillis()).put("schema", 1).toString().toByteArray()
            suspendCancellableCoroutine { c ->
                manager.createOfflineRegion(definition, metadata, object : OfflineManager.CreateOfflineRegionCallback {
                    override fun onCreate(offlineRegion: OfflineRegion) {
                        attach(offlineRegion)
                        if (c.isActive) c.resume(offlineRegion.id)
                    }
                    override fun onError(error: String) { if (c.isActive) c.resumeWithException(IllegalStateException(error)) }
                })
            }
        }
    }

    suspend fun resume(id: Long) = withContext(Dispatchers.Main.immediate) {
        load()
        require(native.containsKey(id)) { "Região não encontrada." }
        if (data.value.firstOrNull { it.id == id }?.complete == true) return@withContext
        val pending = work.getWorkInfosForUniqueWork(workName(id)).await().any { !it.state.isFinished }
        if (pending) return@withContext
        message(id, "Na fila; aguardando rede e condições do Android")
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (prefs.state.value.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .setRequiresStorageNotLow(true).build()
        val request = OneTimeWorkRequestBuilder<RegionDownloadWorker>()
            .setInputData(workDataOf("regionId" to id)).setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("dmaps-offline").addTag(workName(id)).build()
        work.enqueueUniqueWork(workName(id), ExistingWorkPolicy.KEEP, request).result.await()
    }

    suspend fun pause(id: Long) = withContext(Dispatchers.Main.immediate) {
        work.cancelUniqueWork(workName(id)).result.await()
        while (id in active) delay(30)
        native[id]?.setDownloadState(OfflineRegion.STATE_INACTIVE)
        message(id, "Pausado; dados parciais preservados")
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.Main.immediate) {
        edits.withLock {
            pause(id)
            val region = native[id] ?: return@withLock
            suspendCancellableCoroutine<Unit> { c ->
                region.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
                    override fun onDelete() {
                        native.remove(id); data.value = data.value.filterNot { it.id == id }; prefs.forget(id)
                        if (c.isActive) c.resume(Unit)
                    }
                    override fun onError(error: String) { if (c.isActive) c.resumeWithException(IllegalStateException(error)) }
                })
            }
        }
    }

    suspend fun begin(id: Long): OfflineRegion = withContext(Dispatchers.Main.immediate) {
        load()
        check(active.add(id)) { "Já existe um download ativo." }
        native[id] ?: run { active.remove(id); error("Região não encontrada") }
    }

    fun finish(id: Long) {
        native[id]?.let { it.setDownloadState(OfflineRegion.STATE_INACTIVE); it.setObserver(null) }
        active.remove(id)
    }

    suspend fun clearCache() = withContext(Dispatchers.Main.immediate) {
        check(active.isEmpty()) { "Pause os downloads antes de gerenciar o armazenamento." }
        suspendCancellableCoroutine<Unit> { c ->
            manager.clearAmbientCache(object : OfflineManager.FileSourceCallback {
                override fun onSuccess() {
                    manager.packDatabase(object : OfflineManager.FileSourceCallback {
                        override fun onSuccess() { if (c.isActive) c.resume(Unit) }
                        override fun onError(message: String) { if (c.isActive) c.resumeWithException(IllegalStateException(message)) }
                    })
                }
                override fun onError(message: String) { if (c.isActive) c.resumeWithException(IllegalStateException(message)) }
            })
        }
    }

    suspend fun refreshStatuses() = withContext(Dispatchers.Main.immediate) {
        load()
        val infos = work.getWorkInfosByTag("dmaps-offline").await()
        data.value.filterNot { it.complete || it.id in active }.forEach { item ->
            val scheduled = infos.any { !it.state.isFinished && workName(item.id) in it.tags }
            if (item.message.startsWith("Baixando") && !scheduled) message(item.id, "Interrompido; toque em Retomar")
        }
    }

    fun freeBytes(): Long = StatFs(context.filesDir.absolutePath).availableBytes
    suspend fun diskBytes(): Long = withContext(Dispatchers.IO) {
        context.filesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
    companion object { fun workName(id: Long) = "dmaps-region-$id" }
}
