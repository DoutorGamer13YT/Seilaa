# Skills de programação instaladas

Instalação local concluída sem reiniciar a sessão nem trocar de ambiente.

- Origem: https://github.com/tiagopgr/skills-ia
- Commit fixado: `1983bef1bf8609fc8030d371224ee9e9a5d4bd61`.
- Destino: `/workspace/atlas/.agents/skills/` (raiz do projeto; `/workspace/.agents/` é protegido pelo ambiente).
- Método: leitura dos arquivos originais via conector GitHub, sem executar scripts do repositório.
- Verificação: os 10 arquivos são idênticos aos blobs Git originais (SHA-1 com cabeçalho Git e SHA-256 registrado), com `name` e `description` no frontmatter.
- Registro reproduzível: `.agents/skills/INSTALLATION.json`.

## Seleção

Foram selecionadas skills gerais de engenharia aplicáveis a Kotlin/Android ou à manutenção do projeto:

1. `code-review-estruturado-checklist`
2. `debugger-sistematico-causa-raiz`
3. `design-de-api-restful-boas-praticas`
4. `estimativa-de-prazo-de-desenvolvimento`
5. `ia-como-engenheiro-de-software-pessoal`
6. `modelagem-de-banco-de-dados-schema`
7. `pipeline-cicd-github-actions`
8. `planejamento-de-sprint-solo`
9. `readme-profissional-template`
10. `testes-unitarios-framework-de-escrita`

As demais 12 skills da categoria Código são específicas de web, Docker, WhatsApp, creators, planilhas, no-code ou automações de negócio e não foram adicionadas ao app Android. Não foram instaladas categorias de marketing ou outros assuntos.

## Uso nesta sessão

Os arquivos locais podem ser lidos imediatamente como orientação de trabalho. Foram lidas integralmente as skills de revisão e depuração para a retomada. A presença em disco não equivale a afirmar registro automático em algum catálogo de interface; nenhum reinício foi necessário para usar as instruções diretamente.

A instrução atual do usuário de **não compilar o aplicativo** prevalece sobre qualquer sugestão genérica de testes, build ou CI contida nas skills. A instalação da skill de CI não cria nem dispara pipelines.
