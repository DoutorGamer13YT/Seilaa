package dev.atlas.core

import kotlin.math.*

/** All distances and times are estimates derived from the provider's route, never live traffic. */
data class NavigationProgress(
    val stepIndex: Int,
    val instruction: String,
    val distanceToManeuverMeters: Double,
    val remainingDistanceMeters: Double,
    val remainingDurationSeconds: Double,
    val offRoute: Boolean,
    val arrived: Boolean,
    val nearestCoordinate: Coordinate?,
    val travelledGeometryMeters: Double = 0.0,
    val segmentIndex: Int = 0,
    val routeKey: String = "",
    val fixTimestampMillis: Long = 0L,
    val deviationCount: Int = 0,
)

/** Stateless, deterministic route matching. Keep previous progress only for the same route. */
object NavigationEngine {
    fun progress(route: Route, fix: LocationFix, previous: NavigationProgress? = null): NavigationProgress {
        val key = "${route.id}:${route.geometry.hashCode()}"
        val prior = previous?.takeIf { it.routeKey == key }
        if (prior != null && fix.timestampMillis <= prior.fixTimestampMillis) return prior
        val points = route.geometry
        if (points.size < 2) return NavigationProgress(
            0, route.steps.firstOrNull()?.instruction ?: "Instruções indisponíveis", 0.0,
            route.distanceMeters.safePositive(), route.durationSeconds.safePositive(), true, false,
            points.firstOrNull(), routeKey = key, fixTimestampMillis = fix.timestampMillis,
        )
        val lengths = points.zipWithNext { a, b -> a.distanceTo(b) }
        val total = lengths.sum()
        if (total < 0.01) return NavigationProgress(
            0, route.steps.lastOrNull()?.instruction ?: "Instruções indisponíveis", 0.0, 0.0, 0.0,
            fix.coordinate.distanceTo(points.last()) > 50.0, false, points.last(),
            routeKey = key, fixTimestampMillis = fix.timestampMillis,
        )
        val accuracy = fix.accuracyMeters.toDouble().takeIf { it.isFinite() && it >= 0 } ?: 100.0
        val elapsed = prior?.let { ((fix.timestampMillis - it.fixTimestampMillis) / 1000.0).coerceIn(0.0, 300.0) } ?: 0.0
        val plausibleSpeed = when (route.mode) {
            TransportMode.CAR -> 65.0
            TransportMode.BIKE -> 20.0
            TransportMode.WALK -> 5.0
        }
        // The forward window prevents jumping to a later road at a crossing or hairpin.
        val maxAdvance = max(75.0, elapsed * plausibleSpeed + accuracy.coerceAtMost(100.0) * 2)
        val floor = max(0.0, (prior?.travelledGeometryMeters ?: 0.0) - 40.0)
        val ceiling = prior?.let { min(total, it.travelledGeometryMeters + maxAdvance) } ?: total
        var offset = 0.0
        var best: Projection? = null
        lengths.forEachIndexed { index, length ->
            val end = offset + length
            if (length > 0.001 && end >= floor && offset <= ceiling) {
                val projection = project(fix.coordinate, points[index], points[index + 1])
                val minFraction = ((floor - offset) / length).coerceIn(0.0, 1.0)
                val maxFraction = ((ceiling - offset) / length).coerceIn(0.0, 1.0)
                val fraction = projection.coerceIn(minFraction, maxFraction)
                val coordinate = interpolate(points[index], points[index + 1], fraction)
                val candidate = Projection(coordinate, offset + length * fraction,
                    fix.coordinate.distanceTo(coordinate), index)
                if (best == null || candidate.distance < best!!.distance - 0.5) best = candidate
            }
            offset = end
        }
        val match = best ?: Projection(points.last(), total, fix.coordinate.distanceTo(points.last()), points.lastIndex - 1)
        val threshold = max(if (route.mode == TransportMode.CAR) 45.0 else 30.0, accuracy * 2.5)
        val deviating = match.distance > threshold
        val deviationCount = if (deviating) (prior?.deviationCount ?: 0) + 1 else 0
        // Require two fixes to enter deviation; use a lower threshold before clearing it.
        val offRoute = deviationCount >= 2 || (prior?.offRoute == true && match.distance > threshold * 0.65)
        val travelled = if (deviating) prior?.travelledGeometryMeters ?: match.along
            else max(prior?.travelledGeometryMeters ?: 0.0, match.along)
        val fraction = (travelled / total).coerceIn(0.0, 1.0)
        val providerDistance = route.distanceMeters.safePositive().takeIf { it > 0 } ?: total
        val remaining = providerDistance * (1.0 - fraction)
        val stepTotal = route.steps.sumOf { it.distanceMeters.safePositive() }
        val stepTravelled = fraction * stepTotal
        var cumulative = 0.0
        var currentStep = route.steps.lastIndex.coerceAtLeast(0)
        for ((index, step) in route.steps.withIndex()) {
            if (stepTravelled < cumulative + step.distanceMeters.safePositive() || index == route.steps.lastIndex) {
                currentStep = index
                break
            }
            cumulative += step.distanceMeters.safePositive()
        }
        val nextStep = (currentStep + 1).coerceAtMost(route.steps.lastIndex).coerceAtLeast(0)
        val step = route.steps.getOrNull(currentStep)
        val stepRemaining = max(0.0, cumulative + (step?.distanceMeters?.safePositive() ?: 0.0) - stepTravelled)
        val distanceToManeuver = if (stepTotal > 0) (stepRemaining / stepTotal * providerDistance).coerceAtMost(remaining) else remaining
        val durationTotal = route.steps.sumOf { it.durationSeconds.safePositive() }
        val duration = if (step != null && stepTotal > 0 && durationTotal > 0 && step.distanceMeters > 0) {
            val seconds = step.durationSeconds.safePositive() * (stepRemaining / step.distanceMeters).coerceIn(0.0, 1.0) +
                route.steps.drop(currentStep + 1).sumOf { it.durationSeconds.safePositive() }
            seconds / durationTotal * route.durationSeconds.safePositive()
        } else route.durationSeconds.safePositive() * (1.0 - fraction)
        val arrived = accuracy <= 50.0 && !offRoute && remaining <= max(20.0, accuracy) &&
            fix.coordinate.distanceTo(points.last()) <= max(20.0, accuracy)
        return NavigationProgress(
            nextStep, route.steps.getOrNull(nextStep)?.instruction ?: "Instruções indisponíveis",
            if (arrived) 0.0 else distanceToManeuver, if (arrived) 0.0 else remaining,
            if (arrived) 0.0 else duration, offRoute, arrived, match.coordinate,
            travelled, match.segment, key, fix.timestampMillis, deviationCount,
        )
    }

    private data class Projection(val coordinate: Coordinate, val along: Double, val distance: Double, val segment: Int)
    private fun Double.safePositive() = if (isFinite()) coerceAtLeast(0.0) else 0.0
    private fun longitudeDelta(a: Double, b: Double): Double = ((b - a + 540.0) % 360.0) - 180.0
    private fun interpolate(a: Coordinate, b: Coordinate, fraction: Double): Coordinate = Coordinate(
        (a.latitude + (b.latitude - a.latitude) * fraction).coerceIn(-90.0, 90.0),
        ((a.longitude + longitudeDelta(a.longitude, b.longitude) * fraction + 540.0) % 360.0) - 180.0,
    )
    private fun project(point: Coordinate, a: Coordinate, b: Coordinate): Double {
        val latitudeScale = cos(Math.toRadians((a.latitude + b.latitude) / 2)).coerceAtLeast(0.000001)
        val bx = longitudeDelta(a.longitude, b.longitude) * latitudeScale
        val by = b.latitude - a.latitude
        val px = longitudeDelta(a.longitude, point.longitude) * latitudeScale
        val py = point.latitude - a.latitude
        val denominator = bx * bx + by * by
        return if (denominator < 1e-20) 0.0 else ((px * bx + py * by) / denominator).coerceIn(0.0, 1.0)
    }
}

fun progress(route: Route, fix: LocationFix, previous: NavigationProgress? = null): NavigationProgress =
    NavigationEngine.progress(route, fix, previous)
