package com.infinityclicker.upgrades

import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.game.Rarity
import java.util.Locale
import kotlin.math.pow

enum class ShopCategory(val label: String) {
    CLICKS("Cliques"),
    PRODUCTION("Produção"),
    MULTIPLIERS("Multiplicadores"),
    PERMANENT("Permanentes")
}

sealed class Requirement {
    object None : Requirement()
    data class TotalEnergy(val amount: BigNum) : Requirement()
    data class GeneratorOwned(val generatorId: Int, val count: Long) : Requirement()

    fun describe(): String = when (this) {
        None -> ""
        is TotalEnergy -> "Produza ${NumberFormatter.format(amount)} de energia no total"
        is GeneratorOwned -> "Possua $count × ${GeneratorDefs.byId(generatorId).name}"
    }
}

/** O que uma melhoria de clique "extra" faz por nível (as 100 melhorias novas da loja). */
enum class ClickEffect { MULT, FLAT, CRIT_CHANCE, CRIT_POWER, COMBO_CAP, PRODUCTION_SHARE }

data class UpgradeDef(
    val id: String,
    val category: ShopCategory,
    val name: String,
    val description: String,
    val rarity: Rarity,
    val baseCost: BigNum,
    val growth: Double,
    val maxLevel: Int,
    val requirement: Requirement,
    /** Efeito genérico aplicado pelo motor (só nas melhorias de clique extras); null nas melhorias clássicas. */
    val clickEffect: ClickEffect? = null,
    /** Valor por nível do [clickEffect] (fator, soma, fração ou pontos, conforme o tipo). */
    val perLevel: Double = 0.0,
    /** Texto do efeito acumulado para um dado nível. */
    val effectText: (Int) -> String
)

object UpgradeIds {
    const val CLICK_POWER = "click_power"
    const val CLICK_MULT = "click_mult"
    const val CRIT_CHANCE = "crit_chance"
    const val CRIT_POWER = "crit_power"
    const val COMBO_CAP = "combo_cap"
    const val CLICK_PS = "click_ps"
    const val MULT_GLOBAL_1 = "mult_global_1"
    const val MULT_GLOBAL_2 = "mult_global_2"
    const val MULT_GLOBAL_3 = "mult_global_3"
    const val OFFLINE_CAP = "offline_cap"
    const val OFFLINE_EFF = "offline_eff"

    fun generator(id: Int) = "gen_up_$id"
}

object UpgradeDefs {

    private fun big(v: Double) = BigNum.of(v)
    private fun pow2(level: Int) = NumberFormatter.format(BigNum.of(2.0).pow(level.toDouble()))
    private fun mult(base: Double, level: Int) = NumberFormatter.format(BigNum.of(base).pow(level.toDouble()))
    private fun pct(v: Double) = String.format(Locale.US, "%.0f%%", v)

    private val clicks = listOf(
        UpgradeDef(
            UpgradeIds.CLICK_POWER, ShopCategory.CLICKS, "Toque Reforçado",
            "+1 de energia base por clique a cada nível.",
            Rarity.COMUM, big(30.0), 1.31, 200, Requirement.None
        ) { l -> "+$l por clique" },
        UpgradeDef(
            UpgradeIds.CLICK_MULT, ShopCategory.CLICKS, "Pulso Duplo",
            "Dobra a energia por clique a cada nível.",
            Rarity.INCOMUM, big(3_300.0), 8.25, 40, Requirement.TotalEnergy(big(1_000.0))
        ) { l -> "×${pow2(l)} nos cliques" },
        UpgradeDef(
            UpgradeIds.CRIT_CHANCE, ShopCategory.CLICKS, "Sorte Estelar",
            "+1% de chance de clique crítico por nível.",
            Rarity.RARO, big(540.0), 1.47, 40, Requirement.TotalEnergy(big(500.0))
        ) { l -> "+${l}% de chance crítica" },
        UpgradeDef(
            UpgradeIds.CRIT_POWER, ShopCategory.CLICKS, "Fenda Crítica",
            "+0,5× no multiplicador de cliques críticos por nível.",
            Rarity.EPICO, big(2_100.0), 1.53, 100, Requirement.TotalEnergy(big(2_000.0))
        ) { l -> "+${String.format(Locale.US, "%.1f", l * 0.5)}× no crítico" },
        UpgradeDef(
            UpgradeIds.COMBO_CAP, ShopCategory.CLICKS, "Ressonância",
            "+5 no combo máximo por nível (cada passo de combo dá +2% nos cliques).",
            Rarity.RARO, big(1_040.0), 1.73, 50, Requirement.TotalEnergy(big(800.0))
        ) { l -> "combo máx. ${30 + 5 * l}" },
        UpgradeDef(
            UpgradeIds.CLICK_PS, ShopCategory.CLICKS, "Sifão Cósmico",
            "Cada clique também rende +0,05% da sua produção por segundo, por nível.",
            Rarity.LENDARIO, big(300_000.0), 2.25, 50, Requirement.TotalEnergy(big(50_000.0))
        ) { l -> "+${String.format(Locale.US, "%.2f", l * 0.05)}% da produção/s por clique" }
    )

    private val production: List<UpgradeDef> = GeneratorDefs.all.map { g ->
        UpgradeDef(
            UpgradeIds.generator(g.id), ShopCategory.PRODUCTION, "Otimização: ${g.name}",
            "Dobra a produção de ${g.name} a cada nível.",
            g.rarity, g.baseCost * 36.0, 6.2, 30,
            Requirement.GeneratorOwned(g.id, 10)
        ) { l -> "×${pow2(l)} em ${g.name}" }
    }

    /**
     * 100 melhorias de clique extras, liberadas aos poucos (energia total cresce ~3× a cada degrau).
     * Padrão de 10 em 10: 3 multiplicadores, 2 de força bruta, 2 de produção por clique, 1 de chance crítica,
     * 1 de poder crítico e 1 de combo. Os nomes combinam o efeito com um corpo celeste e um grau (I, II, III...).
     */
    private val clickPattern = listOf(
        ClickEffect.MULT, ClickEffect.FLAT, ClickEffect.CRIT_CHANCE, ClickEffect.PRODUCTION_SHARE, ClickEffect.MULT,
        ClickEffect.CRIT_POWER, ClickEffect.COMBO_CAP, ClickEffect.FLAT, ClickEffect.MULT, ClickEffect.PRODUCTION_SHARE
    )
    private val clickBodies = listOf("Asteroides", "Cometas", "Luas", "Estrelas", "Pulsares", "Quasares", "Nebulosas", "Galáxias", "Buracos Negros", "Multiversos")
    private val roman = listOf("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X")

    private val clickExtras: List<UpgradeDef> = run {
        val seen = HashMap<ClickEffect, Int>()
        List(100) { j ->
            val effect = clickPattern[j % clickPattern.size]
            val n = seen.merge(effect, 1, Int::plus)!! - 1       // posição dentro do próprio tipo
            val body = clickBodies[n % clickBodies.size]
            val grade = roman[(n / clickBodies.size).coerceAtMost(roman.lastIndex)]
            val energy = 10.0.pow(3.5 + 0.48 * j)                 // total de energia para liberar
            val rarity = Rarity.entries[minOf(Rarity.entries.size - 1, j / 13)]
            val id = "click_up_$j"
            when (effect) {
                ClickEffect.MULT -> {
                    val f = 1.15 + 0.001 * j
                    UpgradeDef(id, ShopCategory.CLICKS, "Pulso de $body $grade",
                        "Multiplica a energia por clique por ${String.format(Locale.US, "%.2f", f)} a cada nível.",
                        rarity, big(energy * 1.3), 2.6, 12, Requirement.TotalEnergy(big(energy)), effect, f
                    ) { l -> "×${mult(f, l)} nos cliques" }
                }
                ClickEffect.FLAT -> {
                    val v = 2.0 * 1.3.pow(j)
                    UpgradeDef(id, ShopCategory.CLICKS, "Toque de $body $grade",
                        "+${NumberFormatter.format(big(v))} de energia base por clique a cada nível.",
                        rarity, big(energy * 1.2), 1.9, 25, Requirement.TotalEnergy(big(energy)), effect, v
                    ) { l -> "+${NumberFormatter.format(big(v * l))} por clique" }
                }
                ClickEffect.CRIT_CHANCE -> {
                    val v = 0.002
                    UpgradeDef(id, ShopCategory.CLICKS, "Sorte de $body $grade",
                        "+0,2% de chance de clique crítico por nível.",
                        rarity, big(energy * 1.2), 1.8, 15, Requirement.TotalEnergy(big(energy)), effect, v
                    ) { l -> "+${String.format(Locale.US, "%.1f", l * 0.2)}% de chance crítica" }
                }
                ClickEffect.CRIT_POWER -> {
                    val v = 0.1 + 0.002 * j
                    UpgradeDef(id, ShopCategory.CLICKS, "Fenda de $body $grade",
                        "+${String.format(Locale.US, "%.2f", v)}× no multiplicador de crítico por nível.",
                        rarity, big(energy * 1.2), 1.9, 20, Requirement.TotalEnergy(big(energy)), effect, v
                    ) { l -> "+${String.format(Locale.US, "%.2f", l * v)}× no crítico" }
                }
                ClickEffect.COMBO_CAP -> {
                    val v = 2.0
                    UpgradeDef(id, ShopCategory.CLICKS, "Ritmo de $body $grade",
                        "+2 no combo máximo por nível.",
                        rarity, big(energy * 1.2), 2.1, 20, Requirement.TotalEnergy(big(energy)), effect, v
                    ) { l -> "+${2 * l} no combo máximo" }
                }
                ClickEffect.PRODUCTION_SHARE -> {
                    val v = 0.0001
                    UpgradeDef(id, ShopCategory.CLICKS, "Sifão de $body $grade",
                        "Cada clique rende +0,01% da produção por segundo, por nível.",
                        rarity, big(energy * 1.4), 2.3, 15, Requirement.TotalEnergy(big(energy)), effect, v
                    ) { l -> "+${String.format(Locale.US, "%.2f", l * 0.01)}% da produção/s por clique" }
                }
            }
        }
    }

    /** Só as melhorias com efeito genérico: o motor percorre esta lista curta ao recalcular. */
    val clickExtrasList: List<UpgradeDef> get() = clickExtras

    private val multipliers = listOf(
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_1, ShopCategory.MULTIPLIERS, "Matriz de Fótons",
            "Multiplica TODA a produção por 1,25 a cada nível.",
            Rarity.RARO, big(7_000.0), 3.12, 60, Requirement.TotalEnergy(big(3_000.0))
        ) { l -> "×${mult(1.25, l)} na produção" },
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_2, ShopCategory.MULTIPLIERS, "Eco do Vazio",
            "Dobra TODA a produção a cada nível.",
            Rarity.MITICO, big(1.55e11), 26.0, 40, Requirement.TotalEnergy(big(1e10))
        ) { l -> "×${pow2(l)} na produção" },
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_3, ShopCategory.MULTIPLIERS, "Singularidade",
            "Multiplica TODA a produção por 10 a cada nível.",
            Rarity.TRANSCENDENTAL, big(1.70e25), 1_050.0, 20, Requirement.TotalEnergy(big(1e22))
        ) { l -> "×${mult(10.0, l)} na produção" }
    )

    private val permanent = listOf(
        UpgradeDef(
            UpgradeIds.OFFLINE_CAP, ShopCategory.PERMANENT, "Câmara Temporal",
            "+2h no limite de ganhos offline por nível (base: 8h).",
            Rarity.EPICO, big(27_000.0), 2.25, 22, Requirement.TotalEnergy(big(10_000.0))
        ) { l -> "limite offline: ${8 + 2 * l}h" },
        UpgradeDef(
            UpgradeIds.OFFLINE_EFF, ShopCategory.PERMANENT, "Condensador de Vácuo",
            "+5% de eficiência dos ganhos offline por nível (base: 50%).",
            Rarity.RARO, big(140_000.0), 3.6, 10, Requirement.TotalEnergy(big(50_000.0))
        ) { l -> "eficiência offline: ${pct(50.0 + 5.0 * l)}" }
    )

    val all: List<UpgradeDef> = clicks + clickExtras + production + multipliers + permanent

    val byId: Map<String, UpgradeDef> = all.associateBy { it.id }

    fun inCategory(category: ShopCategory): List<UpgradeDef> = all.filter { it.category == category }
}
