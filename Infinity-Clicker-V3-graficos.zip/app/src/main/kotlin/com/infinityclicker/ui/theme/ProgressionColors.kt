package com.infinityclicker.ui.theme

import androidx.compose.ui.graphics.Color
import com.infinityclicker.game.BackgroundDef
import com.infinityclicker.game.CrystalDef
import com.infinityclicker.game.DimensionDef

/** Conversão de cor mantida na camada de UI; o domínio armazena apenas ARGB simples. */
val DimensionDef.tintColor: Color get() = Color(tintArgb)
val CrystalDef.tintColor: Color get() = Color(tintArgb)
val BackgroundDef.tintColor: Color get() = Color(tintArgb)
