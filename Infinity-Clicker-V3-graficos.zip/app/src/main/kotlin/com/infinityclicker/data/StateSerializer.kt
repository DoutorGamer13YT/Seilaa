package com.infinityclicker.data

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.ActiveChallenge
import com.infinityclicker.game.ActiveCosmicEvent
import com.infinityclicker.game.ActiveBoss
import com.infinityclicker.game.BackgroundDefs
import com.infinityclicker.game.ChallengeDefs
import com.infinityclicker.game.CrystalDefs
import com.infinityclicker.game.CosmicEventDefs
import com.infinityclicker.game.DailyMissionDefs
import com.infinityclicker.game.DimensionDefs
import com.infinityclicker.game.Formulas
import com.infinityclicker.game.GameState
import com.infinityclicker.game.PrestigeEntry
import com.infinityclicker.game.SkillTree
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import java.util.zip.CRC32

/**
 * Formato texto do save, com versão e checksum CRC32.
 * Um save truncado, editado à mão ou corrompido não passa no checksum e é descartado
 * (o repositório então tenta o backup), em vez de carregar números quebrados.
 */
object StateSerializer {
    /** V3 acrescenta galeria, árvore expandida, desafios e cenários sem invalidar saves V1/V2. */
    const val VERSION = 3
    private const val MAGIC = "IC1"

    fun serialize(s: GameState): String {
        val body = StringBuilder()
        body.append(MAGIC).append('\n')
        body.append("v=").append(VERSION).append('\n')
        body.append("energy=").append(s.energy.serialize()).append('\n')
        body.append("total=").append(s.totalEnergy.serialize()).append('\n')
        body.append("offlineEarned=").append(s.offlineEarned.serialize()).append('\n')
        body.append("clickEnergy=").append(s.clickEnergy.serialize()).append('\n')
        body.append("productionEnergy=").append(s.productionEnergy.serialize()).append('\n')
        body.append("eventEnergy=").append(s.eventEnergy.serialize()).append('\n')
        body.append("highestProduction=").append(s.highestProduction.serialize()).append('\n')
        body.append("highestTapMultiplier=").append(s.highestTapMultiplier.coerceAtLeast(1.0)).append('\n')
        body.append("bestCps=").append(s.bestClicksPerSecond.coerceAtLeast(0)).append('\n')
        body.append("clicks=").append(s.totalClicks).append('\n')
        body.append("crits=").append(s.critClicks).append('\n')
        body.append("maxCombo=").append(s.maxCombo).append('\n')
        body.append("genBought=").append(s.generatorsBought).append('\n')
        body.append("upBought=").append(s.upgradeLevelsBought).append('\n')
        body.append("playMs=").append(s.playTimeMs).append('\n')
        body.append("last=").append(s.lastSessionMs).append('\n')
        body.append("gens=").append(s.generators.joinToString(",")).append('\n')
        body.append("ups=")
            .append(s.upgradeLevels.entries.filter { it.value > 0 }.sortedBy { it.key }
                .joinToString(",") { "${it.key}:${it.value}" })
            .append('\n')
        body.append("run=").append(s.runEnergy.serialize()).append('\n')
        body.append("prestige=").append(s.prestigePoints.coerceAtLeast(0)).append('|')
            .append(s.prestigeCount.coerceAtLeast(0)).append('\n')
        body.append("prestigeHistory=").append(
            s.prestigeHistory.takeLast(MAX_HISTORY).joinToString(";") {
                "${it.atMs.coerceAtLeast(0L)}~${it.points.coerceAtLeast(0)}~${it.lifetimeEnergy.serialize()}"
            }
        ).append('\n')
        body.append("skills=").append(serializeIntMap(s.skillLevels)).append('\n')
        body.append("dimension=").append(s.currentDimension.coerceIn(0, DimensionDefs.count - 1)).append('\n')
        body.append("dimUnlocked=").append(serializeFlags(s.dimensionUnlocked)).append('\n')
        body.append("shards=").append(s.dimensionShards.joinToString(",") { it.coerceAtLeast(0L).toString() }).append('\n')
        body.append("resonance=").append(s.dimensionResonance.joinToString(",") { it.coerceAtLeast(0).toString() }).append('\n')
        body.append("bossWins=").append(s.bossWins.joinToString(",") { it.coerceAtLeast(0).toString() }).append('\n')
        body.append("activeBoss=").append(s.activeBoss?.let {
            "${it.dimensionId}|${it.health.serialize()}|${it.deadlineMs.coerceAtLeast(0L)}"
        } ?: "").append('\n')
        body.append("crystals=").append(serializeFlags(s.crystalsUnlocked)).append('\n')
        body.append("equippedCrystal=").append(s.equippedCrystal.coerceIn(0, CrystalDefs.count - 1)).append('\n')
        body.append("backgrounds=").append(serializeFlags(s.backgroundsUnlocked)).append('\n')
        body.append("equippedBackground=").append(s.equippedBackground.coerceIn(0, BackgroundDefs.count - 1)).append('\n')
        body.append("abilityLevels=").append(serializeIntMap(s.abilityLevels)).append('\n')
        body.append("abilityCooldown=").append(serializeLongMap(s.abilityCooldownUntilMs)).append('\n')
        body.append("abilityActive=").append(serializeLongMap(s.abilityActiveUntilMs)).append('\n')
        body.append("abilityUses=").append(serializeLongMap(s.abilityUseCounts)).append('\n')
        body.append("abilitiesUsed=").append(s.abilitiesUsed.coerceAtLeast(0L)).append('\n')
        body.append("activeEvent=").append(s.activeEvent?.let { "${it.eventId}|${it.endsAtMs.coerceAtLeast(0L)}" } ?: "").append('\n')
        body.append("eventCooldown=").append(s.eventCooldownUntilMs.coerceAtLeast(0L)).append('\n')
        body.append("eventsTriggered=").append(s.eventsTriggered.coerceAtLeast(0L)).append('\n')
        body.append("activeChallenge=").append(s.activeChallenge?.let { "${it.challengeId}|${it.startedAtMs.coerceAtLeast(0L)}|${it.deadlineMs.coerceAtLeast(0L)}|${it.progress.coerceAtLeast(0L)}" } ?: "").append('\n')
        body.append("challengeCompletions=").append(s.challengeCompletions.coerceAtLeast(0L)).append('\n')
        body.append("challengeFastest=").append(if (s.challengeFastestMs == Long.MAX_VALUE) 0L else s.challengeFastestMs.coerceAtLeast(0L)).append('\n')
        body.append("challengeWins=").append(s.challengeWins.joinToString(",") { it.coerceAtLeast(0L).toString() }).append('\n')
        body.append("challengeAbandoned=").append(s.challengesAbandoned.coerceAtLeast(0L)).append('\n')
        body.append("dailyDay=").append(s.dailyDay).append('\n')
        body.append("dailyProgress=").append(s.dailyProgress.joinToString(",") { it.coerceAtLeast(0L).toString() }).append('\n')
        body.append("dailyClaimed=").append(serializeFlags(s.dailyClaimed)).append('\n')
        body.append("lastLoginDay=").append(s.lastLoginDay).append('\n')
        body.append("loginStreak=").append(s.loginStreak.coerceAtLeast(0)).append('\n')
        body.append("loginClaimedDay=").append(s.loginClaimedDay).append('\n')
        body.append("achievements=").append(s.achievementsClaimed.filter { AchievementIds.contains(it) }.sorted().joinToString(",")).append('\n')
        body.append("achievementUnlocked=").append(s.achievementsUnlockedAt.filterKeys { AchievementIds.contains(it) }.entries.sortedBy { it.key }
            .joinToString(",") { "${it.key}:${it.value.coerceAtLeast(0L)}" }).append('\n')
        body.append("purchaseModes=").append(s.purchaseModeUses.joinToString(",") { it.coerceAtLeast(0L).toString() }).append('\n')
        body.append("highestGeneratorTier=").append(s.highestGeneratorTierEver.coerceIn(-1, GeneratorDefs.count - 1)).append('\n')
        body.append("highestUpgradeLevel=").append(s.highestUpgradeLevelEver.coerceAtLeast(0)).append('\n')
        body.append("dimensionTravels=").append(s.dimensionTravelCount.coerceAtLeast(0L)).append('\n')
        body.append("tutorial=").append(s.tutorialStep.coerceIn(0, 4)).append('\n')
        body.append("revision=").append(s.saveRevision.coerceAtLeast(0L)).append('\n')
        body.append("modified=").append(s.lastModifiedMs.coerceAtLeast(0L)).append('\n')
        val text = body.toString()
        return text + "crc=" + crc(text)
    }

    /** Retorna null se o texto estiver corrompido, incompleto ou for de uma versão futura. */
    fun deserialize(text: String): GameState? = try {
        parse(text)
    } catch (e: Exception) {
        null
    }

    private fun parse(text: String): GameState? {
        val idx = text.lastIndexOf("crc=")
        if (idx < 0) return null
        val body = text.substring(0, idx)
        if (text.substring(idx + 4).trim() != crc(body)) return null

        val lines = body.split('\n')
        if (lines.firstOrNull() != MAGIC) return null
        val map = HashMap<String, String>()
        for (line in lines.drop(1)) {
            val eq = line.indexOf('=')
            if (eq > 0) map[line.substring(0, eq)] = line.substring(eq + 1)
        }

        val version = map["v"]?.toIntOrNull() ?: return null
        if (version !in 1..VERSION) return null

        val s = GameState()
        s.energy = BigNum.parse(map["energy"] ?: return null) ?: return null
        s.totalEnergy = BigNum.max(s.energy, BigNum.parse(map["total"] ?: return null) ?: return null)
        s.offlineEarned = map["offlineEarned"]?.let { BigNum.parse(it) } ?: BigNum.ZERO
        s.totalClicks = (map["clicks"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.critClicks = (map["crits"]?.toLongOrNull() ?: 0L).coerceIn(0L, s.totalClicks)
        s.maxCombo = (map["maxCombo"]?.toIntOrNull() ?: 0).coerceAtLeast(0)
        s.generatorsBought = (map["genBought"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.upgradeLevelsBought = (map["upBought"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.playTimeMs = (map["playMs"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.lastSessionMs = (map["last"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)

        val gens = (map["gens"] ?: "").split(',').filter { it.isNotEmpty() }
        for (i in 0 until minOf(gens.size, GeneratorDefs.count)) {
            s.generators[i] = (gens[i].toLongOrNull() ?: 0L).coerceIn(0L, Formulas.MAX_OWNED)
        }

        val ups = (map["ups"] ?: "").split(',').filter { it.isNotEmpty() }
        for (entry in ups) {
            val colon = entry.lastIndexOf(':')
            if (colon <= 0) continue
            val def = UpgradeDefs.byId[entry.substring(0, colon)] ?: continue
            val level = (entry.substring(colon + 1).toIntOrNull() ?: 0).coerceIn(0, def.maxLevel)
            if (level > 0) s.upgradeLevels[def.id] = level
        }
        // V1 não conhecia sistemas adicionais: runEnergy começa com a energia de vida e todo o
        // resto assume valores seguros. Isso mantém o antigo progresso intacto e jogável.
        if (version >= 2) parseV2(map, s) else s.runEnergy = s.totalEnergy
        if (version >= 3) parseV3(map, s)
        return s
    }

    private fun parseV2(map: Map<String, String>, s: GameState) {
        s.runEnergy = map["run"]?.let { BigNum.parse(it) } ?: s.totalEnergy

        map["prestige"]?.split('|')?.let { pair ->
            s.prestigePoints = (pair.getOrNull(0)?.toIntOrNull() ?: 0).coerceAtLeast(0)
            s.prestigeCount = (pair.getOrNull(1)?.toIntOrNull() ?: 0).coerceAtLeast(0)
        }
        map["prestigeHistory"]?.split(';')?.filter { it.isNotBlank() }?.takeLast(MAX_HISTORY)?.forEach { row ->
            val p = row.split('~')
            val item = PrestigeEntry(
                atMs = (p.getOrNull(0)?.toLongOrNull() ?: 0L).coerceAtLeast(0L),
                points = (p.getOrNull(1)?.toIntOrNull() ?: 0).coerceAtLeast(0),
                lifetimeEnergy = p.getOrNull(2)?.let { BigNum.parse(it) } ?: BigNum.ZERO
            )
            if (item.points > 0) s.prestigeHistory += item
        }
        parseIntMap(map["skills"]) { id, level ->
            SkillTree.byId[id]?.let { def -> s.skillLevels[id] = level.coerceIn(0, def.maxLevel) }
        }
        s.currentDimension = (map["dimension"]?.toIntOrNull() ?: 0).coerceIn(0, DimensionDefs.count - 1)
        parseFlags(map["dimUnlocked"], s.dimensionUnlocked)
        s.dimensionUnlocked[0] = true
        parseLongArray(map["shards"], s.dimensionShards)
        parseIntArray(map["resonance"], s.dimensionResonance)
        parseIntArray(map["bossWins"], s.bossWins)
        parseActiveBoss(map["activeBoss"])?.let { boss ->
            if (boss.dimensionId in 0 until DimensionDefs.count && !boss.health.isZero) s.activeBoss = boss
        }
        parseFlags(map["crystals"], s.crystalsUnlocked)
        s.crystalsUnlocked[0] = true
        s.equippedCrystal = (map["equippedCrystal"]?.toIntOrNull() ?: 0).coerceIn(0, CrystalDefs.count - 1)
        if (!s.crystalsUnlocked[s.equippedCrystal]) s.equippedCrystal = 0
        parseIntMap(map["abilityLevels"]) { id, level ->
            AbilityDefs.byId[id]?.let { def -> s.abilityLevels[id] = level.coerceIn(0, def.maxLevel) }
        }
        parseLongMap(map["abilityCooldown"]) { id, time -> if (AbilityDefs.byId.containsKey(id)) s.abilityCooldownUntilMs[id] = time.coerceAtLeast(0L) }
        parseLongMap(map["abilityActive"]) { id, time -> if (AbilityDefs.byId.containsKey(id)) s.abilityActiveUntilMs[id] = time.coerceAtLeast(0L) }
        s.abilitiesUsed = (map["abilitiesUsed"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.dailyDay = map["dailyDay"]?.toLongOrNull() ?: -1L
        parseLongArray(map["dailyProgress"], s.dailyProgress)
        parseFlags(map["dailyClaimed"], s.dailyClaimed)
        s.lastLoginDay = map["lastLoginDay"]?.toLongOrNull() ?: -1L
        s.loginStreak = (map["loginStreak"]?.toIntOrNull() ?: 0).coerceAtLeast(0)
        s.loginClaimedDay = map["loginClaimedDay"]?.toLongOrNull() ?: -1L
        map["achievements"]?.split(',')?.filter { AchievementIds.contains(it) }?.let { s.achievementsClaimed.addAll(it) }
        s.tutorialStep = (map["tutorial"]?.toIntOrNull() ?: 0).coerceIn(0, 4)
        s.saveRevision = (map["revision"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.lastModifiedMs = (map["modified"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
    }

    private fun parseV3(map: Map<String, String>, s: GameState) {
        s.clickEnergy = map["clickEnergy"]?.let { BigNum.parse(it) } ?: BigNum.ZERO
        s.productionEnergy = map["productionEnergy"]?.let { BigNum.parse(it) } ?: BigNum.ZERO
        s.eventEnergy = map["eventEnergy"]?.let { BigNum.parse(it) } ?: BigNum.ZERO
        s.highestProduction = map["highestProduction"]?.let { BigNum.parse(it) } ?: BigNum.ZERO
        s.highestTapMultiplier = (map["highestTapMultiplier"]?.toDoubleOrNull() ?: 1.0).takeIf { it.isFinite() }?.coerceIn(1.0, 1e12) ?: 1.0
        s.bestClicksPerSecond = (map["bestCps"]?.toIntOrNull() ?: 0).coerceIn(0, 10_000)

        parseFlags(map["backgrounds"], s.backgroundsUnlocked)
        s.backgroundsUnlocked[0] = true
        s.equippedBackground = (map["equippedBackground"]?.toIntOrNull() ?: 0).coerceIn(0, BackgroundDefs.count - 1)
        if (!s.backgroundsUnlocked[s.equippedBackground]) s.equippedBackground = 0

        parseLongMap(map["abilityUses"]) { id, count -> if (AbilityDefs.byId.containsKey(id)) s.abilityUseCounts[id] = count.coerceAtLeast(0L) }
        parseActiveEvent(map["activeEvent"])?.let { event -> if (CosmicEventDefs.byId.containsKey(event.eventId)) s.activeEvent = event }
        s.eventCooldownUntilMs = (map["eventCooldown"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.eventsTriggered = (map["eventsTriggered"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        parseActiveChallenge(map["activeChallenge"])?.let { challenge -> if (ChallengeDefs.byId.containsKey(challenge.challengeId)) s.activeChallenge = challenge }
        s.challengeCompletions = (map["challengeCompletions"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
        s.challengeFastestMs = (map["challengeFastest"]?.toLongOrNull() ?: 0L).let { if (it <= 0L) Long.MAX_VALUE else it }
        parseLongArray(map["challengeWins"], s.challengeWins)
        s.challengesAbandoned = (map["challengeAbandoned"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)

        parseLongMap(map["achievementUnlocked"]) { id, at -> if (AchievementIds.contains(id)) s.achievementsUnlockedAt[id] = at.coerceAtLeast(0L) }
        parseLongArray(map["purchaseModes"], s.purchaseModeUses)
        s.highestGeneratorTierEver = (map["highestGeneratorTier"]?.toIntOrNull() ?: -1).coerceIn(-1, GeneratorDefs.count - 1)
        s.highestUpgradeLevelEver = (map["highestUpgradeLevel"]?.toIntOrNull() ?: 0).coerceAtLeast(0)
        s.dimensionTravelCount = (map["dimensionTravels"]?.toLongOrNull() ?: 0L).coerceAtLeast(0L)
    }

    private fun serializeIntMap(map: Map<String, Int>) = map.entries.filter { it.value > 0 }.sortedBy { it.key }
        .joinToString(",") { "${it.key}:${it.value}" }

    private fun serializeLongMap(map: Map<String, Long>) = map.entries.filter { it.value > 0L }.sortedBy { it.key }
        .joinToString(",") { "${it.key}:${it.value}" }

    private fun serializeFlags(values: BooleanArray) = values.joinToString("") { if (it) "1" else "0" }

    private fun parseIntMap(raw: String?, accept: (String, Int) -> Unit) {
        raw.orEmpty().split(',').filter { it.isNotBlank() }.forEach { entry ->
            val colon = entry.lastIndexOf(':')
            if (colon > 0) entry.substring(colon + 1).toIntOrNull()?.let { accept(entry.substring(0, colon), it) }
        }
    }

    private fun parseLongMap(raw: String?, accept: (String, Long) -> Unit) {
        raw.orEmpty().split(',').filter { it.isNotBlank() }.forEach { entry ->
            val colon = entry.lastIndexOf(':')
            if (colon > 0) entry.substring(colon + 1).toLongOrNull()?.let { accept(entry.substring(0, colon), it) }
        }
    }

    private fun parseFlags(raw: String?, target: BooleanArray) {
        raw.orEmpty().take(target.size).forEachIndexed { index, c -> target[index] = c == '1' }
    }

    private fun parseLongArray(raw: String?, target: LongArray) {
        raw.orEmpty().split(',').take(target.size).forEachIndexed { i, v -> target[i] = (v.toLongOrNull() ?: 0L).coerceAtLeast(0L) }
    }

    private fun parseIntArray(raw: String?, target: IntArray) {
        raw.orEmpty().split(',').take(target.size).forEachIndexed { i, v -> target[i] = (v.toIntOrNull() ?: 0).coerceAtLeast(0) }
    }

    private fun parseActiveBoss(raw: String?): ActiveBoss? {
        val p = raw.orEmpty().split('|')
        val id = p.getOrNull(0)?.toIntOrNull() ?: return null
        val health = p.getOrNull(1)?.let { BigNum.parse(it) } ?: return null
        val deadline = p.getOrNull(2)?.toLongOrNull() ?: return null
        return ActiveBoss(id, health, deadline.coerceAtLeast(0L))
    }

    private fun parseActiveEvent(raw: String?): ActiveCosmicEvent? {
        val p = raw.orEmpty().split('|')
        val id = p.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return null
        val ends = p.getOrNull(1)?.toLongOrNull() ?: return null
        return ActiveCosmicEvent(id, ends.coerceAtLeast(0L))
    }

    private fun parseActiveChallenge(raw: String?): ActiveChallenge? {
        val p = raw.orEmpty().split('|')
        val id = p.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return null
        val started = p.getOrNull(1)?.toLongOrNull() ?: return null
        val deadline = p.getOrNull(2)?.toLongOrNull() ?: return null
        val progress = p.getOrNull(3)?.toLongOrNull() ?: return null
        return ActiveChallenge(id, started.coerceAtLeast(0L), deadline.coerceAtLeast(0L), progress.coerceAtLeast(0L))
    }

    private fun crc(text: String): String {
        val c = CRC32()
        c.update(text.toByteArray(Charsets.UTF_8))
        return java.lang.Long.toHexString(c.value)
    }

    private val AchievementIds = com.infinityclicker.game.AchievementDefs.all.map { it.id }.toSet()
    private const val MAX_HISTORY = 20
}
