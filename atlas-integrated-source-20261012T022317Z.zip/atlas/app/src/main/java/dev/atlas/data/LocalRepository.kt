package dev.atlas.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.room.withTransaction
import dev.atlas.core.AppException
import dev.atlas.core.AppSettings
import dev.atlas.core.ErrorKind
import dev.atlas.core.Place
import dev.atlas.core.SavedList
import dev.atlas.core.SavedPlace
import dev.atlas.core.SearchHistory
import dev.atlas.core.Shortcut
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.retryWhen

/** All mutations are atomic and propagate a user-readable error without erasing stored data. */
class LocalRepository internal constructor(
    private val database: AtlasDatabase,
    private val preferences: DataStore<Preferences>,
) {
    constructor(context: Context) : this(AtlasDatabase.get(context), context.applicationContext.atlasSettings)

    private val dao = database.dao()
    private val errorEvents = MutableSharedFlow<AppException>(extraBufferCapacity = 8)
    val errors: Flow<AppException> = errorEvents.asSharedFlow()

    val favorites: Flow<List<SavedPlace>> = dao.observeFavorites().map { rows ->
        rows.map { SavedPlace(it.place.toPlace(), it.memberships.map { member -> member.listId }.sorted(),
            it.favorite.savedAt) }
    }.recoverReads().distinctUntilChanged()

    val lists: Flow<List<SavedList>> = dao.observeLists().map { rows ->
        rows.map { SavedList(it.id, it.name, it.position) }
    }.recoverReads().distinctUntilChanged()

    val history: Flow<List<SearchHistory>> = dao.observeHistory().map { rows ->
        rows.map { SearchHistory(it.query, it.timestampMillis) }
    }.recoverReads().distinctUntilChanged()

    val shortcuts: Flow<List<Shortcut>> = dao.observeShortcuts().map { rows ->
        rows.map { Shortcut(it.shortcut.kind, it.place.toPlace()) }
    }.recoverReads().distinctUntilChanged()

    val settings: Flow<AppSettings> = preferences.data.map(SettingsStorage::decode)
        .recoverReads().distinctUntilChanged()

    suspend fun savePlace(place: Place) = write {
        validatePlace(place)
        database.withTransaction { saveFavorite(place) }
    }

    suspend fun removePlace(placeId: String) = write {
        database.withTransaction {
            dao.deleteFavorite(placeId)
            dao.deleteUnreferencedPlaces()
        }
    }

    suspend fun createList(name: String) = write {
        val valid = StorageValidation.listName(name)
        val normalized = StorageValidation.normalize(valid)
        database.withTransaction {
            val existing = dao.allLists()
            ensureUniqueName(existing, normalized)
            dao.insertList(SavedListEntity(name = valid, normalizedName = normalized, position = existing.size))
        }
        Unit
    }

    suspend fun renameList(id: Long, name: String) = write {
        val valid = StorageValidation.listName(name)
        val normalized = StorageValidation.normalize(valid)
        database.withTransaction {
            val existing = dao.allLists()
            requireList(existing, id)
            ensureUniqueName(existing.filterNot { it.id == id }, normalized)
            dao.renameList(id, valid, normalized)
        }
    }

    suspend fun deleteList(id: Long) = write {
        database.withTransaction {
            dao.deleteList(id)
            dao.allLists().forEachIndexed { index, list -> dao.updateListPosition(list.id, index) }
        }
    }

    suspend fun moveList(id: Long, delta: Int) = write {
        database.withTransaction {
            val current = dao.allLists().toMutableList()
            requireList(current, id)
            val from = current.indexOfFirst { it.id == id }
            val to = (from.toLong() + delta.toLong()).coerceIn(0, (current.size - 1).toLong()).toInt()
            current.add(to, current.removeAt(from))
            current.forEachIndexed { index, list -> dao.updateListPosition(list.id, index) }
        }
    }

    suspend fun setPlaceLists(place: Place, listIds: Set<Long>) = write {
        validatePlace(place)
        database.withTransaction {
            val knownIds = dao.allLists().mapTo(mutableSetOf()) { it.id }
            if (!knownIds.containsAll(listIds)) {
                throw AppException(ErrorKind.INVALID_INPUT, "Uma das listas não existe mais. Atualize e tente novamente.")
            }
            saveFavorite(place)
            dao.deleteMemberships(place.id)
            dao.insertMemberships(listIds.map { ListMembershipEntity(place.id, it) })
        }
    }

    suspend fun recordSearch(query: String) = write {
        val valid = StorageValidation.query(query)
        database.withTransaction {
            // A monotonic timestamp also keeps rapid insertions deterministically ordered.
            val timestamp = maxOf(System.currentTimeMillis(), (dao.lastSearchTimestamp() ?: 0L) + 1L)
            dao.upsertHistory(SearchHistoryEntity(StorageValidation.normalize(valid), valid, timestamp))
            dao.trimHistory()
        }
    }

    suspend fun removeHistory(query: String) = write {
        dao.deleteHistory(StorageValidation.normalize(query))
    }

    suspend fun clearHistory() = write { dao.clearHistory() }

    suspend fun setShortcut(kind: String, place: Place?) = write {
        StorageValidation.shortcut(kind)
        database.withTransaction {
            if (place == null) {
                dao.deleteShortcut(kind)
            } else {
                validatePlace(place)
                dao.upsertPlace(PlaceEntity.from(place))
                dao.upsertShortcut(ShortcutEntity(kind, place.id))
            }
            dao.deleteUnreferencedPlaces()
        }
    }

    suspend fun updateSettings(settings: AppSettings) = write { SettingsStorage.write(preferences, settings) }

    private suspend fun saveFavorite(place: Place) {
        dao.upsertPlace(PlaceEntity.from(place))
        dao.insertFavorite(FavoriteEntity(place.id, System.currentTimeMillis()))
    }

    private fun validatePlace(place: Place) {
        if (place.id.isBlank() || place.id.length > 512 || place.name.isBlank()) {
            throw AppException(ErrorKind.INVALID_INPUT, "Este lugar não contém informações suficientes para ser salvo.")
        }
    }

    private fun ensureUniqueName(lists: List<SavedListEntity>, normalized: String) {
        if (lists.any { it.normalizedName == normalized }) {
            throw AppException(ErrorKind.INVALID_INPUT, "Já existe uma lista com esse nome.")
        }
    }

    private fun requireList(lists: List<SavedListEntity>, id: Long) {
        if (lists.none { it.id == id }) {
            throw AppException(ErrorKind.INVALID_INPUT, "Esta lista não existe mais.")
        }
    }

    private suspend fun <T> write(action: suspend () -> T): T = try {
        action()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (error: AppException) {
        throw error
    } catch (error: Exception) {
        throw storageError(error)
    }

    private fun <T> Flow<T>.recoverReads(): Flow<T> = retryWhen { cause, attempt ->
        if (cause is CancellationException) throw cause
        errorEvents.emit(storageError(cause))
        // Keep the last emitted values in UI state. Never replace an unreadable database with empty data.
        delay((1_000L * (attempt.coerceAtMost(5L) + 1L)).coerceAtMost(6_000L))
        true
    }

    private fun storageError(cause: Throwable) = AppException(ErrorKind.STORAGE,
        "Não foi possível acessar os dados salvos. Verifique o espaço disponível e tente novamente.", cause)
}
