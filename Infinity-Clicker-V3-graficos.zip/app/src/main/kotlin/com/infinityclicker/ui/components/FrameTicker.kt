package com.infinityclicker.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalView
import kotlin.math.roundToInt
import androidx.compose.runtime.mutableStateOf
import com.infinityclicker.data.GraphicsQuality
import kotlin.math.PI
import kotlinx.coroutines.isActive

/**
 * Relógio de animação com limite de FPS real e sincronizado ao vsync.
 *
 * Em vez de medir tempo (que gera quadros desiguais, p.ex. 90 fps numa tela de 120 Hz = 3 quadros
 * novos e 1 repetido), o limite vira um divisor inteiro da taxa REAL da tela:
 *   tela 120 Hz: 120→÷1, 90→÷1 (a tela não faz 90; fica fluido a 120), 60→÷2, 30→÷4
 *   tela  60 Hz: 120/90/60→÷1, 30→÷2
 * Assim todo quadro novo dura o mesmo número de vsyncs e o movimento fica uniforme.
 * O valor é o tempo decorrido em nanossegundos; as animações são baseadas nele, então a velocidade
 * do movimento é a mesma em qualquer limite (muda só a suavidade).
 */
@Composable
fun rememberFrameTicker(fpsCap: Int): State<Long> {
    val state = remember { mutableLongStateOf(0L) }
    val cap by rememberUpdatedState(fpsCap.coerceIn(10, 240))
    val view = LocalView.current
    LaunchedEffect(view) {
        var origin = -1L
        var frame = 0L
        var displayHz = 60f
        while (isActive) {
            withFrameNanos { now ->
                if (origin < 0L) origin = now
                // refreshRate é barato, mas só muda quando o sistema troca o modo da tela.
                if (frame % 30L == 0L) view.display?.refreshRate?.takeIf { it > 1f }?.let { displayHz = it }
                if (frame % frameDivisor(displayHz, cap) == 0L) state.longValue = now - origin
                frame++
            }
        }
    }
    return state
}

/** Quantos vsyncs cada quadro novo deve durar para chegar mais perto de [cap] fps. */
internal fun frameDivisor(displayHz: Float, cap: Int): Long =
    (displayHz / cap).roundToInt().coerceAtLeast(1).toLong()

/** Ticker compartilhado, fornecido pela GameApp conforme o limite de FPS das configurações. */
val LocalFrameTicker = staticCompositionLocalOf<State<Long>> { mutableStateOf(0L) }

/** Fase 0..2π de um ciclo de [periodMs] a partir do tempo do ticker. */
fun phaseOf(nanos: Long, periodMs: Long): Float {
    val period = periodMs * 1_000_000L
    return ((nanos % period).toDouble() / period.toDouble() * 2.0 * PI).toFloat()
}

/** Nível de detalhe do renderizador: 0 econômico, 1 equilibrado, 2 alta, 3 ultra. */
val GraphicsQuality.detail: Int
    get() = when (this) {
        GraphicsQuality.LOW -> 0
        GraphicsQuality.MEDIUM -> 1
        GraphicsQuality.AUTO, GraphicsQuality.HIGH -> 2
        GraphicsQuality.ULTRA -> 3
    }
