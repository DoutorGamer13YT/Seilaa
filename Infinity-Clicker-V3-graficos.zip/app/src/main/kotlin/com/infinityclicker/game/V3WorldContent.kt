package com.infinityclicker.game

import com.infinityclicker.core.BigNum

/** Oito cenários renderizados pelo Canvas, todos desbloqueáveis e equipáveis offline. */
enum class BackgroundStyle {
    DEEP_SPACE,
    NEBULA,
    SPIRAL_GALAXY,
    BLACK_HOLE,
    QUANTUM,
    TEMPORAL,
    INFINITE_REALM,
    TRANSCENDENTAL_REALITY
}

data class BackgroundDef(
    val id: Int,
    val name: String,
    val subtitle: String,
    val unlockAt: BigNum,
    val tintArgb: Int,
    val style: BackgroundStyle
)

object BackgroundDefs {
    val all = listOf(
        BackgroundDef(0, "Espaço Profundo", "Estrelas silenciosas além da primeira centelha.", BigNum.ZERO, 0xFF52E5FF.toInt(), BackgroundStyle.DEEP_SPACE),
        BackgroundDef(1, "Nebulosa Cósmica", "Nuvens ionizadas respondem ao seu pulso.", BigNum.of(1e5), 0xFFFF5FD2.toInt(), BackgroundStyle.NEBULA),
        BackgroundDef(2, "Galáxia Espiral", "Braços luminosos giram ao redor da energia.", BigNum.of(1e8), 0xFFB07CFF.toInt(), BackgroundStyle.SPIRAL_GALAXY),
        BackgroundDef(3, "Buraco Negro", "Um horizonte de eventos emoldura o cristal.", BigNum.of(1e12), 0xFF798BFF.toInt(), BackgroundStyle.BLACK_HOLE),
        BackgroundDef(4, "Universo Quântico", "Probabilidades cintilam entre cada toque.", BigNum.of(1e17), 0xFF6BFFB0.toInt(), BackgroundStyle.QUANTUM),
        BackgroundDef(5, "Dimensão Temporal", "Anéis de tempo deslizam pelo vazio.", BigNum.of(1e24), 0xFFFFD36B.toInt(), BackgroundStyle.TEMPORAL),
        BackgroundDef(6, "Reino Infinito", "Profundidade sem bordas, cheia de constelações.", BigNum.of(1e34), 0xFFFFFFFF.toInt(), BackgroundStyle.INFINITE_REALM),
        BackgroundDef(7, "Realidade Transcendental", "A matéria se curva ao redor de uma aurora impossível.", BigNum.of(1e48), 0xFFFF9BEB.toInt(), BackgroundStyle.TRANSCENDENTAL_REALITY)
    )
    val count get() = all.size
    fun byId(id: Int) = all.getOrElse(id) { all.first() }
}

enum class CosmicEventEffect { CLICK, PRODUCTION, CRIT, COMBO, BOSS }

data class CosmicEventDef(
    val id: String,
    val name: String,
    val description: String,
    val effect: CosmicEventEffect,
    val baseBonus: Double,
    val durationMs: Long,
    val tintArgb: Int
)

/** Eventos inteiramente locais; nenhum deles é conteúdo remoto disfarçado. */
object CosmicEventDefs {
    val all = listOf(
        CosmicEventDef("meteor_shower", "Chuva de Meteoros", "Cada toque libera impacto extra.", CosmicEventEffect.CLICK, .35, 42_000L, 0xFFFFD36B.toInt()),
        CosmicEventDef("stellar_storm", "Tempestade Estelar", "Geradores entram em sobrecarga controlada.", CosmicEventEffect.PRODUCTION, .50, 48_000L, 0xFF52E5FF.toInt()),
        CosmicEventDef("quantum_luck", "Aurora Quântica", "A chance crítica sobe temporariamente.", CosmicEventEffect.CRIT, .12, 38_000L, 0xFF6BFFB0.toInt()),
        CosmicEventDef("resonance_wave", "Onda de Ressonância", "Combos crescem com força incomum.", CosmicEventEffect.COMBO, .035, 45_000L, 0xFFFF5FD2.toInt()),
        CosmicEventDef("void_hunt", "Caçada do Vazio", "Danos contra chefes se tornam mais densos.", CosmicEventEffect.BOSS, .45, 50_000L, 0xFFB07CFF.toInt())
    )
    val byId = all.associateBy { it.id }
}

enum class ChallengeMetric { CLICKS, COMBO, CRITS, GENERATORS, ABILITIES, BOSS_WINS }

data class ChallengeDef(
    val id: String,
    val name: String,
    val description: String,
    val metric: ChallengeMetric,
    val target: Long,
    val durationMs: Long,
    val energyReward: BigNum,
    val prestigeReward: Int,
    val available: (GameState) -> Boolean
)

/** Desafios opcionais e repetíveis. A disponibilidade impede objetivos inviáveis no estado atual. */
object ChallengeDefs {
    /** Meta já com a dificuldade global aplicada (arredondada, nunca abaixo de 1). */
    private fun goal(base: Long): Long = Math.round(base * Formulas.DIFFICULTY).coerceAtLeast(1L)

    val all = listOf(
        ChallengeDef(
            "manual_pulse", "Pulso Manual", "Faça ${goal(60)} cliques em 30 s sem possuir geradores.", ChallengeMetric.CLICKS, goal(60), 30_000L,
            BigNum.of(350.0), 1, { state -> state.generators.all { it == 0L } }
        ),
        ChallengeDef(
            "combo_rhythm", "Ritmo de Cometa", "Alcance um combo de ${goal(20)} em 20 s.", ChallengeMetric.COMBO, goal(20), 20_000L,
            BigNum.of(750.0), 1, { true }
        ),
        ChallengeDef(
            "critical_focus", "Foco Crítico", "Obtenha ${goal(1)} clique crítico em 45 s.", ChallengeMetric.CRITS, goal(1), 45_000L,
            BigNum.of(1_200.0), 1, { true }
        ),
        ChallengeDef(
            "build_sprint", "Expansão Relâmpago", "Compre ${goal(10)} geradores em 60 s.", ChallengeMetric.GENERATORS, goal(10), 60_000L,
            BigNum.of(2_500.0), 2, { state -> state.totalEnergy >= BigNum.of(500.0) }
        ),
        ChallengeDef(
            "ability_cascade", "Cascata de Habilidades", "Use ${goal(2)} habilidades em 75 s.", ChallengeMetric.ABILITIES, goal(2), 75_000L,
            BigNum.of(5_000.0), 2, { state -> state.generators.any { it > 0L } }
        ),
        ChallengeDef(
            "boss_hunt", "Caçada Cósmica", "Derrote o chefe ativo antes do prazo do desafio.", ChallengeMetric.BOSS_WINS, goal(1), 150_000L,
            BigNum.of(15_000.0), 3, { state -> state.activeBoss != null }
        )
    )
    val count get() = all.size
    val byId = all.associateBy { it.id }
}
