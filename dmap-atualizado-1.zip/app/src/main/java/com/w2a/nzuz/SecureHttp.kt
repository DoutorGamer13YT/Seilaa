package com.w2a.nzuz

import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object SecureHttp {
    fun url(value: String): URL {
        val u = URL(value)
        val h = u.host.lowercase()
        require(u.protocol == "https" && h.isNotBlank() && u.userInfo == null && u.ref == null) { "Use uma URL HTTPS sem credenciais" }
        require(!(h == "apple.com" || h.endsWith(".apple.com") || h == "openstreetmap.org" || h.endsWith(".openstreetmap.org") || h == "maps.protomaps.com")) {
            "Configure sua distribuição regional; não use Apple, tiles comunitários ou builds diários como servidor do app"
        }
        return u
    }

    fun connect(value: String, headers: Map<String, String> = emptyMap(), method: String = "GET", body: String? = null): HttpURLConnection {
        val c = url(value).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 15_000; c.readTimeout = 20_000
        c.requestMethod = method
        c.setRequestProperty("Accept-Encoding", "identity")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        try {
            if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
            return c
        } catch (e: Exception) { c.disconnect(); throw e }
    }

    fun json(value: String, token: String = "", body: JSONObject? = null): JSONObject {
        val c = connect(value, if (token.isBlank()) emptyMap() else mapOf("Authorization" to "Bearer $token"), if (body == null) "GET" else "POST", body?.toString())
        try {
            require(c.responseCode in 200..299) { "Servidor respondeu ${c.responseCode}. Confira a configuração e tente novamente." }
            val data = c.inputStream.use { it.readBytesLimited(4 * 1024 * 1024) }
            return JSONObject(String(data, Charsets.UTF_8))
        } finally { c.disconnect() }
    }
}

fun java.io.InputStream.readBytesLimited(max: Int): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    val buf = ByteArray(16384)
    while (true) { val n = read(buf); if (n < 0) break; require(out.size() + n <= max) { "Resposta excede o limite" }; out.write(buf, 0, n) }
    return out.toByteArray()
}
fun digest(file: File, check: () -> Unit = {}): String {
    val md = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input -> val buf = ByteArray(65536); while (true) { check(); val n = input.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
    return md.digest().joinToString("") { "%02x".format(it) }
}
fun parseCatalog(json: JSONObject): List<MapPackage> {
    require(json.getInt("schema") == 1)
    val a = json.getJSONArray("regions")
    require(a.length() <= 5000)
    val result = List(a.length()) { MapPackage(a.getJSONObject(it)) }
    require(result.map { it.id }.distinct().size == result.size) { "Catálogo contém regiões duplicadas" }
    return result
}
