package com.infinityclicker.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/** Cores da Aurora Eterna: o brilho do fundo troca de uma para a próxima durante o evento. */
private val AuroraPalette = listOf(
    Color(0xFF6BFFB0), Color(0xFFB07CFF), Color(0xFFFF5FD2), Color(0xFF52E5FF), Color(0xFFFFD36B)
)

/**
 * Cor de fundo durante a Aurora Eterna: percorre a paleta a cada 7 s. Fora do evento devolve [base] sem mudar nada.
 * A troca é direta (sem animação de cor) para não recompor o jogo inteiro a cada quadro.
 */
@Composable
fun rememberAuroraTint(active: Boolean, base: Color): Color {
    var step by remember { mutableIntStateOf(0) }
    LaunchedEffect(active) {
        if (active) while (true) { delay(7_000L); step++ }
    }
    return if (active) AuroraPalette[step % AuroraPalette.size] else base
}

/**
 * Efeito visual da Aurora Eterna: cortinas de luz onduladas, véu colorido e chuva de brilhos por toda a tela.
 * Fica atrás da interface e não captura toques. Fora do evento a intensidade é 0 e o desenho sai na primeira linha,
 * sem ler o relógio de animação (custo praticamente nulo).
 */
@Composable
fun AuroraOverlay(active: Boolean, motionEnabled: Boolean = true, modifier: Modifier = Modifier) {
    val strength = animateFloatAsState(if (active) 1f else 0f, tween(if (active) 2_600 else 3_500), label = "auroraStrength")
    val ticker = LocalFrameTicker.current
    // Um brush vertical por cortina (cor forte no alto, some embaixo) e um véu geral; criados uma vez.
    val curtainBrushes = remember {
        AuroraPalette.map { c -> Brush.verticalGradient(listOf(c.copy(alpha = 0.95f), c.copy(alpha = 0.35f), Color.Transparent)) }
    }
    val veil = remember {
        Brush.verticalGradient(listOf(Color(0x3352E5FF), Color(0x22B07CFF), Color(0x33FF5FD2)))
    }
    val paths = remember { List(AuroraPalette.size) { Path() } }
    Canvas(modifier.fillMaxSize()) {
        val s = strength.value
        if (s <= 0.003f) return@Canvas
        val nanos = if (motionEnabled) ticker.value else 0L
        val t = (nanos / 1_000_000_000.0).toFloat()
        val w = size.width
        val h = size.height
        drawRect(veil, alpha = 0.55f * s)
        val steps = 22
        for (i in paths.indices) {
            val path = paths[i]
            path.rewind()
            val baseX = w * (0.10f + 0.20f * i)
            val amp = w * (0.05f + 0.012f * i)
            val freq = (2.2f + 0.5f * i) * PI.toFloat() / h
            val speed = 0.35f + 0.11f * i
            for (k in 0..steps) {
                val y = h * k / steps
                val x = baseX + sin(y * freq + t * speed + i * 1.7f) * amp + sin(y * freq * 2.3f - t * speed * 0.7f) * amp * 0.35f
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val breathe = 0.65f + 0.35f * sin(t * (0.6f + 0.13f * i) + i)
            drawPath(path, curtainBrushes[i], alpha = 0.16f * breathe * s, style = Stroke(width = w * (0.16f + 0.03f * (i % 3)), cap = StrokeCap.Round))
            drawPath(path, curtainBrushes[i], alpha = 0.30f * breathe * s, style = Stroke(width = w * 0.035f, cap = StrokeCap.Round))
        }
        // Chuva de brilhos: posições derivadas do índice e do tempo (sem estado nem alocação).
        val sparkles = 46
        for (i in 0 until sparkles) {
            val fx = ((i * 0.6180339f) % 1f)
            val fall = (t / (7f + (i % 5)) + i * 0.137f) % 1f
            val x = fx * w + sin(t * 0.8f + i) * 6f
            val y = fall * h
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (1.6f + (i % 4) * 0.5f) + i * 1.3f))
            val c = AuroraPalette[i % AuroraPalette.size]
            val r = 1.3f + (i % 3) * 0.9f
            drawCircle(c.copy(alpha = 0.14f * tw * s), r * 3.4f, Offset(x, y))
            drawCircle(Color.White.copy(alpha = 0.85f * tw * s), r, Offset(x, y))
            if (i % 4 == 0) {
                val len = r * 4.5f * tw
                drawLine(c.copy(alpha = 0.7f * tw * s), Offset(x - len, y), Offset(x + len, y), 1f)
                drawLine(c.copy(alpha = 0.7f * tw * s), Offset(x, y - len), Offset(x, y + len), 1f)
            }
        }
    }
}
