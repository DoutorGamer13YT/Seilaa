package com.infinityclicker.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import kotlin.math.roundToInt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.abs
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.infinityclicker.audio.Sfx
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.ui.components.EnergyGovernor
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.SpaceBackground
import com.infinityclicker.ui.components.applyFrameRate
import com.infinityclicker.ui.components.planFrameRate
import com.infinityclicker.ui.components.rememberFrameTicker
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.components.SegmentedControl
import com.infinityclicker.ui.screens.DeveloperScreen
import com.infinityclicker.ui.screens.DimensionsScreen
import com.infinityclicker.ui.screens.HomeScreen
import com.infinityclicker.ui.screens.MissionsScreen
import com.infinityclicker.ui.screens.ProfileScreen
import com.infinityclicker.ui.screens.ShopScreen
import com.infinityclicker.ui.theme.InfinityTheme
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val tabs = listOf("Início", "Loja", "Dimensões", "Missões")
private val tabIcons = listOf("✦", "◈", "◎", "✧")
private const val HUB_TAB = 4
private val hubSections = listOf("Resumo", "Ajustes", "Ambientes", "Dev")

@Composable
fun GameApp(vm: GameViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var hubSection by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val background = ui.backgrounds.firstOrNull { it.equipped }?.def
    val currentTint = background?.tintColor ?: ui.dimensions.firstOrNull { it.current }?.def?.tintColor ?: Neon.Cyan
    val effectiveQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.exportSaveText()
            if (text != null) {
                scope.launch {
                    val success = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
                                ?: error("Fluxo de saída indisponível")
                        }.isSuccess
                    }
                    vm.reportExportResult(success)
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (text == null) vm.reportImportReadFailure() else vm.importSaveText(text)
            }
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }
    LaunchedEffect(tab) { vm.setActiveTab(tab) }
    // Teto efetivo: o que o usuário escolheu, limitado pelo governador térmico. Se o aparelho
    // esquentar, o governador rebaixa para 60 e depois 30 fps antes do throttling do sistema.
    var thermalCap by remember { mutableIntStateOf(240) }
    val effectiveFps = EnergyGovernor.suggestedCap().let { gov -> minOf(if (ui.settings.batterySaver) 30 else ui.settings.frameRateCap, gov) }
    val frameTicker = rememberFrameTicker(effectiveFps)
    var fpsInfo by remember { mutableStateOf("") }
    // Governador térmico: registra uma vez e atualiza o teto quando o sistema reporta calor.
    LaunchedEffect(Unit) {
        EnergyGovernor.start(context, this) { cap ->
            if (cap != thermalCap) thermalCap = cap
        }
    }
    LaunchedEffect(effectiveFps) {
        // Pede à tela o modo que melhor entrega o limite escolhido; o FrameTicker ajusta as
        // animações como divisor inteiro da taxa real, então os quadros ficam uniformes.
        val activity = context as? Activity ?: return@LaunchedEffect
        val display = activity.window.decorView.display ?: @Suppress("DEPRECATION") activity.windowManager.defaultDisplay
        val plan = planFrameRate(display, effectiveFps) ?: return@LaunchedEffect
        activity.applyFrameRate(plan)
        fpsInfo = "Tela em ${"%.0f".format(plan.displayHz)} Hz · animações a ${"%.0f".format(plan.animationFps)} fps" +
            if (kotlin.math.abs(plan.animationFps - effectiveFps) > 2f) " (esta tela não tem modo de $effectiveFps Hz)" else ""
    }
    LaunchedEffect(ui.notice) {
        ui.notice?.let {
            snackbar.showSnackbar(it)
            vm.dismissNotice()
        }
    }

    InfinityTheme {
      CompositionLocalProvider(LocalFrameTicker provides frameTicker) {
        Box(Modifier.fillMaxSize()) {
            SpaceBackground(
                tint = currentTint,
                style = background?.style,
                quality = effectiveQuality,
                motionEnabled = !ui.settings.batterySaver
            )
            if (ui.loaded) {
                Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(bottom = BarHeight + BarVPad + 6.dp)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            // Só opacidade, escala sutil e deslocamento (baratos para a GPU). Curva de saída longa:
                            // chega rápido e assenta devagar, como as transições do iOS. Sem animar o tamanho.
                            val dir = if (targetState > initialState) 1 else -1
                            val ease = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
                            ((fadeIn(tween(280, delayMillis = 50, easing = ease)) +
                                scaleIn(tween(320, easing = ease), initialScale = 0.965f) +
                                slideInHorizontally(tween(320, easing = ease)) { dir * it / 10 }) togetherWith
                                (fadeOut(tween(130)) + slideOutHorizontally(tween(280, easing = ease)) { -dir * it / 16 })).using(null)
                        }, label = "tabTransition"
                    ) { screen ->
                        when (screen) {
                            0 -> HomeScreen(ui, vm::tap, vm::useAbility)
                            1 -> ShopScreen(ui, vm::setBuyMode, vm::buyGenerator, vm::buyUpgrade)
                            2 -> DimensionsScreen(ui, vm::unlockDimension, vm::travelDimension, vm::buyResonance, vm::startBoss, vm::equipCrystal)
                            3 -> MissionsScreen(ui, vm::claimDaily, vm::claimLogin, vm::claimAchievement, vm::startChallenge, vm::abandonChallenge)
                            else -> Column(Modifier.fillMaxSize()) {
                                HubHeader(hubSection, { SoundFx.play(Sfx.NAV); hubSection = it }, { SoundFx.play(Sfx.NAV); tab = 0 })
                                Box(Modifier.weight(1f).fillMaxWidth()) {
                                if (hubSection == 3) DeveloperScreen(ui) else ProfileScreen(
                                ui = ui,
                                onScientific = vm::setScientific,
                                onQuality = vm::setGraphicsQuality,
                                onFrameRate = vm::setFrameRate,
                                onSound = vm::setSound,
                                onMusic = vm::setMusic,
                                fpsInfo = fpsInfo,
                                section = hubSection,
                                onBatterySaver = vm::setBatterySaver,
                                onEffects = vm::setEffectsIntensity,
                                onPanelOpacity = vm::setPanelOpacity,
                                onHaptics = vm::setHaptics,
                                onUpgradeAbility = vm::upgradeAbility,
                                onBuySkill = vm::buySkill,
                                onEquipBackground = vm::equipBackground,
                                onExportSave = { exportLauncher.launch("InfinityClicker-V3.ic-save") },
                                onImportSave = { importLauncher.launch(arrayOf("text/plain", "application/octet-stream")) },
                                onPrestige = vm::prestige,
                                onReset = vm::hardReset
                            )
                                }
                            }
                        }
                    }
                }
            }
            SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp))
            BottomBar(tab, ui.settings.hapticsEnabled, { SoundFx.play(Sfx.NAV); tab = it }, Modifier.align(Alignment.BottomCenter))
            AnimatedVisibility(
                visible = ui.loaded && tab != HUB_TAB,
                modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 16.dp),
                enter = fadeIn(tween(240)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = 380f), initialScale = 0.6f),
                exit = fadeOut(tween(120)) + scaleOut(tween(140), targetScale = 0.7f)
            ) { ProfileBubble(Modifier) { SoundFx.play(Sfx.NAV); tab = HUB_TAB } }
        }

        // Música dinâmica: combo, habilidades ativas e chefe mudam as camadas sintetizadas em tempo real.
        val anyAbilityActive = ui.abilities.any { it.activeRemainingMs > 0L }
        val bossOn = ui.activeBoss != null
        val comboLevel = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f
        LaunchedEffect(comboLevel, bossOn, anyAbilityActive) {
            SoundFx.setMood((comboLevel * 0.8f + if (anyAbilityActive) 0.25f else 0f).coerceIn(0f, 1f), bossOn)
        }

        ui.offlineReport?.let { r ->
            com.infinityclicker.ui.components.OfflineReportDialog(
                report = r,
                scientific = ui.settings.scientificNotation,
                onCollect = vm::dismissOfflineReport
            )
        }
      }
    }
}

private val BarInk = Color(0xFFF2F4FA)
private val BarHeight = 66.dp
private val BarSidePad = 22.dp
private val BarVPad = 12.dp
private val BarInner = 5.dp

/** Puxão elástico nas pontas: passando do limite, o dedo move a lente só uma fração. */
private fun rubber(p: Float, n: Int): Float {
    val max = (n - 1).toFloat()
    val r = when {
        p < 0f -> p * 0.35f
        p > max -> max + (p - max) * 0.35f
        else -> p
    }
    return r.coerceIn(-0.4f, max + 0.4f)
}

/**
 * Barra de navegação "Liquid Glass" (iOS 26): cápsula de vidro claro com uma lente que dá para tocar OU ARRASTAR.
 * - Ao tocar, a lente cresce e fica mais transparente; ao soltar, assenta com uma mola na aba mais próxima.
 * - Durante o arraste ela segue o dedo com uma mola rápida (sente o peso), estica na direção do movimento e
 *   amassa na altura (squash & stretch) conforme a velocidade real da animação.
 * - Ícones e rótulos reagem à posição da lente (não ao índice), então crescem e acendem enquanto ela passa.
 * Tudo que muda por quadro é lido só na fase de desenho/camada: arrastar não recompõe nada.
 */
@Composable
private fun BottomBar(current: Int, hapticsEnabled: Boolean, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val n = tabs.size
    val hubOpen = current > tabs.lastIndex
    val lens = remember { Animatable(current.coerceIn(0, tabs.lastIndex).toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val press = animateFloatAsState(
        if (pressed) 1f else 0f,
        if (pressed) spring(dampingRatio = 0.75f, stiffness = 650f) else spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "lensPress"
    )
    val vis = animateFloatAsState(if (hubOpen) 0f else 1f, tween(240), label = "tabVis")
    val dragging = remember { BooleanArray(1) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val onSelectNow by rememberUpdatedState(onSelect)
    val currentNow by rememberUpdatedState(current)
    val hapticsNow by rememberUpdatedState(hapticsEnabled)
    val settle = remember { spring<Float>(dampingRatio = 0.66f, stiffness = 340f) }

    LaunchedEffect(current) {
        if (current > tabs.lastIndex || dragging[0]) return@LaunchedEffect
        // Voltando do painel de perfil a barra está invisível: posiciona sem viajar pela tela.
        if (vis.value < 0.05f) lens.snapTo(current.toFloat()) else lens.animateTo(current.toFloat(), settle)
    }

    Box(
        modifier.navigationBarsPadding().padding(horizontal = BarSidePad, vertical = BarVPad).fillMaxWidth().height(BarHeight)
            .drawWithCache {
                val r = CornerRadius(size.height / 2f)
                val body = Brush.verticalGradient(listOf(Color(0xFF23252D).copy(alpha = 0.62f), Color(0xFF07080C).copy(alpha = 0.78f)))
                val border = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.26f)))
                val s1 = 1.4.dp.toPx(); val dy = 4.dp.toPx()
                val body0 = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, r)) }
                val topSheen = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.14f), Color.Transparent), 0f, size.height * 0.5f)
                val bottomShade = Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.24f)), size.height * 0.5f, size.height)
                onDrawBehind {
                    // Sombra suave em camadas (sem elevação do sistema, que é cara com transparência).
                    for (i in 0 until 4) {
                        val grow = (3 + i * 4).dp.toPx()
                        drawRoundRect(Color.Black.copy(alpha = 0.10f - i * 0.02f), Offset(-grow / 2f, dy - grow / 2f),
                            Size(size.width + grow, size.height + grow), CornerRadius(size.height / 2f + grow / 2f))
                    }
                    drawRoundRect(body, cornerRadius = r)
                    // Borda desenhada para dentro: o traço não escapa da cápsula (era isso que deixava pixels claros nas pontas).
                    val half = s1 / 2f
                    drawRoundRect(border, Offset(half, half), Size(size.width - s1, size.height - s1), CornerRadius(size.height / 2f - half), style = Stroke(s1))
                    // Brilho de vidro curvo no topo e sombra suave embaixo, sem nenhuma linha atravessando a barra.
                    clipPath(body0) {
                        drawRoundRect(topSheen, Offset(3.dp.toPx(), 1.5.dp.toPx()), Size(size.width - 6.dp.toPx(), size.height * 0.5f), CornerRadius(size.height / 4f))
                        drawRoundRect(bottomShade, cornerRadius = r)
                    }
                }
            }
            .pointerInput(n) {
                val pad = BarInner.toPx()
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val itemW = (size.width - pad * 2f) / n
                    fun posAt(x: Float) = (x - pad) / itemW - 0.5f
                    pressed = true
                    var moved = false
                    var x = down.position.x
                    var lastIdx = posAt(x).roundToInt().coerceIn(0, n - 1)
                    // Pré-visualiza: a lente já corre para a aba tocada enquanto o dedo ainda está embaixo.
                    scope.launch { lens.animateTo(lastIdx.toFloat(), settle) }
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        x = change.position.x
                        if (!change.pressed) break
                        if (!moved && abs(x - down.position.x) > slop) { moved = true; dragging[0] = true }
                        if (moved) {
                            change.consume()
                            val p = rubber(posAt(x), n)
                            val idx = p.roundToInt().coerceIn(0, n - 1)
                            if (idx != lastIdx) {
                                lastIdx = idx
                                if (hapticsNow) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            // Mola rápida e bem amortecida: segue o dedo com peso e mantém a velocidade para o esticar.
                            scope.launch { lens.animateTo(p, spring(dampingRatio = 0.8f, stiffness = 800f)) }
                        }
                    }
                    val dest = posAt(x).roundToInt().coerceIn(0, n - 1)
                    pressed = false
                    dragging[0] = false
                    scope.launch { lens.animateTo(dest.toFloat(), settle) }
                    if (dest != currentNow) onSelectNow(dest)
                }
            }
    ) {
        // Camada da lente (atrás dos ícones). Tudo é recortado na cápsula da barra e a lente nunca passa das bordas.
        Spacer(
            Modifier.matchParentSize().padding(BarInner).drawWithCache {
                val pad = BarInner.toPx()
                val outerH = size.height + pad * 2f
                val pill = Path().apply {
                    addRoundRect(RoundRect(-pad, -pad, size.width + pad, size.height + pad, CornerRadius(outerH / 2f)))
                }
                val glow = 1.dp.toPx()
                onDrawBehind {
                    val a = vis.value
                    if (a < 0.01f) return@onDrawBehind
                    val pr = press.value
                    val itemW = size.width / n
                    val stretch = (abs(lens.velocity) * 0.085f).coerceAtMost(0.5f)
                    var w = itemW * (0.94f + stretch + 0.10f * pr)
                    w = w.coerceAtMost(size.width + pad * 2f - glow * 2f)
                    val h = (size.height * (1f + 0.10f * pr - stretch * 0.20f)).coerceAtMost(outerH - glow * 2f)
                    val cx = (lens.value + 0.5f) * itemW
                    val left = (cx - w / 2f).coerceIn(-pad + glow, size.width + pad - glow - w)
                    val top = (size.height - h) / 2f
                    val corner = CornerRadius(h / 2f)
                    clipPath(pill) {
                        // Reflexo de luz no vidro da barra, seguindo a lente.
                        drawRoundRect(
                            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.16f * a), Color.Transparent), Offset(cx, size.height * 0.30f), size.height * 1.6f),
                            Offset(-pad, -pad), Size(size.width + pad * 2f, outerH), CornerRadius(outerH / 2f)
                        )
                        if (pr > 0.01f) drawRoundRect(Color.Black.copy(alpha = 0.30f * pr * a), Offset(left, top + 3.dp.toPx()), Size(w, h), corner)
                        drawRoundRect(
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = (0.20f - 0.05f * pr) * a), Color.White.copy(alpha = (0.09f - 0.02f * pr) * a)),
                                startY = top, endY = top + h
                            ), Offset(left, top), Size(w, h), corner
                        )
                        // Brilho interno de baixo (luz atravessando a lente quando pressionada).
                        if (pr > 0.01f) drawRoundRect(
                            Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.20f * pr * a)), startY = top + h * 0.45f, endY = top + h),
                            Offset(left, top), Size(w, h), corner
                        )
                        // Aro da lente desenhado para dentro (metade do traço) para não vazar pixels claros.
                        val rim = 1.dp.toPx()
                        drawRoundRect(
                            Color.White.copy(alpha = (0.30f + 0.25f * pr) * a), Offset(left + rim / 2f, top + rim / 2f),
                            Size(w - rim, h - rim), CornerRadius((h - rim) / 2f), style = Stroke(rim)
                        )
                        drawRoundRect(
                            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.26f * a), Color.Transparent), startY = top, endY = top + h * 0.5f),
                            Offset(left + 2.dp.toPx(), top + 1.dp.toPx()), Size(w - 4.dp.toPx(), h * 0.5f), CornerRadius(h / 4f)
                        )
                    }
                }
            }
        )
        Row(Modifier.fillMaxSize().padding(BarInner)) {
            tabs.forEachIndexed { index, label ->
                val prox: () -> Float = { (1f - abs(lens.value - index)).coerceAtLeast(0f) * vis.value }
                Column(
                    Modifier.weight(1f).fillMaxHeight()
                        .graphicsLayer { val s = 1f + 0.07f * prox() * (1f + press.value * 0.6f); scaleX = s; scaleY = s }
                        .semantics(mergeDescendants = true) {
                            role = Role.Tab
                            selected = index == current
                            onClick(label = label) { onSelectNow(index); true }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Canvas(Modifier.size(24.dp)) { val p = prox(); drawNavIcon(index, BarInk.copy(alpha = 0.60f + 0.36f * p), p) }
                    Text(
                        label, fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = BarInk, maxLines = 1,
                        modifier = Modifier.padding(top = 3.dp).graphicsLayer { alpha = 0.60f + 0.36f * prox() }
                    )
                }
            }
        }
    }
}

/** Ícones de contorno desenhados em uma grade 24×24; `fill` (0..1) preenche a forma principal da aba ativa. */
private fun DrawScope.drawNavIcon(index: Int, color: Color, fill: Float) {
    val k = size.minDimension / 24f
    val stroke = Stroke(1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    withTransform({ scale(k, k, Offset.Zero) }) {
        when (index) {
            0 -> { // casa
                val house = Path().apply {
                    moveTo(12f, 3.5f); lineTo(21f, 11.4f); lineTo(19f, 11.4f); lineTo(19f, 20f); lineTo(14.5f, 20f)
                    lineTo(14.5f, 14.5f); lineTo(9.5f, 14.5f); lineTo(9.5f, 20f); lineTo(5f, 20f); lineTo(5f, 11.4f); lineTo(3f, 11.4f); close()
                }
                drawPath(house, color.copy(alpha = color.alpha * fill))
                drawPath(house, color, style = stroke)
            }
            1 -> { // sacola
                val bag = Path().apply { moveTo(5.5f, 8f); lineTo(18.5f, 8f); lineTo(19.5f, 20.5f); lineTo(4.5f, 20.5f); close() }
                drawPath(bag, color.copy(alpha = color.alpha * fill))
                drawPath(bag, color, style = stroke)
                drawPath(Path().apply { moveTo(9f, 8f); cubicTo(9f, 3.8f, 15f, 3.8f, 15f, 8f) }, color, style = stroke)
            }
            2 -> { // planeta com anel
                drawCircle(color.copy(alpha = color.alpha * fill), 5.8f, Offset(12f, 12f))
                drawCircle(color, 5.8f, Offset(12f, 12f), style = stroke)
                rotate(-24f, Offset(12f, 12f)) { drawOval(color, Offset(1.6f, 9.5f), Size(20.8f, 5f), style = stroke) }
            }
            else -> { // alvo
                drawCircle(color, 9f, Offset(12f, 12f), style = stroke)
                drawCircle(color.copy(alpha = color.alpha * fill), 4.8f, Offset(12f, 12f))
                drawCircle(color, 4.8f, Offset(12f, 12f), style = stroke)
                drawCircle(color, 1.8f, Offset(12f, 12f))
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.White

/**
 * Botão do painel (perfil, ajustes, ambientes e desenvolvedor): engrenagem sobre uma lente de vidro líquido.
 * O vidro usa o mesmo `glass` dos painéis (corpo translúcido, brilho especular, vazamento de luz e borda com
 * refração) e o `bouncyClick` afunda e volta com mola, como a lente da barra de navegação.
 */
@Composable
private fun ProfileBubble(modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.bouncyClick(onClick = onClick).size(44.dp)
            .glass(CircleShape, tint = Color.White, alpha = 0.20f, borderAlpha = 0.60f)
            .drawBehind {
                // Reflexo de luz no alto da lente, por cima do vidro, dando a curvatura de gota.
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.30f), Color.Transparent),
                        Offset(size.width * 0.34f, size.height * 0.22f), size.minDimension * 0.55f
                    )
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = androidx.compose.ui.res.painterResource(com.infinityclicker.R.drawable.ic_settings_gear),
            contentDescription = "Perfil e ajustes",
            modifier = Modifier.size(24.dp),
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Neon.TextPrimary.copy(alpha = 0.95f))
        )
    }
}

private val hubTitles = listOf("Perfil", "Ajustes", "Ambientes", "Desenvolvedor")

/** Cabeçalho do painel de perfil: botão de voltar, título da seção atual e controle segmentado deslizante. */
@Composable
private fun HubHeader(selected: Int, onSelect: (Int) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.bouncyClick(onClick = onBack).size(40.dp).glass(CircleShape, tint = Neon.Cyan, alpha = 0.18f, borderAlpha = 0.5f),
                contentAlignment = Alignment.Center
            ) { Text("‹", color = Neon.TextPrimary, fontSize = 26.sp) }
            AnimatedContent(
                targetState = selected,
                transitionSpec = { fadeIn(tween(200, delayMillis = 40)) togetherWith fadeOut(tween(100)) },
                label = "hubTitle"
            ) { i ->
                Text(hubTitles.getOrElse(i) { "Perfil" }, color = Neon.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        SegmentedControl(hubSections, selected, onSelect, tint = Neon.Cyan, height = 38.dp, fontSize = 12.sp)
    }
}
