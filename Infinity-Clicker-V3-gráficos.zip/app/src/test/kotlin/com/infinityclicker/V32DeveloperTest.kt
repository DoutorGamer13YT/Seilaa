package com.infinityclicker

import com.infinityclicker.core.AppInfo
import com.infinityclicker.core.BigNum
import com.infinityclicker.data.CloudSaveInfo
import com.infinityclicker.data.CloudSyncPolicy
import com.infinityclicker.data.CloudSyncStatus
import com.infinityclicker.data.SyncDecision
import com.infinityclicker.data.UnavailableCloudProvider
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.ChallengeDefs
import com.infinityclicker.game.DimensionDefs
import com.infinityclicker.game.Formulas
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.game.PlayerRanks
import com.infinityclicker.game.ProgressionFormulas
import com.infinityclicker.game.SkillTree
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/** Garantias de balanceamento, correções do motor, patente e base da nuvem. */
class V32DeveloperTest {

    private fun ratio(a: BigNum, b: BigNum) = (a / b).toDouble()

    // ---------------------------------------------------------------- duração da progressão

    @Test
    fun progressionTakesOneHundredAndTwentyPercentLonger() {
        assertEquals(2.20, Formulas.DIFFICULTY / Formulas.BASE_DIFFICULTY, 1e-12)
        assertEquals(2.53, Formulas.DIFFICULTY, 1e-12)
    }

    @Test
    fun generatorAndUpgradePricesUseTheNewProgressionMultiplier() {
        val e = GameEngine(GameState.new(), Random(1))
        val gen = GeneratorDefs.byId(0)
        assertEquals(Formulas.DIFFICULTY, ratio(e.planGenerator(gen, BuyMode.X1).cost, gen.baseCost), 1e-9)
        val up = UpgradeDefs.byId.getValue("click_power")
        assertEquals(Formulas.DIFFICULTY, ratio(e.planUpgrade(up, BuyMode.X1).cost, up.baseCost), 1e-9)
    }

    @Test
    fun bossHealthUsesTheNewProgressionMultiplier() {
        val e = GameEngine(GameState.new(), Random(1))
        val boss = e.startBoss(1_000L).boss!!
        assertEquals(Formulas.DIFFICULTY, ratio(boss.health, DimensionDefs.byId(0).bossHealth), 1e-9)
        assertEquals(boss.health, e.bossMaxHealth(0))
    }

    @Test
    fun dimensionsAndFirstPrestigeUseTheNewProgressionMultiplier() {
        val def = DimensionDefs.byId(1)
        assertEquals(Formulas.DIFFICULTY, ratio(ProgressionFormulas.dimensionRequirement(def, 0), def.unlockEnergy), 1e-9)
        assertEquals(0, ProgressionFormulas.prestigeGain(BigNum.of(4.0e6), 0))
        assertTrue(ProgressionFormulas.prestigeGain(BigNum.of(4.1e6), 0) >= 1)
        // Mesma energia rende menos pontos que antes (curva deslocada, nunca mais generosa).
        val old = ((BigNum.of(1e12).log10() - 6.15) * 1.12).toInt()
        assertTrue(ProgressionFormulas.prestigeGain(BigNum.of(1e12), 0) <= old)
    }

    @Test
    fun challengeTargetsAreScaledAndDescribedHonestly() {
        val manual = ChallengeDefs.byId.getValue("manual_pulse")
        assertEquals(152L, manual.target)
        assertTrue(manual.description.contains("152"))
        assertEquals(51L, ChallengeDefs.byId.getValue("combo_rhythm").target)
        assertEquals(25L, ChallengeDefs.byId.getValue("build_sprint").target)
        // Recompensas não são multiplicadas.
        assertEquals(BigNum.of(350.0), manual.energyReward)
    }

    // ---------------------------------------------------------------- correção: gastar PP não pode enfraquecer

    @Test
    fun spendingPrestigePointsKeepsThePermanentMultiplier() {
        val s = GameState.new().apply { prestigePoints = 40 }
        val e = GameEngine(s, Random(1))
        val before = e.globalMultiplier
        assertTrue(e.buySkill(SkillTree.AUTO_CORE, 1_000L)) // dá +30% de produção, custo 1 PP
        // Só o bônus de +30% da própria habilidade pode mudar o multiplicador — nunca para menos por ter gasto o PP.
        assertEquals(1.30, ratio(e.globalMultiplier, before), 1e-9)
        val afterSkill = e.globalMultiplier
        assertTrue(e.upgradeAbility(AbilityDefs.SUPER_CLICK, 1_000L))
        assertEquals(1.0, ratio(e.globalMultiplier, afterSkill), 1e-9)
    }

    @Test
    fun prestigePreviewCountsSpentPoints() {
        val s = GameState.new().apply { prestigePoints = 10; runEnergy = BigNum.of(1e9) }
        val e = GameEngine(s, Random(1))
        assertTrue(e.buySkill(SkillTree.POWER_CORE, 1_000L))
        val gain = e.prestigePreview().points
        // 9 disponíveis + 1 gasto + ganho, a 5% cada.
        assertEquals(1.0 + (10 + gain) * 0.05, e.prestigePreview().permanentMultiplierAfter, 1e-9)
    }

    // ---------------------------------------------------------------- otimizações não podem mudar comportamento

    @Test
    fun skillEffectsStayInSyncWithTheCacheAfterEveryPurchase() {
        val s = GameState.new().apply { prestigePoints = 200; totalEnergy = BigNum.of(1e6); energy = BigNum.of(1e6) }
        val e = GameEngine(s, Random(1))
        for (node in SkillTree.all.take(12)) {
            while (e.canBuySkill(node.id)) assertTrue(e.buySkill(node.id, 1_000L))
        }
        SkillTree.all.mapNotNull { it.effect }.distinct().forEach { effect ->
            val expected = SkillTree.effectValue(s, effect)
            // Efeito observável: o desconto de geradores vem direto do cache.
            if (effect == com.infinityclicker.game.SkillEffect.GENERATOR_DISCOUNT) {
                val gen = GeneratorDefs.byId(0)
                val factor = maxOf(0.35, 1.0 - expected) * Formulas.DIFFICULTY
                assertEquals(factor, ratio(e.planGenerator(gen, BuyMode.X1).cost, gen.baseCost), 1e-9)
            }
        }
    }

    @Test
    fun expiredAbilitiesAreRemovedWithoutTouchingActiveOnes() {
        val s = GameState.new().apply {
            generators[0] = 5
            abilityActiveUntilMs[AbilityDefs.SUPER_CLICK] = 500L
            abilityActiveUntilMs[AbilityDefs.TEMPORAL_RUSH] = 9_000L
        }
        val e = GameEngine(s, Random(1))
        assertTrue(e.refreshTimedEffects(1_000L))
        assertFalse(AbilityDefs.SUPER_CLICK in s.abilityActiveUntilMs)
        assertTrue(AbilityDefs.TEMPORAL_RUSH in s.abilityActiveUntilMs)
        assertFalse(e.refreshTimedEffects(1_001L))
    }

    @Test
    fun challengeCompletionStillSurfacesWhenCompletedByPurchase() {
        val s = GameState.new().apply { energy = BigNum.of(1e9); totalEnergy = BigNum.of(1e9) }
        val e = GameEngine(s, Random(1))
        assertTrue(e.startChallenge("build_sprint", 1_000L))
        val target = ChallengeDefs.byId.getValue("build_sprint").target
        assertTrue(e.buyGenerator(0, BuyMode.MAX, 2_000L))
        assertTrue("o desafio exige ${target} geradores", s.generators[0] >= target)
        assertEquals(1L, s.challengeCompletions)
        assertTrue(e.consumeChallengeCompletion() != null)
        assertNull(e.consumeChallengeCompletion())
    }

    // ---------------------------------------------------------------- patente e versão

    @Test
    fun rankFollowsTotalEnergyAndProgressesInsideEachTier() {
        assertEquals("Faísca", PlayerRanks.forEnergy(BigNum.ZERO).rank.name)
        assertEquals("Viajante Estelar", PlayerRanks.forEnergy(BigNum.of(1_000.0)).rank.name)
        val mid = PlayerRanks.forEnergy(BigNum.of(1e8)) // log 8: entre 6 e 10
        assertEquals("Engenheiro de Éter", mid.rank.name)
        assertEquals(0.5f, mid.fraction, 1e-4f)
        assertEquals("Arquiteto de Nebulosas", mid.next!!.name)
        val top = PlayerRanks.forEnergy(BigNum.of(1.0).let { it * BigNum.of(10.0).pow(80.0) })
        assertEquals(PlayerRanks.all.last(), top.rank)
        assertNull(top.next)
        assertEquals(1f, top.fraction, 0f)
    }

    @Test
    fun versionLabelIsExactlyAsRequested() {
        assertEquals("${AppInfo.VERSION_NUMBER} ${AppInfo.CHANNEL}", AppInfo.VERSION_LABEL)
    }

    // ---------------------------------------------------------------- nuvem (em desenvolvimento)

    private fun local(revision: Long, energy: Double, modified: Long = 10L) = GameState.new().apply {
        saveRevision = revision; totalEnergy = BigNum.of(energy); lastModifiedMs = modified
    }

    @Test
    fun cloudIsHonestlyUnavailableAndNeverClaimsToSync() = runBlocking {
        assertEquals(CloudSyncStatus.IN_DEVELOPMENT, UnavailableCloudProvider.status)
        assertFalse(CloudSyncStatus.IN_DEVELOPMENT.available)
        assertNull(UnavailableCloudProvider.fetchInfo())
        assertFalse(UnavailableCloudProvider.upload("x"))
        assertNull(UnavailableCloudProvider.download())
    }

    @Test
    fun syncPolicyNeverOverwritesAnAheadSaveAutomatically() {
        assertEquals(SyncDecision.UPLOAD, CloudSyncPolicy.decide(local(5, 1e6), null))
        assertEquals(SyncDecision.IN_SYNC, CloudSyncPolicy.decide(local(5, 1e6), CloudSaveInfo(5, 10L, BigNum.of(1e6))))
        assertEquals(SyncDecision.UPLOAD, CloudSyncPolicy.decide(local(9, 2e6), CloudSaveInfo(5, 10L, BigNum.of(1e6))))
        assertEquals(SyncDecision.DOWNLOAD, CloudSyncPolicy.decide(local(5, 1e6), CloudSaveInfo(9, 20L, BigNum.of(2e6))))
        // Nuvem mais nova porém com MENOS progresso, e o inverso: conflito, o jogador escolhe.
        assertEquals(SyncDecision.ASK_USER, CloudSyncPolicy.decide(local(5, 9e6), CloudSaveInfo(9, 20L, BigNum.of(1e6))))
        assertEquals(SyncDecision.ASK_USER, CloudSyncPolicy.decide(local(9, 1e6), CloudSaveInfo(5, 20L, BigNum.of(9e6))))
        // Mesma revisão com horários diferentes também é divergência.
        assertEquals(SyncDecision.ASK_USER, CloudSyncPolicy.decide(local(5, 1e6, 10L), CloudSaveInfo(5, 99L, BigNum.of(1e6))))
    }
}
