package dev.atlas.map

import dev.atlas.core.Coordinate

data class CameraRequest(
    val id: Long,
    val target: Coordinate? = null,
    val points: List<Coordinate> = emptyList(),
    val bearing: Double? = null,
    val tilt: Double? = null,
    val zoom: Double? = null,
    val following: Boolean = false,
)
