package dev.atlas.location

import dev.atlas.core.Coordinate
import dev.atlas.core.NavigationProgress
import dev.atlas.core.Route

/** Keeps requested stops in route order. Physical proximity alone never marks a stop as visited. */
internal fun remainingRoutePoints(route: Route, origin: Coordinate, progress: NavigationProgress): List<Coordinate> {
    val destination = route.waypoints.takeIf { it.size >= 2 }?.lastOrNull()
        ?: route.geometry.lastOrNull() ?: return emptyList()
    if (route.geometry.size < 2 || route.waypoints.size < 3) return listOf(origin, destination)
    val travelledSegment = progress.segmentIndex.coerceIn(0, route.geometry.lastIndex - 1)
    var previousMatch = 0
    val remainingStops = route.waypoints.drop(1).dropLast(1).filter { waypoint ->
        // Advancing the search window disambiguates repeated coordinates on a returning route.
        val from = (previousMatch + 1).coerceAtMost(route.geometry.lastIndex)
        val match = (from..route.geometry.lastIndex).minByOrNull { route.geometry[it].distanceTo(waypoint) }
            ?: route.geometry.lastIndex
        previousMatch = match
        // At the end of the preceding segment we conservatively keep the stop until passed.
        match > travelledSegment
    }
    return listOf(origin) + remainingStops + destination
}
