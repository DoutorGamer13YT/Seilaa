package com.vitinhjkjkk.dmap.data

import com.vitinhjkjkk.dmap.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ProviderNotConfiguredException : IOException("Search provider is not configured")

class GeoapifySearchRepository {
    suspend fun search(query: String): List<Place> = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEOAPIFY_API_KEY
        if (key.isBlank()) throw ProviderNotConfiguredException()
        val encodedQuery = URLEncoder.encode(query, Charsets.UTF_8.name())
        val encodedKey = URLEncoder.encode(key, Charsets.UTF_8.name())
        val endpoint = "https://api.geoapify.com/v1/geocode/autocomplete" +
            "?text=$encodedQuery&format=geojson&limit=8&apiKey=$encodedKey"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            setRequestProperty("Accept", "application/geo+json, application/json")
        }
        try {
            val status = connection.responseCode
            if (status !in 200..299) throw IOException("Search request failed")
            val payload = connection.inputStream.bufferedReader().use { it.readText() }
            val features = JSONObject(payload).optJSONArray("features") ?: return@withContext emptyList()
            buildList {
                for (index in 0 until features.length()) {
                    val feature = features.optJSONObject(index) ?: continue
                    val properties = feature.optJSONObject("properties") ?: continue
                    val coordinates = feature.optJSONObject("geometry")
                        ?.optJSONArray("coordinates")
                    val longitude = coordinates?.optDouble(0, Double.NaN)
                        ?: properties.optDouble("lon", Double.NaN)
                    val latitude = coordinates?.optDouble(1, Double.NaN)
                        ?: properties.optDouble("lat", Double.NaN)
                    if (!latitude.isFinite() || !longitude.isFinite()) continue
                    val label = properties.optString("name").takeIf(String::isNotBlank)
                        ?: properties.optString("address_line1").takeIf(String::isNotBlank)
                        ?: properties.optString("formatted", "Local")
                    add(
                        Place(
                            name = label,
                            address = properties.optString("formatted", ""),
                            latitude = latitude,
                            longitude = longitude,
                            category = properties.optString("category", ""),
                        ),
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
