package com.infinityclicker.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.CrystalArea
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun HomeScreen(ui: UiState, onTap: () -> TapResult?, onUseAbility: (String) -> Unit) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    val crystal = ui.crystals.firstOrNull { it.equipped }?.def
    val dimension = ui.dimensions.firstOrNull { it.current }?.def

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        GlassCard(Modifier.fillMaxWidth(), tint = dimension?.tintColor ?: Neon.Cyan, alpha = ui.settings.panelOpacity) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("ENERGIA", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 2.sp)
                    Text(f(ui.energy), color = Neon.TextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("+${f(ui.production)} / s", color = dimension?.tintColor ?: Neon.Cyan, fontSize = 15.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(dimension?.name ?: "Primordial", color = Neon.TextSecondary, fontSize = 11.sp)
                    Text(crystal?.name ?: "Éter Azul", color = crystal?.tintColor ?: Neon.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        val renderQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
        CrystalArea(
            tier = (ui.stats.totalEnergy.exponent / 3L).toInt(),
            crystalStyle = crystal?.id ?: 0,
            baseColor = crystal?.tintColor ?: Neon.Cyan,
            comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f,
            effectsIntensity = ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.5f else renderQuality.particleScale,
            particleLimit = (150f * ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.3f else renderQuality.particleScale).toInt(),
            quality = renderQuality,
            hapticsEnabled = ui.settings.hapticsEnabled,
            motionEnabled = !ui.settings.batterySaver,
            formatGain = { r -> f(r.gain) },
            onTap = onTap,
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        ui.activeBoss?.let { boss ->
            val fraction = (boss.active.health / boss.maxHealth).toDouble().toFloat().coerceIn(0f, 1f)
            GlassCard(Modifier.fillMaxWidth(), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("⚠ ${ui.dimensions.firstOrNull { it.def.id == boss.active.dimensionId }?.def?.bossName ?: "Chefe"}", color = Neon.Pink, fontWeight = FontWeight.Bold)
                    Text("${NumberFormatter.duration(boss.remainingMs)}", color = Neon.Gold, fontSize = 12.sp)
                }
                LinearProgressIndicator(
                    progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(7.dp),
                    color = Neon.Pink, trackColor = Color.White.copy(alpha = 0.12f)
                )
                Text("Vida: ${f(boss.active.health)} · cada toque causa dano real", color = Neon.TextSecondary, fontSize = 12.sp)
            }
        }

        ui.activeEvent?.let { event ->
            GlassCard(Modifier.fillMaxWidth(), tint = Color(event.def.tintArgb), alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("✦ ${event.def.name}", color = Color(event.def.tintArgb), fontWeight = FontWeight.Bold)
                    Text(NumberFormatter.duration(event.remainingMs), color = Neon.Gold, fontSize = 12.sp)
                }
                Text(event.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
        }

        AbilityStrip(ui.abilities, sci, onUseAbility)

        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Clique: ${f(ui.clickGain)}", color = Neon.TextPrimary, fontSize = 13.sp)
                Text("Crítico ${"%.0f".format(ui.critChance * 100)}% · ×${"%.1f".format(ui.critMultiplier)}", color = Neon.Gold, fontSize = 13.sp)
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Combo ${ui.combo}/${ui.maxCombo}", color = Neon.TextSecondary, fontSize = 12.sp)
                Text("×${"%.2f".format(ui.comboMultiplier)}", color = Neon.Green, fontSize = 12.sp)
            }
            LinearProgressIndicator(
                progress = { if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f },
                modifier = Modifier.fillMaxWidth().padding(top = 5.dp).height(5.dp),
                color = Neon.Green,
                trackColor = Color.White.copy(alpha = 0.12f)
            )
        }
        Text(
            tutorialText(ui.tutorialStep), color = Neon.TextSecondary, fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AbilityStrip(abilities: List<AbilityUi>, scientific: Boolean, onUse: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        abilities.forEach { ability ->
            val text = when {
                ability.activeRemainingMs > 0L -> "Ativa ${NumberFormatter.duration(ability.activeRemainingMs)}"
                ability.cooldownRemainingMs > 0L -> "Recarga ${NumberFormatter.duration(ability.cooldownRemainingMs)}"
                else -> "Usar"
            }
            Button(
                onClick = { onUse(ability.def.id) }, enabled = ability.canUse,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (ability.activeRemainingMs > 0L) Neon.Green.copy(alpha = 0.76f) else Neon.Cyan.copy(alpha = 0.78f),
                    contentColor = Neon.Bg,
                    disabledContainerColor = Color.White.copy(alpha = 0.08f),
                    disabledContentColor = Neon.TextSecondary
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ability.def.name, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(text, fontSize = 9.sp)
                }
            }
        }
    }
}

private fun tutorialText(step: Int): String = when (step) {
    0 -> "Toque no cristal para gerar energia."
    1 -> "Abra a Loja e compre um Fragmento Estelar para iniciar a produção automática."
    2 -> "Use as habilidades no painel acima — elas alteram os ganhos de verdade."
    3 -> "Explore Dimensões, enfrente um chefe e prepare o primeiro renascimento."
    else -> "Seu universo renasceu. Invista pontos na árvore para acelerar a próxima corrida."
}
