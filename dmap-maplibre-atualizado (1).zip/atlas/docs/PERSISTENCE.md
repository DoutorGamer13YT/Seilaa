# Persistência local

`dev.atlas.data.LocalRepository(context)` é a entrada pública. Room mantém `atlas.db` no diretório privado do aplicativo; Preferences DataStore mantém `atlas_settings.preferences_pb`. Não é solicitada permissão de armazenamento. Todos os campos recebidos de `Place` são preservados; o armazenamento não cria dados comerciais.

## API

Fluxos: `favorites: Flow<List<SavedPlace>>`, `lists: Flow<List<SavedList>>`, `history: Flow<List<SearchHistory>>`, `shortcuts: Flow<List<Shortcut>>`, `settings: Flow<AppSettings>`, `errors: Flow<AppException>`.

Operações suspend (retorno `Unit`):

- `savePlace(place)`, `removePlace(placeId)`.
- `createList(name)`, `renameList(id, name)`, `deleteList(id)`, `moveList(id, delta)`.
- `setPlaceLists(place, listIds)` substitui as associações de um favorito de forma atômica; o conjunto vazio mantém o lugar nos favoritos gerais.
- `recordSearch(query)`, `removeHistory(query)`, `clearHistory()`.
- `setShortcut(kind, place)` aceita `home` ou `work`; `place = null` remove o atalho.
- `updateSettings(settings)` grava todos os campos de `AppSettings` em uma única edição.

## Integridade e privacidade

- Favoritos e atalhos referenciam a tabela de lugares. Relações com listas têm chave composta e chaves estrangeiras. Excluir uma lista não exclui seus lugares; excluir um favorito não exclui um atalho que usa o mesmo lugar.
- Atualizar metadados usa `@Upsert`, evitando `REPLACE`, que poderia apagar relações em cascata. Salvar novamente mantém a data original do favorito.
- Criar, renomear, excluir e reordenar listas são operações transacionais. Posições são compactadas de `0` a `N-1`; nomes duplicados ignoram maiúsculas, espaços repetidos e composição Unicode. Limite de 80 caracteres.
- O histórico contém no máximo 30 consultas explícitas, com última utilização primeiro. Duplicatas são normalizadas sem remover acentos. Limite de 300 caracteres. A tela decide quando registrar uma consulta; não se deve registrar cada tecla.
- Não existe migração destrutiva. A versão inicial é 1; futuras alterações exigem migrações Room explícitas e testes sobre o esquema exportado. Configure `room.schemaLocation` no processador KSP.
- Os dados locais incluem coordenadas e pesquisas pessoais. Eles não são criptografados individualmente; dependem do sandbox e da proteção do armazenamento Android. A política de backup do manifesto deve excluí-los de backup em nuvem, se essa for a política de privacidade do produto.
- Não há cache de mapas ou rotas offline neste módulo. Favoritos, atalhos, listas, histórico e configurações funcionam sem rede.

## Erros e cancelamento

Operações inválidas lançam `AppException(INVALID_INPUT)`. Falhas de escrita lançam `AppException(STORAGE)` com mensagem de recuperação; cancelamento de coroutine é preservado. As telas devem capturar essas falhas e informar o usuário.

Falhas de observação (incluindo IO do DataStore) emitem `AppException(STORAGE)` em `errors` e tentam novamente com espera entre 1 e 6 segundos enquanto houver observadores. O fluxo não substitui dados existentes por listas vazias, nem sobrescreve preferências que não pôde ler. A UI que usa `stateIn` mantém o último estado recebido. `errors` é um fluxo de eventos: deve ser coletado durante o ciclo de vida visível da interface. Não mantém coordenadas ou dados pessoais em logs.

Valores desconhecidos dos enums de tema e unidades usam os padrões `SYSTEM` e `METRIC`. Preferências ausentes usam os padrões de `AppSettings`. Arquivos corrompidos não são apagados silenciosamente.

## Verificação

Testes JVM: `StorageValidationTest` verifica normalização, limites, validação de atalhos e decodificação de configurações.

Testes instrumentados: `StorageRepositoryTest` usa Room em memória e DataStore temporário para relações, atualização de metadados, reversão transacional, histórico, atalhos, CRUD/reordenação de listas e configurações. `StorageRestartTest` fecha e reabre arquivos reais para confirmar persistência entre instâncias (não simula um reinício físico do aparelho).

Comandos para uma futura verificação autorizada: `./gradlew testDebugUnitTest` e, com emulador/dispositivo disponível, `./gradlew connectedDebugAndroidTest`. Não foram executados nesta revisão: a instrução atual do usuário proíbe compilar, inclusive por meio de testes. A presença dos testes no repositório não significa aprovação; consulte `DEVELOPMENT_STATUS.md` para os resultados reais.

## Revisão estática de integração

Biblioteca e Ajustes chamam a API por meio de `AtlasViewModel`/`AtlasApp`. Os identificadores de atalhos são `home` e `work` em todas essas camadas. A seleção de múltiplas listas no diálogo é preservada por estado salvável após recriação da Activity; IDs removidos enquanto o diálogo estava aberto são descartados antes do envio. A validação inline de nomes acompanha a normalização Unicode e a rejeição de caracteres de controle da persistência.

A revisão de código confirmou chaves estrangeiras, transações, consultas parametrizadas e propagação de cancelamento, sem alterar o esquema. Isso não substitui execução do Room, testes em aparelho, TalkBack ou inspeção visual em fontes ampliadas; esses cenários continuam pendentes.
