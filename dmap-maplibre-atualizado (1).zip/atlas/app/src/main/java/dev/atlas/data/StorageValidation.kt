package dev.atlas.data

import dev.atlas.core.AppException
import dev.atlas.core.ErrorKind
import java.text.Normalizer
import java.util.Locale

internal object StorageValidation {
    fun listName(value: String): String = clean(value).also {
        if (it.isBlank() || it.length > 80 || it.any(Char::isISOControl)) {
            throw AppException(ErrorKind.INVALID_INPUT, "Use um nome de lista com 1 a 80 caracteres.")
        }
    }

    fun query(value: String): String = clean(value).also {
        if (it.isBlank() || it.length > 300 || it.any(Char::isISOControl)) {
            throw AppException(ErrorKind.INVALID_INPUT, "A pesquisa deve ter entre 1 e 300 caracteres.")
        }
    }

    fun normalize(value: String): String = Normalizer.normalize(clean(value), Normalizer.Form.NFC)
        .lowercase(Locale.ROOT)

    fun shortcut(value: String): String = value.also {
        if (it != "home" && it != "work") {
            throw AppException(ErrorKind.INVALID_INPUT, "Atalho desconhecido. Use Casa ou Trabalho.")
        }
    }

    private fun clean(value: String) = value.trim().replace(Regex("\\s+"), " ")
}
