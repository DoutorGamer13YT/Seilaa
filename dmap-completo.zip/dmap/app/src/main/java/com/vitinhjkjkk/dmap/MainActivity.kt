package com.vitinhjkjkk.dmap

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vitinhjkjkk.dmap.data.Place
import com.vitinhjkjkk.dmap.location.Coordinates
import com.vitinhjkjkk.dmap.location.LocationClient
import com.vitinhjkjkk.dmap.maps.MapCameraController
import com.vitinhjkjkk.dmap.maps.MapSurface
import com.vitinhjkjkk.dmap.ui.DmapTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            val vm: DmapViewModel = viewModel(factory = DmapViewModel.Factory(applicationContext))
            DmapRoot(vm, this)
        }
    }
}

@Composable
private fun DmapRoot(vm: DmapViewModel, activity: ComponentActivity) {
    val dark by vm.darkTheme.collectAsStateWithLifecycle()
    SideEffect {
        windowBars(activity, dark)
    }
    DmapTheme(dark) { DmapScreen(vm) }
}

private fun windowBars(activity: ComponentActivity, dark: Boolean) {
    activity.window.statusBarColor = android.graphics.Color.TRANSPARENT
    activity.window.navigationBarColor = android.graphics.Color.TRANSPARENT
    WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
        isAppearanceLightStatusBars = !dark
        isAppearanceLightNavigationBars = !dark
    }
}

@Composable
private fun DmapScreen(vm: DmapViewModel) {
    val context = LocalContext.current
    val camera = remember { MapCameraController() }
    val mode by vm.mapMode.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val selected by vm.selectedPlace.collectAsStateWithLifecycle()
    val dark by vm.darkTheme.collectAsStateWithLifecycle()
    var showSettings by remember { mutableIntStateOf(0) }
    var sheetLevel by remember { mutableIntStateOf(0) }
    var showingFavorites by remember { mutableIntStateOf(0) }
    val focusManager = LocalFocusManager.current
    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { permissions ->
        if (permissions[android.Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[android.Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            LocationClient(context).locate { coordinates -> coordinates?.let(camera::center) }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        MapSurface(mode, camera)

        Row(
            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 16.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f), shadowElevation = 8.dp) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 9.dp)) {
                    Text("Dmap", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("@vitinhjkjkk", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 16.dp, top = 8.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
            shadowElevation = 8.dp,
        ) {
            TextButton(onClick = { showSettings = 1 }) {
                Text("⚙", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleLarge)
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 16.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
            shadowElevation = 8.dp,
        ) {
            TextButton(onClick = {
                val fine = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                val coarse = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (fine || coarse) LocationClient(context).locate { coordinates -> coordinates?.let(camera::center) }
                else locationLauncher.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
            }) {
                Text("◎", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.headlineSmall)
            }
        }

        val sheetHeight by animateDpAsState(
            targetValue = when (sheetLevel) {
                0 -> 174.dp
                1 -> 340.dp
                2 -> 520.dp
                else -> maxHeight * 0.90f
            }.coerceAtMost(maxHeight - 8.dp), label = "search-sheet-height",
        )
        SearchPanel(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sheetHeight).navigationBarsPadding(),
            level = sheetLevel,
            onLevelChange = { sheetLevel = it.coerceIn(0, 3) },
            query = query,
            onQuery = vm::setQuery,
            searching = searching,
            message = message,
            results = results,
            favorites = favorites,
            showingFavorites = showingFavorites == 1,
            onTab = { showingFavorites = it },
            selected = selected,
            onSelect = { place -> vm.selectPlace(place); camera.center(Coordinates(place.latitude, place.longitude)); sheetLevel = 2; focusManager.clearFocus() },
            onFavorite = vm::toggleFavorite,
            onClearSelection = vm::clearSelection,
            onClearFavorites = vm::clearFavorites,
            onOpenRoute = { place -> openExternalRoute(context, place) },
        )

        if (showSettings == 1) {
            SettingsScreen(
                dark = dark,
                mapMode = mode,
                onDark = vm::setDarkTheme,
                onMapMode = vm::setMapMode,
                onClose = { showSettings = 0 },
            )
        }
    }
}

@Composable
private fun SearchPanel(
    modifier: Modifier,
    level: Int,
    onLevelChange: (Int) -> Unit,
    query: String,
    onQuery: (String) -> Unit,
    searching: Boolean,
    message: String?,
    results: List<Place>,
    favorites: List<Place>,
    showingFavorites: Boolean,
    onTab: (Int) -> Unit,
    selected: Place?,
    onSelect: (Place) -> Unit,
    onFavorite: (Place) -> Unit,
    onClearSelection: () -> Unit,
    onClearFavorites: () -> Unit,
    onOpenRoute: (Place) -> Unit,
) {
    val focusManager = LocalFocusManager.current
    var dragAmount by remember { mutableFloatStateOf(0f) }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 18.dp,
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Box(
                Modifier.fillMaxWidth().pointerInput(level) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount -> dragAmount += amount; change.consume() },
                        onDragEnd = {
                            if (dragAmount < -48) onLevelChange(level + 1)
                            else if (dragAmount > 48) onLevelChange(level - 1)
                            dragAmount = 0f
                        },
                        onDragCancel = { dragAmount = 0f },
                    )
                }.clickable { onLevelChange(if (level >= 2) 0 else level + 1) }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.width(38.dp).height(5.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)))
            }
            if (selected != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Local selecionado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = onClearSelection) { Text("Fechar") }
                }
                Text(selected.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (selected.address.isNotBlank()) Text(selected.address, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${selected.latitude}, ${selected.longitude}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onOpenRoute(selected) }) { Text("Abrir rota externa") }
                    TextButton(onClick = { onFavorite(selected) }) { Text("☆ Salvar") }
                }
                return@Column
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = { onTab(0) }) { Text("Buscar no mapa") }
                TextButton(onClick = { onTab(1) }) { Text("Salvos (${favorites.size})") }
            }
            if (!showingFavorites) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQuery,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    placeholder = { Text("Buscar no mapa") },
                    leadingIcon = { Text("⌕", style = MaterialTheme.typography.headlineSmall) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                )
                if (level >= 1) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Restaurantes", "Cafeterias", "Farmácias", "Parques", "Hospitais").forEach { category ->
                            AssistChip(onClick = { onQuery(category) }, label = { Text(category) })
                        }
                    }
                }
            }
            Column(Modifier.weight(1f, fill = true).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                if (showingFavorites) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Lugares salvos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (favorites.isNotEmpty()) TextButton(onClick = onClearFavorites) { Text("Limpar") }
                    }
                    if (favorites.isEmpty()) Text("Seus lugares salvos aparecerão aqui.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    favorites.forEach { place -> PlaceRow(place, onClick = { onSelect(place) }) }
                } else if (selected == null) {
                    if (searching) Text("Pesquisando…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
                    if (message != null) Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
                    results.forEach { place -> PlaceRow(place, onClick = { onSelect(place) }) }
                    if (level >= 2 && query.isBlank()) Text("Pesquise um endereço ou uma categoria para ver dados reais do provedor.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(place: Place, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(place.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (place.address.isNotBlank()) Text(place.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (place.category.isNotBlank()) Text(place.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun SettingsScreen(
    dark: Boolean,
    mapMode: String,
    onDark: (Boolean) -> Unit,
    onMapMode: (String) -> Unit,
    onClose: () -> Unit,
) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Configurações", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                TextButton(onClick = onClose) { Text("Concluir") }
            }
            Spacer(Modifier.height(20.dp))
            Text("Aparência", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = dark, onClick = { onDark(true) }, label = { Text("Escuro") })
                FilterChip(selected = !dark, onClick = { onDark(false) }, label = { Text("Claro") })
            }
            Spacer(Modifier.height(18.dp))
            Text("Mapa", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("AUTO" to "Automático", "ONLINE" to "Online", "OFFLINE" to "Offline").forEach { (value, label) ->
                    FilterChip(selected = mapMode == value, onClick = { onMapMode(value) }, label = { Text(label) })
                }
            }
            Text(
                "Offline: nenhum pacote regional está instalado neste projeto inicial. Configure os serviços externos conforme README.md.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp),
            )
            Spacer(Modifier.height(22.dp))
            Text("Sobre", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Dmap · @vitinhjkjkk · versão 0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Pesquisa e mapas dependem de provedores configurados; veja licenças e privacidade em README.md.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun openExternalRoute(context: android.content.Context, place: Place) {
    val uri = Uri.parse("geo:${place.latitude},${place.longitude}?q=${place.latitude},${place.longitude}(${Uri.encode(place.name)})")
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}
