package dev.atlas.location

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import dev.atlas.core.Coordinate
import dev.atlas.core.LocationFix
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LocationState(
    val fix: LocationFix? = null,
    val permissionGranted: Boolean = false,
    val precise: Boolean = false,
    val providerEnabled: Boolean = false,
    val error: String? = null,
    val isStale: Boolean = true,
)

class LocationTracker(context: Context) {
    private val context = context.applicationContext
    private val manager = this.context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val main = Handler(Looper.getMainLooper())
    private val mutableState = MutableStateFlow(LocationState())
    val state: StateFlow<LocationState> = mutableState.asStateFlow()
    private var started = false
    private var navigating = false
    private var receiverRegistered = false
    private var registeredProviders = emptySet<String>()
    private var fixElapsedNanos = 0L
    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = accept(location)
        override fun onProviderEnabled(provider: String) = refresh()
        override fun onProviderDisabled(provider: String) = refresh()
        @Deprecated("Legacy LocationManager callback")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
    }
    private val providerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = refresh()
    }
    private val freshnessCheck = object : Runnable {
        override fun run() {
            if (!started) return
            updateStatus()
            registerProviders()
            main.postDelayed(this, 5_000)
        }
    }

    fun start(navigating: Boolean = false) = onMain {
        val modeChanged = this.navigating != navigating
        this.navigating = navigating
        if (started && !modeChanged) {
            updateStatus()
            registerProviders()
            return@onMain
        }
        started = true
        updateStatus()
        if (!receiverRegistered) {
            val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION).apply {
                addAction(LocationManager.MODE_CHANGED_ACTION)
            }
            if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(providerReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else @Suppress("UnspecifiedRegisterReceiverFlag") context.registerReceiver(providerReceiver, filter)
            receiverRegistered = true
        }
        if (modeChanged) unregisterUpdates()
        registerProviders()
        readLastKnown()
        main.removeCallbacks(freshnessCheck)
        main.post(freshnessCheck)
    }

    fun stop() = onMain {
        started = false
        main.removeCallbacks(freshnessCheck)
        unregisterUpdates()
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(providerReceiver) }
            receiverRegistered = false
        }
        mutableState.value = mutableState.value.copy(isStale = true)
    }

    fun refresh() = onMain {
        updateStatus()
        if (started) {
            registerProviders()
            readLastKnown()
        }
    }

    private fun onMain(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) action() else main.post(action)
    }

    private fun updateStatus() {
        val precise = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val permission = precise || context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val enabled = availableProviders(precise).isNotEmpty()
        val ageMillis = if (fixElapsedNanos > 0) (SystemClock.elapsedRealtimeNanos() - fixElapsedNanos) / 1_000_000 else Long.MAX_VALUE
        val stale = !started || !permission || !enabled || ageMillis < 0 || ageMillis > (if (navigating) 15_000 else 60_000)
        mutableState.value = mutableState.value.copy(
            permissionGranted = permission, precise = precise, providerEnabled = enabled,
            isStale = stale, error = when {
                !permission -> "Permita a localização para mostrar sua posição."
                !enabled && !precise -> "Localização aproximada indisponível. Confira a localização e a permissão precisa nas configurações."
                !enabled -> "Ative a localização nas configurações do Android."
                stale && mutableState.value.fix != null -> "Sinal de localização temporariamente indisponível."
                else -> null
            },
        )
        if (!permission) unregisterUpdates()
    }

    private fun availableProviders(precise: Boolean): Set<String> = buildSet {
        if (precise && runCatching { manager.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)) add(LocationManager.GPS_PROVIDER)
        if (runCatching { manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)) add(LocationManager.NETWORK_PROVIDER)
    }

    @Suppress("MissingPermission")
    private fun registerProviders() {
        if (!started || !mutableState.value.permissionGranted) return
        val providers = availableProviders(mutableState.value.precise)
        if (providers == registeredProviders) return
        unregisterUpdates()
        val registered = mutableSetOf<String>()
        for (provider in providers) {
            try {
                val gps = provider == LocationManager.GPS_PROVIDER
                manager.requestLocationUpdates(provider,
                    if (navigating && gps) 1_000L else if (navigating || gps) 5_000L else 10_000L,
                    if (navigating && gps) 1f else if (navigating || gps) 5f else 15f,
                    listener, Looper.getMainLooper())
                registered += provider
            } catch (_: SecurityException) {
                mutableState.value = mutableState.value.copy(error = "A permissão de localização foi alterada. Abra as permissões do aplicativo.")
            } catch (_: IllegalArgumentException) {
                mutableState.value = mutableState.value.copy(error = "Este provedor de localização não está disponível no aparelho.")
            }
        }
        registeredProviders = registered
    }

    @Suppress("MissingPermission")
    private fun readLastKnown() {
        if (!mutableState.value.permissionGranted) return
        availableProviders(mutableState.value.precise).mapNotNull { provider ->
            runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        }.filter { (SystemClock.elapsedRealtimeNanos() - it.elapsedRealtimeNanos) / 1_000_000 in 0..120_000 }
            .sortedBy { it.elapsedRealtimeNanos }.forEach(::accept)
    }

    private fun accept(location: Location) {
        if (!started || !location.latitude.isFinite() || !location.longitude.isFinite() ||
            location.latitude !in -90.0..90.0 || location.longitude !in -180.0..180.0) return
        if (location.elapsedRealtimeNanos < fixElapsedNanos) return
        val previous = mutableState.value.fix
        val newAge = (location.elapsedRealtimeNanos - fixElapsedNanos) / 1_000_000
        if (previous != null && newAge < 8_000 && location.hasAccuracy() &&
            location.accuracy > maxOf(previous.accuracyMeters * 2, 75f)) return
        fixElapsedNanos = location.elapsedRealtimeNanos
        mutableState.value = mutableState.value.copy(fix = LocationFix(
            Coordinate(location.latitude, location.longitude),
            if (location.hasAccuracy() && location.accuracy.isFinite()) location.accuracy.coerceAtLeast(0f) else 100f,
            if (location.hasBearing() && location.bearing.isFinite()) location.bearing else null,
            if (location.hasSpeed() && location.speed.isFinite()) location.speed.coerceAtLeast(0f) else null,
            location.time,
        ), error = null)
        updateStatus()
    }

    private fun unregisterUpdates() {
        if (registeredProviders.isNotEmpty()) runCatching { manager.removeUpdates(listener) }
        registeredProviders = emptySet()
    }
}
