# Atlas — linguagem visual

Referência escolhida: Apple Maps/iOS 27. A identidade, o nome, os ícones e o código são próprios; o aplicativo não se apresenta como software Apple. A referência inicial de iOS 18 foi substituída após a atualização explícita do usuário para iOS 27.

## Fontes oficiais

Referências verificadas na pesquisa do agente principal:
- https://support.apple.com/guide/iphone/whats-new-in-ios-27-iphfed2c4091/27/ios/27
- https://apps.apple.com/us/iphone/story/id1896606813 — atualização do Liquid Glass com refração mais uniforme e melhor contraste.
- https://www.apple.com/os/ios/
- https://images.apple.com/ca/newsroom/2026/09/major-updates-for-apples-software-platforms-are-now-available/

Essas fontes orientam a seleção da versão; não equivalem a uma comparação visual do APK. Não houve ainda execução e captura do aplicativo em dispositivo. Não declaramos equivalência pixel a pixel com Apple Maps.

## Material e tokens

`AtlasTheme` centraliza tema do sistema, claro e escuro. Usa tipografia SansSerif fornecida pelo Android: nenhum arquivo SF Pro ou SF Symbols foi copiado. Ícones Material Rounded vetoriais mantêm espessura e dimensões consistentes.

O material usa superfícies translúcidas com 95% de opacidade, contorno claro de 0,8 dp e sombra moderada. Esta implementação fornece uma aproximação visual de material de vidro, sem alegar refração óptica nativa nem aplicar blur à hierarquia inteira. O texto mantém superfície suficientemente opaca para legibilidade sobre mapas variados. O tema escuro usa paleta própria e azul de maior luminosidade.

| Token | Valor |
|---|---|
| Azul claro | #007AFF |
| Azul escuro | #64A8FF |
| Superfície clara | #FCFCFD |
| Superfície escura | #252528 |
| Raio do painel | 30 dp |
| Raio de cartão | 20 dp |
| Busca | mínimo 52 dp; raio 23 dp |
| Botão de mapa | 50 dp; ícone 23 dp |
| Alvo de toque | mínimo 48 dp nos controles |
| Margem externa | 16 dp |
| Transição de seleção | 180 ms |
| Mola do painel | damping 0,88; stiffness 420 |

Títulos 27–32 sp, texto principal 17 sp, secundário 15 sp e metadados 13 sp. Unidades sp respeitam fonte ampliada. Linhas de lugar têm altura mínima, não máxima, e endereço pode quebrar em duas linhas.

## Painel

`AtlasBottomSheet` possui `Collapsed`, `Peek`, `Half` e `Expanded`. As alturas nominalmente recolhida/parcial são 128/290 dp; as demais dependem da altura útil. A altura recolhida preserva o puxador de 48 dp e a busca; em paisagem ou com teclado as âncoras adotam proporções do espaço restante para não se sobrepor. O topo expandido mantém barra de status mais 12 dp; a base respeita a maior margem entre navegação e teclado.

O gesto na superfície funciona com `draggable`; listas internas usam `nestedScroll`. Arrastar para cima expande antes de rolar conteúdo; para baixo recolhe após chegar ao topo da lista. A velocidade seleciona a próxima âncora; a mola assenta o painel. Redução de movimento elimina a mola. `AtlasTheme(reduceMotion = true)` também elimina a transição de seleção dos controles. O puxador expõe estado e ações de expandir/recolher ao TalkBack. A região superior permanece sem bloqueio modal, preservando o mapa interativo.

API `onHeightChanged(Float)` reporta pixels físicos ocupados pelo painel mais a margem inferior/teclado, para ajuste de câmera. O proprietário da tela persiste `position` em `rememberSaveable`. A abertura do teclado expande temporariamente; fechar restaura a posição controlada.

## Revisão estática

Aplicada a skill local `code-review-estruturado-checklist`. Revisados estados, limites de altura, cancelamento de animação, ações de acessibilidade, áreas de toque, escala de texto, uso de dados disponíveis e ausência de recursos privados. A inspeção identifica comportamento previsto pelo código; não substitui testes instrumentados.

Por instrução explícita mais recente do usuário, nenhuma compilação nem teste que compile o app deve ser executado nesta etapa. Permanecem pendentes: validação em emulador de nested scroll/fling e teclado, TalkBack real, escala de fonte 200%, paisagem, comparação por capturas e medições de desempenho.
