package com.infinityclicker.ui

import com.infinityclicker.core.BigNum
import com.infinityclicker.data.UserSettings
import com.infinityclicker.game.AbilityDef
import com.infinityclicker.game.AchievementDef
import com.infinityclicker.game.AchievementProgress
import com.infinityclicker.game.ActiveBoss
import com.infinityclicker.game.ActiveChallenge
import com.infinityclicker.game.BackgroundDef
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.ChallengeDef
import com.infinityclicker.game.CrystalDef
import com.infinityclicker.game.CosmicEventDef
import com.infinityclicker.game.DailyMissionDef
import com.infinityclicker.game.DimensionDef
import com.infinityclicker.game.OfflineReport
import com.infinityclicker.game.PrestigePreview
import com.infinityclicker.game.PurchasePlan
import com.infinityclicker.game.SkillNodeDef
import com.infinityclicker.generators.GeneratorDef
import com.infinityclicker.upgrades.UpgradeDef

data class GeneratorRow(
    val def: GeneratorDef,
    val owned: Long,
    val plan: PurchasePlan,
    val unitProduction: BigNum,
    val totalProduction: BigNum,
    val unlocked: Boolean,
    val nextMilestone: Long
)

data class UpgradeRow(
    val def: UpgradeDef,
    val level: Int,
    val unlocked: Boolean,
    val maxed: Boolean,
    val plan: PurchasePlan
)

data class SkillNodeUi(
    val def: SkillNodeDef,
    val level: Int,
    val canBuy: Boolean,
    val requirementsMet: Boolean
)

data class AbilityUi(
    val def: AbilityDef,
    val level: Int,
    val canUse: Boolean,
    val activeRemainingMs: Long,
    val cooldownRemainingMs: Long,
    val canUpgrade: Boolean
)

data class DimensionUi(
    val def: DimensionDef,
    val unlocked: Boolean,
    val canUnlock: Boolean,
    val unlockRequirement: BigNum,
    val current: Boolean,
    val shards: Long,
    val resonance: Int,
    val resonanceCost: Long,
    val bossWins: Int
)

data class CrystalUi(val def: CrystalDef, val unlocked: Boolean, val equipped: Boolean)
data class BackgroundUi(val def: BackgroundDef, val unlocked: Boolean, val equipped: Boolean)

data class BossUi(val active: ActiveBoss, val maxHealth: BigNum, val remainingMs: Long)
data class CosmicEventUi(val def: CosmicEventDef, val remainingMs: Long)
data class ChallengeUi(
    val def: ChallengeDef,
    val available: Boolean,
    val active: Boolean,
    val progress: Long,
    val remainingMs: Long,
    val wins: Long
)

data class DailyMissionUi(
    val def: DailyMissionDef,
    val progress: Long,
    val claimed: Boolean,
    val canClaim: Boolean
)

data class AchievementUi(
    val def: AchievementDef,
    val unlocked: Boolean,
    val claimed: Boolean,
    val canClaim: Boolean,
    val progress: AchievementProgress,
    val unlockedAtMs: Long? = null
)

data class StatsUi(
    val totalClicks: Long = 0L,
    val critClicks: Long = 0L,
    val maxCombo: Int = 0,
    val generatorsBought: Long = 0L,
    val upgradeLevelsBought: Long = 0L,
    val playTimeMs: Long = 0L,
    val totalEnergy: BigNum = BigNum.ZERO,
    val runEnergy: BigNum = BigNum.ZERO,
    val offlineEarned: BigNum = BigNum.ZERO,
    val prestigePoints: Int = 0,
    val prestigeCount: Int = 0,
    val abilitiesUsed: Long = 0L,
    val bossWins: Int = 0,
    val clicksPerSecond: Int = 0,
    val highestTapMultiplier: Double = 1.0,
    val highestProduction: BigNum = BigNum.ZERO,
    val clickEnergy: BigNum = BigNum.ZERO,
    val productionEnergy: BigNum = BigNum.ZERO,
    val eventsTriggered: Long = 0L,
    val challengeCompletions: Long = 0L,
    val achievementsUnlocked: Int = 0,
    val achievementsClaimed: Int = 0,
    val completionFraction: Float = 0f
)

data class UiState(
    val loaded: Boolean = false,
    val energy: BigNum = BigNum.ZERO,
    val production: BigNum = BigNum.ZERO,
    val clickGain: BigNum = BigNum.ONE,
    val critChance: Double = 0.0,
    val critMultiplier: Double = 0.0,
    val combo: Int = 0,
    val maxCombo: Int = 0,
    val comboMultiplier: Double = 1.0,
    val buyMode: BuyMode = BuyMode.X1,
    val generators: List<GeneratorRow> = emptyList(),
    val upgrades: List<UpgradeRow> = emptyList(),
    val skills: List<SkillNodeUi> = emptyList(),
    val abilities: List<AbilityUi> = emptyList(),
    val dimensions: List<DimensionUi> = emptyList(),
    val crystals: List<CrystalUi> = emptyList(),
    val backgrounds: List<BackgroundUi> = emptyList(),
    val activeBoss: BossUi? = null,
    val activeEvent: CosmicEventUi? = null,
    val challenges: List<ChallengeUi> = emptyList(),
    val dailyMissions: List<DailyMissionUi> = emptyList(),
    val achievements: List<AchievementUi> = emptyList(),
    val loginReward: BigNum = BigNum.ZERO,
    val loginStreak: Int = 0,
    val prestige: PrestigePreview = PrestigePreview(false, 0, BigNum.ZERO, 1.0),
    val stats: StatsUi = StatsUi(),
    val tutorialStep: Int = 0,
    val settings: UserSettings = UserSettings(),
    val offlineReport: OfflineReport? = null,
    val recoveredFromBackup: Boolean = false,
    val notice: String? = null
)
