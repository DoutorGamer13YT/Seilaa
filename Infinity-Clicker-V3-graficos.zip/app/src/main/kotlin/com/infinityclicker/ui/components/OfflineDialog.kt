package com.infinityclicker.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.infinityclicker.audio.Sfx
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.game.OfflineReport
import com.infinityclicker.ui.theme.Neon
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Mote(val x: Float, val y: Float, val r: Float, val lap: Int, val phase: Float, val gold: Boolean)

/**
 * Shader do arco do anel: depende só da cor e do centro, então só é refeito se o centro mudar.
 * Antes um `Brush.sweepGradient` novo (e o shader nativo dele) era criado a cada quadro enquanto o relatório ficava aberto.
 */
private class SweepBrushCache {
    private var brush: Brush? = null
    private var cx = Float.NaN
    private var cy = Float.NaN

    fun get(accent: Color, center: Offset): Brush {
        val cached = brush
        if (cached != null && cx == center.x && cy == center.y) return cached
        cx = center.x
        cy = center.y
        return Brush.sweepGradient(listOf(accent.copy(alpha = 0.35f), accent, Color.White), center).also { brush = it }
    }
}

/**
 * "Bem-vindo de volta": cena animada em vez de um alerta de texto. Um anel mostra quanto do limite offline foi
 * aproveitado (com uma nave na ponta do arco), o ganho de energia sobe contando com sons de tique, os números
 * de apoio entram em cascata e partículas de energia sobem ao fundo. Todos os laços são periódicos
 * (voltas inteiras por ciclo), então recomeçam sem emenda.
 */
@Composable
fun OfflineReportDialog(
    report: OfflineReport,
    scientific: Boolean,
    accent: Color = Neon.Cyan,
    onCollect: () -> Unit
) {
    Dialog(
        onDismissRequest = onCollect,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        OfflineScene(report, scientific, accent, onCollect)
    }
}

@Composable
private fun OfflineScene(report: OfflineReport, scientific: Boolean, accent: Color, onCollect: () -> Unit) {
    val enter = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val count = remember { Animatable(0f) }
    val reveal = remember { Animatable(0f) }
    val capped = report.elapsedMs > report.capMs
    val fraction = if (report.capMs > 0L) (report.creditedMs.toFloat() / report.capMs.toFloat()).coerceIn(0f, 1f) else 1f

    LaunchedEffect(Unit) { enter.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = 220f)) }
    LaunchedEffect(Unit) {
        delay(250)
        ring.animateTo(fraction, tween(1500, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) {
        delay(450)
        SoundFx.play(Sfx.OFFLINE)
        count.animateTo(1f, tween(1800, easing = CubicBezierEasing(0.15f, 0.8f, 0.2f, 1f)))
    }
    LaunchedEffect(Unit) { // tiques subindo de tom enquanto o número conta
        delay(500)
        for (k in 0 until 14) {
            SoundFx.play(Sfx.COUNT_TICK, rate = 0.85f + k * 0.045f, volume = 0.30f)
            delay(112)
        }
    }
    LaunchedEffect(Unit) {
        delay(1000)
        reveal.animateTo(1f, tween(900, easing = LinearEasing))
    }

    val loops = rememberInfiniteTransition(label = "offlineLoops")
    val motion = loops.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "motes")
    val spin = loops.animateFloat(0f, 360f, infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    val pulse = loops.animateFloat(1f, 1.035f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val glowBeat = loops.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "beat")

    val motes = remember {
        val rnd = Random(91)
        List(34) { Mote(rnd.nextFloat(), rnd.nextFloat(), 1.2f + rnd.nextFloat() * 2.6f, 1 + rnd.nextInt(3), rnd.nextFloat(), rnd.nextFloat() > 0.8f) }
    }
    val shipPath = remember {
        Path().apply { moveTo(9f, 0f); lineTo(-5f, 5.5f); lineTo(-2.5f, 0f); lineTo(-5f, -5.5f); close() }
    }
    // Traço tracejado e shader do arco criados uma vez (antes: um PathEffect, um Stroke e um shader novos por quadro).
    val ringMarks = remember { Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f, 13f))) }
    val sweepCache = remember(accent) { SweepBrushCache() }

    Box(Modifier.fillMaxSize().background(Color(0xE6030511)), contentAlignment = Alignment.Center) {
        // Fundo: energia subindo em laço (cada partícula completa voltas inteiras por ciclo).
        Canvas(Modifier.fillMaxSize()) {
            val t = motion.value
            for (m in motes) {
                val y = (((m.y - m.lap * t) % 1f) + 1f) % 1f
                val tw = 0.5f + 0.5f * sin(2f * PI.toFloat() * (t * m.lap + m.phase))
                val c = if (m.gold) Neon.Gold else accent
                drawCircle(c.copy(alpha = 0.10f + 0.22f * tw), m.r * 3f, Offset(m.x * size.width, y * size.height))
                drawCircle(Color.White.copy(alpha = 0.25f + 0.5f * tw), m.r * 0.7f, Offset(m.x * size.width, y * size.height))
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 28.dp)
                .graphicsLayer {
                    val s = 0.82f + 0.18f * enter.value
                    scaleX = s; scaleY = s
                    alpha = enter.value.coerceIn(0f, 1f)
                }
                .glass(RoundedCornerShape(30.dp), tint = accent, alpha = 0.16f, borderAlpha = 0.55f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("RELATÓRIO OFFLINE", color = accent, fontSize = 11.sp, letterSpacing = 4.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Bem-vindo de volta!",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Color.White, accent, Color.White)),
                    fontSize = 26.sp, fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )
            Text("Sua frota continuou trabalhando enquanto você estava fora.", color = Neon.TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)

            // Anel de aproveitamento do limite offline.
            Box(Modifier.size(176.dp).padding(top = 4.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 11.dp.toPx()
                    val rad = (size.minDimension - stroke) / 2f - 6.dp.toPx()
                    val c = Offset(size.width / 2f, size.height / 2f)
                    // Marcas girando devagar (laço de 24 s).
                    rotate(spin.value, c) {
                        drawCircle(
                            accent.copy(alpha = 0.28f), rad + stroke * 0.95f, c,
                            style = ringMarks
                        )
                    }
                    drawCircle(accent.copy(alpha = 0.10f * glowBeat.value), rad + stroke * 0.2f, c)
                    drawCircle(Color.White.copy(alpha = 0.10f), rad, c, style = Stroke(width = stroke))
                    val sweep = 360f * ring.value
                    if (sweep > 0.5f) {
                        rotate(-90f, c) {
                            drawArc(
                                sweepCache.get(accent, c),
                                0f, sweep, false, Offset(c.x - rad, c.y - rad), Size(rad * 2f, rad * 2f),
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                        }
                        // Nave na ponta do arco, apontando na direção do avanço.
                        val a = (-90f + sweep) * PI.toFloat() / 180f
                        val tip = Offset(c.x + cos(a) * rad, c.y + sin(a) * rad)
                        drawCircle(accent.copy(alpha = 0.30f * glowBeat.value), stroke * 1.7f, tip)
                        translate(tip.x, tip.y) {
                            rotate(sweep, Offset.Zero) { drawPath(shipPath, Color.White) }
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TEMPO AUSENTE", color = Neon.TextSecondary, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text(NumberFormatter.duration(report.elapsedMs), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        "creditado ${NumberFormatter.duration(report.creditedMs)}",
                        color = accent, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1
                    )
                }
            }

            // Energia recebida: o número sobe contando.
            Text("ENERGIA RECEBIDA", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 3.sp)
            Text(
                "+" + NumberFormatter.format(report.gain * count.value.toDouble(), scientific),
                style = TextStyle(
                    brush = Brush.verticalGradient(listOf(Color.White, Color.White, Neon.Gold.copy(alpha = 0.9f))),
                    fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, fontFeatureSettings = "tnum"
                ),
                maxLines = 1
            )

            // Números de apoio entram em cascata.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("EFICIÊNCIA", "${"%.0f".format(report.efficiency * 100)}%", Neon.Green, ((reveal.value - 0.0f) / 0.6f).coerceIn(0f, 1f), Modifier.weight(1f))
                StatChip("MULTIPLIC.", "×" + NumberFormatter.format(report.globalMultiplier, scientific), Neon.Violet, ((reveal.value - 0.2f) / 0.6f).coerceIn(0f, 1f), Modifier.weight(1f))
                StatChip("PRODUÇÃO", NumberFormatter.format(report.productionPerSecond, scientific) + "/s", Neon.Gold, ((reveal.value - 0.4f) / 0.6f).coerceIn(0f, 1f), Modifier.weight(1f))
            }
            if (capped) {
                Text(
                    "Limite de ${NumberFormatter.duration(report.capMs)} atingido — volte antes para não deixar ganhos para trás.",
                    color = Neon.Gold, fontSize = 11.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), tint = Neon.Gold, alpha = 0.10f, borderAlpha = 0.30f)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            Spacer(Modifier.height(4.dp))
            Box(
                Modifier.fillMaxWidth()
                    .graphicsLayer { val s = pulse.value; scaleX = s; scaleY = s }
                    .bouncyClick(onClick = onCollect)
                    .glass(RoundedCornerShape(26.dp), tint = accent, alpha = 0.36f, borderAlpha = 0.75f)
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Coletar energia", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, color: Color, appear: Float, modifier: Modifier) {
    Column(
        modifier
            .graphicsLayer { alpha = appear; translationY = (1f - appear) * 24f }
            .glass(RoundedCornerShape(16.dp), tint = color, alpha = 0.16f, borderAlpha = 0.42f)
            .padding(horizontal = 6.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Neon.TextSecondary, fontSize = 8.sp, letterSpacing = 1.2.sp, maxLines = 1)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
