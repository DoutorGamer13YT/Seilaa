package com.infinityclicker.data

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.GameState

/**
 * Base da sincronização com a nuvem — EM DESENVOLVIMENTO. Nada aqui se conecta a um servidor: o jogo continua
 * 100% local (ver FIREBASE_SETUP.md). O que existe é a parte que independe de servidor e pode ser testada:
 * o estado da funcionalidade, o contrato de um provedor e a política que decide quem vence um conflito.
 */
enum class CloudSyncStatus(val label: String, val available: Boolean) {
    IN_DEVELOPMENT("Em desenvolvimento", false)
}

/** Resumo do save guardado no servidor, suficiente para decidir sem baixar o save inteiro. */
data class CloudSaveInfo(val revision: Long, val modifiedMs: Long, val totalEnergy: BigNum)

enum class SyncDecision {
    /** Local e nuvem são o mesmo save. */
    IN_SYNC,
    /** O save local é claramente o mais novo e o mais avançado. */
    UPLOAD,
    /** O save da nuvem é claramente o mais novo e o mais avançado. */
    DOWNLOAD,
    /** Divergência (ex.: outro aparelho jogou offline): quem decide é o jogador. Nunca se apaga save sozinho. */
    ASK_USER
}

object CloudSyncPolicy {
    fun decide(local: GameState, remote: CloudSaveInfo?): SyncDecision {
        if (remote == null) return SyncDecision.UPLOAD
        if (remote.revision == local.saveRevision && remote.modifiedMs == local.lastModifiedMs) return SyncDecision.IN_SYNC
        // "À frente" exige revisão E energia total maiores: um save novo porém com menos progresso é conflito, não vitória.
        val localAhead = local.saveRevision > remote.revision && local.totalEnergy >= remote.totalEnergy
        val remoteAhead = remote.revision > local.saveRevision && remote.totalEnergy >= local.totalEnergy
        return when {
            localAhead -> SyncDecision.UPLOAD
            remoteAhead -> SyncDecision.DOWNLOAD
            else -> SyncDecision.ASK_USER
        }
    }
}

/** Contrato que um provedor real (Firebase, por exemplo) deverá cumprir quando houver um projeto do proprietário. */
interface CloudSaveProvider {
    val status: CloudSyncStatus
    suspend fun fetchInfo(): CloudSaveInfo?
    suspend fun upload(saveText: String): Boolean
    suspend fun download(): String?
}

/** Provedor atual: não existe servidor, portanto toda operação falha de forma explícita e segura. */
object UnavailableCloudProvider : CloudSaveProvider {
    override val status = CloudSyncStatus.IN_DEVELOPMENT
    override suspend fun fetchInfo(): CloudSaveInfo? = null
    override suspend fun upload(saveText: String): Boolean = false
    override suspend fun download(): String? = null
}

object CloudSync {
    val provider: CloudSaveProvider = UnavailableCloudProvider
}
