package dev.atlas.network

import dev.atlas.core.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class RealRoutingRepository(
    client: OkHttpClient,
    osrmBaseUrl: String,
    orsBaseUrl: String,
    private val orsApiKey: String,
) : RoutingRepository {
    private val http = ProviderHttp(client)
    private val osrm = validatedBaseUrl(osrmBaseUrl)
    private val ors = validatedBaseUrl(orsBaseUrl)
    private val pacer = RequestPacer(1_100)
    // Never return stale routing data after a failed recalculation.
    private val cache = ProviderCache<List<Route>>(12, 60_000)
    override val supportedModes: Set<TransportMode> = if (orsApiKey.isBlank()) setOf(TransportMode.CAR)
        else setOf(TransportMode.CAR, TransportMode.WALK, TransportMode.BIKE)

    override suspend fun routes(points: List<Coordinate>, mode: TransportMode): List<Route> {
        if (points.size !in 2..8) throw AppException(ErrorKind.INVALID_INPUT, "Defina origem, destino e no máximo seis paradas.")
        if (points.zipWithNext().any { (first, second) -> first.distanceTo(second) < 1 })
            throw AppException(ErrorKind.INVALID_INPUT, "Escolha pontos diferentes para origem, destino e paradas consecutivas.")
        if (mode !in supportedModes) throw AppException(ErrorKind.MISSING_KEY, "Configure a chave openrouteservice para rotas a pé e de bicicleta.")
        val key = "$mode|${points.joinToString(";") { "${it.longitude},${it.latitude}" }}"
        cache.get(key)?.let { return it }
        pacer.awaitTurn()
        val result = if (mode == TransportMode.CAR) osrmRoutes(points) else orsRoutes(points, mode)
        if (result.isEmpty()) throw AppException(ErrorKind.NO_ROUTE, "Não foi encontrada uma rota entre estes pontos.")
        cache.put(key, result)
        return result
    }

    private suspend fun osrmRoutes(points: List<Coordinate>): List<Route> {
        val coordinates = points.joinToString(";") { "${it.longitude},${it.latitude}" }
        val url = osrm.newBuilder().addPathSegments("route/v1/driving").addPathSegment(coordinates)
            .addQueryParameter("geometries", "geojson")
            .addQueryParameter("steps", "true")
            .addQueryParameter("alternatives", "true")
            .addQueryParameter("overview", "full")
            .addQueryParameter("generate_hints", "false")
            .build()
        val body = http.execute(Request.Builder().url(url).build(), allowRoutingErrorBody = true)
        return parseResponse { RoutingParsers.osrm(body, points) }
    }

    private suspend fun orsRoutes(points: List<Coordinate>, mode: TransportMode): List<Route> {
        val profile = when (mode) {
            TransportMode.CAR -> "driving-car"
            TransportMode.WALK -> "foot-walking"
            TransportMode.BIKE -> "cycling-regular"
        }
        val payload = JSONObject().put("coordinates", JSONArray().apply {
            points.forEach { put(JSONArray().put(it.longitude).put(it.latitude)) }
        }).put("instructions", true).put("language", "pt").put("units", "m")
        // ORS alternatives are restricted to two waypoints and shorter routes.
        if (points.size == 2 && points.first().distanceTo(points.last()) < 40_000) {
            payload.put("alternative_routes", JSONObject().put("target_count", 2).put("share_factor", 0.6).put("weight_factor", 1.4))
        }
        val url = ors.newBuilder().addPathSegments("v2/directions").addPathSegment(profile).addPathSegment("geojson").build()
        val body = http.execute(Request.Builder().url(url).header("Authorization", orsApiKey.trim())
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build(), allowRoutingErrorBody = true)
        return parseResponse { RoutingParsers.ors(body, points, mode) }
    }
}

internal object RoutingParsers {
    fun osrm(body: String, requestedPoints: List<Coordinate>): List<Route> {
        val json = JSONObject(body)
        when (json.optString("code")) {
            "Ok" -> Unit
            "NoRoute", "NoSegment" -> throw AppException(ErrorKind.NO_ROUTE, "Não foi encontrada uma rota viável entre estes pontos.")
            "InvalidQuery", "InvalidValue", "InvalidOptions", "TooBig" -> throw AppException(ErrorKind.INVALID_INPUT, "O serviço não aceitou os pontos ou opções desta rota.")
            else -> throw AppException(ErrorKind.PROVIDER, "Não foi possível calcular a rota neste momento.")
        }
        return json.getJSONArray("routes").objects().mapIndexed { index, route ->
            val geometry = geometry(route.getJSONObject("geometry"))
            val legs = route.getJSONArray("legs").objects()
            val steps = legs.flatMapIndexed { legIndex, leg -> leg.getJSONArray("steps").objects().map { step ->
                val maneuver = step.getJSONObject("maneuver")
                val coordinate = ProviderParsers.coordinate(maneuver.getJSONArray("location"))
                    ?: throw AppException(ErrorKind.PROVIDER, "A rota contém uma manobra inválida.")
                val type = maneuver.getString("type")
                val modifier = maneuver.optString("modifier")
                val street = step.text("name") ?: step.text("ref") ?: ""
                RouteStep(
                    instruction = if (type == "arrive" && legIndex < legs.lastIndex) "Você chegou à parada"
                        else osrmInstruction(type, modifier, street, maneuver.optInt("exit", 0)),
                    street = street, distanceMeters = metric(step, "distance"), durationSeconds = metric(step, "duration"),
                    coordinate = coordinate,
                    maneuver = when { type == "arrive" && legIndex < legs.lastIndex -> "waypoint"; type == "arrive" -> "arrive"; type.contains("roundabout") || type.contains("rotary") -> "roundabout"; modifier.isNotBlank() -> modifier; else -> type },
                )
            } }
            validateSteps(steps)
            Route(
                id = "osrm-$index-${geometry.hashCode()}", geometry = geometry,
                distanceMeters = metric(route, "distance"), durationSeconds = metric(route, "duration"),
                steps = steps, mode = TransportMode.CAR, source = "OSRM · OpenStreetMap",
                summary = legs.mapNotNull { it.text("summary") }.distinct().joinToString(" · "),
                waypoints = requestedPoints,
            )
        }.also { if (it.isEmpty()) throw AppException(ErrorKind.NO_ROUTE, "Não foi encontrada uma rota entre estes pontos.") }
    }

    fun ors(body: String, requestedPoints: List<Coordinate>, mode: TransportMode): List<Route> {
        val json = JSONObject(body)
        json.optJSONObject("error")?.let { error ->
            val kind = when (error.optInt("code")) {
                2009, 2010 -> ErrorKind.NO_ROUTE
                2000, 2001, 2002, 2003, 2004, 2007, 2011 -> ErrorKind.INVALID_INPUT
                else -> ErrorKind.PROVIDER
            }
            throw AppException(kind, if (kind == ErrorKind.NO_ROUTE) "Não foi encontrada uma rota viável entre estes pontos." else "O serviço não conseguiu calcular esta rota. Verifique os pontos e tente novamente.")
        }
        return json.getJSONArray("features").objects().mapIndexed { index, feature ->
            val geometry = geometry(feature.getJSONObject("geometry"))
            val properties = feature.getJSONObject("properties")
            val summary = properties.getJSONObject("summary")
            val segments = properties.getJSONArray("segments").objects()
            val steps = segments.flatMapIndexed { segmentIndex, segment -> segment.getJSONArray("steps").objects().map { step ->
                val pointIndex = step.getJSONArray("way_points").getInt(0)
                val coordinate = geometry.getOrNull(pointIndex)
                    ?: throw AppException(ErrorKind.PROVIDER, "A rota contém uma manobra inválida.")
                RouteStep(
                    instruction = if (step.optInt("type") == 10 && segmentIndex < segments.lastIndex) "Você chegou à parada"
                        else step.text("instruction") ?: throw AppException(ErrorKind.PROVIDER, "O serviço não enviou as instruções desta rota."),
                    street = step.text("name")?.takeUnless { it == "-" } ?: "",
                    distanceMeters = metric(step, "distance"), durationSeconds = metric(step, "duration"),
                    coordinate = coordinate, maneuver = if (step.getInt("type") == 10 && segmentIndex < segments.lastIndex) "waypoint" else orsManeuver(step.getInt("type")),
                )
            } }
            validateSteps(steps)
            Route("ors-$index-${geometry.hashCode()}", geometry, metric(summary, "distance"), metric(summary, "duration"),
                steps, mode, "openrouteservice / HeiGIT · OpenStreetMap", waypoints = requestedPoints)
        }.also { if (it.isEmpty()) throw AppException(ErrorKind.NO_ROUTE, "Não foi encontrada uma rota entre estes pontos.") }
    }

    fun osrmInstruction(type: String, modifier: String, street: String, exit: Int): String {
        val direction = when (modifier) {
            "left" -> "à esquerda"; "right" -> "à direita"
            "slight left" -> "levemente à esquerda"; "slight right" -> "levemente à direita"
            "sharp left" -> "acentuadamente à esquerda"; "sharp right" -> "acentuadamente à direita"
            "straight" -> "em frente"; "uturn" -> "faça o retorno"; else -> ""
        }
        val instruction = when {
            type == "arrive" -> "Você chegou ao destino"
            type == "depart" -> "Siga ${direction.ifBlank { "pela rota" }}"
            type in setOf("roundabout", "rotary") -> if (exit > 0) "Na rotatória, pegue a ${exit}ª saída" else "Entre na rotatória"
            type in setOf("exit roundabout", "exit rotary") -> "Saia da rotatória"
            type == "roundabout turn" -> "Na rotatória, siga ${direction.ifBlank { "pela rota" }}"
            modifier == "uturn" -> "Faça o retorno"
            type == "fork" -> "Mantenha-se ${direction.ifBlank { "na rota" }}"
            type == "merge" -> "Entre na via ${direction.ifBlank { "indicada" }}"
            type == "on ramp" -> "Acesse a rampa ${direction.ifBlank { "indicada" }}"
            type == "off ramp" -> "Pegue a saída ${direction.ifBlank { "indicada" }}"
            type == "end of road" -> "No final da via, vire ${direction.ifBlank { "pela rota" }}"
            type == "turn" && modifier != "straight" -> "Vire ${direction.ifBlank { "pela rota" }}"
            else -> "Continue ${direction.ifBlank { "pela rota" }}"
        }.trim()
        return if (street.isNotBlank() && type != "arrive") "$instruction em $street" else instruction
    }

    private fun orsManeuver(type: Int): String = when (type) {
        0 -> "left"; 1 -> "right"; 2 -> "sharp left"; 3 -> "sharp right"; 4 -> "slight left"; 5 -> "slight right"
        7, 8 -> "roundabout"; 9 -> "uturn"; 10 -> "arrive"; 11 -> "depart"; 12 -> "slight left"; 13 -> "slight right"
        else -> "straight"
    }

    private fun geometry(json: JSONObject): List<Coordinate> {
        if (json.optString("type") != "LineString") throw AppException(ErrorKind.PROVIDER, "O serviço não enviou um traçado de rota válido.")
        val coordinates = json.getJSONArray("coordinates")
        if (coordinates.length() < 2 || coordinates.length() > 100_000) throw AppException(ErrorKind.PROVIDER, "O traçado da rota está vazio ou é grande demais.")
        return (0 until coordinates.length()).map { index ->
            ProviderParsers.coordinate(coordinates.optJSONArray(index))
                ?: throw AppException(ErrorKind.PROVIDER, "O serviço enviou um ponto inválido no traçado.")
        }
    }

    private fun metric(json: JSONObject, key: String): Double = json.getDouble(key).also {
        if (!it.isFinite() || it < 0) throw AppException(ErrorKind.PROVIDER, "O serviço enviou distância ou duração inválida.")
    }

    private fun validateSteps(steps: List<RouteStep>) {
        if (steps.isEmpty() || steps.last().maneuver != "arrive")
            throw AppException(ErrorKind.PROVIDER, "O serviço enviou uma rota sem instruções completas. Tente calcular novamente.")
    }
}
