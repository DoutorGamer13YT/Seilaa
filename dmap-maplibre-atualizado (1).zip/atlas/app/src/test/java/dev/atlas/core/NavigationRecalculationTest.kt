package dev.atlas.core

import dev.atlas.location.remainingRoutePoints
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationRecalculationTest {
    private val geometry = (0..4).map { Coordinate(0.0, it * 0.001) }
    private val route = Route("stops", geometry, 440.0, 100.0, emptyList(), TransportMode.CAR,
        "test fixture", waypoints = listOf(geometry[0], geometry[1], geometry[3], geometry[4]))
    private val origin = Coordinate(0.001, 0.002)
    private fun progress(segment: Int) = NavigationProgress(
        0, "", 0.0, 0.0, 0.0, true, false, null, segmentIndex = segment,
    )

    @Test fun allUnpassedStopsRemainInTheirOriginalOrder() {
        assertEquals(listOf(origin, geometry[1], geometry[3], geometry[4]),
            remainingRoutePoints(route, origin, progress(0)))
    }

    @Test fun passedStopIsExcludedUsingTheMatchedRouteSegment() {
        assertEquals(listOf(origin, geometry[3], geometry[4]),
            remainingRoutePoints(route, origin, progress(2)))
    }

    @Test fun finalDestinationRemainsAfterEveryIntermediateStop() {
        assertEquals(listOf(origin, geometry[4]), remainingRoutePoints(route, origin, progress(3)))
    }

    @Test fun proximityToAFutureStopDoesNotSilentlySkipIt() {
        assertEquals(listOf(geometry[3], geometry[1], geometry[3], geometry[4]),
            remainingRoutePoints(route, geometry[3], progress(0)))
    }

    @Test fun repeatedStopsAreMatchedSequentiallyOnAReturningRoute() {
        val a = Coordinate(0.0, 0.0)
        val b = Coordinate(0.0, 0.001)
        val c = Coordinate(0.001, 0.001)
        val d = Coordinate(0.0, 0.002)
        val loop = route.copy(geometry = listOf(a, b, c, b, d), waypoints = listOf(a, b, c, b, d))
        assertEquals(listOf(origin, b, d), remainingRoutePoints(loop, origin, progress(2)))
    }

    @Test fun routeWithoutWaypointMetadataUsesTheGeometryDestination() {
        assertEquals(listOf(origin, geometry.last()),
            remainingRoutePoints(route.copy(waypoints = emptyList()), origin, progress(2)))
    }

    @Test fun invalidProgressIndexIsBoundedWithoutDroppingTheDestination() {
        assertEquals(listOf(origin, geometry.last()), remainingRoutePoints(route, origin, progress(Int.MAX_VALUE)))
        assertEquals(listOf(origin, geometry[1], geometry[3], geometry[4]),
            remainingRoutePoints(route, origin, progress(-1)))
    }

    @Test fun missingRouteDestinationCannotCreateAFictitiousRoute() {
        assertTrue(remainingRoutePoints(route.copy(geometry = emptyList(), waypoints = emptyList()), origin, progress(0)).isEmpty())
    }
}
