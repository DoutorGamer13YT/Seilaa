// Versões fixadas e compatíveis entre si:
//   Gradle 8.14.3 • AGP 8.9.2 • Kotlin 2.0.21 (+ plugin do compilador Compose) • Compose BOM 2024.12.01
plugins {
    id("com.android.application") version "8.9.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
