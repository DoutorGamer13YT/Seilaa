package com.infinityclicker.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import com.infinityclicker.ui.components.GlassChip
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.LocalMotionEnabled
import com.infinityclicker.ui.components.Motion
import com.infinityclicker.ui.components.bumpOnChange
import com.infinityclicker.ui.components.flashOnChange
import com.infinityclicker.ui.components.enterAnimation
import kotlinx.coroutines.launch

import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Box
import androidx.compose.animation.core.tween
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import com.infinityclicker.ui.components.SegmentedControl
import com.infinityclicker.ui.components.drawPadlock
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.PurchasePlan
import com.infinityclicker.ui.GeneratorRow
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.UpgradeRow
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.components.bouncyClick
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.color
import com.infinityclicker.upgrades.ShopCategory

private val sections = listOf("Geradores") + ShopCategory.values().map { it.label }
private val Ready = Neon.Green

@Composable
fun ShopScreen(
    ui: UiState,
    onBuyMode: (BuyMode) -> Unit,
    onBuyGenerator: (Int) -> Unit,
    onBuyUpgrade: (String) -> Unit
) {
    var section by rememberSaveable { mutableIntStateOf(0) }
    val sci = ui.settings.scientificNotation
    // Um só lambda por notação: os cartões recebem sempre a mesma instância e podem pular a recomposição.
    val f: (BigNum) -> String = remember(sci) { { n: BigNum -> NumberFormatter.format(n, sci) } }
    val modes = remember { BuyMode.values().toList() }

    // Bolinha verde nas seções que têm algo que dá para comprar agora: dá para ver de relance onde gastar.
    val ready = remember(ui.generators, ui.upgrades) {
        BooleanArray(sections.size).also { r ->
            r[0] = ui.generators.any { it.unlocked && it.plan.affordable && it.plan.count > 0 }
            ShopCategory.values().forEachIndexed { i, cat ->
                r[i + 1] = ui.upgrades.any { it.def.category == cat && it.unlocked && !it.maxed && it.plan.affordable && it.plan.count > 0 }
            }
        }
    }

    // Agrupado uma vez por mudança da lista (antes, um filter() novo a cada publicação do estado).
    val upgradesByCategory = remember(ui.upgrades) { ui.upgrades.groupBy { it.def.category } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = ui.settings.panelOpacity) {
            Text("ENERGIA", color = Neon.TextSecondary, fontSize = 10.sp, letterSpacing = 2.sp)
            // Folga à direita: o botão de ajustes flutua no canto e cobria a ponta do cartão.
            Text(f(ui.energy), color = Neon.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(end = 48.dp))
            Text("+${f(ui.production)} por segundo", color = Neon.Cyan, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }

        Text("QUANTIDADE POR COMPRA", color = Neon.TextSecondary, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 12.dp, start = 4.dp, bottom = 5.dp))
        SegmentedControl(modes.map { it.label }, modes.indexOf(ui.buyMode).coerceAtLeast(0), { onBuyMode(modes[it]) }, tint = Neon.Violet, height = 40.dp, fontSize = 14.sp)

        LazyRow(
            Modifier.padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(sections.size) { i ->
                GlassChip(sections[i], selected = section == i, tint = Neon.Cyan, onClick = { section = i }, badge = ready[i] && section != i)
            }
        }

        // Troca de seção: a lista nova desliza para dentro na direção da aba escolhida enquanto a antiga some.
        AnimatedContent(
            targetState = section,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                ((fadeIn(tween(240, delayMillis = 70, easing = Motion.Emphasized)) +
                    slideInHorizontally(tween(320, delayMillis = 70, easing = Motion.Emphasized)) { dir * it / 14 }) togetherWith
                    (fadeOut(tween(90)) + slideOutHorizontally(tween(160, easing = Motion.Emphasized)) { -dir * it / 20 })).using(null)
            },
            label = "shopSection"
        ) { sec ->
            LazyColumn(
                Modifier.fillMaxSize().padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                if (sec == 0) {
                    itemsIndexed(ui.generators, key = { _, row -> row.def.id }, contentType = { _, _ -> "generator" }) { index, row ->
                        val enter = remember(index) { Modifier.enterAnimation(index) }
                        // A energia só entra no cartão que mostra "faltam X": os que dá para comprar (ou bloqueados) não recompõem a cada publicação.
                        val needsEnergy = row.unlocked && !(row.plan.affordable && row.plan.count > 0)
                        GeneratorCard(row, if (needsEnergy) ui.energy else BigNum.ZERO, f, ui.settings.panelOpacity, Modifier.animateItem().then(enter)) { onBuyGenerator(row.def.id) }
                    }
                } else {
                    val cat = ShopCategory.values()[sec - 1]
                    val visible = upgradesByCategory[cat].orEmpty()
                    itemsIndexed(visible, key = { _, row -> row.def.id }, contentType = { _, _ -> "upgrade" }) { index, row ->
                        val enter = remember(index) { Modifier.enterAnimation(index) }
                        val needsEnergy = row.unlocked && !row.maxed && !(row.plan.affordable && row.plan.count > 0)
                        UpgradeCard(row, if (needsEnergy) ui.energy else BigNum.ZERO, f, ui.settings.panelOpacity, Modifier.animateItem().then(enter)) { onBuyUpgrade(row.def.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GeneratorCard(row: GeneratorRow, energy: BigNum, f: (BigNum) -> String, alpha: Float, modifier: Modifier, onBuy: () -> Unit) {
    val tint = row.def.rarity.color()
    val shown = if (row.plan.count > 0) row.plan.count else 1L
    ShopCard(
        title = row.def.name, badge = "×${row.owned}",
        rarity = if (row.isBest && row.unlocked) "${row.def.rarity.label} · ★ MELHOR COMPRA" else row.def.rarity.label,
        description = row.def.description,
        tint = tint, alpha = alpha, modifier = modifier,
        locked = !row.unlocked, lockedText = "Bloqueado: compre o gerador anterior.",
        maxed = false, energy = energy, plan = row.plan, f = f,
        label = "Comprar ×$shown", onBuy = onBuy,
        etaText = row.etaSeconds?.let { NumberFormatter.duration((it * 1000.0).coerceAtMost(9.0e15).toLong()) }
    ) {
        StatBox("Cada um", "${f(row.unitProduction)}/s", Neon.TextPrimary)
        StatBox("Total", "${f(row.totalProduction)}/s", Neon.Cyan)
        StatBox("Marco ×2", "faltam ${(row.nextMilestone - row.owned).coerceAtLeast(0)}", Neon.Gold)
    }
}

@Composable
private fun UpgradeCard(row: UpgradeRow, energy: BigNum, f: (BigNum) -> String, alpha: Float, modifier: Modifier, onBuy: () -> Unit) {
    val tint = row.def.rarity.color()
    ShopCard(
        title = row.def.name, badge = "${row.level}/${row.def.maxLevel}", rarity = row.def.rarity.label, description = row.def.description,
        tint = tint, alpha = alpha, modifier = modifier,
        locked = !row.unlocked, lockedText = "Bloqueado: ${row.def.requirement.describe()}",
        maxed = row.maxed, energy = energy, plan = row.plan, f = f,
        label = "Evoluir +${if (row.plan.count > 0) row.plan.count else 1}", onBuy = onBuy
    ) {
        StatBox("Efeito atual", row.def.effectText(row.level), Neon.TextPrimary)
        if (!row.maxed) StatBox("Próximo nível", row.def.effectText(row.level + 1), Neon.Green)
    }
}

/**
 * Cartão de compra padrão: título e quantidade possuída em destaque, números-chave em caixinhas e UM botão grande
 * que mostra o preço e, quando falta energia, quanto falta e uma barra de progresso até poder comprar.
 * Cartões que dá para comprar agora ficam mais brilhantes; bloqueados ficam apagados.
 */
@Composable
private fun ShopCard(
    title: String, badge: String, rarity: String, description: String,
    tint: Color, alpha: Float, modifier: Modifier,
    locked: Boolean, lockedText: String, maxed: Boolean,
    energy: BigNum, plan: PurchasePlan, f: (BigNum) -> String,
    label: String, onBuy: () -> Unit,
    etaText: String? = null,
    stats: @Composable RowScope.() -> Unit
) {
    val canBuy = !locked && !maxed && plan.affordable && plan.count > 0
    val cardAlpha = when { canBuy -> (alpha + 0.10f).coerceAtMost(0.34f); locked -> alpha * 0.55f; else -> alpha }
    GlassCard(modifier.fillMaxWidth().flashOnChange(badge, Ready), tint = if (canBuy) Ready else tint, alpha = cardAlpha) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = if (locked) Neon.TextSecondary else Neon.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    rarity, color = tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(top = 3.dp).glass(RoundedCornerShape(50), tint = tint, alpha = 0.16f, borderAlpha = 0.40f).padding(horizontal = 9.dp, vertical = 2.dp)
                )
            }
            Text(
                badge, color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center,
                modifier = Modifier.bumpOnChange(badge).glass(RoundedCornerShape(14.dp), tint = tint, alpha = 0.20f, borderAlpha = 0.45f).padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        Text(description, color = Neon.TextSecondary, fontSize = 13.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp))
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), content = stats)
        when {
            maxed -> StatusLine("Nível máximo", Neon.Green, false)
            locked -> StatusLine(lockedText, Neon.Pink, true)
            else -> {
                val progress = if (canBuy) 1f else progressOf(energy, plan.cost)
                BuyButton(
                    label, f(plan.cost), canBuy, if (canBuy) Ready else tint, onBuy, Modifier.fillMaxWidth().padding(top = 10.dp),
                    subtitle = if (canBuy) null else "Faltam ${f(plan.cost - energy)} · ${(progress * 100).toInt()}%" + (etaText?.let { " · em $it" } ?: ""), progress = progress
                )
            }
        }
    }
}

private fun progressOf(energy: BigNum, cost: BigNum): Float =
    if (cost.isZero) 1f else (energy / cost).toDouble().toFloat().coerceIn(0f, 1f)

@Composable
private fun RowScope.StatBox(label: String, value: String, color: Color) {
    Column(
        Modifier.weight(1f).background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(12.dp)).padding(horizontal = 9.dp, vertical = 6.dp)
    ) {
        Text(label.uppercase(), color = Neon.TextSecondary, fontSize = 9.sp, letterSpacing = 0.8.sp, maxLines = 1)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 15.sp)
    }
}

@Composable
private fun StatusLine(text: String, color: Color, lock: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp).background(color.copy(alpha = 0.12f), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (lock) Canvas(Modifier.size(18.dp)) { drawPadlock(color) }
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Botão de compra padrão do jogo (loja, dimensões, habilidades, missões). Cheio e colorido quando dá para comprar;
 * senão fica apagado e a barra interna mostra o [progress] da energia já juntada. [subtitle] explica o que falta.
 *
 * Movimento: a troca entre apagado e aceso é um fade (não um salto), a barra de progresso corre com mola, ao ficar
 * comprável o botão dá um pulinho, um brilho diagonal varre o botão aceso e cada toque solta um clarão.
 * Tudo isso é lido só na hora do desenho, então não recompõe nada.
 */
@Composable
internal fun BuyButton(
    label: String, price: String?, enabled: Boolean, tint: Color, onClick: () -> Unit,
    modifier: Modifier = Modifier, subtitle: String? = null, progress: Float = 1f,
    height: androidx.compose.ui.unit.Dp = 54.dp, compact: Boolean = false
) {
    val motion = LocalMotionEnabled.current
    val ticker = LocalFrameTicker.current
    val scope = rememberCoroutineScope()
    val ready = animateFloatAsState(if (enabled) 1f else 0f, tween(320, easing = Motion.Emphasized), label = "buyReady")
    val fillP = animateFloatAsState(progress.coerceIn(0f, 1f), spring(dampingRatio = 0.9f, stiffness = 180f), label = "buyProgress")
    val ink by animateColorAsState(if (enabled) Neon.Bg else Neon.TextPrimary, tween(240), label = "buyInk")
    val flash = remember { Animatable(0f) }
    val pop = remember { Animatable(1f) }
    val wasEnabled = remember { booleanArrayOf(enabled) }
    LaunchedEffect(enabled) {
        if (enabled && !wasEnabled[0] && motion) {
            pop.snapTo(1.05f)
            pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 500f))
        }
        wasEnabled[0] = enabled
    }
    val sweepSeed = remember(label) { (label.hashCode() and 0x7fffffff) % 3_000L }
    val fire: () -> Unit = {
        if (motion) scope.launch {
            flash.snapTo(1f)
            flash.animateTo(0f, tween(420, easing = LinearOutSlowInEasing))
        }
        onClick()
    }
    Box(
        modifier.height(height)
            .graphicsLayer { scaleX = pop.value; scaleY = pop.value }
            .bouncyClick(enabled = enabled, onClick = fire)
            .clip(RoundedCornerShape(16.dp))
            .drawWithCache {
                val on = Brush.verticalGradient(listOf(tint.copy(alpha = 0.98f), tint.copy(alpha = 0.72f)))
                val off = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.05f)))
                val sheen = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.34f), Color.Transparent), 0f, size.height * 0.55f)
                val rim = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.70f), Color.White.copy(alpha = 0.06f)))
                val stroke = Stroke(1.dp.toPx())
                // Faixa diagonal do brilho que varre o botão: um Path só, criado por tamanho e apenas deslocado a cada quadro.
                val bandW = size.height * 0.9f
                val band = Path().apply {
                    moveTo(0f, 0f); lineTo(bandW, 0f); lineTo(bandW - size.height * 0.5f, size.height); lineTo(-size.height * 0.5f, size.height); close()
                }
                onDrawBehind {
                    val r = ready.value
                    drawRect(off, alpha = 1f - r)
                    drawRect(on, alpha = r)
                    if (progress < 1f && r < 0.999f) {
                        drawRect(tint.copy(alpha = 0.30f), size = androidx.compose.ui.geometry.Size(size.width * fillP.value, size.height), alpha = 1f - r)
                    }
                    drawRect(sheen, alpha = 0.24f + 0.76f * r)
                    if (motion && r > 0.9f) {
                        val cycle = 3_600L
                        val p = ((ticker.value / 1_000_000L + sweepSeed) % cycle) / cycle.toFloat()
                        if (p < 0.42f) {
                            val q = p / 0.42f
                            val x = -bandW + q * (size.width + bandW * 2f)
                            translate(x, 0f) { drawPath(band, Color.White.copy(alpha = 0.20f * kotlin.math.sin(q * Math.PI.toFloat()))) }
                        }
                    }
                    val f = flash.value
                    if (f > 0.01f) drawRect(Color.White.copy(alpha = 0.55f * f))
                    drawRect(rim, alpha = 0.26f + 0.74f * r, style = stroke)
                }
            }
            .padding(horizontal = if (compact) 10.dp else 14.dp),
        contentAlignment = if (compact) Alignment.Center else Alignment.CenterStart
    ) {
        val fs = if (compact) 12.sp else if (height < 48.dp) 14.sp else 16.sp
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = if (compact) Arrangement.Center else Arrangement.spacedBy(8.dp)) {
            Column(if (compact) Modifier else Modifier.weight(1f), horizontalAlignment = if (compact) Alignment.CenterHorizontally else Alignment.Start) {
                Text(label, color = ink, fontWeight = FontWeight.Bold, fontSize = fs, maxLines = 1)
                if (subtitle != null) Text(subtitle, color = Neon.TextSecondary, fontSize = 11.sp, maxLines = 1)
            }
            if (price != null) Text(price, color = ink, fontWeight = FontWeight.Bold, fontSize = fs, maxLines = 1)
        }
    }
}
