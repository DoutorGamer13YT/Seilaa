package com.infinityclicker.ui.components

import android.app.Activity
import android.os.Build
import android.view.Display
import android.view.WindowManager

/** Resultado do pedido de taxa de atualização: o que a tela vai usar e quantos fps as animações terão. */
data class FrameRatePlan(val modeId: Int, val displayHz: Float, val animationFps: Float)

/**
 * Escolhe, entre os modos de mesma resolução, o que melhor entrega [cap] fps com quadros uniformes.
 * Cada modo r é avaliado com o divisor inteiro d = round(r/cap); o erro é |r/d − cap|.
 * Empate (ex.: 90 em tela 60/120 Hz) vai para a taxa maior, que é mais fluida.
 */
fun planFrameRate(display: Display?, cap: Int): FrameRatePlan? {
    display ?: return null
    val current = display.mode
    val modes = display.supportedModes.filter {
        it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight
    }.ifEmpty { listOf(current) }
    val best = modes.minWith(
        compareBy<Display.Mode> { mode ->
            val d = frameDivisor(mode.refreshRate, cap).toFloat()
            kotlin.math.abs(mode.refreshRate / d - cap)
        }.thenByDescending { mode -> mode.refreshRate / frameDivisor(mode.refreshRate, cap) }
            .thenBy { it.refreshRate }
    )
    return FrameRatePlan(best.modeId, best.refreshRate, best.refreshRate / frameDivisor(best.refreshRate, cap))
}

/**
 * Pede o modo ao sistema por todas as vias disponíveis: o modo exato, a taxa preferida, a faixa
 * mín/máx (Android 14+) e a taxa pedida pela view (Android 15+). One UI costuma respeitar só algumas.
 */
fun Activity.applyFrameRate(plan: FrameRatePlan) {
    val attrs: WindowManager.LayoutParams = window.attributes
    attrs.preferredDisplayModeId = plan.modeId
    attrs.preferredRefreshRate = plan.displayHz
    window.attributes = attrs
    if (Build.VERSION.SDK_INT >= 35) window.decorView.requestedFrameRate = plan.displayHz
}
