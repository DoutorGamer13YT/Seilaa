package com.infinityclicker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import com.infinityclicker.ui.components.glass
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.CrystalArea
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun HomeScreen(ui: UiState, onTap: () -> TapResult?, onUseAbility: (String) -> Unit) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    val crystal = ui.crystals.firstOrNull { it.equipped }?.def
    val dimension = ui.dimensions.firstOrNull { it.current }?.def

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val accent = dimension?.tintColor ?: Neon.Cyan
        // Cabeçalho: a energia é a estrela da tela, centralizada e com degradê; o resto vira etiquetas de vidro.
        Column(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Tag(dimension?.name ?: "Primordial", accent)
                Tag(crystal?.name ?: "Éter Azul", crystal?.tintColor ?: Neon.Cyan)
            }
            Text("ENERGIA", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 10.dp))
            Text(
                f(ui.energy),
                style = TextStyle(
                    brush = Brush.verticalGradient(listOf(Color.White, Color.White, accent.copy(alpha = 0.85f))),
                    fontSize = 42.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp,
                    shadow = Shadow(accent.copy(alpha = 0.55f), Offset(0f, 0f), 22f)
                ),
                maxLines = 1
            )
            Text(
                "+${f(ui.production)} / s", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 2.dp).glass(RoundedCornerShape(50), tint = accent, alpha = 0.18f, borderAlpha = 0.45f)
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }

        val renderQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
        CrystalArea(
            tier = (ui.stats.totalEnergy.exponent / 3L).toInt(),
            crystalStyle = crystal?.id ?: 0,
            baseColor = crystal?.tintColor ?: Neon.Cyan,
            comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f,
            effectsIntensity = ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.5f else renderQuality.particleScale,
            particleLimit = (150f * ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.3f else renderQuality.particleScale).toInt(),
            quality = renderQuality,
            hapticsEnabled = ui.settings.hapticsEnabled,
            motionEnabled = !ui.settings.batterySaver,
            formatGain = { r -> f(r.gain) },
            onTap = onTap,
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        ui.activeBoss?.let { boss ->
            val fraction = (boss.active.health / boss.maxHealth).toDouble().toFloat().coerceIn(0f, 1f)
            GlassCard(Modifier.fillMaxWidth(), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("⚠ ${ui.dimensions.firstOrNull { it.def.id == boss.active.dimensionId }?.def?.bossName ?: "Chefe"}", color = Neon.Pink, fontWeight = FontWeight.Bold)
                    Text("${NumberFormatter.duration(boss.remainingMs)}", color = Neon.Gold, fontSize = 12.sp)
                }
                LinearProgressIndicator(
                    progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(7.dp),
                    color = Neon.Pink, trackColor = Color.White.copy(alpha = 0.12f)
                )
                Text("Vida: ${f(boss.active.health)} · cada toque causa dano real", color = Neon.TextSecondary, fontSize = 12.sp)
            }
        }

        ui.activeEvent?.let { event ->
            GlassCard(Modifier.fillMaxWidth(), tint = Color(event.def.tintArgb), alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("✦ ${event.def.name}", color = Color(event.def.tintArgb), fontWeight = FontWeight.Bold)
                    Text(NumberFormatter.duration(event.remainingMs), color = Neon.Gold, fontSize = 12.sp)
                }
                Text(event.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
        }

        AbilityStrip(ui.abilities, sci, onUseAbility)

        val comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f
        Column(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), tint = Neon.Violet, alpha = ui.settings.panelOpacity + 0.04f, borderAlpha = 0.45f)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Metric("CLIQUE", "+${f(ui.clickGain)}", Neon.TextPrimary)
                Metric("CRÍTICO", "${"%.0f".format(ui.critChance * 100)}% · ×${"%.1f".format(ui.critMultiplier)}", Neon.Gold, Alignment.CenterHorizontally)
                Metric("COMBO", "${ui.combo}/${ui.maxCombo} · ×${"%.2f".format(ui.comboMultiplier)}", Neon.Green, Alignment.End)
            }
            Box(
                Modifier.fillMaxWidth().padding(top = 10.dp).height(6.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.10f))
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(comboFraction.coerceIn(0f, 1f)).clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Neon.Green.copy(alpha = 0.6f), Neon.Cyan, Neon.Violet)))
                )
            }
        }
        Text(
            tutorialText(ui.tutorialStep), color = Neon.TextSecondary, fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp, maxLines = 1,
        modifier = Modifier.glass(RoundedCornerShape(50), tint = color, alpha = 0.14f, borderAlpha = 0.40f).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
private fun Metric(label: String, value: String, color: Color, align: Alignment.Horizontal = Alignment.Start) {
    Column(horizontalAlignment = align) {
        Text(label, color = Neon.TextSecondary, fontSize = 9.sp, letterSpacing = 1.5.sp)
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun AbilityStrip(abilities: List<AbilityUi>, scientific: Boolean, onUse: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        abilities.forEach { ability ->
            val text = when {
                ability.activeRemainingMs > 0L -> "Ativa ${NumberFormatter.duration(ability.activeRemainingMs)}"
                ability.cooldownRemainingMs > 0L -> "Recarga ${NumberFormatter.duration(ability.cooldownRemainingMs)}"
                else -> "Usar"
            }
            val active = ability.activeRemainingMs > 0L
            val tint = when { active -> Neon.Green; ability.canUse -> Neon.Cyan; else -> Color.White }
            Column(
                Modifier.glass(RoundedCornerShape(20.dp), tint = tint, alpha = if (ability.canUse || active) 0.30f else 0.07f, borderAlpha = if (ability.canUse || active) 0.62f else 0.22f)
                    .clickable(enabled = ability.canUse) { onUse(ability.def.id) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(ability.def.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ability.canUse || active) Neon.TextPrimary else Neon.TextSecondary, maxLines = 1)
                Text(text, fontSize = 10.sp, color = if (active) Neon.Green else if (ability.canUse) Neon.Cyan else Neon.TextSecondary, maxLines = 1)
            }
        }
    }
}

private fun tutorialText(step: Int): String = when (step) {
    0 -> "Toque no cristal para gerar energia."
    1 -> "Abra a Loja e compre um Fragmento Estelar para iniciar a produção automática."
    2 -> "Use as habilidades no painel acima — elas alteram os ganhos de verdade."
    3 -> "Explore Dimensões, enfrente um chefe e prepare o primeiro renascimento."
    else -> "Seu universo renasceu. Invista pontos na árvore para acelerar a próxima corrida."
}
