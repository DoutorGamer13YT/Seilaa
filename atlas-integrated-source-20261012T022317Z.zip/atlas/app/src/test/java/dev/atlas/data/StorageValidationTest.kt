package dev.atlas.data

import androidx.datastore.preferences.core.preferencesOf
import dev.atlas.core.AppException
import dev.atlas.core.AppSettings
import dev.atlas.core.ErrorKind
import dev.atlas.core.ThemeMode
import dev.atlas.core.Units
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class StorageValidationTest {
    @Test fun duplicateQueriesIgnoreCaseWhitespaceAndUnicodeComposition() {
        assertEquals(StorageValidation.normalize("  CAFÉ   Central  "),
            StorageValidation.normalize("cafe\u0301 central"))
        // Accents remain semantically meaningful: São and Sao are not silently conflated.
        assertEquals("são paulo", StorageValidation.normalize(" São   Paulo "))
    }

    @Test fun listNamesAreTrimmedAndValidated() {
        assertEquals("Fim de semana", StorageValidation.listName("  Fim   de semana "))
        assertEquals(ErrorKind.INVALID_INPUT,
            assertThrows(AppException::class.java) { StorageValidation.listName(" \t ") }.kind)
        assertThrows(AppException::class.java) { StorageValidation.listName("a".repeat(81)) }
        assertThrows(AppException::class.java) { StorageValidation.listName("Viagem\u0000") }
    }

    @Test fun historyRejectsBlankAndOversizedQueries() {
        assertThrows(AppException::class.java) { StorageValidation.query("") }
        assertThrows(AppException::class.java) { StorageValidation.query("a".repeat(301)) }
        assertEquals("Avenida Paulista", StorageValidation.query(" Avenida  Paulista "))
    }

    @Test fun onlyHomeAndWorkShortcutsAreAccepted() {
        assertEquals("home", StorageValidation.shortcut("home"))
        assertEquals("work", StorageValidation.shortcut("work"))
        assertThrows(AppException::class.java) { StorageValidation.shortcut("hotel") }
    }

    @Test fun settingsUseSafeDefaultsForUnknownEnumValues() {
        val decoded = SettingsStorage.decode(preferencesOf(
            SettingsStorage.theme to "OLD_THEME",
            SettingsStorage.units to "UNKNOWN",
        ))
        assertEquals(AppSettings(), decoded)
    }

    @Test fun settingsDecodeEveryStoredPreference() {
        val decoded = SettingsStorage.decode(preferencesOf(
            SettingsStorage.theme to "DARK",
            SettingsStorage.units to "IMPERIAL",
            SettingsStorage.voice to false,
            SettingsStorage.reduceMotion to true,
            SettingsStorage.haptics to false,
        ))
        assertEquals(AppSettings(ThemeMode.DARK, Units.IMPERIAL, voice = false,
            reduceMotion = true, haptics = false), decoded)
    }
}
