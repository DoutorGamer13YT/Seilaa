package dev.atlas.map

import android.content.Context
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.Choreographer
import android.view.MotionEvent
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.atlas.core.Coordinate
import dev.atlas.core.CameraPolicy
import dev.atlas.core.HeadingMath
import dev.atlas.core.MapOrientation
import dev.atlas.location.CompassState
import kotlinx.coroutines.flow.StateFlow
import dev.atlas.core.LocationFix
import dev.atlas.core.Place
import dev.atlas.core.Route
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import kotlin.math.*

@Composable
fun AtlasMap(
    modifier: Modifier = Modifier,
    dark: Boolean,
    places: List<Place>,
    selectedPlace: Place?,
    route: Route?,
    location: LocationFix?,
    cameraRequest: CameraRequest?,
    bottomPaddingDp: () -> Float,
    reduceMotion: Boolean,
    onPlaceClick: (Place) -> Unit,
    onMapLongPress: (Coordinate) -> Unit,
    onCenterChanged: (Coordinate) -> Unit,
    onMapError: (String?) -> Unit,
    onUserGesture: () -> Unit = {},
    leftPaddingDp: Float = 0f,
    topPaddingDp: Float = 100f,
    orientation: MapOrientation = MapOrientation.NORTH,
    compass: StateFlow<CompassState>? = null,
    navigating: Boolean = false,
    onBearingChanged: (Float) -> Unit = {},
    onTiltChanged: (Boolean) -> Unit = {},
    onUserRotated: () -> Unit = {},
    active: Boolean = true,
    retryToken: Int = 0,
    panelInteracting: Boolean = false,
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val density = LocalDensity.current.density
    val click by rememberUpdatedState(onPlaceClick)
    val longPress by rememberUpdatedState(onMapLongPress)
    val centerChanged by rememberUpdatedState(onCenterChanged)
    val error by rememberUpdatedState(onMapError)
    val userGesture by rememberUpdatedState(onUserGesture)
    val bearingChanged by rememberUpdatedState(onBearingChanged)
    val tiltChanged by rememberUpdatedState(onTiltChanged)
    val userRotated by rememberUpdatedState(onUserRotated)
    var latitude by rememberSaveable { mutableStateOf(-23.5505) }
    var longitude by rememberSaveable { mutableStateOf(-46.6333) }
    var zoom by rememberSaveable { mutableStateOf(12.0) }
    var bearing by rememberSaveable { mutableStateOf(0.0) }
    var tilt by rememberSaveable { mutableStateOf(0.0) }
    val controller = remember(context, density) {
        MapLibre.getInstance(context)
        MapController(context, density)
    }
    controller.placeClick = { click(it) }
    controller.longPress = { longPress(it) }
    controller.onError = { error(it) }
    controller.userGesture = { userGesture() }
    controller.onBearing = { bearingChanged(it) }
    controller.onUserRotated = { userRotated() }
    controller.onCenterChanged = { centerChanged(it) }
    controller.onCameraIdle = { position ->
        tiltChanged(position.tilt > 10.0)
        position.target?.let { target ->
            latitude = target.latitude
            longitude = target.longitude
            zoom = position.zoom
            bearing = position.bearing
            tilt = position.tilt
        }
    }
    AndroidView(
        modifier = modifier,
        factory = {
            controller.create()
            controller.view.getMapAsync { map ->
                controller.attach(map, CameraPosition.Builder()
                    .target(LatLng(latitude, longitude)).zoom(zoom).bearing(bearing).tilt(tilt).build())
            }
            controller.view
        },
        update = {
            controller.update(MapContent(dark, places, selectedPlace, route, location,
                cameraRequest, bottomPaddingDp(), leftPaddingDp, topPaddingDp, reduceMotion, orientation, navigating, retryToken, panelInteracting))
        },
    )
    if (compass != null) LaunchedEffect(controller, compass) {
        compass.collect { controller.onHeading(it.heading) }
    }
    DisposableEffect(controller, lifecycle, active) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> if (active) controller.start()
                Lifecycle.Event.ON_RESUME -> if (active) controller.resume()
                Lifecycle.Event.ON_PAUSE -> controller.pause()
                Lifecycle.Event.ON_STOP -> controller.stop()
                Lifecycle.Event.ON_DESTROY -> controller.destroy()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (active) {
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) controller.resume()
            else if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) controller.start()
        } else controller.stop()
        onDispose {
            lifecycle.removeObserver(observer)
            controller.stop()
        }
    }
    DisposableEffect(controller) { onDispose { controller.destroy() } }
}

private data class MapContent(
    val dark: Boolean, val places: List<Place>, val selected: Place?, val route: Route?,
    val location: LocationFix?, val camera: CameraRequest?, val bottomDp: Float, val leftDp: Float, val topDp: Float,
    val reduceMotion: Boolean, val orientation: MapOrientation, val navigating: Boolean, val retryToken: Int, val panelInteracting: Boolean,
)

private class MapController(private val context: Context, private val density: Float) {
    val view = MapView(context)
    var placeClick: (Place) -> Unit = {}
    var longPress: (Coordinate) -> Unit = {}
    var onCameraIdle: (CameraPosition) -> Unit = {}
    var onCenterChanged: (Coordinate) -> Unit = {}
    var onError: (String?) -> Unit = {}
    var userGesture: () -> Unit = {}
    var onBearing: (Float) -> Unit = {}
    var onUserRotated: () -> Unit = {}
    private var map: MapLibreMap? = null
    private var style: Style? = null
    private var content: MapContent? = null
    private var requestedStyle: String? = null
    private var cameraId: Long? = null
    private var boundsRequestId: Long? = null
    private var requestBounds: LatLngBounds? = null
    private var lastRetryToken = 0
    private var destroyed = false
    private var created = false
    private var started = false
    private var resumed = false
    private var failed = false
    private var styleGeneration = 0
    private var lastReportedCenter: Coordinate? = null
    private var previousPlaces: Pair<List<Place>, Place?>? = null
    private var previousRoute: Route? = null
    private var routeJob: Job? = null
    private var previousLocation: Pair<LocationFix?, Boolean>? = null
    private var followHeading = false
    private var orientationMode: MapOrientation? = null
    private var manuallyExploring = false
    private var headingSuspended = false
    private var touchActive = false
    private var lastHeadingFrame = 0L
    private var cameraGeneration = 0
    private val styleScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val styleJson = mutableMapOf<String, String>()
    private var cameraScheduled = false
    private val cameraRunnable = Runnable { cameraScheduled = false; content?.let(::updateCamera) }
    private var targetHeading: Float? = null
    private var gestureActive = false
    private var programmaticAnimation = false
    private var followerScheduled = false
    private var gestureStartBearing = 0f
    private var rotationReported = false
    private var lastReportedBearing = Float.NaN
    private var coneVisible = false
    private var coneHeading = Float.NaN
    private val choreographer: Choreographer by lazy { Choreographer.getInstance() }
    private val frameCallback = Choreographer.FrameCallback { frameTime ->
        followerScheduled = false
        stepHeading(frameTime)
    }
    private var previousPadding: List<Int>? = null
    private val failureListener = MapView.OnDidFailLoadingMapListener {
        if (!destroyed) {
            failed = true
            onError("Não foi possível carregar o mapa. Verifique sua conexão e tente novamente.")
        }
    }
    private val finishedListener = MapView.OnDidFinishLoadingMapListener {
        if (!destroyed) {
            failed = false
            onError(null)
        }
    }
    private val memoryCallbacks = object : ComponentCallbacks2 {
        override fun onConfigurationChanged(newConfig: Configuration) = Unit
        override fun onLowMemory() { if (created && !destroyed) view.onLowMemory() }
        override fun onTrimMemory(level: Int) {
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) onLowMemory()
        }
    }

    init {
        view.addOnDidFailLoadingMapListener(failureListener)
        view.addOnDidFinishLoadingMapListener(finishedListener)
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touchActive = true
                    lastHeadingFrame = 0L
                    cancelPendingCamera()
                    cameraGeneration++
                    map?.cancelTransitions()
                    programmaticAnimation = false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    touchActive = false
                    if (!gestureActive) { scheduleHeading(); scheduleCamera() }
                }
            }
            false
        }
        view.contentDescription = "Mapa interativo. Arraste para explorar; toque em um lugar para ver detalhes."
        view.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (!destroyed && (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop)) {
                content?.let(::render)
            }
        }
    }

    fun create() {
        if (created || destroyed) return
        view.onCreate(null)
        created = true
        context.applicationContext.registerComponentCallbacks(memoryCallbacks)
    }

    fun start() {
        if (destroyed || started) return
        create()
        view.onStart()
        started = true
    }

    fun resume() {
        if (destroyed || resumed) return
        start()
        view.onResume()
        resumed = true
        scheduleHeading()
        scheduleCamera()
    }

    fun pause() {
        cancelPendingCamera()
        choreographer.removeFrameCallback(frameCallback)
        followerScheduled = false
        lastHeadingFrame = 0L
        cameraGeneration++
        map?.cancelTransitions()
        programmaticAnimation = false
        if (resumed && !destroyed) view.onPause()
        resumed = false
    }

    fun stop() {
        pause()
        if (started && !destroyed) view.onStop()
        started = false
    }

    fun attach(map: MapLibreMap, initial: CameraPosition) {
        if (destroyed) return
        this.map = map
        map.cameraPosition = initial
        map.setPrefetchZoomDelta(3)
        map.setTileCacheEnabled(true)
        map.uiSettings.apply {
            isCompassEnabled = false
            isLogoEnabled = false
            isAttributionEnabled = false
            isScrollGesturesEnabled = true
            isZoomGesturesEnabled = true
            isRotateGesturesEnabled = true
            isScaleVelocityAnimationEnabled = true
            isRotateVelocityAnimationEnabled = true
            isFlingVelocityAnimationEnabled = true
            isIncreaseScaleThresholdWhenRotating = true
            isDisableRotateWhenScaling = false
            isTiltGesturesEnabled = true
        }
        map.addOnCameraMoveListener {
            if (!destroyed) {
                val bearing = map.cameraPosition.bearing.toFloat()
                if (lastReportedBearing.isNaN() || abs(HeadingMath.shortestDelta(lastReportedBearing, bearing)) >= 0.25f) {
                    lastReportedBearing = bearing
                    onBearing(bearing)
                }
                if (gestureActive && !rotationReported && orientationMode != MapOrientation.FREE &&
                    abs(HeadingMath.shortestDelta(gestureStartBearing, bearing)) > 1.5f) {
                    rotationReported = true
                    onUserRotated()
                }
            }
        }
        map.addOnCameraIdleListener {
            if (!destroyed) {
                gestureActive = false
                val position = map.cameraPosition
                onBearing(position.bearing.toFloat())
                lastReportedBearing = position.bearing.toFloat()
                onCameraIdle(position)
                scheduleHeading()
                scheduleCamera()
                position.target?.let { point ->
                    val coordinate = Coordinate(point.latitude.coerceIn(-90.0, 90.0), wrapLongitude(point.longitude))
                    if (lastReportedCenter?.distanceTo(coordinate)?.let { it >= 5.0 } != false) {
                        lastReportedCenter = coordinate
                        onCenterChanged(coordinate)
                    }
                }
            }
        }
        map.addOnCameraMoveStartedListener { reason ->
            if (!destroyed && reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) {
                gestureActive = true
                manuallyExploring = true
                headingSuspended = true
                programmaticAnimation = false
                cameraGeneration++
                cameraId = content?.camera?.id
                cancelPendingCamera()
                rotationReported = false
                gestureStartBearing = map.cameraPosition.bearing.toFloat()
                userGesture()
            }
        }
        map.addOnMapLongClickListener {
            longPress(Coordinate(it.latitude.coerceIn(-90.0, 90.0), wrapLongitude(it.longitude)))
            true
        }
        map.addOnMapClickListener { point ->
            if (destroyed || style == null) return@addOnMapClickListener false
            val screen = map.projection.toScreenLocation(point)
            val radius = 24 * density
            val features = map.queryRenderedFeatures(android.graphics.RectF(
                screen.x - radius, screen.y - radius, screen.x + radius, screen.y + radius),
                "atlas-selected", "atlas-places")
            val id = features.firstOrNull()?.getStringProperty("id")
            val current = content
            val place = if (current?.selected?.id == id) current.selected else current?.places?.find { it.id == id }
            if (place != null) placeClick(place)
            place != null
        }
        content?.let(::update)
    }

    fun update(next: MapContent) {
        val panelDragStarted = next.panelInteracting && content?.panelInteracting != true
        content = next
        if (panelDragStarted) {
            cancelPendingCamera()
            cameraGeneration++
            if (programmaticAnimation && !manuallyExploring && (next.selected != null || next.route != null)) cameraId = null
            map?.cancelTransitions()
            programmaticAnimation = false
            lastHeadingFrame = 0L
        }
        val map = map ?: return
        if (destroyed) return
        applyOrientation(next.orientation, next.navigating, map)
        val styleName = if (next.dark) "dark" else "light"
        if (requestedStyle != styleName || lastRetryToken != next.retryToken) {
            val generation = ++styleGeneration
            requestedStyle = styleName
            style = null
            previousPlaces = null
            previousRoute = null
            routeJob?.cancel()
            previousLocation = null
            lastRetryToken = next.retryToken
            failed = false
            styleScope.launch {
                val json = try {
                    styleJson[styleName] ?: withContext(Dispatchers.IO) {
                        context.assets.open("styles/atlas-$styleName.json").bufferedReader().use { it.readText() }
                    }.also { styleJson[styleName] = it }
                } catch (_: java.io.IOException) {
                    if (generation == styleGeneration && !destroyed) {
                        failed = true
                        onError("O estilo do mapa não está disponível. Reinstale o aplicativo.")
                    }
                    return@launch
                }
                if (destroyed || generation != styleGeneration) return@launch
                map.setStyle(Style.Builder().fromJson(json)) { loaded ->
                    if (!destroyed && generation == styleGeneration) {
                        style = loaded
                        addOverlayLayers(loaded)
                        content?.let(::render)
                    }
                }
            }
        }
        render(next)
    }

    private fun render(next: MapContent) {
        val map = map ?: return
        val style = style ?: return
        val placeState = next.places to next.selected
        if (previousPlaces != placeState) {
            previousPlaces = placeState
            style.getSourceAs<GeoJsonSource>("atlas-places-source")?.setGeoJson(collection(next.places
                .filterNot { it.id == next.selected?.id }.take(250).map(::placeFeature)))
            style.getSourceAs<GeoJsonSource>("atlas-selected-source")?.setGeoJson(collection(listOfNotNull(next.selected?.let(::placeFeature))))
        }
        if (previousRoute != next.route) {
            previousRoute = next.route
            routeJob?.cancel()
            val route = next.route
            routeJob = styleScope.launch {
                val (line, waypoints) = withContext(Dispatchers.Default) {
                    val geometry = route?.geometry.orEmpty()
                    collection(if (geometry.size < 2) emptyList() else listOf(
                        feature("LineString", JSONArray(geometry.map(::position))))) to
                        collection(route?.waypoints.orEmpty().map { feature("Point", position(it)) })
                }
                if (!destroyed && this@MapController.style === style && previousRoute == route) {
                    style.getSourceAs<GeoJsonSource>("atlas-route-source")?.setGeoJson(line)
                    style.getSourceAs<GeoJsonSource>("atlas-waypoints-source")?.setGeoJson(waypoints)
                }
            }
        }
        if (previousLocation != (next.location to next.navigating)) {
            previousLocation = next.location to next.navigating
            style.getSourceAs<GeoJsonSource>("atlas-location-source")?.setGeoJson(collection(
                listOfNotNull(next.location?.let { fix ->
                    val properties = JSONObject()
                    if (next.navigating) CameraPolicy.courseOrNull(fix.bearing, fix.speedMetersPerSecond)?.let { properties.put("course", it.toDouble()) }
                    feature("Point", position(fix.coordinate), properties)
                })))
            style.getSourceAs<GeoJsonSource>("atlas-accuracy-source")?.setGeoJson(collection(
                listOfNotNull(next.location?.takeIf { it.accuracyMeters.isFinite() && it.accuracyMeters > 0 }?.let(::accuracyFeature))))
        }
        showCone(targetHeading)
        scheduleCamera()
    }

    private fun scheduleCamera() {
        if (destroyed || !resumed || gestureActive || touchActive || content?.panelInteracting == true) return
        if (cameraScheduled) return
        cameraScheduled = true
        view.postDelayed(cameraRunnable, 48L)
    }

    private fun cancelPendingCamera() {
        view.removeCallbacks(cameraRunnable)
        cameraScheduled = false
    }

    private fun updateCamera(next: MapContent) {
        val map = map ?: return
        if (destroyed || !resumed || style == null || gestureActive || touchActive || next.panelInteracting || view.width <= 0 || view.height <= 0) return
        val request = next.camera
        val newRequest = request != null && request.id != cameraId
        if (newRequest && request?.following != true) {
            manuallyExploring = false
            headingSuspended = false
        }
        if (request?.following == true && manuallyExploring) { cameraId = request.id; return }
        val top = (next.topDp * density).roundToInt().coerceAtMost((view.height - 100 * density).roundToInt().coerceAtLeast(0))
        val bottom = (next.bottomDp * density).roundToInt().coerceIn(0, (view.height - top - 100 * density).roundToInt().coerceAtLeast(0))
        val left = (next.leftDp * density).roundToInt().coerceIn(0, (view.width - 120 * density).roundToInt().coerceAtLeast(0))
        val padding = listOf(left, top, 0, bottom)
        val viewportChanged = padding != previousPadding
        if (!newRequest && (!viewportChanged || manuallyExploring)) return
        val current = map.cameraPosition
        val builder = CameraPosition.Builder(current)
            .padding(left.toDouble(), top.toDouble(), 0.0, bottom.toDouble())
        val shouldFrame = newRequest || (viewportChanged && !manuallyExploring &&
            (next.route != null || next.selected != null))
        if (request != null && boundsRequestId != request.id) {
            boundsRequestId = request.id
            val unique = request.points.distinct()
            requestBounds = if (unique.size > 1) LatLngBounds.Builder()
                .includes(unique.map { LatLng(it.latitude, it.longitude) }).build() else null
        }
        val bounds = requestBounds.takeIf { shouldFrame }
        if (bounds != null) {
            val margin = (28 * density).roundToInt()
            map.getCameraForLatLngBounds(bounds, intArrayOf(left + margin, top + margin, margin, bottom + margin),
                request?.bearing ?: current.bearing, request?.tilt ?: current.tilt)?.let {
                builder.target(it.target).zoom(it.zoom.coerceIn(1.0, 20.0))
            }
        } else if (shouldFrame) {
            (request?.target ?: request?.points?.firstOrNull())?.let { builder.target(LatLng(it.latitude, it.longitude)) }
            request?.zoom?.let { builder.zoom(it.coerceIn(1.0, 20.0)) }
        }
        if (newRequest) {
            request?.bearing?.let { builder.bearing(it) }
            request?.tilt?.let { builder.tilt(it.coerceIn(0.0, 60.0)) }
            cameraId = request?.id
        }
        previousPadding = padding
        val destination = builder.build()
        val distance = current.target?.let { start -> destination.target?.let { start.distanceTo(it) } } ?: 0.0
        val zoomDelta = abs(destination.zoom - current.zoom)
        val angle = abs(HeadingMath.shortestDelta(current.bearing.toFloat(), destination.bearing.toFloat()))
        if (distance < 0.5 && zoomDelta < 0.005 && angle < 0.2 && abs(destination.tilt - current.tilt) < 0.2 && !viewportChanged) return
        val duration = when {
            request?.following == true && newRequest -> 800
            !newRequest -> 420
            distance < 2.0 && zoomDelta < 0.1 -> (360 + angle * 1.6).roundToInt().coerceAtMost(620)
            else -> (440 + ln(1 + distance / 250.0) * 90 + zoomDelta * 65).roundToInt().coerceIn(440, 1150)
        }
        val generation = ++cameraGeneration
        map.cancelTransitions()
        val update = CameraUpdateFactory.newCameraPosition(destination)
        if (next.reduceMotion) {
            programmaticAnimation = false
            map.moveCamera(update)
            return
        }
        programmaticAnimation = true
        val callback = object : MapLibreMap.CancelableCallback {
            override fun onCancel() {
                if (generation == cameraGeneration) { programmaticAnimation = false; scheduleHeading() }
            }
            override fun onFinish() {
                if (generation == cameraGeneration) { programmaticAnimation = false; scheduleHeading() }
            }
        }
        if (newRequest && request?.following != true && distance > 15000 && zoomDelta > 1.5) {
            map.animateCamera(update, duration, callback)
        } else map.easeCamera(update, duration, true, callback)
    }

    private fun applyOrientation(mode: MapOrientation, navigating: Boolean, map: MapLibreMap) {
        if (orientationMode != mode) {
            headingSuspended = false
            lastHeadingFrame = 0L
        }
        orientationMode = mode
        val follow = mode == MapOrientation.COMPASS && !navigating
        if (follow != followHeading) {
            followHeading = follow
            if (!follow) showCone(null)
        }
        map.uiSettings.setAllVelocityAnimationsEnabled(content?.reduceMotion != true)
        if (follow) scheduleHeading()
    }

    fun onHeading(heading: Float?) {
        targetHeading = heading
        showCone(heading)
        if (heading != null) scheduleHeading()
    }

    private fun scheduleHeading() {
        if (destroyed || !resumed || !followHeading || headingSuspended || touchActive || gestureActive || content?.panelInteracting == true ||
            programmaticAnimation || followerScheduled || targetHeading == null) return
        followerScheduled = true
        choreographer.postFrameCallback(frameCallback)
    }

    private fun stepHeading(frameTime: Long) {
        val map = map ?: return
        if (destroyed || !resumed || !followHeading || headingSuspended || touchActive || gestureActive || content?.panelInteracting == true || programmaticAnimation) {
            lastHeadingFrame = 0L
            return
        }
        val target = targetHeading ?: return
        val current = map.cameraPosition.bearing.toFloat()
        val delta = HeadingMath.shortestDelta(current, target)
        if (abs(delta) < 0.3f) { lastHeadingFrame = 0L; return }
        val elapsed = if (lastHeadingFrame == 0L) 1f / 60f else ((frameTime - lastHeadingFrame) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastHeadingFrame = frameTime
        val factor = if (content?.reduceMotion == true) 1f else 1f - exp(-elapsed / 0.14f)
        val next = HeadingMath.normalize(current + delta * factor)
        map.moveCamera(CameraUpdateFactory.bearingTo(next.toDouble()))
        scheduleHeading()
    }

    private fun showCone(heading: Float?) {
        val layer = style?.getLayerAs<SymbolLayer>("atlas-heading") ?: return
        if (heading == null || !followHeading) {
            if (coneVisible) {
                layer.setProperties(visibility(Property.NONE))
                coneVisible = false
                coneHeading = Float.NaN
            }
            return
        }
        if (!coneVisible || coneHeading.isNaN() || abs(HeadingMath.shortestDelta(coneHeading, heading)) >= 1f) {
            layer.setProperties(iconRotate(heading), visibility(Property.VISIBLE))
            coneVisible = true
            coneHeading = heading
        }
    }

    private fun addOverlayLayers(style: Style) {
        listOf("places", "selected", "route", "waypoints", "accuracy", "location").forEach {
            style.addSource(GeoJsonSource("atlas-$it-source", collection(emptyList())))
        }
        style.addLayer(FillLayer("atlas-accuracy", "atlas-accuracy-source").withProperties(
            fillColor("#0A84FF"), fillOpacity(0.12f), fillOutlineColor("#75B7F8")))
        style.addLayer(LineLayer("atlas-route-casing", "atlas-route-source").withProperties(
            lineColor("#FFFFFF"), lineOpacity(.95f), lineWidth(10f), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(LineLayer("atlas-route", "atlas-route-source").withProperties(
            lineColor("#087AFF"), lineWidth(6f), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(CircleLayer("atlas-waypoints", "atlas-waypoints-source").withProperties(
            circleColor("#FFFFFF"), circleRadius(5f), circleStrokeColor("#087AFF"), circleStrokeWidth(3f)))
        style.addLayer(CircleLayer("atlas-places", "atlas-places-source").withProperties(
            circleColor(Expression.get("color")), circleRadius(9f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(2.5f)))
        style.addLayer(CircleLayer("atlas-selected-halo", "atlas-selected-source").withProperties(
            circleColor("#087AFF"), circleRadius(22f), circleOpacity(.14f)))
        style.addLayer(CircleLayer("atlas-selected", "atlas-selected-source").withProperties(
            circleColor("#087AFF"), circleRadius(13f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(3.5f)))
        style.addLayer(SymbolLayer("atlas-selected-label", "atlas-selected-source").withProperties(
            textField(Expression.get("name")), textFont(arrayOf("Noto Sans Regular")), textSize(13f),
            textOffset(arrayOf(0f, 2.2f)), textColor(if (content?.dark == true) "#F4F4F6" else "#24262B"),
            textHaloColor(if (content?.dark == true) "#242830" else "#FFFFFF"), textHaloWidth(2f), textMaxWidth(15f)))
        style.addImage("atlas-heading-cone", headingCone(density))
        style.addImage("atlas-course-arrow", courseArrow(density))
        coneVisible = false
        coneHeading = Float.NaN
        style.addLayer(SymbolLayer("atlas-heading", "atlas-location-source").withProperties(
            iconImage("atlas-heading-cone"), iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconAllowOverlap(true), iconIgnorePlacement(true), visibility(Property.NONE)))
        val noCourse = Expression.not(Expression.has("course"))
        style.addLayer(CircleLayer("atlas-location-halo", "atlas-location-source").withProperties(
            circleColor("#087AFF"), circleOpacity(.16f), circleRadius(15f)).also { it.setFilter(noCourse) })
        style.addLayer(CircleLayer("atlas-location", "atlas-location-source").withProperties(
            circleColor("#0A84FF"), circleRadius(7f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(3f)).also { it.setFilter(noCourse) })
        style.addLayer(SymbolLayer("atlas-course", "atlas-location-source").withProperties(
            iconImage("atlas-course-arrow"), iconRotate(Expression.get("course")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconAllowOverlap(true), iconIgnorePlacement(true)).also { it.setFilter(Expression.has("course")) })
    }

    fun destroy() {
        if (destroyed) return
        stop()
        destroyed = true
        styleScope.cancel()
        styleJson.clear()
        view.setOnTouchListener(null)
        cancelPendingCamera()
        choreographer.removeFrameCallback(frameCallback)
        followerScheduled = false
        map?.cancelTransitions()
        view.removeOnDidFailLoadingMapListener(failureListener)
        view.removeOnDidFinishLoadingMapListener(finishedListener)
        if (created) {
            context.applicationContext.unregisterComponentCallbacks(memoryCallbacks)
            view.onDestroy()
        }
        map = null
        style = null
    }
}

private fun headingCone(density: Float): Bitmap {
    val size = (120 * density).roundToInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bitmap.density = (160 * density).roundToInt()
    val center = size / 2f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(center, center, center,
            intArrayOf(0xA60A84FF.toInt(), 0x000A84FF), floatArrayOf(0.08f, 1f), Shader.TileMode.CLAMP)
    }
    Canvas(bitmap).drawArc(RectF(0f, 0f, size.toFloat(), size.toFloat()), -90f - 34f, 68f, true, paint)
    return bitmap
}

private fun courseArrow(density: Float): Bitmap {
    val size = (44 * density).roundToInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bitmap.density = (160 * density).roundToInt()
    val s = size / 44f
    val path = Path().apply {
        moveTo(22f * s, 5f * s)
        lineTo(36f * s, 37f * s)
        lineTo(22f * s, 30f * s)
        lineTo(8f * s, 37f * s)
        close()
    }
    val canvas = Canvas(bitmap)
    canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * s; strokeJoin = Paint.Join.ROUND; color = AndroidColor.WHITE
    })
    canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A84FF.toInt() })
    return bitmap
}

private fun wrapLongitude(value: Double): Double = ((value + 180) % 360 + 360) % 360 - 180
private fun position(value: Coordinate) = JSONArray().put(value.longitude).put(value.latitude)
private fun feature(type: String, coordinates: JSONArray, properties: JSONObject = JSONObject()) = JSONObject()
    .put("type", "Feature").put("properties", properties)
    .put("geometry", JSONObject().put("type", type).put("coordinates", coordinates))
private fun collection(features: List<JSONObject>) = JSONObject().put("type", "FeatureCollection")
    .put("features", JSONArray(features)).toString()
private fun placeFeature(place: Place): JSONObject {
    val category = place.category.lowercase()
    val color = when {
        listOf("restaur", "café", "cafe", "food").any(category::contains) -> "#EF8D32"
        listOf("park", "parque", "nature").any(category::contains) -> "#48A865"
        listOf("hosp", "farm", "health").any(category::contains) -> "#E56475"
        listOf("hotel", "lodging").any(category::contains) -> "#986DC9"
        else -> "#647ED1"
    }
    return feature("Point", position(place.coordinate), JSONObject().put("id", place.id).put("name", place.name).put("color", color))
}

private fun accuracyFeature(fix: LocationFix): JSONObject {
    val distance = fix.accuracyMeters.coerceAtMost(100_000f) / 6_371_008.8
    val latitude = Math.toRadians(fix.coordinate.latitude)
    val longitude = Math.toRadians(fix.coordinate.longitude)
    val ring = JSONArray()
    for (i in 0..48) {
        val angle = i * 2.0 * Math.PI / 48
        val lat = asin(sin(latitude) * cos(distance) + cos(latitude) * sin(distance) * cos(angle))
        val lon = longitude + atan2(sin(angle) * sin(distance) * cos(latitude), cos(distance) - sin(latitude) * sin(lat))
        ring.put(JSONArray().put(wrapLongitude(Math.toDegrees(lon))).put(Math.toDegrees(lat)))
    }
    return feature("Polygon", JSONArray().put(ring))
}
