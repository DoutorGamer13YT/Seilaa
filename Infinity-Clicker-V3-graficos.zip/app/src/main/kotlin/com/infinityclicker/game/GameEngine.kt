package com.infinityclicker.game

import com.infinityclicker.core.BigNum
import com.infinityclicker.generators.GeneratorDef
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.ClickEffect
import com.infinityclicker.upgrades.Requirement
import com.infinityclicker.upgrades.UpgradeDefs
import com.infinityclicker.upgrades.UpgradeDef
import com.infinityclicker.upgrades.UpgradeIds
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong
import kotlin.random.Random

enum class BuyMode(val label: String, val count: Long) {
    X1("×1", 1), X10("×10", 10), X100("×100", 100), MAX("Máx", -1)
}

/** Resultado de planejar uma compra: quantas unidades, quanto custa e se dá para pagar agora. */
data class PurchasePlan(val count: Long, val cost: BigNum, val affordable: Boolean)

data class TapResult(
    val gain: BigNum,
    val crit: Boolean,
    val combo: Int,
    val comboMultiplier: Double,
    val bossDamage: BigNum = BigNum.ZERO,
    val bossDefeated: Boolean = false,
    val bossReward: BigNum = BigNum.ZERO
)

data class OfflineReport(
    val elapsedMs: Long,
    val creditedMs: Long,
    val capMs: Long,
    val efficiency: Double,
    val globalMultiplier: BigNum,
    val productionPerSecond: BigNum,
    val gain: BigNum
)

data class AbilityUseResult(
    val used: Boolean,
    val abilityId: String,
    val gain: BigNum = BigNum.ZERO,
    val activeUntilMs: Long = 0L,
    val cooldownUntilMs: Long = 0L
)

data class PrestigePreview(
    val available: Boolean,
    val points: Int,
    val runEnergy: BigNum,
    val permanentMultiplierAfter: Double
)

data class PrestigeResult(val pointsGained: Int, val totalPrestigePoints: Int)

data class BossStartResult(val started: Boolean, val boss: ActiveBoss? = null)

data class ChallengeCompletion(val name: String, val energy: BigNum, val prestigePoints: Int)

/**
 * Motor econômico independente de Android e Compose. Todas as ações públicas alteram dados reais
 * persistidos em [GameState], permitindo teste unitário e impedindo controles meramente visuais.
 * Não é thread-safe: o ViewModel sincroniza o acesso.
 */
class GameEngine(val state: GameState, private val random: Random = Random.Default) {

    var production: BigNum = BigNum.ZERO; private set
    var globalMultiplier: BigNum = BigNum.ONE; private set
    var clickBase: BigNum = BigNum.ONE; private set
    var critChance: Double = Formulas.BASE_CRIT_CHANCE; private set
    var critMultiplier: Double = Formulas.BASE_CRIT_MULT; private set
    var maxCombo: Int = Formulas.BASE_COMBO_MAX; private set
    var offlineCapHours: Int = Formulas.BASE_OFFLINE_HOURS; private set
    var offlineEfficiency: Double = Formulas.BASE_OFFLINE_EFFICIENCY; private set
    private var comboStep: Double = Formulas.COMBO_STEP

    /**
     * Efeitos da árvore somados uma única vez por [recompute]. Antes, cada chamada a skill() percorria os 100 nós;
     * como o motor pergunta isso dezenas de vezes por recálculo (e por geradores × 110 na loja), virava o maior
     * custo de CPU do jogo. Todo caminho que muda níveis da árvore (compra, importação, novo universo) recalcula.
     */
    private val skillCache = DoubleArray(SkillEffect.entries.size)
    /** PP já gastos em nós da árvore e evoluções de habilidades; contam para o multiplicador permanente. */
    private var spentPoints: Long = 0L

    var comboCount: Int = 0; private set
    private var lastTapMs: Long = Long.MIN_VALUE
    private val recentTapTimes = ArrayDeque<Long>()
    private var pendingChallengeCompletion: ChallengeCompletion? = null

    init {
        normalizeState()
        recompute()
        recordAchievementUnlocks()
    }

    // ---------------------------------------------------------------- derivados

    /** Recalcula os valores derivados depois de qualquer compra, troca de dimensão ou efeito temporal. */
    fun recompute(nowWallMs: Long = System.currentTimeMillis()) {
        rebuildSkillCache()
        val lv = state::level
        val power = state.skillLevel(SkillTree.POWER_CORE)
        val auto = state.skillLevel(SkillTree.AUTO_CORE)
        val dimension = DimensionDefs.byId(state.currentDimension)
        val temporalActive = isAbilityActive(AbilityDefs.TEMPORAL_RUSH, nowWallMs)
        val superActive = isAbilityActive(AbilityDefs.SUPER_CLICK, nowWallMs)
        val overloadActive = isAbilityActive(AbilityDefs.QUANTUM_OVERLOAD, nowWallMs)

        val event = activeEventDef(nowWallMs)
        val eventPower = 1.0 + skill(SkillEffect.EVENT_POWER)
        val upgradeMultiplier =
            BigNum.of(1.25).pow(lv(UpgradeIds.MULT_GLOBAL_1).toDouble()) *
                BigNum.of(2.0).pow(lv(UpgradeIds.MULT_GLOBAL_2).toDouble()) *
                BigNum.of(10.0).pow(lv(UpgradeIds.MULT_GLOBAL_3).toDouble())
        val prestigeMultiplier = permanentMultiplier()
        val dimensionMultiplier = BigNum.of(dimensionMultiplier(dimension.id))
        val automationMultiplier = BigNum.of(1.0 + auto * 0.30 + skill(SkillEffect.PRODUCTION_MULTIPLIER))
        val temporalMultiplier = if (temporalActive) {
            BigNum.of((2.0 + abilityLevel(AbilityDefs.TEMPORAL_RUSH) * 0.4) * (1.0 + skill(SkillEffect.ABILITY_POWER)))
        } else BigNum.ONE
        val eventProduction = if (event?.effect == CosmicEventEffect.PRODUCTION) BigNum.of(1.0 + event.baseBonus * eventPower) else BigNum.ONE
        globalMultiplier = upgradeMultiplier * prestigeMultiplier * dimensionMultiplier * automationMultiplier * temporalMultiplier * eventProduction

        var raw = BigNum.ZERO
        for (def in GeneratorDefs.all) {
            val owned = state.generators[def.id]
            if (owned > 0L) raw += unitProductionRaw(def, owned) * BigNum.of(owned)
        }
        production = raw * globalMultiplier
        state.highestProduction = BigNum.max(state.highestProduction, production)

        // As 100 melhorias de clique extras: somam-se (ou multiplicam) por tipo antes da conta final.
        var extraFlat = BigNum.ZERO
        var extraMult = BigNum.ONE
        var extraCritChance = 0.0
        var extraCritPower = 0.0
        var extraCombo = 0.0
        var extraShare = 0.0
        for (def in UpgradeDefs.clickExtrasList) {
            val level = state.level(def.id)
            if (level <= 0) continue
            when (def.clickEffect) {
                ClickEffect.MULT -> extraMult *= BigNum.of(def.perLevel).pow(level.toDouble())
                ClickEffect.FLAT -> extraFlat += BigNum.of(def.perLevel * level)
                ClickEffect.CRIT_CHANCE -> extraCritChance += def.perLevel * level
                ClickEffect.CRIT_POWER -> extraCritPower += def.perLevel * level
                ClickEffect.COMBO_CAP -> extraCombo += def.perLevel * level
                ClickEffect.PRODUCTION_SHARE -> extraShare += def.perLevel * level
                null -> Unit
            }
        }

        val crystal = CrystalDefs.byId(state.equippedCrystal)
        val clickProductionRate = Formulas.CLICK_PS_PER_LEVEL * lv(UpgradeIds.CLICK_PS) + skill(SkillEffect.CLICK_FROM_PRODUCTION) + extraShare
        var click = ((BigNum.of(1 + lv(UpgradeIds.CLICK_POWER) + skill(SkillEffect.CLICK_FLAT)) + extraFlat) *
            BigNum.of(2.0).pow(lv(UpgradeIds.CLICK_MULT).toDouble()) * extraMult) +
            production * clickProductionRate
        click *= BigNum.of(1.0 + power * 0.25 + skill(SkillEffect.CLICK_MULTIPLIER))
        click *= BigNum.of(crystal.clickMultiplier * (1.0 + skill(SkillEffect.CRYSTAL_POWER)))
        click *= prestigeMultiplier
        if (superActive) click *= BigNum.of((2.0 + abilityLevel(AbilityDefs.SUPER_CLICK) * 0.5) * (1.0 + skill(SkillEffect.ABILITY_POWER)))
        if (event?.effect == CosmicEventEffect.CLICK) click *= BigNum.of(1.0 + event.baseBonus * eventPower)
        clickBase = click

        val normalCrit = min(
            Formulas.MAX_CRIT_CHANCE,
            Formulas.BASE_CRIT_CHANCE + 0.01 * lv(UpgradeIds.CRIT_CHANCE) + extraCritChance + 0.02 * state.skillLevel(SkillTree.POWER_CRIT) + skill(SkillEffect.CRIT_CHANCE) +
                (if (event?.effect == CosmicEventEffect.CRIT) event.baseBonus * eventPower else 0.0)
        )
        critChance = ProgressionFormulas.cappedCrit(normalCrit, abilityLevel(AbilityDefs.QUANTUM_OVERLOAD), overloadActive)
        critMultiplier = Formulas.BASE_CRIT_MULT + 0.5 * lv(UpgradeIds.CRIT_POWER) + extraCritPower + 0.15 * state.prestigeCount + skill(SkillEffect.CRIT_POWER)
        maxCombo = Formulas.BASE_COMBO_MAX + 5 * lv(UpgradeIds.COMBO_CAP) + 10 * state.skillLevel(SkillTree.POWER_COMBO) + skill(SkillEffect.COMBO_CAP).toInt() + extraCombo.toInt()
        comboStep = Formulas.COMBO_STEP + skill(SkillEffect.COMBO_STEP) +
            (if (event?.effect == CosmicEventEffect.COMBO) event.baseBonus * eventPower else 0.0)
        offlineCapHours = Formulas.BASE_OFFLINE_HOURS + 2 * lv(UpgradeIds.OFFLINE_CAP) + 2 * state.skillLevel(SkillTree.AUTO_OFFLINE) + skill(SkillEffect.OFFLINE_HOURS).toInt()
        offlineEfficiency = min(
            1.0,
            Formulas.BASE_OFFLINE_EFFICIENCY + 0.05 * lv(UpgradeIds.OFFLINE_EFF) + 0.05 * state.skillLevel(SkillTree.AUTO_OFFLINE) + skill(SkillEffect.OFFLINE_EFFICIENCY)
        )
    }

    /**
     * Bônus permanente do prestígio. Conta os PP gastos além dos disponíveis: antes, comprar um nó da árvore
     * (ou evoluir uma habilidade) tirava PP do total e derrubava o multiplicador global — gastar pontos
     * deixava o jogador mais fraco em vez de mais forte.
     */
    private fun permanentMultiplier(): BigNum = BigNum.of(permanentMultiplierFor(state.prestigePoints))

    private fun permanentMultiplierFor(availablePoints: Int): Double =
        1.0 + (availablePoints.toDouble() + spentPoints) * (0.05 + 0.10 * state.skillLevel(SkillTree.TRANS_CORE) + skill(SkillEffect.PRESTIGE_PERMANENT))

    /** Multiplicador de produção da dimensão (base × ressonância), igual ao aplicado no [recompute]. */
    fun dimensionMultiplier(id: Int): Double {
        val def = DimensionDefs.byId(id)
        val resonance = if (id in state.dimensionResonance.indices) state.dimensionResonance[id] else 0
        return def.productionMultiplier * (1.0 + resonance * (0.15 + skill(SkillEffect.RESONANCE_POWER)))
    }

    /** Vida máxima do chefe da dimensão na próxima invocação (já com dificuldade). */
    fun bossMaxHealth(dimensionId: Int): BigNum {
        val def = DimensionDefs.byId(dimensionId)
        return ProgressionFormulas.bossHealth(def, state.bossWins[def.id])
    }

    private fun skill(effect: SkillEffect): Double = skillCache[effect.ordinal]

    private fun rebuildSkillCache() {
        java.util.Arrays.fill(skillCache, 0.0)
        var spent = 0L
        for (node in SkillTree.all) {
            val level = state.skillLevel(node.id)
            if (level <= 0) continue
            val effect = node.effect
            if (effect != null) skillCache[effect.ordinal] += level * node.effectPerLevel
            // custo do nível n é base·n; somar 1..level dá base·level·(level+1)/2
            val paidLevels = level.coerceAtMost(node.maxLevel).toLong()
            spent += node.baseCost.toLong() * paidLevels * (paidLevels + 1L) / 2L
        }
        for (ability in AbilityDefs.all) {
            // Habilidades começam no nível 1; subir de L para L+1 custa baseCost·(L+1).
            val level = abilityLevel(ability.id).toLong()
            spent += ability.baseCost.toLong() * (level * (level + 1L) / 2L - 1L)
        }
        spentPoints = spent
    }

    fun milestoneStep(): Long = max(10L, Formulas.MILESTONE_STEP - state.skillLevel(SkillTree.AUTO_MILESTONE).toLong() * 2L - skill(SkillEffect.MILESTONE_REDUCTION).toLong())

    private fun unitProductionRaw(def: GeneratorDef, owned: Long): BigNum {
        val milestoneStep = milestoneStep()
        return def.baseProduction *
            BigNum.of(2.0).pow((owned / milestoneStep).toDouble()) *
            BigNum.of(2.0).pow(state.level(UpgradeIds.generator(def.id)).toDouble())
    }

    /** Produção por segundo de uma unidade já com melhorias, dimensão e multiplicadores. */
    fun unitProduction(def: GeneratorDef): BigNum = unitProductionRaw(def, state.generators[def.id]) * globalMultiplier

    fun dimensionRequirement(id: Int): BigNum = ProgressionFormulas.dimensionRequirement(
        DimensionDefs.byId(id), state.skillLevel(SkillTree.TRANS_DIMENSION), skill(SkillEffect.DIMENSION_REDUCTION)
    )

    fun resonanceCost(id: Int): Long = 2L +
        (if (id in state.dimensionResonance.indices) state.dimensionResonance[id] else 0).toLong() * 3L

    // ---------------------------------------------------------------- cliques e combate

    fun comboMultiplier(): Double = 1.0 + max(0, comboCount - 1) * comboStep

    fun decayCombo(nowMs: Long) {
        if (comboCount > 0 && nowMs - lastTapMs > Formulas.COMBO_WINDOW_MS) comboCount = 0
    }

    /**
     * Cada chamada processa um toque; não há debounce. [nowMs] é monotônico para combos e
     * [wallNowMs] persiste recargas mesmo depois de fechar o aplicativo.
     */
    fun tap(nowMs: Long, wallNowMs: Long = System.currentTimeMillis()): TapResult {
        refreshTimedEffects(wallNowMs)
        val inWindow = comboCount > 0 && nowMs >= lastTapMs && nowMs - lastTapMs <= Formulas.COMBO_WINDOW_MS
        comboCount = if (inWindow) min(comboCount + 1, maxCombo) else 1
        lastTapMs = nowMs

        val comboMult = comboMultiplier()
        val crit = random.nextDouble() < critChance
        var gain = clickBase * comboMult
        if (crit) gain *= critMultiplier
        addEnergy(gain, EnergySource.CLICK)
        state.totalClicks = state.totalClicks.saturatedPlus(1L)
        if (crit) state.critClicks = state.critClicks.saturatedPlus(1L)
        state.maxCombo = max(state.maxCombo, comboCount)
        val tapMultiplier = if (clickBase.isZero) 1.0
        else (gain / clickBase).toDouble().let { if (it.isFinite()) it.coerceIn(1.0, 1e12) else 1e12 }
        state.highestTapMultiplier = max(state.highestTapMultiplier, tapMultiplier)
        trackTapRate(nowMs)
        incrementDaily(DailyMetric.CLICKS, 1, wallNowMs)
        updateChallenge(ChallengeMetric.CLICKS, 1, wallNowMs)
        updateChallenge(ChallengeMetric.COMBO, comboCount.toLong(), wallNowMs, keepHighest = true)
        if (crit) updateChallenge(ChallengeMetric.CRITS, 1, wallNowMs)
        val bossDamage = gain * (1.0 + skill(SkillEffect.BOSS_DAMAGE) + eventBonus(CosmicEventEffect.BOSS, wallNowMs))
        val combat = damageBoss(bossDamage, wallNowMs)
        maybeTriggerEvent(wallNowMs)
        if (state.totalClicks % 10L == 0L || crit) recordAchievementUnlocks(wallNowMs)
        advanceTutorial(1)
        return TapResult(gain, crit, comboCount, comboMult, combat.damage, combat.defeated, combat.reward)
    }

    fun baseClickGain(): BigNum = clickBase

    private data class CombatOutcome(val damage: BigNum = BigNum.ZERO, val defeated: Boolean = false, val reward: BigNum = BigNum.ZERO)

    private fun damageBoss(damage: BigNum, nowWallMs: Long): CombatOutcome {
        val boss = state.activeBoss ?: return CombatOutcome()
        if (boss.deadlineMs <= nowWallMs || boss.dimensionId != state.currentDimension) {
            state.activeBoss = null
            return CombatOutcome()
        }
        boss.health -= damage
        if (!boss.health.isZero) return CombatOutcome(damage = damage)
        val def = DimensionDefs.byId(boss.dimensionId)
        val reward = def.bossHealth * (0.12 + state.bossWins[def.id] * 0.01)
        state.bossWins[def.id] = state.bossWins[def.id].saturatedPlus(1)
        state.dimensionShards[def.id] = state.dimensionShards[def.id].saturatedPlus(
            max(1L, (def.shardReward * (1.0 + skill(SkillEffect.SHARD_REWARD))).roundToLong())
        )
        state.activeBoss = null
        addEnergy(reward, EnergySource.BOSS)
        updateChallenge(ChallengeMetric.BOSS_WINS, 1, nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return CombatOutcome(damage = damage, defeated = true, reward = reward)
    }

    // ---------------------------------------------------------------- produção e tempo

    fun advance(dtMs: Long, wallNowMs: Long = System.currentTimeMillis()) {
        if (dtMs <= 0L) return
        refreshTimedEffects(wallNowMs)
        val dt = min(dtMs, Formulas.MAX_STEP_MS)
        state.playTimeMs = state.playTimeMs.saturatedPlus(dt)
        if (!production.isZero) addEnergy(production * (dt / 1000.0), EnergySource.PRODUCTION)
    }

    /** Remove efeitos expirados, chefes vencidos pelo relógio e atualiza derivados se necessário. */
    fun refreshTimedEffects(nowWallMs: Long): Boolean {
        var changed = false
        // Chamado a cada toque, a cada passo do laço (30×/s) e a cada publicação: sem alocar listas temporárias.
        if (state.abilityActiveUntilMs.isNotEmpty()) {
            val it = state.abilityActiveUntilMs.entries.iterator()
            while (it.hasNext()) {
                if (it.next().value <= nowWallMs) {
                    it.remove()
                    changed = true
                }
            }
        }
        if (state.activeBoss?.deadlineMs?.let { it <= nowWallMs } == true) {
            state.activeBoss = null
            changed = true
        }
        if (state.activeEvent?.endsAtMs?.let { it <= nowWallMs } == true) {
            state.activeEvent = null
            changed = true
        }
        if (state.activeChallenge?.deadlineMs?.let { it <= nowWallMs } == true) {
            state.activeChallenge = null
            state.challengesAbandoned = state.challengesAbandoned.saturatedPlus(1L)
            changed = true
        }
        if (changed) recompute(nowWallMs)
        return changed
    }

    private fun activeEventDef(nowWallMs: Long): CosmicEventDef? {
        val event = state.activeEvent ?: return null
        return if (event.endsAtMs > nowWallMs) CosmicEventDefs.byId[event.eventId] else null
    }

    private fun eventBonus(effect: CosmicEventEffect, nowWallMs: Long): Double {
        val event = activeEventDef(nowWallMs) ?: return 0.0
        return if (event.effect == effect) event.baseBonus * (1.0 + skill(SkillEffect.EVENT_POWER)) else 0.0
    }

    /** Chance baixa e cooldown longo: eventos ajudam, mas não viram um botão de recompensa infinita. */
    private fun maybeTriggerEvent(nowWallMs: Long) {
        if (state.activeEvent != null) return
        // Evita que um universo recém-criado tenha um evento antes do jogador entender o
        // núcleo do jogo. Também torna a economia de abertura determinística e testável.
        if (state.eventCooldownUntilMs == 0L) {
            state.eventCooldownUntilMs = nowWallMs + INITIAL_EVENT_DELAY_MS
            return
        }
        if (nowWallMs < state.eventCooldownUntilMs) return
        val chance = (0.018 + skill(SkillEffect.EVENT_CHANCE)).coerceAtMost(0.18)
        if (random.nextDouble() >= chance) return
        val def = CosmicEventDefs.all[random.nextInt(CosmicEventDefs.all.size)]
        state.activeEvent = ActiveCosmicEvent(def.id, nowWallMs + def.durationMs)
        state.eventCooldownUntilMs = nowWallMs + 90_000L
        state.eventsTriggered = state.eventsTriggered.saturatedPlus(1L)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
    }

    private enum class EnergySource { CLICK, PRODUCTION, OFFLINE, EVENT, BOSS, CHALLENGE, DAILY, LOGIN, ABILITY, OTHER }

    private fun addEnergy(amount: BigNum, source: EnergySource = EnergySource.OTHER) {
        if (amount.isZero) return
        state.energy += amount
        state.totalEnergy += amount
        state.runEnergy += amount
        when (source) {
            EnergySource.CLICK -> state.clickEnergy += amount
            EnergySource.PRODUCTION -> state.productionEnergy += amount
            EnergySource.EVENT -> state.eventEnergy += amount
            else -> Unit
        }
        refreshUnlocks()
    }

    private fun refreshUnlocks() {
        CrystalDefs.all.forEach { crystal ->
            if (state.totalEnergy >= crystal.unlockAt) state.crystalsUnlocked[crystal.id] = true
        }
        BackgroundDefs.all.forEach { background ->
            if (state.totalEnergy >= background.unlockAt) state.backgroundsUnlocked[background.id] = true
        }
    }

    private fun trackTapRate(nowMs: Long) {
        recentTapTimes.addLast(nowMs)
        while (recentTapTimes.isNotEmpty() && nowMs - recentTapTimes.first() > 1_000L) recentTapTimes.removeFirst()
        state.bestClicksPerSecond = max(state.bestClicksPerSecond, recentTapTimes.size)
    }

    // ---------------------------------------------------------------- compras existentes

    fun isGeneratorUnlocked(id: Int): Boolean =
        id == 0 || state.generators[id] > 0L || state.generators[id - 1] > 0L

    fun planGenerator(def: GeneratorDef, mode: BuyMode): PurchasePlan {
        val owned = state.generators[def.id]
        val room = Formulas.MAX_OWNED - owned
        if (room <= 0L) return PurchasePlan(0L, BigNum.ZERO, false)
        return plan(discountedGeneratorBase(def), def.growth, owned, mode, room)
    }

    fun buyGenerator(id: Int, mode: BuyMode, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        if (!isGeneratorUnlocked(id)) return false
        val def = GeneratorDefs.byId(id)
        val plan = planGenerator(def, mode)
        if (plan.count <= 0L || !plan.affordable) return false
        state.energy -= plan.cost
        state.generators[id] += plan.count
        state.generatorsBought = state.generatorsBought.saturatedPlus(plan.count)
        state.purchaseModeUses[mode.ordinal] = state.purchaseModeUses[mode.ordinal].saturatedPlus(1L)
        state.highestGeneratorTierEver = max(state.highestGeneratorTierEver, id)
        incrementDaily(DailyMetric.PURCHASES, 1, nowWallMs)
        updateChallenge(ChallengeMetric.GENERATORS, plan.count, nowWallMs)
        advanceTutorial(2)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    fun isUnlocked(req: Requirement): Boolean = when (req) {
        Requirement.None -> true
        is Requirement.TotalEnergy -> state.totalEnergy >= req.amount
        is Requirement.GeneratorOwned -> state.generators[req.generatorId] >= req.count
    }

    fun planUpgrade(def: UpgradeDef, mode: BuyMode): PurchasePlan {
        val level = state.level(def.id)
        val remaining = (def.maxLevel - level).toLong()
        if (remaining <= 0L) return PurchasePlan(0L, BigNum.ZERO, false)
        return plan(discountedUpgradeBase(def), def.growth, level.toLong(), mode, remaining)
    }

    fun buyUpgrade(id: String, mode: BuyMode, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        val def = com.infinityclicker.upgrades.UpgradeDefs.byId[id] ?: return false
        if (!isUnlocked(def.requirement)) return false
        val plan = planUpgrade(def, mode)
        if (plan.count <= 0L || !plan.affordable) return false
        state.energy -= plan.cost
        state.upgradeLevels[id] = state.level(id) + plan.count.toInt()
        state.upgradeLevelsBought = state.upgradeLevelsBought.saturatedPlus(plan.count)
        state.purchaseModeUses[mode.ordinal] = state.purchaseModeUses[mode.ordinal].saturatedPlus(1L)
        state.highestUpgradeLevelEver = max(state.highestUpgradeLevelEver, state.level(id))
        incrementDaily(DailyMetric.PURCHASES, 1, nowWallMs)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    // O desconto da árvore tem piso de 35%; a dificuldade global entra por último e vale para todo preço.
    private fun discountedGeneratorBase(def: GeneratorDef): BigNum =
        def.baseCost * (max(0.35, 1.0 - skill(SkillEffect.GENERATOR_DISCOUNT)) * Formulas.DIFFICULTY)

    private fun discountedUpgradeBase(def: UpgradeDef): BigNum =
        def.baseCost * (max(0.35, 1.0 - skill(SkillEffect.UPGRADE_DISCOUNT)) * Formulas.DIFFICULTY)

    private fun plan(base: BigNum, growth: Double, owned: Long, mode: BuyMode, limit: Long): PurchasePlan {
        if (mode == BuyMode.MAX) {
            val n = Formulas.maxAffordable(base, growth, owned, state.energy, limit)
            return if (n > 0L) PurchasePlan(n, Formulas.bulkCost(base, growth, owned, n), true)
            else PurchasePlan(1L, Formulas.unitCost(base, growth, owned), false)
        }
        val n = min(mode.count, limit)
        val cost = Formulas.bulkCost(base, growth, owned, n)
        return PurchasePlan(n, cost, state.energy >= cost)
    }

    // ---------------------------------------------------------------- árvore, habilidades e renascimento

    fun canBuySkill(id: String): Boolean {
        val def = SkillTree.byId[id] ?: return false
        val level = state.skillLevel(id)
        return level < def.maxLevel && state.prestigePoints >= def.costAt(level) &&
            def.prerequisites.all { state.skillLevel(it) > 0 }
    }

    fun buySkill(id: String, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        val def = SkillTree.byId[id] ?: return false
        if (!canBuySkill(id)) return false
        val level = state.skillLevel(id)
        state.prestigePoints -= def.costAt(level)
        state.skillLevels[id] = level + 1
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    /** Habilidades começam no nível 1 para que nenhum botão novo seja inerte; evoluções usam prestígio. */
    fun abilityLevel(id: String): Int {
        val def = AbilityDefs.byId[id] ?: return 0
        return (state.abilityLevels[id] ?: 1).coerceIn(1, def.maxLevel)
    }

    fun canUpgradeAbility(id: String): Boolean {
        val def = AbilityDefs.byId[id] ?: return false
        val level = abilityLevel(id)
        return level < def.maxLevel && state.prestigePoints >= def.upgradeCost(level)
    }

    fun upgradeAbility(id: String, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        val def = AbilityDefs.byId[id] ?: return false
        val level = abilityLevel(id)
        if (level >= def.maxLevel || state.prestigePoints < def.upgradeCost(level)) return false
        state.prestigePoints -= def.upgradeCost(level)
        state.abilityLevels[id] = level + 1
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    fun abilityActiveUntil(id: String): Long = state.abilityActiveUntilMs[id] ?: 0L
    fun abilityCooldownUntil(id: String): Long = state.abilityCooldownUntilMs[id] ?: 0L
    fun isAbilityActive(id: String, nowWallMs: Long): Boolean = abilityActiveUntil(id) > nowWallMs

    fun canUseAbility(id: String, nowWallMs: Long): Boolean {
        val def = AbilityDefs.byId[id] ?: return false
        if (abilityCooldownUntil(id) > nowWallMs) return false
        return when (def.id) {
            AbilityDefs.TEMPORAL_RUSH, AbilityDefs.COSMIC_BURST -> !production.isZero
            else -> true
        }
    }

    fun useAbility(id: String, nowWallMs: Long): AbilityUseResult {
        refreshTimedEffects(nowWallMs)
        val def = AbilityDefs.byId[id] ?: return AbilityUseResult(false, id)
        if (!canUseAbility(id, nowWallMs)) return AbilityUseResult(false, id)
        val level = abilityLevel(id)
        val cooldownReduction = skill(SkillEffect.ABILITY_COOLDOWN).coerceIn(0.0, 0.70)
        // Explosão Cósmica tem recarga fixa (6 min): nem nível nem habilidades da árvore a encurtam.
        val cooldown = if (def.fixedCooldownMs > 0L) nowWallMs + def.fixedCooldownMs
        else nowWallMs + (def.cooldownMs(level) * (1.0 - cooldownReduction)).roundToLong()
        state.abilityCooldownUntilMs[id] = cooldown
        var until = 0L
        var gain = BigNum.ZERO
        val abilityPower = 1.0 + skill(SkillEffect.ABILITY_POWER)
        when (id) {
            AbilityDefs.COSMIC_BURST -> {
                gain = production * ((20 + level * 10).toDouble() * abilityPower)
                addEnergy(gain, EnergySource.ABILITY)
            }
            else -> {
                until = nowWallMs + (def.durationMs(level) * (1.0 + skill(SkillEffect.ABILITY_DURATION))).roundToLong()
                state.abilityActiveUntilMs[id] = until
            }
        }
        state.abilitiesUsed = state.abilitiesUsed.saturatedPlus(1L)
        state.abilityUseCounts[id] = (state.abilityUseCounts[id] ?: 0L).saturatedPlus(1L)
        incrementDaily(DailyMetric.ABILITIES, 1, nowWallMs)
        updateChallenge(ChallengeMetric.ABILITIES, 1, nowWallMs)
        advanceTutorial(3)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return AbilityUseResult(true, id, gain, until, cooldown)
    }

    fun prestigePreview(): PrestigePreview {
        val baseGained = ProgressionFormulas.prestigeGain(state.runEnergy, state.skillLevel(SkillTree.TRANS_PRESTIGE))
        val gained = (baseGained * (1.0 + skill(SkillEffect.PRESTIGE_GAIN))).toInt()
            .coerceAtLeast(0).coerceAtMost(prestigeRoom())
        val after = state.prestigePoints.saturatedPlus(gained)
        return PrestigePreview(
            available = gained > 0,
            points = gained,
            runEnergy = state.runEnergy,
            permanentMultiplierAfter = permanentMultiplierFor(after)
        )
    }

    /** Reinicia só a corrida econômica; totais, árvore, dimensões, cristais e missões ficam preservados. */
    fun prestige(nowWallMs: Long): PrestigeResult? {
        val preview = prestigePreview()
        if (!preview.available) return null
        grantPrestige(preview.points)
        state.prestigeCount = state.prestigeCount.saturatedPlus(1)
        state.prestigeHistory += PrestigeEntry(nowWallMs, preview.points, state.totalEnergy)
        if (state.prestigeHistory.size > 20) state.prestigeHistory.removeAt(0)
        state.energy = BigNum.ZERO
        state.runEnergy = BigNum.ZERO
        state.generators.fill(0L)
        state.upgradeLevels.clear()
        state.activeBoss = null
        state.currentDimension = 0
        state.abilityActiveUntilMs.clear()
        state.abilityCooldownUntilMs.clear()
        comboCount = 0
        lastTapMs = Long.MIN_VALUE
        advanceTutorial(4)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return PrestigeResult(preview.points, state.prestigePoints)
    }

    // ---------------------------------------------------------------- dimensões e chefes

    fun canUnlockDimension(id: Int): Boolean {
        if (id !in 1 until DimensionDefs.count || state.dimensionUnlocked[id]) return false
        return state.dimensionUnlocked[id - 1] && state.totalEnergy >= dimensionRequirement(id)
    }

    fun unlockDimension(id: Int): Boolean {
        if (!canUnlockDimension(id)) return false
        state.dimensionUnlocked[id] = true
        recordAchievementUnlocks()
        return true
    }

    fun travelDimension(id: Int, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        if (id !in 0 until DimensionDefs.count || !state.dimensionUnlocked[id]) return false
        if (state.currentDimension == id) return false
        state.currentDimension = id
        state.dimensionTravelCount = state.dimensionTravelCount.saturatedPlus(1L)
        state.activeBoss = null
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    fun buyResonance(id: Int, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        if (id !in 0 until DimensionDefs.count || !state.dimensionUnlocked[id]) return false
        val cost = resonanceCost(id)
        if (state.dimensionShards[id] < cost) return false
        state.dimensionShards[id] -= cost
        state.dimensionResonance[id] = state.dimensionResonance[id].saturatedPlus(1)
        if (state.currentDimension == id) recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    fun startBoss(nowWallMs: Long): BossStartResult {
        if (state.activeBoss != null) return BossStartResult(false, state.activeBoss)
        val def = DimensionDefs.byId(state.currentDimension)
        val health = bossMaxHealth(def.id)
        val boss = ActiveBoss(def.id, health, nowWallMs + (def.bossDurationMs * (1.0 + skill(SkillEffect.BOSS_DURATION))).roundToLong())
        state.activeBoss = boss
        return BossStartResult(true, boss)
    }

    fun equipCrystal(id: Int, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        if (id !in 0 until CrystalDefs.count || !state.crystalsUnlocked[id]) return false
        state.equippedCrystal = id
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    fun equipBackground(id: Int, nowWallMs: Long = System.currentTimeMillis()): Boolean {
        if (id !in 0 until BackgroundDefs.count || !state.backgroundsUnlocked[id]) return false
        state.equippedBackground = id
        recordAchievementUnlocks(nowWallMs)
        return true
    }

    // ---------------------------------------------------------------- missões, conquista e login

    fun refreshDaily(nowWallMs: Long) {
        val day = nowWallMs.floorDay()
        if (state.dailyDay != day) {
            state.dailyDay = day
            state.dailyProgress.fill(0L)
            state.dailyClaimed.fill(false)
        }
    }

    private fun incrementDaily(metric: DailyMetric, amount: Long, nowWallMs: Long) {
        refreshDaily(nowWallMs)
        DailyMissionDefs.all.forEachIndexed { index, def ->
            if (def.metric == metric && !state.dailyClaimed[index]) {
                state.dailyProgress[index] = state.dailyProgress[index].saturatedPlus(amount).coerceAtMost(def.target)
            }
        }
    }

    fun claimDaily(index: Int, nowWallMs: Long): BigNum? {
        refreshDaily(nowWallMs)
        val def = DailyMissionDefs.all.getOrNull(index) ?: return null
        if (state.dailyClaimed[index] || state.dailyProgress[index] < def.target) return null
        state.dailyClaimed[index] = true
        addEnergy(def.reward, EnergySource.DAILY)
        recordAchievementUnlocks(nowWallMs)
        return def.reward
    }

    fun loginRewardPreview(nowWallMs: Long): BigNum {
        val day = nowWallMs.floorDay()
        if (state.loginClaimedDay == day) return BigNum.ZERO
        val projectedStreak = if (state.lastLoginDay == day - 1) state.loginStreak + 1 else 1
        return BigNum.of(100L * projectedStreak.coerceAtMost(7).toLong()) + production * 10.0
    }

    fun claimLogin(nowWallMs: Long): BigNum? {
        val day = nowWallMs.floorDay()
        if (state.loginClaimedDay == day) return null
        state.loginStreak = if (state.lastLoginDay == day - 1) state.loginStreak + 1 else 1
        state.lastLoginDay = day
        state.loginClaimedDay = day
        val reward = loginRewardPreviewBeforeClaim()
        addEnergy(reward, EnergySource.LOGIN)
        recordAchievementUnlocks(nowWallMs)
        return reward
    }

    private fun loginRewardPreviewBeforeClaim(): BigNum =
        BigNum.of(100L * state.loginStreak.coerceAtMost(7).toLong()) + production * 10.0

    fun canClaimAchievement(id: String): Boolean {
        val def = AchievementDefs.byId[id] ?: return false
        return id !in state.achievementsClaimed && def.achieved(state)
    }

    fun claimAchievement(id: String, nowWallMs: Long = System.currentTimeMillis()): Int? {
        val def = AchievementDefs.byId[id] ?: return null
        if (!canClaimAchievement(id)) return null
        state.achievementsClaimed += id
        state.achievementsUnlockedAt.putIfAbsent(id, nowWallMs)
        val granted = max(1, (def.reward * (1.0 + skill(SkillEffect.ACHIEVEMENT_REWARD))).roundToLong().toInt())
        grantPrestige(granted)
        recompute(nowWallMs)
        return granted
    }

    /** Marca conquistas atingidas, sem conceder nada até o jogador coletar explicitamente. */
    fun recordAchievementUnlocks(nowWallMs: Long = System.currentTimeMillis()) {
        AchievementDefs.all.forEach { def ->
            if (def.id !in state.achievementsUnlockedAt && def.achieved(state)) {
                state.achievementsUnlockedAt[def.id] = nowWallMs
            }
        }
    }

    fun startChallenge(id: String, nowWallMs: Long): Boolean {
        if (state.activeChallenge != null) return false
        val def = ChallengeDefs.byId[id] ?: return false
        if (!def.available(state)) return false
        state.activeChallenge = ActiveChallenge(def.id, nowWallMs, nowWallMs + def.durationMs)
        return true
    }

    fun abandonChallenge(): Boolean {
        if (state.activeChallenge == null) return false
        state.activeChallenge = null
        state.challengesAbandoned = state.challengesAbandoned.saturatedPlus(1L)
        return true
    }

    fun consumeChallengeCompletion(): ChallengeCompletion? = pendingChallengeCompletion.also { pendingChallengeCompletion = null }

    private fun updateChallenge(metric: ChallengeMetric, amount: Long, nowWallMs: Long, keepHighest: Boolean = false) {
        val active = state.activeChallenge ?: return
        val def = ChallengeDefs.byId[active.challengeId] ?: run {
            state.activeChallenge = null
            return
        }
        if (active.deadlineMs <= nowWallMs) {
            state.activeChallenge = null
            state.challengesAbandoned = state.challengesAbandoned.saturatedPlus(1L)
            return
        }
        if (def.id == "manual_pulse" && state.generators.any { it > 0L }) {
            state.activeChallenge = null
            state.challengesAbandoned = state.challengesAbandoned.saturatedPlus(1L)
            return
        }
        if (def.metric != metric) return
        active.progress = if (keepHighest) max(active.progress, amount) else active.progress.saturatedPlus(amount).coerceAtMost(def.target)
        if (active.progress < def.target) return

        state.activeChallenge = null
        state.challengeCompletions = state.challengeCompletions.saturatedPlus(1L)
        val index = ChallengeDefs.all.indexOfFirst { it.id == def.id }
        if (index >= 0) state.challengeWins[index] = state.challengeWins[index].saturatedPlus(1L)
        state.challengeFastestMs = min(state.challengeFastestMs, (nowWallMs - active.startedAtMs).coerceAtLeast(0L))
        addEnergy(def.energyReward, EnergySource.CHALLENGE)
        grantPrestige(def.prestigeReward)
        recompute(nowWallMs)
        recordAchievementUnlocks(nowWallMs)
        pendingChallengeCompletion = ChallengeCompletion(def.name, def.energyReward, def.prestigeReward)
    }

    private fun advanceTutorial(step: Int) {
        if (state.tutorialStep < step) state.tutorialStep = step
    }

    // ---------------------------------------------------------------- offline

    /** Credita ganhos offline uma vez; a marca de tempo é alterada antes de qualquer retorno. */
    fun applyOffline(nowMs: Long): OfflineReport? {
        refreshTimedEffects(nowMs)
        val last = state.lastSessionMs
        state.lastSessionMs = nowMs
        if (last <= 0L) return null
        val elapsed = nowMs - last
        if (elapsed <= 0L || production.isZero) return null
        val capMs = offlineCapHours * 3_600_000L
        val credited = min(elapsed, capMs)
        val gain = production * (credited / 1000.0) * offlineEfficiency
        if (gain.isZero) return null
        addEnergy(gain, EnergySource.OFFLINE)
        state.offlineEarned += gain
        recordAchievementUnlocks(nowMs)
        return OfflineReport(elapsed, credited, capMs, offlineEfficiency, globalMultiplier, production, gain)
    }

    private fun normalizeState() {
        state.currentDimension = state.currentDimension.coerceIn(0, DimensionDefs.count - 1)
        state.highestGeneratorTierEver = max(state.highestGeneratorTierEver, state.generators.indexOfLast { it > 0L })
        state.highestUpgradeLevelEver = max(state.highestUpgradeLevelEver, state.upgradeLevels.values.maxOrNull() ?: 0)
        state.dimensionUnlocked[0] = true
        state.crystalsUnlocked[0] = true
        state.backgroundsUnlocked[0] = true
        if (state.equippedCrystal !in state.crystalsUnlocked.indices || !state.crystalsUnlocked[state.equippedCrystal]) {
            state.equippedCrystal = 0
        }
        if (state.equippedBackground !in state.backgroundsUnlocked.indices || !state.backgroundsUnlocked[state.equippedBackground]) {
            state.equippedBackground = 0
        }
        refreshUnlocks()
    }

    private fun Long.floorDay(): Long = this / DAY_MS

    private fun prestigeRoom(): Int = Int.MAX_VALUE - state.prestigePoints.coerceIn(0, Int.MAX_VALUE)

    /** Mantém o campo Int compatível com saves antigos sem permitir que o total volte de sinal. */
    private fun grantPrestige(points: Int): Int {
        val granted = points.coerceAtLeast(0).coerceAtMost(prestigeRoom())
        state.prestigePoints = state.prestigePoints.saturatedPlus(granted)
        return granted
    }

    private fun Long.saturatedPlus(amount: Long): Long {
        if (amount > 0L && this > Long.MAX_VALUE - amount) return Long.MAX_VALUE
        if (amount < 0L && this < Long.MIN_VALUE - amount) return Long.MIN_VALUE
        return this + amount
    }

    private fun Int.saturatedPlus(amount: Int): Int {
        if (amount > 0 && this > Int.MAX_VALUE - amount) return Int.MAX_VALUE
        if (amount < 0 && this < Int.MIN_VALUE - amount) return Int.MIN_VALUE
        return this + amount
    }

    private companion object {
        const val DAY_MS = 86_400_000L
        const val INITIAL_EVENT_DELAY_MS = 90_000L
    }
}
