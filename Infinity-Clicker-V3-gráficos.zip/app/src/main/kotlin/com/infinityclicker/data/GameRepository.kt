package com.infinityclicker.data

import java.util.concurrent.atomic.AtomicLong
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclicker.game.GameState
import kotlinx.coroutines.flow.first

private val Context.gameDataStore by preferencesDataStore(name = "infinity_clicker")

enum class GraphicsQuality(val label: String, val particleScale: Float, val starCount: Int) {
    AUTO("Automático", 0.82f, 72),
    LOW("Econômico", 0.32f, 28),
    MEDIUM("Equilibrado", 0.60f, 52),
    HIGH("Alta", 1.0f, 90),
    ULTRA("Ultra", 1.28f, 120)
}

/** Perfil realmente usado pelo renderizador quando o jogador escolhe Automático. */
fun GraphicsQuality.resolvedFor(
    batterySaver: Boolean,
    deviceQuality: GraphicsQuality = GraphicsQuality.ULTRA
): GraphicsQuality = when {
    batterySaver -> GraphicsQuality.LOW
    this == GraphicsQuality.AUTO -> deviceQuality.takeUnless { it == GraphicsQuality.AUTO } ?: GraphicsQuality.ULTRA
    else -> this
}

/** Preferências que de fato alteram o renderizador. [deviceQuality] é detectada por sessão e não é salva. */
data class UserSettings(
    val scientificNotation: Boolean = false,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.AUTO,
    val frameRateCap: Int = 120,
    val batterySaver: Boolean = false,
    val effectsIntensity: Float = 1f,
    val panelOpacity: Float = 0.12f,
    /** Desliga somente movimentos decorativos; resposta ao toque e dados do jogo continuam normais. */
    val motionEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val deviceQuality: GraphicsQuality = GraphicsQuality.ULTRA
)

data class LoadedGame(
    val state: GameState,
    val settings: UserSettings,
    /** true quando o save principal estava corrompido e o backup foi usado. */
    val recoveredFromBackup: Boolean
)

/**
 * Persistência local com DataStore (escrita atômica por transação).
 * Guarda o save principal e o save anterior como backup: se o principal falhar no checksum,
 * o backup é carregado em vez de perder o progresso.
 */
class GameRepository(context: Context) {
    private val store = context.applicationContext.gameDataStore

    /**
     * Revisão do save principal gravado (ou carregado). Com ela, cada gravação normal não precisa mais
     * decodificar o save inteiro duas vezes: gravações atrasadas e fora de ordem são descartadas por aqui.
     */
    private val lastRevision = AtomicLong(-1L)

    suspend fun load(): LoadedGame {
        val prefs = store.data.first()
        val quality = prefs[KEY_QUALITY]?.let { raw -> GraphicsQuality.entries.firstOrNull { it.name == raw } }
            ?: GraphicsQuality.AUTO
        val fps = (prefs[KEY_FPS] ?: 120).let { if (it in setOf(30, 60, 90, 120)) it else 120 }
        val settings = UserSettings(
            scientificNotation = prefs[KEY_SCI] ?: false,
            graphicsQuality = quality,
            frameRateCap = fps,
            batterySaver = prefs[KEY_BATTERY] ?: false,
            effectsIntensity = (prefs[KEY_EFFECTS] ?: 1f).coerceIn(0.25f, 1.5f),
            panelOpacity = (prefs[KEY_PANEL] ?: 0.12f).coerceIn(0.06f, 0.30f),
            motionEnabled = prefs[KEY_MOTION] ?: true,
            hapticsEnabled = prefs[KEY_HAPTICS] ?: true,
            soundEnabled = prefs[KEY_SOUND] ?: true,
            musicEnabled = prefs[KEY_MUSIC] ?: true
        )

        prefs[KEY_PRIMARY]?.let { text ->
            StateSerializer.deserialize(text)?.let { lastRevision.set(it.saveRevision); return LoadedGame(it, settings, false) }
        }
        prefs[KEY_BACKUP]?.let { text ->
            StateSerializer.deserialize(text)?.let { return LoadedGame(it, settings, true) }
        }
        return LoadedGame(GameState.new(), settings, recoveredFromBackup = false)
    }

    /** [text] já vem serializado (feito sob lock pelo chamador), então a escrita não toca no estado vivo. */
    suspend fun saveText(text: String) {
        val rev = revisionOf(text)
        if (rev >= 0L && rev <= lastRevision.get()) return
        store.edit { p ->
            // O ViewModel pode enfileirar snapshots em threads diferentes. A revisão impede que uma
            // gravação antiga, entregue atrasada, reverta o progresso novo (conferida de novo dentro da transação).
            if (rev >= 0L && rev <= lastRevision.get()) return@edit
            val old = p[KEY_PRIMARY]
            val known = lastRevision.get() >= 0L
            var oldValid = old != null && known
            if (old != null && !known) {
                // Primeira gravação da sessão sem save conhecido: valida o que existe antes de virar backup.
                val current = StateSerializer.deserialize(old)
                oldValid = current != null
                if (rev < 0L) {
                    val incoming = StateSerializer.deserialize(text) ?: return@edit
                    if (current != null && !isAtLeastAsRecent(incoming, current)) return@edit
                } else if (current != null && rev < current.saveRevision) return@edit
            } else if (rev < 0L) {
                StateSerializer.deserialize(text) ?: return@edit
            }
            if (oldValid && old != null) p[KEY_BACKUP] = old
            p[KEY_PRIMARY] = text
            if (rev >= 0L) lastRevision.set(rev)
        }
    }

    private fun revisionOf(text: String): Long {
        val i = text.indexOf("revision=")
        if (i < 0) return -1L
        var j = i + 9
        var v = 0L
        var any = false
        while (j < text.length && text[j] in '0'..'9' && v < Long.MAX_VALUE / 20L) {
            v = v * 10L + (text[j] - '0'); j++; any = true
        }
        return if (any) v else -1L
    }

    /** Reinício confirmado pelo jogador: remove também o backup para não ressuscitar progresso apagado. */
    suspend fun replaceAll(text: String) {
        store.edit { p ->
            p.remove(KEY_BACKUP)
            p[KEY_PRIMARY] = text
            lastRevision.set(revisionOf(text))
        }
    }

    /** Importação confirmada: preserva o save atual como backup antes de trocar a fonte principal. */
    suspend fun importText(text: String) {
        store.edit { p ->
            if (StateSerializer.deserialize(text) == null) return@edit
            val old = p[KEY_PRIMARY]
            if (old != null && StateSerializer.deserialize(old) != null) p[KEY_BACKUP] = old
            p[KEY_PRIMARY] = text
            lastRevision.set(revisionOf(text))
        }
    }

    suspend fun saveSettings(settings: UserSettings) {
        store.edit { p ->
            p[KEY_SCI] = settings.scientificNotation
            p[KEY_QUALITY] = settings.graphicsQuality.name
            p[KEY_FPS] = settings.frameRateCap
            p[KEY_BATTERY] = settings.batterySaver
            p[KEY_EFFECTS] = settings.effectsIntensity
            p[KEY_PANEL] = settings.panelOpacity
            p[KEY_MOTION] = settings.motionEnabled
            p[KEY_HAPTICS] = settings.hapticsEnabled
            p[KEY_SOUND] = settings.soundEnabled
            p[KEY_MUSIC] = settings.musicEnabled
        }
    }

    suspend fun wipe() {
        store.edit { p ->
            p.remove(KEY_PRIMARY)
            p.remove(KEY_BACKUP)
        }
    }

    private companion object {
        val KEY_PRIMARY = stringPreferencesKey("state_primary")
        val KEY_BACKUP = stringPreferencesKey("state_backup")
        val KEY_SCI = booleanPreferencesKey("pref_scientific")
        val KEY_QUALITY = stringPreferencesKey("pref_graphics_quality")
        val KEY_FPS = intPreferencesKey("pref_fps_cap")
        val KEY_BATTERY = booleanPreferencesKey("pref_battery_saver")
        val KEY_EFFECTS = floatPreferencesKey("pref_effects_intensity")
        val KEY_PANEL = floatPreferencesKey("pref_panel_opacity")
        val KEY_MOTION = booleanPreferencesKey("pref_motion_enabled")
        val KEY_HAPTICS = booleanPreferencesKey("pref_haptics")
        val KEY_SOUND = booleanPreferencesKey("pref_sound")
        val KEY_MUSIC = booleanPreferencesKey("pref_music")

        private fun isAtLeastAsRecent(incoming: GameState, current: GameState): Boolean =
            incoming.saveRevision > current.saveRevision ||
                (incoming.saveRevision == current.saveRevision && incoming.lastModifiedMs >= current.lastModifiedMs)
    }
}
