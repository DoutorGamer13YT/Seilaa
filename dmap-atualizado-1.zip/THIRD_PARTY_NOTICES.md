# Componentes, dados e licenças

Os textos completos e avisos estão em `server/licenses/` e `app/src/main/assets/licenses.txt`; a tela Sobre → Licenças e atribuições apresenta os avisos no app. A preparação de pacotes inclui os notices e licenças dos recursos locais.

- MapLibre Native Android: BSD-2-Clause; https://github.com/maplibre/maplibre-native/blob/main/LICENSE.md. Preservar também notices de dependências transitivas na distribuição final.
- AndroidX/Compose/WorkManager, Kotlin/coroutines e Gradle Wrapper: Apache-2.0. O wrapper existente não foi executado ou substituído.
- Protomaps Basemaps: código BSD-3-Clause, design do mapa CC0. Dados derivados do OpenStreetMap: ODbL 1.0, com crédito a © OpenStreetMap contributors. Os avisos específicos de fontes adicionais estão em `Protomaps-DATA.txt`; o operador deve garantir que correspondam ao build utilizado.
- Glyphs Noto: SIL Open Font License. Sprites derivados de Tangram icons: MIT. As cópias dos assets usadas pelo servidor devem preservar as respectivas licenças originais.
- `land.geojson`: Natural Earth, escala 1:110m, domínio público. Origem: https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_land.geojson. Uso: prévia de contornos para seleção de área. Termos: https://www.naturalearthdata.com/about/terms-of-use/.
- Apple Maps: site remoto proprietário. Nenhum código, mapa, fonte ou ícone da Apple foi incorporado. O uso online permanece sujeito aos termos e restrições do serviço.

Não há PMTiles regionais ou dados do planeta neste ZIP. O único pequeno conjunto geográfico incluído é a prévia Natural Earth. Os pacotes regionais serão preparados e distribuídos separadamente pelo operador.
