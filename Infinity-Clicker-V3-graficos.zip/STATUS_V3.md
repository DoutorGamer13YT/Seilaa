# Status — Infinity Clicker 3.0

## Implementado e conectado ao motor

| Sistema | Entrega verificável no código |
|---|---|
| Save compatível | Formato `IC1` V3 com CRC32, backup anterior e leitura de V1/V2; novos campos recebem defaults seguros em saves antigos. |
| Economia V3 | Custos e crescimento por tier/raridade revisados, primeiro prestígio logarítmico a partir de 1,6M e testes de regressão da curva. |
| Cristal 3D | Facetas, reflexão, núcleo, rotação, ondas, críticos, partículas com teto e feedback tátil configurável. |
| Ambientes | Oito fundos Canvas equipáveis, persistidos e realmente diferentes na renderização. |
| Árvore | 100 nós em cinco caminhos, com pré-requisitos, custo, zoom/arraste e efeitos calculados no `GameEngine`. |
| Conquistas | 250 itens: Cliques 40, Produção 35, Melhorias 35, Prestígio 30, Habilidades 30, Desafios 30, Exploração 25 e Secretas 25. Recompensas são únicas e multiplicadores de árvore são aplicados de verdade. |
| Desafios | Seis provas iniciadas pelo jogador; metas, prazo, cancelamento, recompensa, melhor tempo e vitórias são persistidos. |
| Eventos | Cinco eventos locais com cooldown, duração persistida e efeitos reais em clique, produção, crítico, combo ou dano a chefe. |
| Estatísticas | Cliques/s, melhor multiplicador, picos de produção, fontes de energia, eficiência automática, conquistas e progressão. |
| Backup do jogador | Exportação e importação pelo Storage Access Framework; importação inválida é rejeitada e uma importação válida mantém o save anterior como backup. |
| Desempenho | Abas pesadas não reconstruídas no loop da tela inicial; qualidade/partículas/fundo/FPS/economia de bateria continuam aplicados. |

## Deliberadamente pendente

- Música e efeitos sonoros licenciados: não há assets de áudio originais neste repositório; por isso não foi exibido controle de áudio inerte.
- Firebase Auth/Firestore e sincronização: continuam desativados até existir projeto Firebase, fingerprints da assinatura de produção e regras do proprietário. O jogo local não exige internet.
- Profiling em Galaxy A54 físico: o código reduz trabalho por qualidade, mas medição térmica/FPS/bateria deve ser feita no aparelho antes de alegar números constantes.
- APK de release: exige uma chave de assinatura legítima do proprietário. Um APK debug terá assinatura diferente e pode exigir desinstalar uma versão anterior assinada por outra chave.

## Validação incluída

Além dos testes V1/V2 existentes, `V3ProgressionTest` valida a distribuição 250/100, condições alcançáveis no estado de progressão completa e round-trip V3. `V3BalanceTest` protege a curva econômica e o limiar de prestígio.

## Correção de FPS, rolagem e tela inicial
- FPS: o limite agora é um divisor inteiro da taxa real da tela (FrameTicker) e o modo de tela é escolhido pelo menor erro (RefreshRate.kt). Em telas 60/120 Hz o "90" roda a 120 (sem quadros repetidos); o Perfil mostra a taxa real aplicada.
- Rolagem: a UI deixou de ser publicada a cada 8–17 ms (agora 66/100/200 ms conforme a aba); o motor roda a 33 ms; o vidro não usa mais `shadow` por painel.
- Tela inicial: novo cabeçalho de energia, cristal com raios, pedestal, anel orbital, fagulhas e brilho; habilidades e combo redesenhados.
- Sem SDK Android neste ambiente: compile pelo workflow build-apk.yml.
- Perfil/Dev saíram da barra inferior: bolinha de perfil no topo abre painel com Resumo, Ajustes, Ambientes e Dev.
- Gráficos: estrelas cadentes, clarões nas estrelas, vinheta, flash ao tocar, brilho nas partículas, chanfro e aberração cromática no cristal.
- Correção de crash: a lista de Dimensões usava o mesmo id (0,1,2…) como chave de dimensões e cristais; ao rolar até o fim os dois grupos ficavam visíveis e o LazyColumn lançava IllegalArgumentException (chave duplicada). Chaves agora são "dim-N" e "crystal-N".
- Sons: SoundFx.kt sintetiza 11 efeitos + pad ambiente em loop (sem arquivos de áudio); opções "Efeitos sonoros" e "Música ambiente" em Perfil › Ajustes.
- Frames pulados: Canvas do cristal e do fundo agora têm camada própria (graphicsLayer), brushes cacheados em espaço unitário (sem shader nativo novo por quadro), texto flutuante com layout em cache, fundo a 30 fps com relógio próprio.
- Polimento: indicador deslizante com mola na barra inferior, botões com clique elástico (bouncyClick), anel de marcas + arco de combo em volta do cristal, vazamento de luz nos painéis de vidro.
- Release otimizado (R8, shrinkResources, baseline-prof, profileinstaller) e pool de Paths no cristal: feitos na rodada "otimize tudo".
- Rodada "mais bonito e otimizado": GlowBar (barra com mola, degradê e brilho) em Início, Missões e Perfil; dígitos tabulares na energia; dica do tutorial em pílula de vidro; o laço de 66 ms reaproveita dimensões/cristais/fundos (revalida a cada ~1 s e nas ações).
- Barra de navegação redesenhada no estilo Liquid Glass do iOS 26 (cápsula de vidro claro, ícones desenhados, indicador em lente que estica ao deslizar).
