package com.infinityclicker.ui.components

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

/**
 * Verdadeiro quando o próprio sistema pede menos movimento: modo de economia de bateria do Android ligado
 * ou "remover animações" (escala de animação 0) nas opções de acessibilidade/desenvolvedor.
 * O jogo trata isso como o modo economia de bateria dele (animações decorativas paradas, 30 fps, qualidade menor).
 */
@Composable
fun rememberSystemReducedMotion(): Boolean {
    val context = LocalContext.current
    var powerSave by remember { mutableStateOf(false) }
    DisposableEffect(context) {
        val pm = context.getSystemService(PowerManager::class.java)
        powerSave = pm?.isPowerSaveMode == true
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                powerSave = pm?.isPowerSaveMode == true
            }
        }
        // Broadcast protegido do sistema: não precisa de flag de exportação.
        runCatching { context.registerReceiver(receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)) }
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }
    val animationsOff = remember(context) {
        runCatching { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    return powerSave || animationsOff
}
