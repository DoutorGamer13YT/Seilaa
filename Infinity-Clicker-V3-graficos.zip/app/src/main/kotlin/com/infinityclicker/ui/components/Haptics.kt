package com.infinityclicker.ui.components

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

enum class HapticKind { TICK, CLICK, HEAVY }

/**
 * Vibração direta pelo motor do aparelho. O performHapticFeedback do Compose depende da opção do sistema
 * "vibração ao toque" e, em vários Samsung, simplesmente não faz nada; aqui o pulso vai direto ao Vibrator.
 */
object Haptics {
    @Volatile private var vibrator: Vibrator? = null
    private var usable = false
    private var lastAt = 0L

    /** Um efeito pronto por tipo: antes cada toque alocava um VibrationEffect novo. Só a thread de toque preenche. */
    private val effects = arrayOfNulls<VibrationEffect>(3)

    /**
     * `vibrate()` é uma chamada binder síncrona. Feita na thread de toque, atrasava o quadro do cristal a cada toque
     * (até ~33 por segundo em autoclicker); numa thread própria o toque só enfileira o pulso.
     */
    private val worker: Handler by lazy {
        Handler(HandlerThread("haptics").apply { isDaemon = true; start() }.looper)
    }

    private fun resolve(context: Context): Vibrator? {
        vibrator?.let { return it }
        val app = context.applicationContext
        val v = if (Build.VERSION.SDK_INT >= 31) {
            app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        usable = v?.hasVibrator() == true
        vibrator = v
        return v
    }

    private fun effectFor(v: Vibrator, kind: HapticKind): VibrationEffect {
        effects[kind.ordinal]?.let { return it }
        val ms = when (kind) { HapticKind.TICK -> 14L; HapticKind.CLICK -> 22L; HapticKind.HEAVY -> 42L }
        val amp = when (kind) { HapticKind.TICK -> 120; HapticKind.CLICK -> 180; HapticKind.HEAVY -> 255 }
        val effect = if (v.hasAmplitudeControl()) VibrationEffect.createOneShot(ms, amp)
        else VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
        effects[kind.ordinal] = effect
        return effect
    }

    fun play(context: Context, kind: HapticKind) {
        val now = SystemClock.elapsedRealtime()
        // Evita empilhar pulsos em toques muito rápidos (autoclicker): vira um zumbido contínuo.
        if (now - lastAt < 30L) return
        lastAt = now
        val v = resolve(context) ?: return
        if (!usable) return
        val effect = effectFor(v, kind)
        worker.post { runCatching { v.vibrate(effect) } }
    }
}
