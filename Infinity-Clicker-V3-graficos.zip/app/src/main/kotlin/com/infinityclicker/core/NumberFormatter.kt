package com.infinityclicker.core

import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * Formatação de [BigNum] para a tela.
 *
 * Abreviado: 1,5K  2,5M  3B  4T  Qa Qi Sx Sp Oc No Dc ... Vg (até 1e66) e depois aa, ab, ... zz.
 * Científico: 1.23e45.
 * Só as sequências além de "zz" (≈ 1e2100) caem para notação científica automaticamente.
 */
object NumberFormatter {

    private val NAMED = listOf(
        "", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No",
        "Dc", "Ud", "Dd", "Td", "Qad", "Qid", "Sxd", "Spd", "Ocd", "Nod", "Vg"
    )
    private const val LETTER_GROUPS = 26 * 26

    fun suffix(group: Int): String? {
        if (group < 0) return null
        if (group < NAMED.size) return NAMED[group]
        val idx = group - NAMED.size
        if (idx >= LETTER_GROUPS) return null
        return "${'a' + idx / 26}${'a' + idx % 26}"
    }

    fun format(n: BigNum, scientific: Boolean = false): String {
        if (n.isZero) return "0"
        if (n.exponent < 3L) return small(n)
        if (scientific) return sci(n)
        if (n.exponent >= 3L * (NAMED.size + LETTER_GROUPS)) return sci(n)

        var group = (n.exponent / 3L).toInt()
        var lead = n.mantissa * 10.0.pow((n.exponent % 3L).toInt())
        var decimals = decimalsFor(lead)
        var rounded = roundTo(lead, decimals)
        if (rounded >= 1000.0) {
            group += 1
            lead = rounded / 1000.0
            decimals = decimalsFor(lead)
            rounded = roundTo(lead, decimals)
        }
        val suffix = suffix(group) ?: return sci(n)
        return trimZeros(String.format(Locale.US, "%.${decimals}f", rounded)) + suffix
    }

    /** Valores abaixo de 1000 (inclui frações). */
    private fun small(n: BigNum): String {
        if (n.exponent < -3L) return sci(n)
        val v = n.toDouble()
        if (v >= 1.0) {
            val decimals = decimalsFor(v)
            val rounded = roundTo(v, decimals)
            if (rounded >= 1000.0) return "1K"
            return trimZeros(String.format(Locale.US, "%.${decimals}f", rounded))
        }
        val decimals = if (v < 0.1) 3 else 2
        return trimZeros(String.format(Locale.US, "%.${decimals}f", v))
    }

    private fun sci(n: BigNum): String {
        var m = roundTo(n.mantissa, 2)
        var e = n.exponent
        if (m >= 10.0) {
            m /= 10.0
            e += 1
        }
        return String.format(Locale.US, "%.2fe%d", m, e)
    }

    private fun decimalsFor(lead: Double): Int = when {
        lead < 10.0 -> 2
        lead < 100.0 -> 1
        else -> 0
    }

    private fun roundTo(v: Double, decimals: Int): Double {
        val f = 10.0.pow(decimals)
        return (v * f).roundToLong() / f
    }

    private fun trimZeros(s: String): String =
        if (s.contains('.')) s.trimEnd('0').trimEnd('.') else s

    /** Duração legível: "2h 05min", "3min 10s", "45s". */
    fun duration(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val d = total / 86_400L
        val h = (total % 86_400L) / 3_600L
        val m = (total % 3_600L) / 60L
        val s = total % 60L
        return when {
            d > 0 -> "${d}d ${h}h ${m}min"
            h > 0 -> "${h}h ${String.format(Locale.US, "%02d", m)}min"
            m > 0 -> "${m}min ${String.format(Locale.US, "%02d", s)}s"
            else -> "${s}s"
        }
    }
}
