package com.infinityclicker.ui.components

import android.content.Context
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Governador térmico: escuta o status térmico do sistema e sugere um teto de FPS
 * ANTES do throttling do SoC. Isso economiza bateria e evita engasgos quando o
 * aparelho esquenta (o app reage em segundos; o sistema, em minutos).
 */
object EnergyGovernor {
    /** Estado do Compose: quem lê o teto na composição recompõe sozinho quando o aparelho esquenta ou esfria. */
    var thermalStatus: Int by mutableIntStateOf(PowerManager.THERMAL_STATUS_NONE); private set

    /** Teto de FPS recomendado pelo estado térmico atual (240 = sem restrição). */
    fun suggestedCap(): Int = when (thermalStatus) {
        PowerManager.THERMAL_STATUS_MODERATE -> 60
        PowerManager.THERMAL_STATUS_SEVERE,
        PowerManager.THERMAL_STATUS_CRITICAL,
        PowerManager.THERMAL_STATUS_EMERGENCY -> 30
        else -> 240
    }

    /** Registra o listener térmico; [onChanged] é chamado na main thread a cada mudança de status. */
    fun start(context: Context, scope: CoroutineScope, onChanged: (Int) -> Unit) {
        val pm = context.getSystemService(PowerManager::class.java) ?: return
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            if (status != thermalStatus) {
                thermalStatus = status
                onChanged(suggestedCap())
            }
        }
        pm.addThermalStatusListener(context.mainExecutor, listener)
        // Primeira leitura: o status atual pode já ser diferente do NONE inicial.
        val initial = pm.currentThermalStatus
        if (initial != thermalStatus) {
            thermalStatus = initial
            onChanged(suggestedCap())
        }
        // O listener vive enquanto o escopo estiver ativo (LaunchedEffect cancela ao sair da tela).
        scope.launch {
            try {
                while (isActive) delay(60_000)
            } finally {
                pm.removeThermalStatusListener(listener)
            }
        }
    }
}
