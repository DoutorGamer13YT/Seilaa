package dev.atlas

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import dev.atlas.core.DeepLinks
import dev.atlas.ui.AtlasApp
import dev.atlas.ui.AtlasViewModel

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<AtlasViewModel> {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T =
                AtlasViewModel(application as AtlasApplication, extras.createSavedStateHandle()) as T
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) receiveLink(intent)
        setContent { AtlasApp(viewModel) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); receiveLink(intent) }
    private fun receiveLink(intent: Intent?) {
        val raw = intent?.dataString ?: return
        val target = DeepLinks.parse(raw)
        if (target != null) viewModel.handleLink(target) else viewModel.message("Este link não contém um lugar ou uma pesquisa válida.")
    }
}
