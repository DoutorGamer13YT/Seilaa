# Estado técnico do Dmap 0.1.0

| Recurso | Estado | Observação |
|---|---|---|
| Compose, tema escuro/claro | Implementado no código | Persistência DataStore; sem compilação executada |
| Busca Geoapify | Implementada no código | Precisa chave; resultados reais dependem do serviço |
| Favoritos | Implementados localmente | DataStore, sem listas |
| Localização pontual | Implementada no código | Permissão Android; não é rastreamento contínuo |
| MapLibre online | Adaptador implementado | Precisa style URL autorizado |
| Apple Maps | Adaptador MapKit JS condicional | Precisa backend/token/origem e validação em WebView |
| Offline regional | Pendente | Nenhum download ou pacote local foi incluído |
| Rotas e navegação | Pendente | Ação abre app de mapas externo via `geo:` |
| Bússola, histórico, detalhes completos | Pendente | Não simulados |
| Build/QA | Pendente | Gradle proibido pela solicitação; sem alegação de build validado |
