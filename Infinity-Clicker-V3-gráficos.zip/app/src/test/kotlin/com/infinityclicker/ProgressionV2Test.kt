package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.data.StateSerializer
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.CrystalDefs
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.game.SkillTree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.zip.CRC32
import kotlin.random.Random

class ProgressionV2Test {

    @Test
    fun v1SaveMigratesWithoutLosingLifetimeProgress() {
        val body = """
            IC1
            v=1
            energy=5.0:3
            total=9.0:6
            offlineEarned=0.0:0
            clicks=12
            crits=1
            maxCombo=4
            genBought=3
            upBought=2
            playMs=10
            last=123
            gens=3,0,0,0,0,0,0,0,0,0
            ups=
        """.trimIndent() + "\n"
        val crc = CRC32().also { it.update(body.toByteArray(Charsets.UTF_8)) }.value.toString(16)
        val state = StateSerializer.deserialize(body + "crc=$crc")
        assertNotNull(state)
        assertEquals(BigNum.of(9e6), state!!.totalEnergy)
        assertEquals(state.totalEnergy, state.runEnergy)
        assertEquals(3L, state.generators[0])
        assertTrue(state.dimensionUnlocked[0])
        assertTrue(state.crystalsUnlocked[0])
    }

    @Test
    fun v2RoundTripKeepsNewProgressionFields() {
        val s = GameState.new().apply {
            energy = BigNum.of(1234.0); totalEnergy = BigNum.of(1e9); runEnergy = BigNum.of(8e6)
            prestigePoints = 11; prestigeCount = 2
            skillLevels[SkillTree.POWER_CORE] = 3
            dimensionUnlocked[1] = true; dimensionShards[1] = 7; dimensionResonance[1] = 2
            crystalsUnlocked[1] = true; equippedCrystal = 1
            abilityLevels[AbilityDefs.SUPER_CLICK] = 4; abilityCooldownUntilMs[AbilityDefs.SUPER_CLICK] = 888L
            dailyDay = 123L; dailyProgress[0] = 50L; dailyClaimed[0] = true
            achievementsClaimed += "click_1k"
        }
        val back = StateSerializer.deserialize(StateSerializer.serialize(s))!!
        assertEquals(s.runEnergy, back.runEnergy)
        assertEquals(11, back.prestigePoints)
        assertEquals(3, back.skillLevel(SkillTree.POWER_CORE))
        assertEquals(7L, back.dimensionShards[1])
        assertEquals(2, back.dimensionResonance[1])
        assertEquals(1, back.equippedCrystal)
        assertEquals(4, back.abilityLevel(AbilityDefs.SUPER_CLICK))
        assertTrue(back.dailyClaimed[0])
        assertTrue("click_1k" in back.achievementsClaimed)
    }

    @Test
    fun skillsAndCrystalModifyActualClickCalculation() {
        val s = GameState.new().apply { prestigePoints = 10; crystalsUnlocked[1] = true }
        val engine = GameEngine(s, Random(1))
        val initial = engine.baseClickGain()
        assertTrue(engine.buySkill(SkillTree.POWER_CORE, 1_000L))
        assertEquals(1.25, (engine.baseClickGain() / initial).toDouble(), 1e-9)
        assertTrue(engine.equipCrystal(1, 1_000L))
        assertEquals(CrystalDefs.byId(1).clickMultiplier, (engine.baseClickGain() / (initial * 1.25)).toDouble(), 1e-9)
    }

    @Test
    fun bossTakesTapDamageAndRewardsShardsExactlyOnce() {
        val s = GameState.new().apply { upgradeLevels["click_power"] = 20 }
        val engine = GameEngine(s, Random(4))
        assertTrue(engine.startBoss(1_000L).started)
        engine.state.activeBoss!!.health = BigNum.ONE
        val result = engine.tap(1L, 1_001L)
        assertTrue(result.bossDefeated)
        assertTrue(result.bossReward > BigNum.ZERO)
        assertEquals(1, engine.state.bossWins[0])
        assertEquals(1L, engine.state.dimensionShards[0])
        assertFalse(engine.tap(2L, 1_002L).bossDefeated)
    }

    @Test
    fun prestigeOnlyResetsRunEconomyAndKeepsPermanentData() {
        val prestigeEnergy = BigNum.of(5e6)
        val s = GameState.new().apply {
            energy = prestigeEnergy; totalEnergy = prestigeEnergy; runEnergy = prestigeEnergy
            generators[0] = 5; upgradeLevels["click_power"] = 1; crystalsUnlocked[1] = true
        }
        val engine = GameEngine(s)
        val result = engine.prestige(1_000L)
        assertNotNull(result)
        assertTrue(result!!.pointsGained > 0)
        assertEquals(BigNum.ZERO, s.energy)
        assertEquals(BigNum.ZERO, s.runEnergy)
        assertEquals(0L, s.generators[0])
        assertEquals(0, s.level("click_power"))
        assertEquals(prestigeEnergy, s.totalEnergy)
        assertTrue(s.crystalsUnlocked[1])
        assertEquals(1, s.prestigeCount)
    }

    @Test
    fun abilityHasPersistentCooldownAndBurstRequiresProduction() {
        val s = GameState.new().apply { generators[0] = 1 }
        val engine = GameEngine(s)
        assertTrue(engine.canUseAbility(AbilityDefs.SUPER_CLICK, 1_000L))
        assertTrue(engine.useAbility(AbilityDefs.SUPER_CLICK, 1_000L).used)
        assertFalse(engine.canUseAbility(AbilityDefs.SUPER_CLICK, 1_001L))
        assertTrue(engine.isAbilityActive(AbilityDefs.SUPER_CLICK, 1_001L))
        assertTrue(engine.useAbility(AbilityDefs.COSMIC_BURST, 40_000L).gain > BigNum.ZERO)
    }
}
