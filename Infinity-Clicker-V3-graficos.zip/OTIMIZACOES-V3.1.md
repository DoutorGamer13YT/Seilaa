# Otimizações V3.1

## Energia
- **EnergyGovernor** (novo, `ui/components/EnergyGovernor.kt`): escuta o status térmico do
  PowerManager e rebaixa o teto de FPS (120→60 no MODERATE, →30 em SEVERE/CRITICAL/EMERGENCY)
  antes do throttling do SoC. Integrado ao `GameApp`: `effectiveFps` passa a ser
  `min(configuração do usuário, teto térmico)`, e o plano de refresh rate é reaplicado a cada
  mudança térmica. BatterySaver manual continua forçando 30 fps.
- `gradle.properties`: `android.enableR8.fullMode=true` (menos código morto, cold start menor).

## Animações / desenho
- **Crystal**: cálculo das facetas sem alocação por quadro. `Point3`/`Facet` (data classes criadas
  a cada desenho) foram substituídos por `FacetScratch` (arrays reutilizados + selection sort,
  n ≤ 12). A ordem de pintura (painter's algorithm) é idêntica à anterior.
- **SpaceBackground**: cintilação das estrelas tabelada — 16 amostras de `sin()` pré-computadas por
  estrela; o desenho só indexa a rampa, sem `sin()` por estrela por quadro (mesma curva visual).

## Tela Dev
- `@vitinhjkjkk` continua sendo o handle exibido (Instagram do criador).
