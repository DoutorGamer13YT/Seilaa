# Análise da entrada e alterações

## O que havia no ZIP

`Dmap NewVersion.zip` tinha 999 entradas (incluindo diretórios), com `AndroidManifest.xml` binário, `resources.arsc`, `classes.dex`, `classes2.dex`, bibliotecas `.so`, recursos Android e `assets/app_config.json`.

Não havia `.kt`, `.java`, arquivos Gradle, Gradle Wrapper, código HTML/JS independente nem workflow de compilação. A configuração indicava:

- Nome visual original: Apple Maps.
- Package original: `com.w2a.nzuz`.
- Destino: `https://maps.apple.com/`.
- Tipo: wrapper WEB, engine SYSTEM_WEBVIEW.
- JavaScript e DOM storage ligados; geolocalização configurável.
- Anúncios/ativação desligados; aviso de instalação de terceiro habilitado.
- Scripts de alteração global de eventos e carregamento da página.

Não foi afirmada recuperação de código-fonte. Os binários, assinaturas, scripts de injeção, textos promocionais, ícones proprietários e módulos nativos do APK não foram redistribuídos. Foram reaproveitados apenas parâmetros funcionais (endereço público e identificador de pacote) e o comportamento de abrir o mapa online. A interface nativa foi escrita novamente.

## Arquivos criados

| Arquivo/grupo | Responsabilidade |
|---|---|
| `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties` | Estrutura Android e versões de plugins |
| `gradlew`, `gradlew.bat`, `gradle/wrapper/*` | Wrapper oficial para futura compilação; não executado |
| `app/build.gradle.kts` | Módulo Android, SDKs, dependências e Compose |
| `app/src/main/AndroidManifest.xml` | Launcher, permissões mínimas e serviço dataSync do WorkManager |
| `res/values/strings.xml`, `themes.xml`, `res/drawable/ic_dmaps.xml` | Nome, tema e ícone vetorial original |
| `DmapsApp.kt` | Inicialização do MapLibre e repositório compartilhado |
| `Preferences.kt` | Configurações, posição da câmera, mensagens e validação básica da fonte |
| `DeviceState.kt` | Conectividade validada e GPS via Android |
| `MapViewModel.kt` | Modo online/offline, seleção de região, comandos e tratamento de erros |
| `AppleMapView.kt` | WebView HTTPS, permissões por origem, fallback e navegação segura |
| `NativeMapView.kt` | Ciclo de vida do MapView, câmera, localização, bússola e seleção geográfica |
| `OfflineRepository.kt` | Regiões reais, deduplicação, armazenamento, pausa/retomada/exclusão |
| `RegionDownloadWorker.kt` | Downloads longos, notificações e progresso real |
| `SourceVerifier.kt` | Validação de estilo, TileJSON e URLs de dependências |
| `OfflineCapabilities.kt` | Contratos de pesquisa/rotas locais e indisponibilidade explícita |
| `MainActivity.kt` | Abas, mapa, seleção de região, painel inferior e permissões |
| `SettingsPanels.kt` | Configurações, regiões, progresso e gerenciamento |
| `server/serve_mbtiles.py` | Fonte HTTPS opcional a partir de MBTiles raster licenciados |
| `tools/verify_static.py` | Verificação estática de sintaxe, XML e estrutura, sem Gradle |
| Documentação Markdown e relatório | Configuração, limitações, arquivos e testes futuros |

Os arquivos Kotlin acima ficam em `app/src/main/java/com/w2a/nzuz/`.

Não existiam fontes editáveis para modificar individualmente; todos os arquivos do projeto são novos. O `build-apk.yml` não existia e não foi criado.

## Arquitetura

A Activity usa Compose para a interface e AndroidView para WebView/MapView. As configurações ficam em SharedPreferences privadas. O repositório mantém um único conjunto de objetos OfflineRegion no processo e expõe snapshots por StateFlow. As chamadas de controle do SDK ocorrem na main thread conforme a API exige; rede, banco e renderização são realizados pelo motor nativo em suas threads. Validação HTTP e leitura de tamanhos de arquivos usam Dispatchers.IO.

WorkManager persiste o agendamento e o identificador da região. O worker instala um único observador, ativa a região e desativa/remove o observador em `finally`, inclusive após cancelamento. UI mostra apenas contadores do SDK. Cancelar um worker preserva tiles; excluir uma região chama o mecanismo nativo de exclusão.

O site Apple não participa desse banco. Não há interface JavaScript nativa exposta ao site. O modo offline usa a mesma URL de estilo registrada na definição da região para encontrar os recursos baixados. O acesso à rede do SDK é desligado na visualização offline; não há extrapolação de conteúdo Apple.
