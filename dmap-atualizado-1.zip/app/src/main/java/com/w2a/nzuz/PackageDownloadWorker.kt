package com.w2a.nzuz

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection

class PackageDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val app = context.applicationContext as DmapsApp
    private val store = app.packages
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val key = inputData.getString("key") ?: return@withContext Result.failure()
        if (!Regex("[A-Za-z0-9_-]+[.][A-Za-z0-9_-]+").matches(key)) return@withContext Result.failure()
        var p: MapPackage? = null
        try {
            store.lock(key).withLock {
                val pack = MapPackage(JSONObject(android.util.AtomicFile(File(store.root, "$key/metadata.json")).openRead().bufferedReader().use { it.readText() }))
                p = pack
                require(pack.key == key)
                if (File(store.installed(pack), "pack.json").isFile) return@withLock
                setForeground(notification(pack, store.part(pack).length(), "Baixando região"))
                File(store.directory(pack), "staging").deleteRecursively()
                require(store.freeBytes() >= (pack.bytes - store.part(pack).length()).coerceAtLeast(0) + pack.unpackedBytes + PackageStore.RESERVE) { "Espaço insuficiente" }
                transfer(pack)
                ensureActive()
                store.publish(pack, "Verificando integridade…")
                val verificationJob = currentCoroutineContext().job
                require(digest(store.part(pack)) { verificationJob.ensureActive() } == pack.sha256) { "SHA-256 divergente; cancele e baixe novamente" }
                val stage = File(store.directory(pack), "staging")
                val job = currentCoroutineContext().job
                PackageVerifier.extract(store.part(pack), stage, pack) {
                    job.ensureActive()
                    require(store.freeBytes() > PackageStore.RESERVE) { "Armazenamento insuficiente" }
                }
                ensureActive()
                require(!store.inUse(pack)) { "Feche o mapa antes de reinstalar" }
                val destination = store.installed(pack)
                if (destination.exists()) require(destination.deleteRecursively())
                require(stage.renameTo(destination)) { "Não foi possível concluir a instalação" }
                store.part(pack).delete()
                File(store.directory(pack), "etag").delete()
                store.publish(pack, "Disponível offline")
            }
            Result.success()
        } catch (e: CancellationException) {
            p?.let { store.publish(it, "Interrompido; dados parciais preservados") }; throw e
        } catch (e: IOException) {
            p?.let { store.publish(it, if (runAttemptCount < 5) "Conexão interrompida; retomada agendada" else "Pausado; toque em Retomar", e.message.orEmpty()) }
            if (runAttemptCount < 5) Result.retry() else Result.failure()
        } catch (e: Exception) {
            p?.let { store.publish(it, "Pausado: ${e.message}", e.message.orEmpty()) }; Result.failure()
        }
    }
    private suspend fun transfer(p: MapPackage) {
        val part = store.part(p)
        val etagFile = File(store.directory(p), "etag")
        if (part.length() > p.bytes) { part.delete(); etagFile.delete() }
        if (part.length() == p.bytes) return
        var offset = part.length()
        val headers = mutableMapOf<String, String>()
        if (offset > 0) {
            headers["Range"] = "bytes=$offset-"
            etagFile.takeIf { it.isFile }?.readText()?.takeIf { it.startsWith('"') }?.let { headers["If-Range"] = it }
        }
        val c = SecureHttp.connect(p.url, headers)
        try {
            val status = c.responseCode
            if (status == 429 || status >= 500) throw IOException("Servidor temporariamente indisponível ($status)")
            require(status == 200 || status == 206) { "HTTP $status; use a URL HTTPS final, sem redirecionamentos" }
            if (status == 200) offset = 0
            if (status == 206) {
                val expected = "bytes $offset-${p.bytes - 1}/${p.bytes}"
                require(c.getHeaderField("Content-Range") == expected) { "Resposta Range inválida" }
            }
            val length = c.contentLengthLong
            require(length < 0 || length == p.bytes - offset) { "Tamanho remoto divergente" }
            c.getHeaderField("ETag")?.takeIf { it.startsWith('"') }?.let { PackageStore.atomic(etagFile, it) }
            RandomAccessFile(part, "rw").use { out ->
                if (offset == 0L) out.setLength(0)
                out.seek(offset)
                c.inputStream.buffered().use { input ->
                    val b = ByteArray(65536)
                    var done = offset
                    var last = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(b); if (n < 0) break
                        require(done + n <= p.bytes) { "Download excedeu o tamanho esperado" }
                        out.write(b, 0, n); done += n
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (now - last >= 1000) {
                            last = now
                            require(store.freeBytes() > PackageStore.RESERVE) { "Pouco espaço disponível" }
                            store.publish(p, "Baixando")
                            setProgress(workDataOf("bytes" to done, "total" to p.bytes))
                            setForeground(notification(p, done, "Baixando região"))
                        }
                    }
                    out.fd.sync()
                    if (done != p.bytes) throw IOException("Transferência incompleta")
                }
            }
        } finally { c.disconnect() }
    }
    private fun notification(p: MapPackage, bytes: Long, status: String): ForegroundInfo {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("regional", "Regiões Protomaps", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(applicationContext, 0, Intent(applicationContext, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(applicationContext, "regional").setSmallIcon(R.drawable.ic_dmaps)
            .setContentTitle("Dmap • ${p.name}").setContentText("$status • ${formatBytes(bytes)} / ${formatBytes(p.bytes)}")
            .setProgress(100, ((bytes * 100) / p.bytes).toInt().coerceIn(0, 100), false)
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Pausar", WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)).build()
        val notificationId = 2_000_000 + (p.key.hashCode() and 0xfffff)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(notificationId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(notificationId, n)
    }
}
