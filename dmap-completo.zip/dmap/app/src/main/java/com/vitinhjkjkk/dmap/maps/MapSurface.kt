package com.vitinhjkjkk.dmap.maps

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vitinhjkjkk.dmap.BuildConfig
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import java.net.URI

@Composable
fun MapSurface(mode: String, camera: MapCameraController, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val online = remember { isOnline(context) }
    val mapKitTokenUrl = BuildConfig.MAPKIT_TOKEN_URL
    val mapKitOrigin = BuildConfig.MAPKIT_WEB_ORIGIN
    val styleUrl = BuildConfig.MAP_STYLE_URL
    Box(modifier.fillMaxSize()) {
        when {
            mode == "OFFLINE" -> MapUnavailable("Nenhuma região offline instalada")
            !online -> MapUnavailable("Sem conexão. Mapas offline ainda não configurados")
            mapKitTokenUrl.startsWith("https://") && mapKitOrigin.startsWith("https://") ->
                AppleMapKitSurface(mapKitTokenUrl, mapKitOrigin, camera)
            styleUrl.startsWith("https://") -> MapLibreOnlineSurface(styleUrl, camera)
            else -> MapUnavailable("Configure um provedor de mapas; veja README.md")
        }
    }
}

@Composable
private fun MapUnavailable(message: String) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center,
    ) {
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun MapLibreOnlineSurface(styleUrl: String, camera: MapCameraController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mapView = remember(context) {
        MapLibre.getInstance(context)
        MapView(context).apply { onCreate(Bundle()) }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { mapView.apply {
            getMapAsync { map ->
                camera.attachMap(map)
                map.setStyle(Style.Builder().fromUri(styleUrl)) {
                    camera.attachMap(map)
                }
            }
        } },
    )
    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) mapView.onStart()
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) mapView.onResume()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            camera.attachMap(null)
            mapView.onPause()
            mapView.onStop()
            mapView.onDestroy()
        }
    }
}

@Composable
private fun AppleMapKitSurface(tokenUrl: String, origin: String, camera: MapCameraController) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val webView = remember(context) {
        WebView(context).apply {
            setBackgroundColor(AndroidColor.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val host = request.url.host.orEmpty().lowercase()
                    val originHost = runCatching { URI(origin).host }.getOrNull()?.lowercase()
                    return !(host == originHost || host == "apple.com" || host.endsWith(".apple.com"))
                }
            }
            val html = context.assets.open("apple_mapkit.html").bufferedReader().use { it.readText() }
                .replace("__DMAP_TOKEN_URL__", JSONObject.quote(tokenUrl))
                .replace("__DMAP_TOKEN_ORIGIN__", URI(tokenUrl).let { uri -> "https://${uri.host}${if (uri.port >= 0) ":${uri.port}" else ""}" })
            loadDataWithBaseURL(origin, html, "text/html", "UTF-8", null)
        }
    }
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { webView })
    DisposableEffect(lifecycleOwner, webView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> webView.onResume()
                Lifecycle.Event.ON_PAUSE -> webView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        camera.attachWebView(webView)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) webView.onResume()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            camera.attachWebView(null)
            webView.stopLoading()
            webView.destroy()
        }
    }
}

private fun isOnline(context: Context): Boolean {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
