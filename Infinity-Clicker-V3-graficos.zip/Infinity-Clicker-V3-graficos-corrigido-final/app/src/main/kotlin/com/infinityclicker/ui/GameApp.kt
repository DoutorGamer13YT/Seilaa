package com.infinityclicker.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.SpaceBackground
import com.infinityclicker.ui.components.applyFrameRate
import com.infinityclicker.ui.components.planFrameRate
import com.infinityclicker.ui.components.rememberFrameTicker
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.screens.DeveloperScreen
import com.infinityclicker.ui.screens.DimensionsScreen
import com.infinityclicker.ui.screens.HomeScreen
import com.infinityclicker.ui.screens.MissionsScreen
import com.infinityclicker.ui.screens.ProfileScreen
import com.infinityclicker.ui.screens.ShopScreen
import com.infinityclicker.ui.theme.InfinityTheme
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val tabs = listOf("Início", "Loja", "Dimensões", "Missões")
private val tabIcons = listOf("✦", "◈", "◎", "✧")
private const val HUB_TAB = 4
private val hubSections = listOf("Resumo", "Ajustes", "Ambientes", "Dev")

@Composable
fun GameApp(vm: GameViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var hubSection by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val background = ui.backgrounds.firstOrNull { it.equipped }?.def
    val currentTint = background?.tintColor ?: ui.dimensions.firstOrNull { it.current }?.def?.tintColor ?: Neon.Cyan
    val effectiveQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.exportSaveText()
            if (text != null) {
                scope.launch {
                    val success = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
                                ?: error("Fluxo de saída indisponível")
                        }.isSuccess
                    }
                    vm.reportExportResult(success)
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (text == null) vm.reportImportReadFailure() else vm.importSaveText(text)
            }
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }
    LaunchedEffect(tab) { vm.setActiveTab(tab) }
    val effectiveFps = if (ui.settings.batterySaver) 30 else ui.settings.frameRateCap
    val frameTicker = rememberFrameTicker(effectiveFps)
    var fpsInfo by remember { mutableStateOf("") }
    LaunchedEffect(effectiveFps) {
        // Pede à tela o modo que melhor entrega o limite escolhido; o FrameTicker ajusta as
        // animações como divisor inteiro da taxa real, então os quadros ficam uniformes.
        val activity = context as? Activity ?: return@LaunchedEffect
        val display = activity.window.decorView.display ?: @Suppress("DEPRECATION") activity.windowManager.defaultDisplay
        val plan = planFrameRate(display, effectiveFps) ?: return@LaunchedEffect
        activity.applyFrameRate(plan)
        fpsInfo = "Tela em ${"%.0f".format(plan.displayHz)} Hz · animações a ${"%.0f".format(plan.animationFps)} fps" +
            if (kotlin.math.abs(plan.animationFps - effectiveFps) > 2f) " (esta tela não tem modo de $effectiveFps Hz)" else ""
    }
    LaunchedEffect(ui.notice) {
        ui.notice?.let {
            snackbar.showSnackbar(it)
            vm.dismissNotice()
        }
    }

    InfinityTheme {
      CompositionLocalProvider(LocalFrameTicker provides frameTicker) {
        Box(Modifier.fillMaxSize()) {
            SpaceBackground(
                tint = currentTint,
                style = background?.style,
                quality = effectiveQuality,
                motionEnabled = !ui.settings.batterySaver
            )
            if (ui.loaded) {
                Box(Modifier.fillMaxSize().statusBarsPadding().padding(bottom = 88.dp)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            // Transição curta e só de opacidade/deslocamento (barata para a GPU); molas
                            // lentas mantinham duas telas pesadas compostas ao mesmo tempo por ~1 s.
                            val dir = if (targetState > initialState) 1 else -1
                            (fadeIn(tween(220, delayMillis = 40, easing = FastOutSlowInEasing)) +
                                slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { dir * it / 14 }) togetherWith
                                (fadeOut(tween(120)) + slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -dir * it / 18 })
                        }, label = "tabTransition"
                    ) { screen ->
                        when (screen) {
                            0 -> HomeScreen(ui, vm::tap, vm::useAbility)
                            1 -> ShopScreen(ui, vm::setBuyMode, vm::buyGenerator, vm::buyUpgrade)
                            2 -> DimensionsScreen(ui, vm::unlockDimension, vm::travelDimension, vm::buyResonance, vm::startBoss, vm::equipCrystal)
                            3 -> MissionsScreen(ui, vm::claimDaily, vm::claimLogin, vm::claimAchievement, vm::startChallenge, vm::abandonChallenge)
                            else -> Column(Modifier.fillMaxSize()) {
                                HubHeader(hubSection, { hubSection = it }, { tab = 0 })
                                Box(Modifier.weight(1f).fillMaxWidth()) {
                                if (hubSection == 3) DeveloperScreen(ui) else ProfileScreen(
                                ui = ui,
                                onScientific = vm::setScientific,
                                onQuality = vm::setGraphicsQuality,
                                onFrameRate = vm::setFrameRate,
                                fpsInfo = fpsInfo,
                                section = hubSection,
                                onBatterySaver = vm::setBatterySaver,
                                onEffects = vm::setEffectsIntensity,
                                onPanelOpacity = vm::setPanelOpacity,
                                onHaptics = vm::setHaptics,
                                onUpgradeAbility = vm::upgradeAbility,
                                onBuySkill = vm::buySkill,
                                onEquipBackground = vm::equipBackground,
                                onExportSave = { exportLauncher.launch("InfinityClicker-V3.ic-save") },
                                onImportSave = { importLauncher.launch(arrayOf("text/plain", "application/octet-stream")) },
                                onPrestige = vm::prestige,
                                onReset = vm::hardReset
                            )
                                }
                            }
                        }
                    }
                }
            }
            SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp))
            BottomBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
            if (ui.loaded && tab != HUB_TAB) ProfileBubble(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 14.dp)) { tab = HUB_TAB }
        }

        ui.offlineReport?.let { r ->
            val sci = ui.settings.scientificNotation
            AlertDialog(
                onDismissRequest = vm::dismissOfflineReport,
                title = { Text("Bem-vindo de volta!") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Tempo ausente: ${NumberFormatter.duration(r.elapsedMs)}")
                        Text("Tempo creditado: ${NumberFormatter.duration(r.creditedMs)}" + if (r.elapsedMs > r.capMs) " (limite de ${NumberFormatter.duration(r.capMs)})" else "")
                        Text("Eficiência offline: ${"%.0f".format(r.efficiency * 100)}%")
                        Text("Multiplicador global: ×${NumberFormatter.format(r.globalMultiplier, sci)}")
                        Text("Produção: ${NumberFormatter.format(r.productionPerSecond, sci)}/s")
                        Text("Energia recebida: ${NumberFormatter.format(r.gain, sci)}", fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = { TextButton(onClick = vm::dismissOfflineReport) { Text("Coletar") } }
            )
        }
      }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth()
            .glass(RoundedCornerShape(30.dp), tint = Neon.Violet, alpha = 0.17f, borderAlpha = 0.52f).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        tabs.forEachIndexed { index, label ->
            val active = index == selected
            Column(
                Modifier.weight(1f).glass(
                    RoundedCornerShape(23.dp), tint = if (active) Neon.Cyan else Color0,
                    alpha = if (active) 0.34f else 0f, borderAlpha = if (active) 0.58f else 0f
                ).clickable { onSelect(index) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(tabIcons[index], fontSize = 18.sp, color = if (active) Neon.Cyan else Neon.TextSecondary)
                Text(label, fontSize = 10.sp, color = if (active) Neon.TextPrimary else Neon.TextSecondary)
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.White

/** Bolinha de perfil: abre o painel com perfil, ajustes, ambientes e desenvolvedor. Usa a foto do dev se existir. */
@Composable
private fun ProfileBubble(modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val photo = remember {
        val id = context.resources.getIdentifier("developer_photo", "drawable", context.packageName)
        if (id == 0) null else runCatching { android.graphics.BitmapFactory.decodeResource(context.resources, id)?.asImageBitmap() }.getOrNull()
    }
    Box(
        modifier.size(44.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Neon.Violet.copy(alpha = 0.55f), Neon.Cyan.copy(alpha = 0.40f))))
            .border(1.5.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.75f), Neon.Cyan.copy(alpha = 0.35f))), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (photo != null) Image(photo, "Perfil", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("◉", color = Neon.TextPrimary, fontSize = 22.sp)
    }
}

@Composable
private fun HubHeader(selected: Int, onSelect: (Int) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(40.dp).glass(CircleShape, tint = Neon.Cyan, alpha = 0.18f, borderAlpha = 0.5f).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("‹", color = Neon.TextPrimary, fontSize = 26.sp) }
            Text("Perfil", color = Neon.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            hubSections.forEachIndexed { i, label ->
                val on = i == selected
                Text(
                    label, color = if (on) Neon.Bg else Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.glass(RoundedCornerShape(50), tint = if (on) Neon.Cyan else Color.White, alpha = if (on) 0.85f else 0.10f)
                        .clickable { onSelect(i) }.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}
