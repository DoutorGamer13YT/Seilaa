package com.infinityclicker.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableStateOf
import com.infinityclicker.data.GraphicsQuality
import kotlin.math.PI
import kotlinx.coroutines.isActive

/**
 * Relógio de animação com limite de FPS real. As animações do Compose rodam na taxa da tela
 * (60/120 Hz) e ignoravam o limite escolhido; aqui o estado só muda no ritmo do limite, então
 * os Canvas que o leem só são redesenhados nesse ritmo.
 * O valor é o tempo decorrido em nanossegundos.
 */
@Composable
fun rememberFrameTicker(fpsCap: Int): State<Long> {
    val state = remember { mutableLongStateOf(0L) }
    val cap by rememberUpdatedState(fpsCap.coerceIn(10, 240))
    LaunchedEffect(Unit) {
        var origin = -1L
        var nextEmit = 0L
        while (isActive) {
            withFrameNanos { now ->
                if (origin < 0L) {
                    origin = now
                    nextEmit = now
                }
                val interval = 1_000_000_000L / cap
                // Tolerância de 2 ms para não perder o quadro por jitter do vsync (ex.: 90 em 120 Hz).
                if (now + 2_000_000L >= nextEmit) {
                    nextEmit = if (now - nextEmit > interval) now + interval else nextEmit + interval
                    state.longValue = now - origin
                }
            }
        }
    }
    return state
}

/** Ticker compartilhado, fornecido pela GameApp conforme o limite de FPS das configurações. */
val LocalFrameTicker = staticCompositionLocalOf<State<Long>> { mutableStateOf(0L) }

/** Fase 0..2π de um ciclo de [periodMs] a partir do tempo do ticker. */
fun phaseOf(nanos: Long, periodMs: Long): Float {
    val period = periodMs * 1_000_000L
    return ((nanos % period).toDouble() / period.toDouble() * 2.0 * PI).toFloat()
}

/** Nível de detalhe do renderizador: 0 econômico, 1 equilibrado, 2 alta, 3 ultra. */
val GraphicsQuality.detail: Int
    get() = when (this) {
        GraphicsQuality.LOW -> 0
        GraphicsQuality.MEDIUM -> 1
        GraphicsQuality.AUTO, GraphicsQuality.HIGH -> 2
        GraphicsQuality.ULTRA -> 3
    }
