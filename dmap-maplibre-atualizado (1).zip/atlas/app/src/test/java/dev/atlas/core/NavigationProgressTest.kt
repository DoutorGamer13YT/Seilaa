package dev.atlas.core

import org.junit.Assert.*
import org.junit.Test

class NavigationProgressTest {
    private val start = Coordinate(0.0, 0.0)
    private val turn = Coordinate(0.0, 0.005)
    private val end = Coordinate(0.0, 0.01)
    private val distance = start.distanceTo(end)
    private val route = Route(
        "test-route", listOf(start, turn, end), distance, 600.0,
        listOf(
            RouteStep("Siga em frente", "Rua A", distance / 2, 400.0, start),
            RouteStep("Vire à direita", "Rua B", distance / 2, 200.0, turn, "turn-right"),
            RouteStep("Destino à direita", "Rua B", 0.0, 0.0, end, "arrive"),
        ), TransportMode.CAR, "fixture",
    )
    private fun fix(latitude: Double = 0.0, longitude: Double = 0.0, time: Long = 10_000, accuracy: Float = 5f) =
        LocationFix(Coordinate(latitude, longitude), accuracy, null, null, time)

    @Test fun departureShowsTheNextProviderManeuver() {
        val progress = NavigationEngine.progress(route, fix())
        assertEquals(1, progress.stepIndex)
        assertEquals("Vire à direita", progress.instruction)
        assertEquals(distance / 2, progress.distanceToManeuverMeters, 0.5)
        assertEquals(distance, progress.remainingDistanceMeters, 0.5)
        assertEquals(600.0, progress.remainingDurationSeconds, 0.5)
        assertFalse(progress.arrived)
        assertFalse(progress.offRoute)
    }

    @Test fun remainingTimeUsesProviderStepDurations() {
        val progress = NavigationEngine.progress(route, fix(longitude = 0.0025))
        assertEquals(distance * 0.75, progress.remainingDistanceMeters, 0.5)
        assertEquals(400.0, progress.remainingDurationSeconds, 0.5)
        assertEquals(distance * 0.25, progress.distanceToManeuverMeters, 0.5)
    }

    @Test fun routeProgressDoesNotRegressWithGpsNoise() {
        val previous = NavigationEngine.progress(route, fix(longitude = 0.005))
        val current = NavigationEngine.progress(route, fix(longitude = 0.0049, time = 11_000), previous)
        assertEquals(previous.remainingDistanceMeters, current.remainingDistanceMeters, 0.01)
        assertFalse(current.offRoute)
    }

    @Test fun staleFixCannotMoveNavigationBackwards() {
        val previous = NavigationEngine.progress(route, fix(longitude = 0.005, time = 20_000))
        assertSame(previous, NavigationEngine.progress(route, fix(time = 10_000), previous))
    }

    @Test fun duplicateFixCannotSatisfyDeviationHysteresis() {
        val outside = fix(latitude = 0.001)
        val previous = NavigationEngine.progress(route, outside)
        assertEquals(1, previous.deviationCount)
        assertSame(previous, NavigationEngine.progress(route, outside, previous))
        assertFalse(previous.offRoute)
    }

    @Test fun deviationRequiresTwoFixesAndRecoversWithHysteresis() {
        val start = NavigationEngine.progress(route, fix())
        val first = NavigationEngine.progress(route, fix(latitude = 0.001, time = 11_000), start)
        val second = NavigationEngine.progress(route, fix(latitude = 0.001, time = 12_000), first)
        assertFalse(first.offRoute)
        assertTrue(second.offRoute)
        val recovering = NavigationEngine.progress(route, fix(latitude = 0.0003, time = 13_000), second)
        assertTrue(recovering.offRoute)
        val recovered = NavigationEngine.progress(route, fix(latitude = 0.0001, time = 14_000), recovering)
        assertFalse(recovered.offRoute)
    }

    @Test fun poorAccuracyDoesNotDeclareSpuriousDeviationOrArrival() {
        val previous = NavigationEngine.progress(route, fix(latitude = 0.001, accuracy = 100f))
        val current = NavigationEngine.progress(route, fix(latitude = 0.001, time = 11_000, accuracy = 100f), previous)
        assertFalse(current.offRoute)
        assertFalse(NavigationEngine.progress(route, fix(longitude = 0.01, accuracy = 100f)).arrived)
    }

    @Test fun arrivalNeedsDestinationProximityAndCompletesDistanceAndTime() {
        val arrived = NavigationEngine.progress(route, fix(longitude = 0.00995))
        assertTrue(arrived.arrived)
        assertEquals(0.0, arrived.remainingDistanceMeters, 0.0)
        assertEquals(0.0, arrived.remainingDurationSeconds, 0.0)
        val beyond = NavigationEngine.progress(route, fix(longitude = 0.011))
        assertFalse(beyond.arrived)
    }

    @Test fun differentRouteResetsProgressAndMatchingWindow() {
        val previous = NavigationEngine.progress(route, fix(longitude = 0.009))
        val reversed = route.copy(id = "return", geometry = route.geometry.reversed())
        val current = NavigationEngine.progress(reversed, fix(longitude = 0.01, time = 11_000), previous)
        assertEquals(distance, current.remainingDistanceMeters, 0.5)
    }

    @Test fun suddenGpsJumpDoesNotSkipMostOfTheRoute() {
        val previous = NavigationEngine.progress(route, fix())
        val current = NavigationEngine.progress(route, fix(longitude = 0.009, time = 11_000), previous)
        assertTrue(current.remainingDistanceMeters > distance * 0.8)
        assertFalse(current.arrived)
    }

    @Test fun datelineCrossingUsesShortLongitudeDistance() {
        val a = Coordinate(0.0, 179.99)
        val b = Coordinate(0.0, -179.99)
        val crossing = route.copy(geometry = listOf(a, b), distanceMeters = a.distanceTo(b), steps = emptyList())
        val current = NavigationEngine.progress(crossing, fix(longitude = 180.0))
        assertEquals(crossing.distanceMeters / 2, current.remainingDistanceMeters, 1.0)
        assertTrue(current.nearestCoordinate!!.distanceTo(Coordinate(0.0, 180.0)) < 1.0)
        assertEquals("Instruções indisponíveis", current.instruction)
    }

    @Test fun malformedRouteHasFiniteRecoverableState() {
        val invalid = NavigationEngine.progress(route.copy(geometry = emptyList(), distanceMeters = Double.NaN), fix())
        assertTrue(invalid.offRoute)
        assertFalse(invalid.arrived)
        assertTrue(invalid.remainingDistanceMeters.isFinite())
        assertNull(invalid.nearestCoordinate)
        val duplicate = NavigationEngine.progress(route.copy(geometry = listOf(start, start)), fix())
        assertFalse(duplicate.arrived)
        assertTrue(duplicate.remainingDurationSeconds.isFinite())
    }

    @Test fun absentStepDistancesUseProviderRouteDurationRatio() {
        val withoutSteps = NavigationEngine.progress(route.copy(steps = emptyList()), fix(longitude = 0.005))
        assertEquals(300.0, withoutSteps.remainingDurationSeconds, 0.1)
        assertEquals(distance / 2, withoutSteps.remainingDistanceMeters, 0.5)
    }

    @Test fun invalidCoordinatesAreRejected() {
        listOf(Double.NaN to 0.0, Double.POSITIVE_INFINITY to 0.0, 91.0 to 0.0,
            0.0 to 181.0, -91.0 to -181.0).forEach { (latitude, longitude) ->
            try {
                Coordinate(latitude, longitude)
                fail("Invalid coordinate was accepted")
            } catch (_: IllegalArgumentException) { /* Required validation. */ }
        }
    }

    @Test fun coordinateDistanceIsSymmetricAndStableAtAntipodes() {
        val a = Coordinate(0.0, 0.0)
        val b = Coordinate(0.0, 180.0)
        assertEquals(a.distanceTo(b), b.distanceTo(a), 0.0001)
        assertTrue(a.distanceTo(b).isFinite())
        assertEquals(0.0, a.distanceTo(a), 0.0)
    }
}
