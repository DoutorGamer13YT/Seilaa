package dev.atlas.data

import androidx.datastore.preferences.core.preferencesOf
import dev.atlas.core.ThemeMode
import org.junit.Assert.assertEquals
import org.junit.Test

class SettingsStorageTest {
    @Test
    fun decodesDarkTheme() {
        val settings = SettingsStorage.decode(preferencesOf(SettingsStorage.theme to "DARK"))
        assertEquals(ThemeMode.DARK, settings.theme)
    }

    @Test
    fun unknownThemeFallsBackToSystem() {
        val settings = SettingsStorage.decode(preferencesOf(SettingsStorage.theme to "PURPLE"))
        assertEquals(ThemeMode.SYSTEM, settings.theme)
    }

    @Test
    fun missingThemeFallsBackToSystem() {
        assertEquals(ThemeMode.SYSTEM, SettingsStorage.decode(preferencesOf()).theme)
    }
}
