package com.infinityclicker.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import com.infinityclicker.ui.components.SpaceBackground
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.BackgroundUi
import com.infinityclicker.ui.SkillNodeUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import com.infinityclicker.game.SkillPath
import kotlin.math.roundToInt

@Composable
fun ProfileScreen(
    ui: UiState,
    onScientific: (Boolean) -> Unit,
    onQuality: (GraphicsQuality) -> Unit,
    onFrameRate: (Int) -> Unit,
    fpsInfo: String,
    section: Int,
    onBatterySaver: (Boolean) -> Unit,
    onEffects: (Float) -> Unit,
    onPanelOpacity: (Float) -> Unit,
    onHaptics: (Boolean) -> Unit,
    onUpgradeAbility: (String) -> Unit,
    onBuySkill: (String) -> Unit,
    onEquipBackground: (Int) -> Unit,
    onExportSave: () -> Unit,
    onImportSave: () -> Unit,
    onPrestige: () -> Unit,
    onReset: () -> Unit
) {
    val sci = ui.settings.scientificNotation
    val s = ui.stats
    var confirmReset by remember { mutableStateOf(false) }
    var confirmPrestige by remember { mutableStateOf(false) }
    var showTree by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (section == 0) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Gold, alpha = ui.settings.panelOpacity) {
            Text("Renascimento Cósmico · ${ui.stats.prestigePoints} PP", color = Neon.Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Energia da corrida: ${NumberFormatter.format(ui.prestige.runEnergy, sci)}", color = Neon.TextSecondary, fontSize = 13.sp)
            Text(
                if (ui.prestige.available) "+${ui.prestige.points} pontos de prestígio · bônus permanente após: ×${"%.2f".format(ui.prestige.permanentMultiplierAfter)}"
                else "Produza 1M de energia nesta corrida para renascer.",
                color = if (ui.prestige.available) Neon.Gold else Neon.TextSecondary, fontSize = 13.sp
            )
            Button(
                onClick = { confirmPrestige = true }, enabled = ui.prestige.available,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon.Gold.copy(alpha = 0.86f), contentColor = Neon.Bg)
            ) { Text("Renascer", fontWeight = FontWeight.Bold) }
            Button(
                onClick = { showTree = true }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon.Violet.copy(alpha = 0.78f), contentColor = Neon.Bg)
            ) { Text("Árvore de habilidades · ${ui.skills.count { it.level > 0 }}/${ui.skills.size} nós", fontWeight = FontWeight.Bold) }
        }

        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = ui.settings.panelOpacity) {
            Text("Estatísticas", color = Neon.Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Stat("Energia total produzida", NumberFormatter.format(s.totalEnergy, sci))
            Stat("Cliques", s.totalClicks.toString())
            Stat("Cliques por segundo", s.clicksPerSecond.toString())
            Stat("Cliques críticos", s.critClicks.toString())
            Stat("Maior combo", s.maxCombo.toString())
            Stat("Melhor multiplicador", "×${"%.2f".format(s.highestTapMultiplier)}")
            Stat("Maior produção/s", NumberFormatter.format(s.highestProduction, sci))
            Stat("Geradores comprados", s.generatorsBought.toString())
            Stat("Melhorias compradas", s.upgradeLevelsBought.toString())
            Stat("Habilidades usadas", s.abilitiesUsed.toString())
            Stat("Chefes derrotados", s.bossWins.toString())
            Stat("Eventos cósmicos", s.eventsTriggered.toString())
            Stat("Desafios concluídos", s.challengeCompletions.toString())
            Stat("Pontos de prestígio", s.prestigePoints.toString())
            Stat("Renascimentos", s.prestigeCount.toString())
            Stat("Energia ganha offline", NumberFormatter.format(s.offlineEarned, sci))
            Stat("Energia manual", NumberFormatter.format(s.clickEnergy, sci))
            Stat("Energia automática", NumberFormatter.format(s.productionEnergy, sci))
            Stat("Eficiência automática", automationEfficiency(s))
            Stat("Conquistas", "${s.achievementsClaimed}/${com.infinityclicker.game.AchievementDefs.all.size}")
            Stat("Tempo jogado", NumberFormatter.duration(s.playTimeMs))
        }

        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
            Text("Habilidades especiais", color = Neon.Violet, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Evoluções usam pontos de prestígio e mudam os valores aplicados no motor.", color = Neon.TextSecondary, fontSize = 12.sp)
            ui.abilities.forEach { ability -> AbilityUpgradeRow(ability, onUpgradeAbility) }
        }

        }
        if (section == 1) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = ui.settings.panelOpacity) {
            Text("Gráficos e interface", color = Neon.Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            ToggleRow("Notação científica", sci, onScientific)
            Text(if (sci) "Exemplo: 1.23e45" else "Exemplo: 1.23Dc", color = Neon.TextSecondary, fontSize = 12.sp)
            Text("Qualidade visual", color = Neon.TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            ChoiceStrip(GraphicsQuality.entries.map { it.label }, GraphicsQuality.entries.indexOf(ui.settings.graphicsQuality)) { index ->
                onQuality(GraphicsQuality.entries[index])
            }
            Text("Limite de FPS", color = Neon.TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            val fps = listOf(30, 60, 90, 120)
            ChoiceStrip(fps.map { "$it" }, fps.indexOf(ui.settings.frameRateCap).coerceAtLeast(1)) { onFrameRate(fps[it]) }
            ToggleRow("Economia de bateria", ui.settings.batterySaver, onBatterySaver)
            ToggleRow("Feedback tátil", ui.settings.hapticsEnabled, onHaptics)
            Text("Intensidade dos efeitos: ${(ui.settings.effectsIntensity * 100).roundToInt()}%", color = Neon.TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Slider(value = ui.settings.effectsIntensity, onValueChange = onEffects, valueRange = 0.25f..1.5f)
            Text("Transparência dos painéis: ${(ui.settings.panelOpacity * 100).roundToInt()}%", color = Neon.TextPrimary, fontSize = 13.sp)
            Slider(value = ui.settings.panelOpacity, onValueChange = onPanelOpacity, valueRange = 0.06f..0.30f)
            if (fpsInfo.isNotEmpty()) Text(fpsInfo, color = Neon.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
            Text("O limite vira um divisor da taxa real da tela para o movimento ficar uniforme. No Samsung, deixe Configurações › Tela › Movimento suave em Adaptável (ou Alto) para liberar 120 Hz.", color = Neon.TextSecondary, fontSize = 11.sp)
        }

        }
        if (section == 2) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
            Text("Ambientes", color = Neon.Pink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Cada ambiente troca a renderização do fundo; nenhum item é somente decorativo.", color = Neon.TextSecondary, fontSize = 12.sp)
            ui.backgrounds.forEach { background -> BackgroundRow(background, onEquipBackground) }
        }

        }
        if (section == 1) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Green, alpha = ui.settings.panelOpacity) {
            Text("Backup e recuperação", color = Neon.Green, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Exportar cria um arquivo com checksum. Importar valida o arquivo e preserva o save atual como backup antes da troca.", color = Neon.TextSecondary, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onExportSave, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon.Green.copy(alpha = .82f), contentColor = Neon.Bg)
                ) { Text("Exportar", fontSize = 12.sp) }
                Button(
                    onClick = onImportSave, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon.Cyan.copy(alpha = .80f), contentColor = Neon.Bg)
                ) { Text("Importar", fontSize = 12.sp) }
            }
        }

        if (ui.recoveredFromBackup) {
            Text("O save principal estava corrompido; o backup anterior foi restaurado.", color = Neon.Gold, fontSize = 13.sp)
        }

        Button(
            onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Neon.Pink.copy(alpha = 0.85f), contentColor = Neon.Bg)
        ) { Text("Apagar progresso local", fontWeight = FontWeight.Bold) }
        }
    }

    if (confirmPrestige) {
        AlertDialog(
            onDismissRequest = { confirmPrestige = false },
            title = { Text("Confirmar renascimento?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Você receberá ${ui.prestige.points} ponto(s) de prestígio.")
                    Text("Será reiniciado: energia atual, geradores, melhorias normais, combo, habilidade ativa e chefe.")
                    Text("Será preservado: energia total, estatísticas, pontos e árvore de prestígio, cristais, dimensões, fragmentos, missões e conquistas.")
                }
            },
            confirmButton = { TextButton(onClick = { confirmPrestige = false; onPrestige() }) { Text("Renascer") } },
            dismissButton = { TextButton(onClick = { confirmPrestige = false }) { Text("Cancelar") } }
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Apagar tudo?") },
            text = { Text("O progresso local será apagado. Esta ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }
    if (showTree) SkillTreeDialog(ui.skills, ui.stats.prestigePoints, onBuySkill) { showTree = false }
}

@Composable
private fun AbilityUpgradeRow(ability: AbilityUi, onUpgrade: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${ability.def.name} · Nv. ${ability.level}/${ability.def.maxLevel}", color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(ability.def.effectText(ability.level), color = Neon.TextSecondary, fontSize = 11.sp)
        }
        Button(
            onClick = { onUpgrade(ability.def.id) }, enabled = ability.canUpgrade,
            colors = ButtonDefaults.buttonColors(containerColor = Neon.Violet.copy(alpha = 0.80f), contentColor = Neon.Bg)
        ) { Text("${ability.def.upgradeCost(ability.level)} PP", fontSize = 10.sp) }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Neon.TextPrimary, fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceStrip(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEachIndexed { index, label ->
            val selectedNow = index == selected
            Text(
                label, color = if (selectedNow) Neon.Bg else Neon.TextPrimary, fontSize = 12.sp,
                modifier = Modifier.glass(tint = if (selectedNow) Neon.Cyan else Color.White, alpha = if (selectedNow) 0.82f else 0.08f)
                    .clickable { onSelect(index) }.padding(horizontal = 11.dp, vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun BackgroundRow(background: BackgroundUi, onEquip: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(background.def.name, color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(if (background.unlocked) background.def.subtitle else "Desbloqueia em ${NumberFormatter.format(background.def.unlockAt)} de energia total", color = Neon.TextSecondary, fontSize = 10.sp)
        }
        Button(
            onClick = { onEquip(background.def.id) },
            enabled = background.unlocked && !background.equipped,
            colors = ButtonDefaults.buttonColors(containerColor = background.def.tintColor.copy(alpha = .82f), contentColor = Neon.Bg)
        ) { Text(if (background.equipped) "Ativo" else "Usar", fontSize = 10.sp) }
    }
}

@Composable
private fun DeveloperCard() {
    val context = LocalContext.current
    GlassCard(
        modifier = Modifier.fillMaxWidth().clickable {
            runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/vitinhjkjkk/")))
            }
        },
        tint = Neon.Cyan,
        alpha = .12f
    ) {
        Text("Desenvolvedor", color = Neon.Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("@vitinhjkjkk · Instagram", color = Neon.TextPrimary, fontSize = 14.sp)
    }
}

private fun automationEfficiency(s: com.infinityclicker.ui.StatsUi): String {
    if (s.totalEnergy.isZero) return "0%"
    return "${"%.1f".format((s.productionEnergy / s.totalEnergy).toDouble().coerceIn(0.0, 1.0) * 100)}%"
}

@Composable
private fun SkillTreeDialog(nodes: List<SkillNodeUi>, prestigePoints: Int, onBuy: (String) -> Unit, onDismiss: () -> Unit) {
    // Tela cheia própria (janela separada, sem a largura reduzida do diálogo padrão).
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().background(Neon.Bg)) {
            SpaceBackground(tint = Neon.Violet, modifier = Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Árvore de Habilidades", color = Neon.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                        Text("$prestigePoints PP disponíveis · deslize para explorar.", color = Neon.TextSecondary, fontSize = 11.sp)
                    }
                    TextButton(onClick = onDismiss) { Text("Fechar") }
                }
                SkillTreeMap(nodes, onBuy, Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun SkillTreeMap(nodes: List<SkillNodeUi>, onBuy: (String) -> Unit, modifier: Modifier = Modifier) {
    val paths = SkillPath.entries
    val pathColors = listOf(Neon.Cyan, Neon.Green, Neon.Pink, Neon.Gold, Neon.Violet)
    // Rolagem nativa nos dois eixos (inércia estilo iOS) com colunas largas e cartões grandes.
    Box(modifier.horizontalScroll(rememberScrollState()).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            paths.forEachIndexed { column, path ->
                val color = pathColors[column % pathColors.size]
                val pathNodes = nodes.filter { it.def.path == path }
                Column(Modifier.width(212.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    SkillPathHeader(path.label, color, pathNodes.count { it.level > 0 }, pathNodes.size)
                    pathNodes.forEachIndexed { i, node ->
                        if (i > 0) {
                            val lit = pathNodes[i - 1].level > 0
                            Box(
                                Modifier.width(3.dp).height(18.dp).clip(RoundedCornerShape(2.dp))
                                    .background(color.copy(alpha = if (lit) 0.85f else 0.22f))
                            )
                        }
                        SkillNodeCard(node, color, onBuy)
                    }
                    androidx.compose.foundation.layout.Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun SkillPathHeader(label: String, color: Color, owned: Int, total: Int) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .glass(RoundedCornerShape(22.dp), tint = color, alpha = 0.20f, borderAlpha = 0.55f).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(label, color = Neon.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("$owned de $total desbloqueadas", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        LinearProgressIndicator(
            progress = { if (total == 0) 0f else owned.toFloat() / total },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(5.dp).clip(RoundedCornerShape(3.dp)),
            color = color, trackColor = Color.White.copy(alpha = 0.12f)
        )
    }
}

@Composable
private fun SkillNodeCard(node: SkillNodeUi, pathColor: Color, onBuy: (String) -> Unit) {
    val maxed = node.level >= node.def.maxLevel
    val owned = node.level > 0
    val accent = when {
        maxed -> Neon.Gold
        owned -> pathColor
        node.requirementsMet -> pathColor.copy(alpha = 0.85f)
        else -> Neon.TextSecondary
    }
    val progress by androidx.compose.animation.core.animateFloatAsState(
        targetValue = node.level.toFloat() / node.def.maxLevel.coerceAtLeast(1),
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.8f, stiffness = 180f), label = "skillRing"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth()
            .glass(shape, tint = accent, alpha = if (owned) 0.24f else if (node.requirementsMet) 0.14f else 0.06f, borderAlpha = if (owned) 0.6f else 0.3f)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 5.dp.toPx()
                    val inset = stroke / 2f
                    val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
                    drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, Offset(inset, inset), arcSize,
                        style = Stroke(stroke))
                    if (progress > 0f) drawArc(accent, -90f, 360f * progress, false, Offset(inset, inset), arcSize,
                        style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                Text(if (node.requirementsMet || owned) "${node.level}" else "🔒", color = Neon.TextPrimary, fontSize = if (node.requirementsMet || owned) 18.sp else 15.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(node.def.name, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp)
                Text("Nível ${node.level}/${node.def.maxLevel}", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
        Text(node.def.description, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 10.dp))
        Text(
            if (owned) "Atual: ${node.def.effectText(node.level)}" else "Efeito: ${node.def.effectText(1)}",
            color = Neon.TextPrimary.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp)
        )
        val actionShape = RoundedCornerShape(50)
        when {
            maxed -> Text("Nível máximo", color = Neon.Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 10.dp))
            node.canBuy -> Box(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(actionShape).background(accent)
                    .clickable { onBuy(node.def.id) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Text("Evoluir · ${node.def.costAt(node.level)} PP", color = Neon.Bg, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            node.requirementsMet -> Text("Precisa de ${node.def.costAt(node.level)} PP", color = Neon.TextSecondary, fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp))
            else -> Text("Desbloqueie a habilidade anterior", color = Neon.TextSecondary, fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Neon.TextSecondary, fontSize = 13.sp)
        Text(value, color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
