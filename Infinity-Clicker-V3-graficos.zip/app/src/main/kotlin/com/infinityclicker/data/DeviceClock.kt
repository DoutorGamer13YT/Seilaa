package com.infinityclicker.data

import android.content.Context
import android.provider.Settings

/**
 * O jogo sempre conta o tempo pelo relógio do celular, mas só confia nele quando o Android está com "Data e hora
 * automáticas" e "Fuso horário automático" ligados: aí a hora vem da rede da operadora e o dia vira na hora certa
 * do país. Não precisa de internet no jogo nem de permissão. Se a leitura falhar, assume que está sincronizado
 * para não bloquear jogadores em aparelhos que não expõem esses ajustes.
 */
object DeviceClock {
    fun isAutoSynced(context: Context): Boolean = try {
        val resolver = context.contentResolver
        Settings.Global.getInt(resolver, Settings.Global.AUTO_TIME, 1) == 1 &&
            Settings.Global.getInt(resolver, Settings.Global.AUTO_TIME_ZONE, 1) == 1
    } catch (_: Exception) {
        true
    }
}
