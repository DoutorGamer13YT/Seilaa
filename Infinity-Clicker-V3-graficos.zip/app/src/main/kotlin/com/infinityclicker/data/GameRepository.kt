package com.infinityclicker.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclicker.game.GameState
import kotlinx.coroutines.flow.first

private val Context.gameDataStore by preferencesDataStore(name = "infinity_clicker")

enum class GraphicsQuality(val label: String, val particleScale: Float, val starCount: Int) {
    AUTO("Automático", 0.82f, 72),
    LOW("Econômico", 0.32f, 28),
    MEDIUM("Equilibrado", 0.60f, 52),
    HIGH("Alta", 1.0f, 90),
    ULTRA("Ultra", 1.28f, 120)
}

/** Perfil realmente usado pelo renderizador quando o jogador escolhe Automático. */
fun GraphicsQuality.resolvedFor(batterySaver: Boolean): GraphicsQuality = when (this) {
    GraphicsQuality.AUTO -> if (batterySaver) GraphicsQuality.LOW else GraphicsQuality.HIGH
    else -> this
}

/** Preferências que de fato alteram o renderizador; os defaults são econômicos no Galaxy A54. */
data class UserSettings(
    val scientificNotation: Boolean = false,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.AUTO,
    val frameRateCap: Int = 60,
    val batterySaver: Boolean = false,
    val effectsIntensity: Float = 1f,
    val panelOpacity: Float = 0.12f,
    val hapticsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true
)

data class LoadedGame(
    val state: GameState,
    val settings: UserSettings,
    /** true quando o save principal estava corrompido e o backup foi usado. */
    val recoveredFromBackup: Boolean
)

/**
 * Persistência local com DataStore (escrita atômica por transação).
 * Guarda o save principal e o save anterior como backup: se o principal falhar no checksum,
 * o backup é carregado em vez de perder o progresso.
 */
class GameRepository(context: Context) {
    private val store = context.applicationContext.gameDataStore

    suspend fun load(): LoadedGame {
        val prefs = store.data.first()
        val quality = prefs[KEY_QUALITY]?.let { raw -> GraphicsQuality.entries.firstOrNull { it.name == raw } }
            ?: GraphicsQuality.AUTO
        val fps = (prefs[KEY_FPS] ?: 60).let { if (it in setOf(30, 60, 90, 120)) it else 60 }
        val settings = UserSettings(
            scientificNotation = prefs[KEY_SCI] ?: false,
            graphicsQuality = quality,
            frameRateCap = fps,
            batterySaver = prefs[KEY_BATTERY] ?: false,
            effectsIntensity = (prefs[KEY_EFFECTS] ?: 1f).coerceIn(0.25f, 1.5f),
            panelOpacity = (prefs[KEY_PANEL] ?: 0.12f).coerceIn(0.06f, 0.30f),
            hapticsEnabled = prefs[KEY_HAPTICS] ?: true,
            soundEnabled = prefs[KEY_SOUND] ?: true,
            musicEnabled = prefs[KEY_MUSIC] ?: true
        )

        prefs[KEY_PRIMARY]?.let { text ->
            StateSerializer.deserialize(text)?.let { return LoadedGame(it, settings, false) }
        }
        prefs[KEY_BACKUP]?.let { text ->
            StateSerializer.deserialize(text)?.let { return LoadedGame(it, settings, true) }
        }
        return LoadedGame(GameState.new(), settings, recoveredFromBackup = false)
    }

    /** [text] já vem serializado (feito sob lock pelo chamador), então a escrita não toca no estado vivo. */
    suspend fun saveText(text: String) {
        store.edit { p ->
            val incoming = StateSerializer.deserialize(text) ?: return@edit
            val old = p[KEY_PRIMARY]
            val current = old?.let(StateSerializer::deserialize)
            // O ViewModel pode enfileirar snapshots em threads diferentes. A versão/horário
            // impedem que uma gravação antiga, entregue atrasada, reverta o progresso novo.
            if (current != null && !isAtLeastAsRecent(incoming, current)) return@edit
            if (old != null && current != null) p[KEY_BACKUP] = old
            p[KEY_PRIMARY] = text
        }
    }

    /** Reinício confirmado pelo jogador: remove também o backup para não ressuscitar progresso apagado. */
    suspend fun replaceAll(text: String) {
        store.edit { p ->
            p.remove(KEY_BACKUP)
            p[KEY_PRIMARY] = text
        }
    }

    /** Importação confirmada: preserva o save atual como backup antes de trocar a fonte principal. */
    suspend fun importText(text: String) {
        store.edit { p ->
            if (StateSerializer.deserialize(text) == null) return@edit
            val old = p[KEY_PRIMARY]
            if (old != null && StateSerializer.deserialize(old) != null) p[KEY_BACKUP] = old
            p[KEY_PRIMARY] = text
        }
    }

    suspend fun saveSettings(settings: UserSettings) {
        store.edit { p ->
            p[KEY_SCI] = settings.scientificNotation
            p[KEY_QUALITY] = settings.graphicsQuality.name
            p[KEY_FPS] = settings.frameRateCap
            p[KEY_BATTERY] = settings.batterySaver
            p[KEY_EFFECTS] = settings.effectsIntensity
            p[KEY_PANEL] = settings.panelOpacity
            p[KEY_HAPTICS] = settings.hapticsEnabled
            p[KEY_SOUND] = settings.soundEnabled
            p[KEY_MUSIC] = settings.musicEnabled
        }
    }

    suspend fun wipe() {
        store.edit { p ->
            p.remove(KEY_PRIMARY)
            p.remove(KEY_BACKUP)
        }
    }

    private companion object {
        val KEY_PRIMARY = stringPreferencesKey("state_primary")
        val KEY_BACKUP = stringPreferencesKey("state_backup")
        val KEY_SCI = booleanPreferencesKey("pref_scientific")
        val KEY_QUALITY = stringPreferencesKey("pref_graphics_quality")
        val KEY_FPS = intPreferencesKey("pref_fps_cap")
        val KEY_BATTERY = booleanPreferencesKey("pref_battery_saver")
        val KEY_EFFECTS = floatPreferencesKey("pref_effects_intensity")
        val KEY_PANEL = floatPreferencesKey("pref_panel_opacity")
        val KEY_HAPTICS = booleanPreferencesKey("pref_haptics")
        val KEY_SOUND = booleanPreferencesKey("pref_sound")
        val KEY_MUSIC = booleanPreferencesKey("pref_music")

        private fun isAtLeastAsRecent(incoming: GameState, current: GameState): Boolean =
            incoming.saveRevision > current.saveRevision ||
                (incoming.saveRevision == current.saveRevision && incoming.lastModifiedMs >= current.lastModifiedMs)
    }
}
