# Preparação segura para Firebase (não ativada neste build)

O jogo atual funciona integralmente offline e não exibe login ou sincronização que não possam ser concluídos. Firebase não foi incluído sem um projeto pertencente ao aplicativo, pois um `google-services.json` de exemplo não permite autenticação real.

Quando houver um projeto Firebase do proprietário, a integração deve seguir estes passos antes de qualquer botão ser exibido:

1. Criar/selecionar o projeto no Firebase Console e registrar o pacote `com.infinityclicker`.
2. Adicionar os fingerprints SHA-1 e SHA-256 da **mesma chave que assina o APK de produção**. Não usar uma chave de terceiros nem colocar keystore no repositório.
3. Baixar `google-services.json` específico do app e colocá-lo em `app/google-services.json`. Esse arquivo deve ficar fora de commits públicos quando contiver identificadores sensíveis do projeto.
4. Adicionar Firebase Authentication (Google e anônimo) e Cloud Firestore no Console. Habilitar o provedor Google somente depois dos fingerprints estarem corretos.
5. Aplicar regras mínimas de Firestore que restrinjam cada documento ao próprio usuário, por exemplo:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /players/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

6. Versionar o documento de progresso e comparar `lastModifiedMs`/`saveRevision`. Ao entrar, nunca apagar o save local automaticamente: oferecer **usar local**, **usar nuvem** ou uma mesclagem somente de campos cumulativos seguros (conquistas, cristais, totais máximos). Recursos gastáveis devem exigir confirmação em caso de conflito.
7. Testar convidado, vinculação de Google, offline, conflito entre dispositivos, logout e reinstalação em um projeto de testes antes de ativar o recurso em produção.

Não inclua chave administrativa, JSON de conta de serviço ou senha em APK, Git ou workflow. A chave pública do arquivo de configuração não substitui regras de segurança do Firestore.
