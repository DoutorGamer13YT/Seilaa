package com.w2a.nzuz

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.webkit.*
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppleMapView(vm: MapViewModel, modifier: Modifier = Modifier, active: Boolean = true, retryKey: Int = 0, offline: Boolean = false, requestLocation: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val isActive by rememberUpdatedState(active)
    var loaded by remember { mutableStateOf(false) }
    val camera = remember { vm.prefs.camera() }
    val initial = remember {
        camera?.let { "https://maps.apple.com/?ll=${it[0]},${it[1]}&z=${it[2]}" } ?: "https://maps.apple.com/"
    }
    var back by remember { mutableStateOf(false) }
    val web = remember {
        WebView(context).apply {
            setBackgroundColor(android.graphics.Color.rgb(242, 244, 248))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.mediaPlaybackRequiresUserGesture = true
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            settings.setGeolocationEnabled(true)
            settings.safeBrowsingEnabled = true
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return false
                    val u = request.url
                    if (u.scheme == "https" && u.host == "maps.apple.com" && (u.port == -1 || u.port == 443)) return false
                    if (request.hasGesture() && u.scheme in listOf("https", "http", "tel", "mailto")) {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, u)) }
                    }
                    return true
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) vm.webFailure.value = "O mapa online não está acessível. Você pode usar uma região baixada."
                }
                override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                    if (request.isForMainFrame && errorResponse.statusCode >= 400) vm.webFailure.value = "O serviço online respondeu com erro ${errorResponse.statusCode}."
                }
                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    handler.cancel()
                    vm.webFailure.value = "Não foi possível estabelecer uma conexão segura com o mapa online."
                }
                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    back = view.canGoBack()
                    val u = url?.let(Uri::parse) ?: return
                    if (u.host != "maps.apple.com") return
                    val ll = u.getQueryParameter("ll")?.split(",")?.mapNotNull(String::toDoubleOrNull)
                    if (ll?.size == 2 && ll[0] in -85.0..85.0 && ll[1] in -180.0..180.0) {
                        vm.prefs.saveCamera(ll[0], ll[1], u.getQueryParameter("z")?.toDoubleOrNull()?.coerceIn(0.0, 20.0) ?: 12.0, 0.0)
                    }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                    val u = Uri.parse(origin)
                    val allowed = u.scheme == "https" && u.host == "maps.apple.com" && (u.port == -1 || u.port == 443) && vm.gps.permitted()
                    callback.invoke(origin, allowed, false)
                    if (!allowed && u.host == "maps.apple.com") {
                        requestLocation()
                        vm.notice.value = "Após permitir, toque novamente na localização dentro do mapa."
                    }
                }
                override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
            }
            setDownloadListener { _, _, _, _, _ -> vm.notice.value = "Downloads do site não são mapas offline. Use Configurações → Mapas offline." }
            if (active) { loadUrl(initial); loaded = true }
        }
    }
    BackHandler(back && active) { web.goBack() }
    DisposableEffect(web, owner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> if (isActive) { web.resumeTimers(); web.onResume() }
                Lifecycle.Event.ON_PAUSE -> { web.onPause(); web.pauseTimers() }
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            web.stopLoading(); web.onPause(); web.removeAllViews(); web.destroy()
        }
    }
    var lastRetry by remember { mutableIntStateOf(retryKey) }
    var wasOffline by remember { mutableStateOf(false) }
    LaunchedEffect(active, retryKey, offline) {
        if (offline) { web.stopLoading(); wasOffline = true }
        if (active) {
            web.resumeTimers(); web.onResume()
            val cameraUrl = vm.prefs.camera()?.let { "https://maps.apple.com/?ll=${it[0]},${it[1]}&z=${it[2]}" } ?: initial
            if (!loaded || retryKey != lastRetry || wasOffline) {
                val current = web.url?.let(Uri::parse)
                val hasRouteOrSearch = current?.getQueryParameter("daddr") != null || current?.getQueryParameter("q") != null
                if (loaded && hasRouteOrSearch) web.reload() else web.loadUrl(cameraUrl)
                loaded = true; lastRetry = retryKey; wasOffline = false
            }
        } else { web.onPause(); web.pauseTimers() }
    }
    LaunchedEffect(web, active, retryKey) {
        if (!active) return@LaunchedEffect
        kotlinx.coroutines.delay(30_000)
        if (web.progress < 100) vm.webFailure.value = "O mapa demorou para responder. Tente novamente ou abra seus mapas offline."
    }
    AndroidView(factory = { web }, modifier = modifier, update = { it.visibility = if (active) android.view.View.VISIBLE else android.view.View.GONE })
}
