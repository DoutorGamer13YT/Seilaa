# Arquivos desta continuação

Comparação com o ZIP de código anterior, sem nova análise do APK. Nomes técnicos e código anterior foram mantidos.

## Criados

- `app/src/main/assets/land.geojson`
- `app/src/main/assets/licenses.txt`
- `app/src/main/assets/overview.json`
- `app/src/main/java/com/w2a/nzuz/PackageDownloadWorker.kt`
- `app/src/main/java/com/w2a/nzuz/PackagePanels.kt`
- `app/src/main/java/com/w2a/nzuz/PackageStore.kt`
- `app/src/main/java/com/w2a/nzuz/PackageVerifier.kt`
- `app/src/main/java/com/w2a/nzuz/RegionalCatalog.kt`
- `app/src/main/java/com/w2a/nzuz/RegionalRequest.kt`
- `app/src/main/java/com/w2a/nzuz/SecureHttp.kt`
- `docs/DISTRIBUICAO_PROTOMAPS.md`
- `server/build_catalog.py`
- `server/catalog.empty.json`
- `server/distribution_service.py`
- `server/generate_styles.mjs`
- `server/licenses/Apache-2.0.txt`
- `server/licenses/CC0-1.0.txt`
- `server/licenses/Icons-MIT.txt`
- `server/licenses/MapLibre-BSD-2-Clause.txt`
- `server/licenses/Noto-OFL.txt`
- `server/licenses/ODbL-1.0.txt`
- `server/licenses/Protomaps-BSD-3-Clause.txt`
- `server/licenses/Protomaps-DATA.txt`
- `server/nginx-locations.conf.example`
- `server/package.json`
- `server/prepare_region.py`

## Modificados

- `README.md`
- `THIRD_PARTY_NOTICES.md`
- `app/build.gradle.kts`
- `app/src/main/java/com/w2a/nzuz/AppleMapView.kt`
- `app/src/main/java/com/w2a/nzuz/DmapsApp.kt`
- `app/src/main/java/com/w2a/nzuz/MainActivity.kt`
- `app/src/main/java/com/w2a/nzuz/MapViewModel.kt`
- `app/src/main/java/com/w2a/nzuz/NativeMapView.kt`
- `app/src/main/java/com/w2a/nzuz/Preferences.kt`
- `app/src/main/java/com/w2a/nzuz/RegionDownloadWorker.kt`
- `app/src/main/java/com/w2a/nzuz/SettingsPanels.kt`
- `app/src/main/java/com/w2a/nzuz/SourceVerifier.kt`
- `app/src/main/res/values/strings.xml`
- `docs/FONTE_OFFLINE.md`
- `docs/STATIC_CHECK_REPORT.txt`
- `docs/VALIDACAO.md`

Este inventário e o relatório estático também foram atualizados. Nenhum workflow foi criado ou alterado.
