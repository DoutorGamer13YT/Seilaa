package com.infinityclicker.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.theme.Neon
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val size: Float, val color: Color
)
private class Shockwave(val x: Float, val y: Float, var life: Float, val maxLife: Float, val color: Color, val critical: Boolean)
private class FloatText(val x: Float, var y: Float, val text: String, val color: Color, var life: Float, val maxLife: Float, val big: Boolean)

/** Partículas e ondas com limites fixos para impedir crescimento de memória em autoclickers. */
private class ParticleField(private val maxParticles: Int, private val rnd: Random = Random(5)) {
    private val particles = ArrayList<Particle>()
    private val waves = ArrayList<Shockwave>()
    private val texts = ArrayList<FloatText>()

    fun burst(origin: Offset, color: Color, count: Int, crit: Boolean) {
        val n = if (crit) count * 2 else count
        repeat(n.coerceAtMost(60)) {
            if (particles.size >= maxParticles) particles.removeAt(0)
            val angle = rnd.nextFloat() * 2f * PI.toFloat()
            val speed = (if (crit) 500f else 310f) * (0.35f + rnd.nextFloat())
            val life = 0.42f + rnd.nextFloat() * 0.58f
            particles += Particle(origin.x, origin.y, cos(angle) * speed, sin(angle) * speed - 70f, life, life,
                2f + rnd.nextFloat() * if (crit) 5.5f else 3.5f, if (crit && rnd.nextBoolean()) Neon.Gold else color)
        }
        if (waves.size >= MAX_WAVES) waves.removeAt(0)
        waves += Shockwave(origin.x, origin.y, if (crit) 0.60f else 0.42f, if (crit) 0.60f else 0.42f, color, crit)
    }

    fun floatText(origin: Offset, text: String, color: Color, big: Boolean) {
        if (texts.size >= MAX_TEXTS) texts.removeAt(0)
        texts += FloatText(origin.x + (rnd.nextFloat() - 0.5f) * 60f, origin.y, text, color, 0.9f, 0.9f, big)
    }

    fun step(dt: Float) {
        val d = min(dt, 0.05f)
        for (i in particles.lastIndex downTo 0) {
            val p = particles[i]
            p.life -= d
            if (p.life <= 0f) particles.removeAt(i) else {
                p.vy += 590f * d; p.x += p.vx * d; p.y += p.vy * d
            }
        }
        for (i in waves.lastIndex downTo 0) {
            val wave = waves[i]
            wave.life -= d
            if (wave.life <= 0f) waves.removeAt(i)
        }
        for (i in texts.lastIndex downTo 0) {
            val text = texts[i]
            text.life -= d
            if (text.life <= 0f) texts.removeAt(i) else text.y -= 88f * d
        }
    }

    fun clear() { particles.clear(); waves.clear(); texts.clear() }

    fun draw(scope: DrawScope) {
        for (wave in waves) {
            val progress = 1f - wave.life / wave.maxLife
            scope.drawCircle(wave.color.copy(alpha = (1f - progress) * if (wave.critical) 0.70f else 0.45f),
                radius = (42f + progress * if (wave.critical) 180f else 120f), center = Offset(wave.x, wave.y), style = Stroke(width = if (wave.critical) 5f else 3f))
        }
        for (p in particles) {
            val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            scope.drawCircle(p.color.copy(alpha = alpha), p.size * (0.5f + 0.5f * alpha), Offset(p.x, p.y))
        }
    }

    fun forEachText(block: (Float, Float, String, Color, Float, Boolean) -> Unit) {
        for (text in texts) block(text.x, text.y, text.text, text.color, (text.life / text.maxLife).coerceIn(0f, 1f), text.big)
    }

    private companion object {
        const val MAX_WAVES = 12
        const val MAX_TEXTS = 14
    }
}

/**
 * Cristal 3D em Canvas: facetas em perspectiva, bordas especulares, núcleo volumétrico e órbitas.
 * Os cinco estilos alteram a geometria real (quantidade de faces/anel/núcleo), sem bitmap externo.
 */
@Composable
fun CrystalArea(
    tier: Int,
    crystalStyle: Int,
    baseColor: Color,
    comboFraction: Float,
    effectsIntensity: Float,
    particleLimit: Int,
    quality: GraphicsQuality,
    hapticsEnabled: Boolean,
    motionEnabled: Boolean,
    formatGain: (TapResult) -> String,
    onTap: () -> TapResult?,
    modifier: Modifier = Modifier
) {
    val field = remember(particleLimit) { ParticleField(particleLimit.coerceIn(24, 260)) }
    val textMeasurer = rememberTextMeasurer()
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val press = remember { Animatable(1f) }
    val ticker = LocalFrameTicker.current
    val detail = quality.detail

    LaunchedEffect(field, motionEnabled) {
        if (!motionEnabled) {
            field.clear()
            return@LaunchedEffect
        }
        var last = 0L
        while (isActive) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) field.step((now - last) / 1_000_000_000f)
                last = now
            }
        }
    }

    Box(
        modifier = modifier.pointerInput(effectsIntensity, baseColor, crystalStyle, motionEnabled, hapticsEnabled) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    for (change in event.changes) {
                        if (!change.changedToDown()) continue
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = min(size.width, size.height) * 0.31f
                        if (hypot(change.position.x - center.x, change.position.y - center.y) > radius * 1.45f) continue
                        change.consume()
                        val result = onTap()
                        if (result != null && hapticsEnabled) {
                            haptic.performHapticFeedback(if (result.crit) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
                        }
                        scope.launch {
                            press.snapTo(0.84f)
                            press.animateTo(1f, spring(dampingRatio = 0.34f, stiffness = Spring.StiffnessMedium))
                        }
                        if (result != null) {
                            val color = if (result.crit) Neon.Gold else baseColor
                            if (motionEnabled) {
                                field.burst(change.position, color, (12 * effectsIntensity).toInt().coerceAtLeast(3), result.crit)
                                field.floatText(change.position - Offset(0f, radius * 0.34f), (if (result.crit) "CRÍTICO! +" else "+") + formatGain(result), color, result.crit)
                                if (!result.bossDamage.isZero) field.floatText(change.position + Offset(0f, radius * 0.20f), "−${formatGain(result.copy(gain = result.bossDamage))}", Neon.Pink, false)
                            }
                        }
                    }
                }
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            // Fases lidas no desenho: o cristal anima no ritmo do limite de FPS escolhido.
            val nanos = ticker.value
            val spin = if (motionEnabled) phaseOf(nanos, 13_000L) else 0f
            val bob = if (motionEnabled) phaseOf(nanos, 4_100L) else 0f
            val pulse = if (motionEnabled) 0.91f + 0.09f * cos(phaseOf(nanos, 4_400L)) else 1f
            val center = Offset(size.width / 2f, size.height / 2f + sin(bob) * size.height * 0.018f)
            val radius = min(size.width, size.height) * 0.30f * press.value
            drawCrystalScene(center, radius, spin, pulse, comboFraction, baseColor, crystalStyle, tier, detail)
            field.draw(this)
            field.forEachText { x, y, text, color, alpha, big ->
                val style = TextStyle(color = color.copy(alpha = alpha), fontSize = (if (big) 26 else 18).sp, fontWeight = FontWeight.Bold)
                val layout = textMeasurer.measure(text, style)
                drawText(layout, Offset(x - layout.size.width / 2f, y - layout.size.height / 2f))
            }
        }
    }
}

private fun DrawScope.drawCrystalScene(
    center: Offset, r: Float, spin: Float, pulse: Float, combo: Float, base: Color, style: Int, tier: Int, detail: Int
) {
    val halo = r * (2.05f + combo * 0.55f)
    drawCircle(Brush.radialGradient(listOf(base.copy(alpha = (0.22f + combo * 0.25f) * pulse), Color.Transparent), center, halo), halo, center)
    if (detail >= 2) { // brilho externo extra (bloom) em Alta/Ultra
        val bloom = halo * 1.35f
        drawCircle(Brush.radialGradient(listOf(base.copy(alpha = 0.10f * pulse), Color.Transparent), center, bloom), bloom, center)
    }
    if (detail >= 1) drawOval(Brush.radialGradient(listOf(base.copy(alpha = 0.24f), Color.Transparent), center, r * 1.05f),
        topLeft = Offset(center.x - r * 1.05f, center.y + r * 0.93f), size = androidx.compose.ui.geometry.Size(r * 2.1f, r * 0.32f))
    if (style >= 2 && detail >= 1) drawOrbits(center, r, spin, base, style)
    drawFacetedCrystal(center, r, spin, base, style, tier, detail)
    if (detail >= 3) { // Ultra: faíscas orbitando o cristal
        repeat(8) { i ->
            val a = spin * (1.6f + i * 0.11f) + i * (2f * PI.toFloat() / 8f)
            val rr = r * (1.35f + 0.12f * (i % 3))
            drawCircle(Color.White.copy(alpha = 0.55f), 2.2f + (i % 3), Offset(center.x + cos(a) * rr, center.y + sin(a) * rr * 0.45f))
        }
    }
}

private fun DrawScope.drawOrbits(center: Offset, r: Float, spin: Float, color: Color, style: Int) {
    repeat(if (style == 4) 3 else 1) { i ->
        val scale = 1f + i * 0.18f
        val tilt = 0.34f + i * 0.08f
        val rect = Rect(center.x - r * 1.18f * scale, center.y - r * tilt, center.x + r * 1.18f * scale, center.y + r * tilt)
        drawArc(color.copy(alpha = 0.30f - i * 0.06f), startAngle = (spin * 57.3f + i * 70f), sweepAngle = 210f,
            useCenter = false, topLeft = rect.topLeft, size = rect.size, style = Stroke(width = 1.6f))
    }
}

private fun DrawScope.drawFacetedCrystal(center: Offset, r: Float, spin: Float, base: Color, style: Int, tier: Int, detail: Int) {
    val sides = when (style) { 0 -> 6; 1 -> 8; 2 -> 10; 3 -> 4; else -> 12 }
    val elongation = when (style) { 1 -> 1.25f; 3 -> 0.88f; 4 -> 1.08f; else -> 1f }
    val ringRadius = r * when (style) { 3 -> 0.92f; 4 -> 0.72f; else -> 0.82f }
    val top = Offset(center.x, center.y - r * 1.08f * elongation)
    val bottom = Offset(center.x, center.y + r * 1.18f * elongation)
    val ringY = center.y - r * 0.04f
    val squash = if (style == 3) 0.38f else 0.29f

    data class Point3(val point: Offset, val z: Float)
    data class Facet(val path: Path, val z: Float, val light: Float, val alpha: Float)
    val ring = List(sides) { i ->
        val a = spin + i * (2f * PI.toFloat() / sides)
        Point3(Offset(center.x + cos(a) * ringRadius, ringY + sin(a) * ringRadius * squash), sin(a))
    }
    val facets = ArrayList<Facet>(sides * 2)
    for (i in 0 until sides) {
        val p1 = ring[i]; val p2 = ring[(i + 1) % sides]
        val angle = spin + (i + 0.5f) * (2f * PI.toFloat() / sides)
        val z = sin(angle)
        val light = 0.42f + 0.58f * cos(angle - 5.25f)
        facets += Facet(Path().apply { moveTo(top.x, top.y); lineTo(p1.point.x, p1.point.y); lineTo(p2.point.x, p2.point.y); close() }, z, light, 0.91f)
        facets += Facet(Path().apply { moveTo(bottom.x, bottom.y); lineTo(p2.point.x, p2.point.y); lineTo(p1.point.x, p1.point.y); close() }, z, light * 0.72f, 0.82f)
    }
    facets.sortBy { it.z }
    val dark = lerp(base, Color(0xFF030411), 0.78f)
    val bright = lerp(base, Color.White, 0.64f)
    facets.forEach { facet ->
        val fill = lerp(dark, bright, facet.light.coerceIn(0f, 1f))
        drawPath(facet.path, fill.copy(alpha = if (facet.z > 0f) facet.alpha else facet.alpha * 0.45f))
        if (detail >= 1) drawPath(facet.path, Color.White.copy(alpha = if (facet.z > 0f) 0.52f else 0.15f), style = Stroke(width = 1.45f))
    }
    // Núcleo interno e reflexo especular: duas camadas dão volume sem blur caro.
    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.72f), base.copy(alpha = 0.35f), Color.Transparent),
        Offset(center.x - r * 0.22f, center.y - r * 0.30f), r * 0.52f), r * 0.52f, Offset(center.x - r * 0.22f, center.y - r * 0.30f))
    if (detail >= 1) drawPath(Path().apply {
        moveTo(top.x, top.y + r * 0.12f); lineTo(center.x - r * 0.16f, center.y - r * 0.12f); lineTo(center.x - r * 0.03f, center.y - r * 0.47f); close()
    }, Color.White.copy(alpha = 0.46f))
    if (style == 4 || tier >= 5) {
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), base.copy(alpha = 0.52f), Color.Transparent), center, r * 0.52f), r * 0.52f, center)
    }
}
