package com.w2a.nzuz

import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

private val identifier = Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,79}")

data class MapPackage(val json: JSONObject) {
    val id: String = json.getString("id")
    val version: String = json.getString("version")
    val key: String = "$id.$version"
    val name: String = json.getString("name")
    val kind: String = json.getString("kind")
    val url: String = json.getString("url")
    val bytes: Long = json.getLong("bytes")
    val unpackedBytes: Long = json.getLong("unpackedBytes")
    val sha256: String = json.getString("sha256").lowercase()
    val minZoom: Int = json.getInt("minZoom")
    val maxZoom: Int = json.getInt("maxZoom")
    val attribution: String = json.getString("attribution")
    val box: List<Double> = json.getJSONArray("bounds").let { a -> List(a.length()) { a.getDouble(it) } }
    val bounds: LatLngBounds get() = LatLngBounds.from(box[3], box[2], box[1], box[0])
    init {
        require(identifier.matches(id) && identifier.matches(version)) { "Identificador de pacote inválido" }
        require(name.isNotBlank() && name.length <= 120 && kind in listOf("city", "state", "custom"))
        require(bytes in 127..MAX_PACKAGE && unpackedBytes in 127..MAX_PACKAGE)
        require(Regex("[a-f0-9]{64}").matches(sha256))
        require(minZoom in 0..15 && maxZoom in minZoom..15)
        require(box.size == 4 && box.all { it.isFinite() } && box[0] >= -180 && box[2] <= 180 &&
            box[1] >= -85 && box[3] <= 85 && box[0] < box[2] && box[1] < box[3])
        require(attribution.contains("OpenStreetMap") && attribution.length <= 2000)
        require(json.getString("provider") == "protomaps" && json.getString("license") == "ODbL-1.0")
        SecureHttp.url(url)
    }
    companion object { const val MAX_PACKAGE = 8L * 1024 * 1024 * 1024 }
}

