package com.w2a.nzuz

import android.content.Context
import android.util.AtomicFile
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

 data class PackageState(val pack: MapPackage, val received: Long, val state: String, val installed: Boolean, val error: String = "")

class PackageStore(private val context: Context, private val prefs: Preferences) {
    val root = File(context.filesDir, "regional").apply { mkdirs() }
    private val mutable = MutableStateFlow<List<PackageState>>(emptyList())
    val items = mutable.asStateFlow()
    private val locks = ConcurrentHashMap<String, Mutex>()
    private val work = WorkManager.getInstance(context)
    private val active = ConcurrentHashMap.newKeySet<String>()
    private val updates = Any()
    val catalog = MutableStateFlow<List<MapPackage>>(emptyList())
    fun lock(key: String) = locks.getOrPut(key) { Mutex() }
    fun directory(p: MapPackage) = File(root, p.key)
    fun installed(p: MapPackage) = File(directory(p), "installed")
    fun part(p: MapPackage) = File(directory(p), "download.part")
    fun use(p: MapPackage) { active.add(p.key) }
    fun release(p: MapPackage) { active.remove(p.key) }
    fun inUse(p: MapPackage) = p.key in active
    fun freeBytes() = root.usableSpace
    suspend fun diskBytes() = withContext(Dispatchers.IO) { root.walkTopDown().filter { it.isFile }.sumOf { it.length() } }
    suspend fun load() = withContext(Dispatchers.IO) {
        root.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
            runCatching {
                val p = MapPackage(JSONObject(AtomicFile(File(dir, "metadata.json")).openRead().bufferedReader().use { it.readText() }))
                require(directory(p).canonicalFile == dir.canonicalFile)
                val status = if (File(dir, "installed/pack.json").isFile) {
                    try { PackageVerifier.verify(installed(p), p, hashes = false); "Disponível offline" }
                    catch (e: Exception) {
                        File(installed(p), "pack.json").renameTo(File(installed(p), "pack.corrupt.json"))
                        "Pacote danificado; exclua e baixe novamente"
                    }
                } else "Interrompido; retome para continuar"
                publish(p, status)
            }
        }
        runCatching { catalog.value = parseCatalog(JSONObject(File(root, "catalog.json").readText())) }
    }
    suspend fun refreshCatalog() = withContext(Dispatchers.IO) {
        val url = prefs.state.value.catalogUrl
        require(url.isNotBlank()) { "Configure a URL HTTPS do catálogo regional Protomaps em Configurações" }
        val json = SecureHttp.json(url)
        val parsed = parseCatalog(json)
        atomic(File(root, "catalog.json"), json.toString())
        catalog.value = parsed
    }
    fun publish(p: MapPackage, state: String, error: String = "") = synchronized(updates) {
        val value = PackageState(p, part(p).length(), state, File(installed(p), "pack.json").isFile, error)
        mutable.value = (mutable.value.filterNot { it.pack.key == p.key } + value).sortedBy { it.pack.name }
    }
    suspend fun resume(p: MapPackage) = withContext(Dispatchers.IO) {
        lock(p.key).withLock {
            if (File(installed(p), "pack.json").isFile) { publish(p, "Disponível offline"); return@withLock }
            directory(p).mkdirs()
            atomic(File(directory(p), "metadata.json"), p.json.toString())
            File(directory(p), "staging").deleteRecursively()
            require(freeBytes() >= (p.bytes - part(p).length()).coerceAtLeast(0) + p.unpackedBytes + RESERVE) { "Espaço insuficiente para baixar e instalar a região" }
            val request = OneTimeWorkRequestBuilder<PackageDownloadWorker>()
                .setInputData(workDataOf("key" to p.key))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(if (prefs.state.value.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).setRequiresStorageNotLow(true).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("regional-pack").build()
            work.enqueueUniqueWork("package-${p.key}", ExistingWorkPolicy.KEEP, request).result.await()
            publish(p, "Agendado; aguardando rede e Android")
        }
    }
    suspend fun pause(p: MapPackage) {
        work.cancelUniqueWork("package-${p.key}").result.await()
        withContext(Dispatchers.IO) { lock(p.key).withLock { publish(p, "Pausado; dados parciais preservados") } }
    }
    suspend fun delete(p: MapPackage) {
        require(!inUse(p)) { "Feche este mapa antes de excluí-lo" }
        pause(p)
        withContext(Dispatchers.IO) { lock(p.key).withLock {
            require(!inUse(p)) { "Mapa em uso" }
            require(directory(p).deleteRecursively()) { "Não foi possível excluir todos os arquivos" }
            synchronized(updates) { mutable.value = mutable.value.filterNot { it.pack.key == p.key } }
        } }
    }
    suspend fun verify(p: MapPackage) = withContext(Dispatchers.IO) {
        lock(p.key).withLock {
            try { PackageVerifier.verify(installed(p), p); publish(p, "Integridade verificada") }
            catch (e: Exception) {
                if (!inUse(p)) File(installed(p), "pack.json").renameTo(File(installed(p), "pack.corrupt.json"))
                publish(p, "Arquivo corrompido; exclua e baixe novamente", e.message.orEmpty()); throw e
            }
        }
    }
    companion object {
        const val RESERVE = 256L * 1024 * 1024
        fun atomic(file: File, value: String) {
            val atomic = AtomicFile(file)
            val out = atomic.startWrite()
            try { out.write(value.toByteArray(Charsets.UTF_8)); atomic.finishWrite(out) }
            catch (e: Exception) { atomic.failWrite(out); throw e }
        }
    }
}
