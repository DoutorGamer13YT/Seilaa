package com.w2a.nzuz

import android.graphics.PointF
import android.location.Location
import android.os.Bundle
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.location.LocationComponentOptions
import org.maplibre.android.location.LocationComponentActivationOptions
import org.maplibre.android.location.modes.CameraMode
import org.maplibre.android.location.modes.RenderMode
import org.maplibre.android.maps.*

enum class Orientation { NORTH, FREE, COMPASS }

class NativeMapHandle {
    var orientation by mutableStateOf(Orientation.NORTH)
    var map: MapLibreMap? = null
    var view: MapView? = null
    var gpsAllowed = false
    var lastLocation: Location? = null
    var locationActive = false
    var following = false
    var selection: LatLngBounds? = null
    var onGesture: (() -> Unit)? = null
    var onSelection: ((LatLngBounds?) -> Unit)? = null
    var onFailure: ((String) -> Unit)? = null

    fun center(compass: Boolean = false) {
        val m = map ?: return
        val fix = lastLocation ?: return
        if (locationActive && gpsAllowed) {
            m.locationComponent.cameraMode = if (compass) CameraMode.TRACKING_COMPASS else CameraMode.TRACKING
            following = true
        }
        m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(fix.latitude, fix.longitude), m.cameraPosition.zoom.coerceAtLeast(12.0)), 650)
    }
    fun orient(value: Orientation) {
        orientation = value
        map?.uiSettings?.isRotateGesturesEnabled = value == Orientation.FREE
        if (locationActive) map?.locationComponent?.renderMode = if (value == Orientation.COMPASS) RenderMode.COMPASS else RenderMode.NORMAL
        when (value) {
            Orientation.NORTH -> { free(); north() }
            Orientation.FREE -> free()
            Orientation.COMPASS -> center(true)
        }
    }
    fun free() {
        following = false
        if (locationActive) map?.locationComponent?.cameraMode = CameraMode.NONE
    }
    fun north() { map?.animateCamera(CameraUpdateFactory.bearingTo(0.0), 450) }
    @Suppress("MissingPermission")
    fun position(location: Location?, granted: Boolean) {
        gpsAllowed = granted
        lastLocation = location
        val m = map ?: return
        val style = m.style ?: return
        if (!granted) {
            if (locationActive) m.locationComponent.isLocationComponentEnabled = false
            return
        }
        if (!m.locationComponent.isLocationComponentActivated) {
            m.locationComponent.activateLocationComponent(LocationComponentActivationOptions.builder(view!!.context, style)
                .useDefaultLocationEngine(false).locationComponentOptions(LocationComponentOptions.builder(view!!.context)
                    .compassAnimationEnabled(true).accuracyAnimationEnabled(true).build()).build())
        }
        locationActive = true
        m.locationComponent.isLocationComponentEnabled = true
        m.locationComponent.renderMode = if (orientation == Orientation.COMPASS) RenderMode.COMPASS else RenderMode.NORMAL
        location?.let { m.locationComponent.forceLocationUpdate(it) }
    }
    fun captureSelection() {
        val m = map ?: return
        val v = view ?: return
        if (v.width < 1 || v.height < 1) return
        val pad = 24f * v.resources.displayMetrics.density
        val nw = m.projection.fromScreenLocation(PointF(pad, pad))
        val se = m.projection.fromScreenLocation(PointF(v.width - pad, v.height - pad))
        if (nw.longitude >= se.longitude || nw.latitude <= se.latitude || se.longitude - nw.longitude >= 180) {
            selection = null
            onSelection?.invoke(null)
            return
        }
        selection = LatLngBounds.from(nw.latitude, se.longitude, se.latitude, nw.longitude)
        selection?.let { onSelection?.invoke(it) }
    }
}

@Composable
fun NativeMapView(
    vm: MapViewModel, handle: NativeMapHandle, region: RegionItem?, selecting: Boolean,
    styleUrl: String, location: Location?, permission: Boolean, modifier: Modifier = Modifier, pack: MapPackage? = null, dark: Boolean = false
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val mapView = remember { MapView(context, MapLibreMapOptions.createFromAttributes(context).textureMode(true)).also { it.onCreate(Bundle()) } }
    val sourceKey = if (pack != null) "package:${pack.key}:$dark" else if (selecting) "select:$styleUrl" else "region:${region?.id}"
    var ready by remember { mutableStateOf(false) }
    DisposableEffect(mapView, owner) {
        handle.view = mapView
        var started = false
        var resumed = false
        fun synchronize() {
            val state = owner.lifecycle.currentState
            if (state.isAtLeast(Lifecycle.State.STARTED) && !started) { mapView.onStart(); started = true }
            if (state.isAtLeast(Lifecycle.State.RESUMED) && !resumed) { mapView.onResume(); resumed = true }
            if (!state.isAtLeast(Lifecycle.State.RESUMED) && resumed) { mapView.onPause(); resumed = false }
            if (!state.isAtLeast(Lifecycle.State.STARTED) && started) { mapView.onStop(); started = false }
        }
        val observer = LifecycleEventObserver { _, _ -> synchronize() }
        owner.lifecycle.addObserver(observer); synchronize()
        mapView.addOnDidFailLoadingMapListener { error -> handle.onFailure?.invoke("Não foi possível abrir o mapa: $error") }
        mapView.getMapAsync { map ->
            handle.map = map
            map.uiSettings.isCompassEnabled = true
            map.uiSettings.isAttributionEnabled = true
            map.uiSettings.isLogoEnabled = false
            map.addOnCameraIdleListener {
                val c = map.cameraPosition
                c.target?.let { vm.prefs.saveCamera(it.latitude, it.longitude, c.zoom, c.bearing) }
                handle.captureSelection()
            }
            map.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) {
                    handle.free(); handle.onGesture?.invoke()
                }
            }
            ready = true
        }
        onDispose {
            owner.lifecycle.removeObserver(observer)
            if (resumed) mapView.onPause()
            if (started) mapView.onStop()
            handle.map = null; handle.view = null; handle.locationActive = false
            mapView.onDestroy()
        }
    }
    LaunchedEffect(ready, sourceKey) {
        val map = handle.map ?: return@LaunchedEffect
        handle.locationActive = false
        map.setLatLngBoundsForCameraTarget(null)
        map.setMinZoomPreference(0.0); map.setMaxZoomPreference(20.0)
        map.uiSettings.isRotateGesturesEnabled = !selecting && handle.orientation == Orientation.FREE
        map.uiSettings.isTiltGesturesEnabled = !selecting
        val url = if (selecting) styleUrl else region?.definition?.styleURL.orEmpty()
        if (url.isBlank() && pack == null) return@LaunchedEffect
        val builder = try {
            if (pack != null) {
                val json = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    PackageVerifier.header(java.io.File(vm.packages.installed(pack), "map.pmtiles"), pack)
                    PackageVerifier.style(vm.packages.installed(pack), dark)
                }
                Style.Builder().fromJson(json)
            } else Style.Builder().fromUri(url)
        } catch (e: Exception) { handle.onFailure?.invoke("Pacote inválido: ${e.message}. Verifique a integridade em Downloads."); return@LaunchedEffect }
        map.setStyle(builder) {
            if (handle.map !== map) return@setStyle
            val b = pack?.bounds ?: region?.definition?.bounds
            if (!selecting && b != null) {
                map.setLatLngBoundsForCameraTarget(b)
                map.setMaxZoomPreference(pack?.maxZoom?.toDouble() ?: region!!.definition.maxZoom)
            }
            val camera = vm.prefs.camera()
            val saved = camera?.let { LatLng(it[0], it[1]) }
            when {
                saved != null && (selecting || b?.contains(saved) == true) -> {
                    map.cameraPosition = CameraPosition.Builder().target(saved)
                        .zoom(camera[2].coerceIn(0.0, if (selecting) 16.0 else pack?.maxZoom?.toDouble() ?: region!!.definition.maxZoom))
                        .bearing(if (selecting || handle.orientation == Orientation.NORTH) 0.0 else camera[3]).tilt(0.0).build()
                }
                b != null && !selecting -> map.moveCamera(CameraUpdateFactory.newLatLngBounds(b, 50))
                location != null -> map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 10.0))
                else -> map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(0.0, 0.0), 2.0))
            }
            handle.position(location, permission)
            handle.view?.post { handle.captureSelection() }
        }
    }
    DisposableEffect(pack?.key) {
        pack?.let { vm.packages.use(it) }
        onDispose { pack?.let { vm.packages.release(it) } }
    }
    LaunchedEffect(location, permission, ready) { handle.position(location, permission) }
    AndroidView(factory = { mapView }, modifier = modifier)
}
