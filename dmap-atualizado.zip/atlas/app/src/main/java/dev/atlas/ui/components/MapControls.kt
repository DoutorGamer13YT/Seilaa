package dev.atlas.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.LocalAtlasColors
import dev.atlas.ui.theme.LocalAtlasReduceMotion

@Composable
fun CircularMapButton(
    icon: ImageVector, label: String, onClick: () -> Unit,
    selected: Boolean = false, modifier: Modifier = Modifier, enabled: Boolean = true,
) {
    val colors = LocalAtlasColors.current
    val isSelected = selected
    val background by animateColorAsState(if (selected) colors.accent else colors.glass, tween(if (LocalAtlasReduceMotion.current) 0 else AtlasDimens.ShortAnimationMillis), label = "control background")
    val interaction = remember { MutableInteractionSource() }
    Surface(
        onClick = onClick, enabled = enabled, interactionSource = interaction,
        modifier = modifier.size(AtlasDimens.ControlSize).pressScale(interaction).semantics { this.selected = isSelected },
        shape = CircleShape, color = background,
        contentColor = if (selected) colors.onAccent else colors.accent,
        border = BorderStroke(0.8.dp, colors.glassBorder),
        shadowElevation = AtlasDimens.FloatingElevation,
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = LocalContentColor.current.copy(alpha = if (enabled) 1f else 0.38f), modifier = Modifier.size(AtlasDimens.IconSize))
        }
    }
}

@Composable
fun SearchField(
    value: String, onValueChange: (String) -> Unit, onSearch: () -> Unit,
    onFocus: () -> Unit, onCancel: () -> Unit, active: Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = LocalAtlasColors.current
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Surface(
            modifier = Modifier.weight(1f).heightIn(min = AtlasDimens.SearchHeight),
            color = colors.secondarySurface.copy(alpha = 0.86f),
            shape = RoundedCornerShape(AtlasDimens.SearchRadius),
        ) {
            Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = colors.secondaryText, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(9.dp))
                BasicTextField(
                    value = value, onValueChange = onValueChange,
                    modifier = Modifier.weight(1f).padding(vertical = 13.dp).onFocusChanged { if (it.isFocused) onFocus() }
                        .semantics { contentDescription = "Pesquisar lugares e endereços" },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = colors.text),
                    cursorBrush = SolidColor(colors.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { keyboard?.hide(); onSearch() }),
                    decorationBox = { field ->
                        Box { if (value.isEmpty()) Text("Buscar no mapa", color = colors.secondaryText, style = MaterialTheme.typography.bodyLarge); field() }
                    },
                )
                if (value.isNotEmpty()) IconButton(onClick = { onValueChange("") }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, "Limpar pesquisa", tint = colors.secondaryText, modifier = Modifier.size(18.dp))
                } else Spacer(Modifier.width(10.dp))
            }
        }
        AnimatedVisibility(visible = active, enter = fadeIn() + expandHorizontally(), exit = fadeOut() + shrinkHorizontally()) {
            TextButton(onClick = { keyboard?.hide(); focusManager.clearFocus(); onCancel() }, contentPadding = PaddingValues(start = 12.dp, end = 0.dp)) {
                Text("Cancelar", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun MapAttribution(modifier: Modifier = Modifier) {
    val colors = LocalAtlasColors.current
    Surface(modifier = modifier, shape = RoundedCornerShape(8.dp), color = colors.glass.copy(alpha = 0.72f)) {
        Text(
            "© OpenStreetMap · OpenFreeMap · OpenMapTiles",
            Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, lineHeight = 12.sp),
            color = colors.secondaryText, maxLines = 1,
        )
    }
}
