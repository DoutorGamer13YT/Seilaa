# Status da atualização 2.0

## Implementado e conectado ao motor

| Sistema | Entrega |
|---|---|
| Save V1 | Leitura do formato `IC1` V1, migração sem apagar dados e regravação em V2 com CRC/backup |
| Cristal | Cinco geometrias/cores equipáveis, bônus de clique, resposta tátil visual, partículas e ondas |
| Habilidades | Recarga e duração persistidas, efeitos aplicados a clique/produção/crítico/energia |
| Prestígio | Prévia, confirmação, pontos, multiplicador permanente, histórico e reset parcial |
| Árvore | Nove nós em três caminhos, requisitos/custos e efeitos econômicos reais |
| Dimensões | Cinco dimensões, requisito de abertura, viagem, multiplicador e ressonância por fragmentos |
| Chefes | Vida persistida, prazo, dano por clique, escala, energia e fragmentos de recompensa |
| Missões | Três diárias locais, login diário, cinco conquistas e proteção contra coleta duplicada |
| Renderização | Fundo dimensionável, perfis de qualidade, economia de bateria, solicitação de FPS e vidro leve |

## Pendente deliberadamente

- Firebase Auth, Google Sign-In, Firestore, regras de segurança e resolução de conflito: dependem de um projeto Firebase e de IDs de assinatura fornecidos pelo proprietário. Não há botão que finja esse fluxo.
- Música/efeitos sonoros: dependem de assets originais/licenciados e de teste de foco de áudio.
- Eventos sazonais/remotos, mais dimensões, desafios por dimensão e conteúdo de servidor.
- Níveis independentes de jogador/cristal e variações de geradores por dimensão ainda não foram adicionados; os cristais atuais evoluem por coleção/equipamento e bônus real.
- Room: avaliar apenas se o futuro conteúdo precisar de tabelas/históricos grandes; o save atual já é transacional e protegido.
- Medição em aparelho físico e profiling no Galaxy A54 5G: o código reduz trabalho por qualidade, mas precisa de medição real para afirmar números de FPS/bateria.
