import { layers, namedFlavor } from '@protomaps/basemaps';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const output = resolve(process.argv[2] || 'styles');
mkdirSync(output, { recursive: true });
for (const theme of ['light', 'dark']) {
  const style = {
    version: 8,
    glyphs: 'dmap://fonts/{fontstack}/{range}.pbf',
    sprite: `dmap://sprites/${theme}`,
    sources: { protomaps: { type: 'vector', url: 'dmap://map.pmtiles', attribution: '© OpenStreetMap contributors · Protomaps · Natural Earth' } },
    layers: layers('protomaps', namedFlavor(theme), { lang: 'pt' })
  };
  writeFileSync(resolve(output, `${theme}.json`), JSON.stringify(style));
}
