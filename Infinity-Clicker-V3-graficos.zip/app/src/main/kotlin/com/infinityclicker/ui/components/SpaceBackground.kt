package com.infinityclicker.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.BackgroundStyle
import com.infinityclicker.ui.theme.Neon
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val BG_U = 1000f

private class Star(
    val x: Float, val y: Float, val r: Float,
    val phase: Float, val speed: Float, val hue: Float,
    val ramp: FloatArray, // 16 amplitudes pré-computadas de um ciclo de cintilação
    val layer: Int        // camada de paralaxe 1..3: as maiores (mais próximas) derivam mais rápido
)

/** Fundo por cenário, com custo escalado pela qualidade e listas de estrelas estáveis em memória. */
@Composable
fun SpaceBackground(
    tint: Color = Neon.Cyan,
    style: BackgroundStyle? = null,
    quality: GraphicsQuality = GraphicsQuality.AUTO,
    motionEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val scene = style ?: BackgroundStyle.DEEP_SPACE
    val stars = remember(quality) {
        val rnd = Random(7)
        List(quality.starCount) {
            // Velocidade INTEIRA: cada estrela completa um número inteiro de ciclos por período, então o laço
            // de 52 s fecha sem emenda (com velocidades fracionárias havia um "pulo" a cada volta).
            val speed = (1 + rnd.nextInt(2)).toFloat()
            val phase = rnd.nextFloat() * (2f * PI.toFloat())
            val rr = 0.55f + rnd.nextFloat() * 1.75f
            Star(
                x = rnd.nextFloat(), y = rnd.nextFloat(), r = rr,
                phase = phase, speed = speed, hue = rnd.nextFloat(),
                // Cintilação tabelada com o mesmo formato da fórmula anterior
                // (0.28 + 0.62·(0.5 + 0.5·sin(2π·ciclo + fase))): 16 amostras feitas uma única vez,
                // o desenho só indexa — sem sin() por estrela por quadro.
                ramp = FloatArray(16) { k ->
                    0.28f + 0.62f * (0.5f + 0.5f * sin(2f * PI.toFloat() * k / 16f + phase))
                },
                layer = if (rr < 1.1f) 1 else if (rr < 1.9f) 2 else 3
            )
        }
    }
    // O fundo se move devagar: um relógio próprio a 30 fps basta e libera a GPU/CPU para o cristal e a rolagem.
    // Ultra/Alta sobem para uma taxa maior (o paralaxe das estrelas fica sem degraus); o governador térmico limita.
    val bgFps = if (!motionEnabled) 10 else minOf(EnergyGovernor.suggestedCap(), if (quality.detail >= 3) 60 else if (quality.detail == 2) 40 else 30)
    val ticker = rememberFrameTicker(bgFps)
    val blobA = remember(tint) { Brush.radialGradient(listOf(tint.copy(alpha = 0.26f), Color.Transparent), Offset.Zero, BG_U) }
    val blobB = remember { Brush.radialGradient(listOf(Neon.Violet.copy(alpha = 0.22f), Color.Transparent), Offset.Zero, BG_U) }
    val blobC = remember(tint) { Brush.radialGradient(listOf(Color.White.copy(alpha = 0.055f), tint.copy(alpha = 0.13f), Color.Transparent), Offset.Zero, BG_U) }
    val periodMs = if (quality == GraphicsQuality.LOW) 90_000L else 52_000L
    val detail = quality.detail

    // O degradê base é estático: fica numa camada própria que nunca é invalidada pelo relógio de animação.
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Neon.BgMid, Neon.Bg, Color(0xFF010208))))) {
    // Manchas de cor estáticas de cada cenário: os shaders são criados uma vez por tamanho, não a cada quadro.
    Box(Modifier.fillMaxSize().drawWithCache {
        val w = size.width
        val h = size.height
        val center = Offset(w * .5f, h * .48f)
        fun blob(color: Color, a: Float, at: Offset, r: Float) =
            Triple(Brush.radialGradient(listOf(color.copy(alpha = a), Color.Transparent), at, r), r, at)
        val blobs = when (scene) {
            BackgroundStyle.NEBULA -> listOf(
                blob(Neon.Pink, .20f, Offset(w * .72f, h * .26f), w * .56f),
                blob(tint, .17f, Offset(w * .20f, h * .74f), w * .48f),
                blob(Neon.Violet, .15f, Offset(w * .46f, h * .50f), w * .40f),
                blob(Color.White, .05f, Offset(w * .60f, h * .38f), w * .22f)
            )
            BackgroundStyle.SPIRAL_GALAXY -> listOf(
                Triple(Brush.radialGradient(listOf(Color.White.copy(alpha = .20f), tint.copy(alpha = .12f), Color.Transparent), center, w * .46f), w * .46f, center),
                Triple(Brush.radialGradient(listOf(Color.White.copy(alpha = .34f), Color.Transparent), center, w * .09f), w * .09f, center)
            )
            BackgroundStyle.BLACK_HOLE -> listOf(
                // Brilho quente do disco de acreção e anel de fótons logo fora do horizonte de eventos.
                Triple(Brush.radialGradient(0.34f to Color.Transparent, 0.42f to tint.copy(alpha = .34f), 0.60f to Neon.Gold.copy(alpha = .10f), 1f to Color.Transparent, center = center, radius = w * .52f), w * .52f, center),
                Triple(Brush.radialGradient(0.80f to Color.Transparent, 0.93f to Color.White.copy(alpha = .55f), 1f to Color.Transparent, center = center, radius = w * .20f), w * .20f, center)
            )
            BackgroundStyle.QUANTUM -> listOf(
                blob(Neon.Green, .10f, center, w * .52f),
                blob(tint, .10f, Offset(w * .20f, h * .20f), w * .36f)
            )
            BackgroundStyle.TEMPORAL -> listOf(blob(Neon.Gold, .14f, center, w * .50f))
            BackgroundStyle.INFINITE_REALM -> listOf(Triple(
                Brush.radialGradient(listOf(Color.White.copy(alpha = .13f), tint.copy(alpha = .08f), Color.Transparent), center, w * .68f), w * .68f, center
            ))
            BackgroundStyle.TRANSCENDENTAL_REALITY -> listOf(blob(Neon.Pink, .22f, Offset(w * .28f, h * .34f), w * .45f), blob(Neon.Gold, .18f, Offset(w * .73f, h * .66f), w * .42f))
            else -> emptyList()
        }
        // Planeta distante com anel (só qualidade média+): esfera sombreada pela luz do canto, borda iluminada e anel inclinado.
        val pr = w * 0.17f
        val pc = Offset(w * 0.94f, h * 0.64f)
        val planetBody = Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.30f), tint.copy(alpha = 0.26f), Color(0xFF02030A).copy(alpha = 0.90f)),
            Offset(pc.x - pr * 0.48f, pc.y - pr * 0.42f), pr * 1.75f
        )
        val planetRim = Brush.radialGradient(0.78f to Color.Transparent, 1f to tint.copy(alpha = 0.38f), center = pc, radius = pr)
        val ringW = pr * 2.7f
        val ringH = pr * 0.66f
        val ringTop = Offset(pc.x - ringW / 2f, pc.y - ringH / 2f)
        val ringSize = Size(ringW, ringH)
        val ringStroke = Stroke(pr * 0.075f)
        onDrawBehind {
            for (b in blobs) drawCircle(b.first, b.second, b.third)
            if (detail >= 1) {
                rotate(-18f, pc) { drawArc(tint.copy(alpha = 0.14f), 180f, 180f, false, ringTop, ringSize, style = ringStroke) }
                drawCircle(planetBody, pr, pc)
                drawCircle(planetRim, pr, pc)
                rotate(-18f, pc) { drawArc(Color.White.copy(alpha = 0.20f), 0f, 180f, false, ringTop, ringSize, style = ringStroke) }
            }
        }
    })
    Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
        // Lido só na fase de desenho: o fundo redesenha no ritmo do limite de FPS, sem recompor.
        val t = if (motionEnabled) phaseOf(ticker.value, periodMs) else 0f
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.25f + 0.08f * cos(t)), h * (0.20f + 0.05f * sin(t)))
        val c2 = Offset(w * (0.80f + 0.06f * sin(t * 2f)), h * (0.70f + 0.05f * cos(t * 2f)))
        val c3 = Offset(w * (0.53f + 0.13f * cos(t * 0.70f + 1.6f)), h * (0.42f + 0.10f * sin(t * 0.80f + 0.5f)))
        withTransform({ translate(c1.x, c1.y); scale(w * 0.77f / BG_U, w * 0.77f / BG_U, Offset.Zero) }) { drawCircle(blobA, BG_U, Offset.Zero) }
        if (detail >= 1) withTransform({ translate(c2.x, c2.y); scale(w * 0.68f / BG_U, w * 0.68f / BG_U, Offset.Zero) }) { drawCircle(blobB, BG_U, Offset.Zero) }
        // Uma terceira nébula pequena cria gradiente em movimento no plano de fundo, apenas em qualidade média/alta.
        if (detail >= 2) withTransform({ translate(c3.x, c3.y); scale(w * 0.40f / BG_U, w * 0.40f / BG_U, Offset.Zero) }) { drawCircle(blobC, BG_U, Offset.Zero) }
        drawSceneAccent(scene, tint, t, w, h, quality)
        if (detail >= 1) drawAuroraRibbons(tint, t, w, h)
        if (detail >= 1) {
            val orbitCenter = Offset(w * 0.5f, h * 0.52f)
            drawCircle(tint.copy(alpha = 0.07f), radius = w * 0.36f + sin(t) * 12f, center = orbitCenter,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.4f))
            drawCircle(Neon.Violet.copy(alpha = 0.05f), radius = w * 0.48f - sin(t) * 9f, center = orbitCenter,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f))
        }
        if (detail >= 1 && motionEnabled) {
            drawShootingStar(ticker.value / 1_000_000L, w, h, tint, 9_000L, 0L)
            if (detail >= 2) drawShootingStar(ticker.value / 1_000_000L, w, h, Color(0xFFFFE9B8), 14_000L, 5_300L)
        }
        for (si in stars.indices) {
            val star = stars[si]
            // t avança 0..2π por período; a cintilação completa 8·speed ciclos nesse intervalo.
            val alpha = if (detail == 0) 0.55f else star.ramp[((t * star.speed * 4f / PI) % 1f * 16f).toInt()]
            val color = if (star.hue > 0.72f) tint else if (star.hue > 0.55f) Color(0xFFFFE9B8) else Color.White
            val x = star.x * w + if (motionEnabled) sin(t * star.speed + star.phase) * 2.5f else 0f
            // Paralaxe em laço: a camada k desce k alturas de tela por período (inteiro => sem emenda ao reiniciar).
            val sy = if (motionEnabled) ((star.y + star.layer * (t / (2f * PI.toFloat()))) % 1f) * h else star.y * h
            if (detail >= 2 && star.r > 1.6f) drawCircle(color.copy(alpha = alpha * 0.18f), radius = star.r * 3.2f, center = Offset(x, sy))
            drawCircle(color.copy(alpha = alpha), radius = star.r, center = Offset(x, sy))
            if (detail >= 2 && star.r > 2.0f) { // clarão em cruz nas estrelas maiores
                val len = star.r * 4.2f * alpha
                drawLine(color.copy(alpha = alpha * 0.55f), Offset(x - len, sy), Offset(x + len, sy), 0.9f)
                drawLine(color.copy(alpha = alpha * 0.55f), Offset(x, sy - len), Offset(x, sy + len), 0.9f)
            }
        }
    }
    // Vinheta estática (cache por tamanho): escurece as bordas e dá profundidade sem custo por quadro.
    Box(Modifier.fillMaxSize().drawWithCache {
        val brush = Brush.radialGradient(
            0.55f to Color.Transparent, 1f to Color(0xFF010208).copy(alpha = 0.62f),
            center = Offset(size.width / 2f, size.height * 0.48f), radius = size.maxDimension * 0.78f
        )
        onDrawBehind { drawRect(brush) }
    })
    }
}

/** Três arcos de aurora muito leves: só alguns traços por quadro, sem Path, bitmap ou shader novo. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAuroraRibbons(tint: Color, t: Float, w: Float, h: Float) {
    repeat(3) { index ->
        val wave = sin(t * (1.15f + index * 0.16f) + index * 1.8f)
        val bandW = w * (0.88f + index * 0.06f)
        val bandH = h * (0.24f + index * 0.045f)
        val x = -w * (0.10f + index * 0.025f)
        val y = h * (0.15f + index * 0.13f) + wave * h * 0.018f
        val color = if (index == 1) Neon.Violet else tint
        drawArc(
            color.copy(alpha = 0.045f - index * 0.008f),
            startAngle = 198f + wave * 8f + index * 11f,
            sweepAngle = 122f,
            useCenter = false,
            topLeft = Offset(x, y),
            size = androidx.compose.ui.geometry.Size(bandW, bandH),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.1f + index * 0.35f)
        )
    }
}

/** Estrela cadente a cada ~9 s: posição derivada do número do ciclo, sem estado nem alocação. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawShootingStar(ms0: Long, w: Float, h: Float, tint: Color, cycle: Long, offsetMs: Long) {
    val ms = ms0 + offsetMs
    val idx = ms / cycle
    val p = (ms % cycle) / 1_100f
    if (p >= 1f) return
    val fx = ((idx * 0.618034) % 1.0).toFloat()
    val fy = ((idx * 0.377) % 1.0).toFloat()
    val dx = -0.86f; val dy = 0.50f
    val head = Offset(w * (0.35f + 0.6f * fx) + dx * p * w * 0.55f, h * (0.04f + 0.30f * fy) + dy * p * w * 0.55f)
    val fade = sin(p * PI.toFloat())
    val tail = Offset(head.x - dx * w * 0.16f, head.y - dy * w * 0.16f)
    // Cauda em 4 segmentos que ganham brilho rumo à cabeça: sem criar um shader (Brush) novo a cada quadro.
    for (k in 0 until 4) {
        val a0 = k / 4f
        val a1 = (k + 1) / 4f
        drawLine(
            tint.copy(alpha = 0.55f * fade * a1 * a1),
            Offset(tail.x + (head.x - tail.x) * a0, tail.y + (head.y - tail.y) * a0),
            Offset(tail.x + (head.x - tail.x) * a1, tail.y + (head.y - tail.y) * a1),
            1f + 0.35f * k
        )
    }
    drawCircle(Color.White.copy(alpha = 0.9f * fade), 2.4f, head)
    drawCircle(tint.copy(alpha = 0.25f * fade), 7f, head)
}

/** Pontos de uma galáxia de dois braços (calculados uma vez): x/y em espaço unitário, tamanho e brilho por ponto. */
private object GalaxyDots {
    const val N = 150
    val x = FloatArray(N)
    val y = FloatArray(N)
    val size = FloatArray(N)
    val glow = FloatArray(N)

    init {
        val rnd = Random(21)
        for (i in 0 until N) {
            val arm = i % 2
            val k = (i / 2f) / (N / 2f) // 0..1 ao longo do braço
            val ang = k * 3.4f * PI.toFloat() + arm * PI.toFloat()
            val rad = 0.05f + k * 0.95f + (rnd.nextFloat() - 0.5f) * 0.20f * (0.3f + k)
            x[i] = cos(ang) * rad
            y[i] = sin(ang) * rad
            size[i] = 0.6f + rnd.nextFloat() * 1.5f
            glow[i] = (1f - k * 0.55f) * (0.35f + rnd.nextFloat() * 0.5f)
        }
    }
}

/** A base estrelada é compartilhada; cada cenário adiciona só algumas primitivas baratas por quadro. */
private fun DrawScope.drawSceneAccent(
    style: BackgroundStyle,
    tint: Color,
    t: Float,
    w: Float,
    h: Float,
    quality: GraphicsQuality
) {
    val center = Offset(w * .5f, h * .48f)
    // t vai de 0 a 2π em cada período: usar 57,2958 (graus por radiano) dá exatamente uma volta por período, sem emenda.
    val turn = t * 57.2958f
    when (style) {
        BackgroundStyle.DEEP_SPACE -> Unit
        BackgroundStyle.NEBULA -> Unit // manchas estáticas: camada em cache acima
        BackgroundStyle.SPIRAL_GALAXY -> {
            // Galáxia inclinada que gira devagar: braços de pontos suaves e núcleo claro (o brilho está na camada em cache).
            val rr = w * .46f
            withTransform({ translate(center.x, center.y); scale(1f, .58f, Offset.Zero); rotate(turn, Offset.Zero) }) {
                for (i in 0 until GalaxyDots.N) {
                    val px = GalaxyDots.x[i] * rr
                    val py = GalaxyDots.y[i] * rr
                    val sz = rr * .016f * GalaxyDots.size[i]
                    if (quality.detail >= 2) drawCircle(tint.copy(alpha = GalaxyDots.glow[i] * .22f), sz * 2.6f, Offset(px, py))
                    drawCircle(Color.White.copy(alpha = GalaxyDots.glow[i] * .55f), sz, Offset(px, py))
                }
            }
        }
        BackgroundStyle.BLACK_HOLE -> {
            val hr = w * .18f
            drawCircle(Color(0xFF000008).copy(alpha = .92f), hr, center)
            // Disco de acreção: anéis inclinados que alternam entre a cor do cenário e dourado.
            repeat(5) { ring ->
                val r = w * (.205f + ring * .04f)
                val color = if (ring % 2 == 0) tint else Neon.Gold
                drawArc(color.copy(alpha = .46f - ring * .07f), -70f + turn + ring * 13f, 250f, false,
                    Offset(center.x - r, center.y - r * .48f), Size(r * 2f, r * .96f), style = Stroke(2.6f - ring * .4f, cap = StrokeCap.Round))
            }
            // Metade da frente do disco cruza na frente do buraco (lente gravitacional).
            val r0 = w * .215f
            drawArc(Neon.Gold.copy(alpha = .36f), 15f, 150f, false,
                Offset(center.x - r0, center.y - r0 * .30f), Size(r0 * 2f, r0 * .60f), style = Stroke(3.2f, cap = StrokeCap.Round))
        }
        BackgroundStyle.QUANTUM -> if (quality != GraphicsQuality.LOW) {
            val step = w / 8f
            repeat(9) { i ->
                val x = i * step + sin(t + i.toFloat()) * 4f
                drawLine(tint.copy(alpha = .09f), Offset(x, 0f), Offset(x, h), 1f)
                val y = i * h / 8f + cos(t * 2f + i.toFloat()) * 3f
                drawLine(Neon.Green.copy(alpha = .08f), Offset(0f, y), Offset(w, y), 1f)
            }
            // Nós nos cruzamentos que pulsam em ondas defasadas (só em qualidade alta ou ultra).
            if (quality.detail >= 2) repeat(9) { i ->
                val x = i * step + sin(t + i.toFloat()) * 4f
                repeat(9) { j ->
                    val y = j * h / 8f + cos(t * 2f + j.toFloat()) * 3f
                    val pulse = .5f + .5f * sin(t * 2f + i * .9f + j * 1.3f)
                    drawCircle(Neon.Green.copy(alpha = .08f + .30f * pulse), 1.8f + 1.6f * pulse, Offset(x, y))
                    if (pulse > .86f) drawCircle(tint.copy(alpha = .16f), 7f, Offset(x, y))
                }
            }
        }
        BackgroundStyle.TEMPORAL -> {
            repeat(4) { ring ->
                val r = w * (.16f + ring * .09f)
                drawArc(Neon.Gold.copy(alpha = .18f - ring * .025f), turn + ring * 90f, 210f, false,
                    Offset(center.x - r, center.y - r), Size(r * 2f, r * 2f), style = Stroke(1.3f, cap = StrokeCap.Round))
            }
            // Marcas de relógio (12 horas) e um ponteiro que dá uma volta por período.
            val cr = w * .16f
            repeat(12) { k ->
                val a = k * (PI.toFloat() / 6f)
                val major = k % 3 == 0
                val inner = if (major) .84f else .92f
                drawLine(Neon.Gold.copy(alpha = if (major) .42f else .20f),
                    Offset(center.x + cos(a) * cr * inner, center.y + sin(a) * cr * inner),
                    Offset(center.x + cos(a) * cr, center.y + sin(a) * cr), if (major) 2.2f else 1.2f, StrokeCap.Round)
            }
            val ha = t - PI.toFloat() / 2f
            drawLine(Neon.Gold.copy(alpha = .38f), center, Offset(center.x + cos(ha) * cr * .76f, center.y + sin(ha) * cr * .76f), 1.8f, StrokeCap.Round)
            drawCircle(Neon.Gold.copy(alpha = .55f), 3.2f, center)
        }
        BackgroundStyle.INFINITE_REALM -> {
            if (quality == GraphicsQuality.ULTRA) repeat(3) { i ->
                drawCircle(tint.copy(alpha = .10f), w * (.18f + i * .12f + sin(t + i.toFloat()) * .01f), center = center, style = Stroke(1f))
            }
        }
        BackgroundStyle.TRANSCENDENTAL_REALITY -> {
            // Estrela central em camadas: halos rosa e dourado, miolo claro e clarão em cruz.
            val pr = w * (.026f + sin(t * 2f) * .006f)
            drawCircle(Neon.Pink.copy(alpha = .10f), pr * 5f, center)
            drawCircle(Neon.Gold.copy(alpha = .14f), pr * 2.6f, center)
            drawCircle(Color.White.copy(alpha = .55f), pr, center)
            val fl = pr * 9f
            drawLine(Color.White.copy(alpha = .28f), Offset(center.x - fl, center.y), Offset(center.x + fl, center.y), 1.2f, StrokeCap.Round)
            drawLine(Color.White.copy(alpha = .28f), Offset(center.x, center.y - fl), Offset(center.x, center.y + fl), 1.2f, StrokeCap.Round)
        }
    }
}
