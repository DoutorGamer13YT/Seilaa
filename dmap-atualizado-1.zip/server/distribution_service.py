#!/usr/bin/env python3
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
from urllib.parse import urlparse
from prepare_region import make_package, bounds, https, atomic_json

DATA = Path(os.environ.get('DMAP_DATA', './distribution')).resolve()
TOKEN = os.environ.get('DMAP_REQUEST_TOKEN', '')
SOURCE = os.environ.get('PROTOMAPS_BUILD_URL', '')
PUBLIC = os.environ.get('DMAP_PUBLIC_BASE', '')
ASSETS = os.environ.get('DMAP_ASSETS', '')
STYLES = os.environ.get('DMAP_STYLES', '')
VERSION = os.environ.get('DMAP_MAP_VERSION', '')
WAKE = threading.Event()
STOP = threading.Event()


def database():
    db = sqlite3.connect(DATA / 'jobs.sqlite', timeout=30)
    db.row_factory = sqlite3.Row
    return db


def prepare_loop():
    while not STOP.is_set():
        with database() as db:
            job = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
            if job:
                db.execute("UPDATE jobs SET status='running' WHERE id=?", (job['id'],))
        if not job:
            WAKE.wait(10)
            WAKE.clear()
            continue
        try:
            spec = json.loads(job['spec'])
            result = make_package(source=SOURCE, output=DATA / 'packages', public_base=PUBLIC, assets=ASSETS, styles=STYLES,
                                  region_id=job['id'], version=VERSION, name=spec['name'], kind='custom', bbox=spec['bounds'], zoom=spec['maxZoom'])
            with database() as db:
                db.execute("UPDATE jobs SET status='ready', result=? WHERE id=?", (json.dumps(result), job['id']))
        except Exception as error:
            with database() as db:
                db.execute("UPDATE jobs SET status='failed', error=? WHERE id=?", (str(error)[:2000], job['id']))


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def reply(self, code, body):
        data = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(data)
        self.close_connection = True

    def do_POST(self):
        if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + TOKEN):
            return self.reply(401, {'error': 'unauthorized'})
        if urlparse(self.path).path != '/requests':
            return self.reply(404, {'error': 'not found'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 1 <= length <= 4096:
                return self.reply(413, {'error': 'request too large'})
            self.connection.settimeout(15)
            data = json.loads(self.rfile.read(length))
            job_id = data['requestId']
            if not re.fullmatch(r'[a-f0-9-]{36}', job_id):
                raise ValueError('invalid request ID')
            spec = {'bounds': bounds(data['bounds']), 'maxZoom': int(data['maxZoom']), 'name': str(data['name']).strip()}
            if not 8 <= spec['maxZoom'] <= 15 or not 1 <= len(spec['name']) <= 120:
                raise ValueError('invalid zoom or name')
            serialized = json.dumps(spec, sort_keys=True)
            with database() as db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
                if row and row['spec'] != serialized:
                    return self.reply(409, {'error': 'request ID is immutable'})
                if not row:
                    if db.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0] >= 32:
                        return self.reply(429, {'error': 'queue full'})
                    free = __import__('shutil').disk_usage(DATA).free
                    if free < 20 * 1024 ** 3:
                        return self.reply(507, {'error': 'server disk space insufficient'})
                    db.execute("INSERT INTO jobs(id,spec,status,created) VALUES (?,?,'queued',?)", (job_id, serialized, time.time()))
                    row = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
                answer = {'requestId': job_id, 'status': row['status']}
                if row['result']:
                    answer['package'] = json.loads(row['result'])
                if row['error']:
                    answer['error'] = row['error']
            WAKE.set()
            self.reply(200, answer)
        except (KeyError, ValueError, TypeError, json.JSONDecodeError) as error:
            self.reply(400, {'error': str(error)})
        except Exception:
            self.reply(500, {'error': 'internal preparation error'})

    def log_message(self, fmt, *args):
        pass


def main():
    if len(TOKEN) < 32:
        raise SystemExit('Set DMAP_REQUEST_TOKEN to a private token with at least 32 characters')
    https(SOURCE)
    https(PUBLIC)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', VERSION):
        raise SystemExit('Set DMAP_MAP_VERSION; change it for every source/style/assets update')
    if not Path(ASSETS).is_dir() or not Path(STYLES).is_dir():
        raise SystemExit('Set DMAP_ASSETS and DMAP_STYLES to prepared local directories')
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / 'packages').mkdir(exist_ok=True)
    with database() as db:
        db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, spec TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, result TEXT, error TEXT)')
        db.execute("UPDATE jobs SET status='queued' WHERE status='running'")
    thread = threading.Thread(target=prepare_loop, daemon=True)
    thread.start()
    server = ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('DMAP_PORT', '8787'))), Handler)
    try:
        server.serve_forever()
    finally:
        STOP.set()
        WAKE.set()
        server.server_close()


if __name__ == '__main__':
    main()
