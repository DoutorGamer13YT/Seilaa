package com.vitinhjkjkk.dmap.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dmapStore by preferencesDataStore(name = "dmap_preferences")

class DmapRepository(private val context: Context) {
    private val darkKey = booleanPreferencesKey("dark_theme")
    private val modeKey = stringPreferencesKey("map_mode")
    private val favoritesKey = stringPreferencesKey("favorites_json")

    val darkTheme: Flow<Boolean> = context.dmapStore.data.map { it[darkKey] ?: true }
    val mapMode: Flow<String> = context.dmapStore.data.map { it[modeKey] ?: "AUTO" }
    val favorites: Flow<List<Place>> = context.dmapStore.data.map { prefs ->
        parseFavorites(prefs[favoritesKey].orEmpty())
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dmapStore.edit { it[darkKey] = enabled }
    }

    suspend fun setMapMode(value: String) {
        context.dmapStore.edit { it[modeKey] = value }
    }

    suspend fun toggleFavorite(place: Place) {
        context.dmapStore.edit { prefs ->
            val current = parseFavorites(prefs[favoritesKey].orEmpty()).toMutableList()
            val index = current.indexOfFirst {
                it.latitude == place.latitude && it.longitude == place.longitude
            }
            if (index >= 0) current.removeAt(index) else current.add(0, place)
            prefs[favoritesKey] = JSONArray().apply {
                current.forEach { item ->
                    put(JSONObject().apply {
                        put("name", item.name)
                        put("address", item.address)
                        put("latitude", item.latitude)
                        put("longitude", item.longitude)
                        put("category", item.category)
                    })
                }
            }.toString()
        }
    }

    suspend fun clearFavorites() {
        context.dmapStore.edit { it[favoritesKey] = "[]" }
    }

    private fun parseFavorites(raw: String): List<Place> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    Place(
                        name = item.optString("name"),
                        address = item.optString("address"),
                        latitude = item.optDouble("latitude"),
                        longitude = item.optDouble("longitude"),
                        category = item.optString("category"),
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())
}
