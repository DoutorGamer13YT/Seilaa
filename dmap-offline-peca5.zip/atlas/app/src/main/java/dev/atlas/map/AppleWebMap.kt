package dev.atlas.map

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.roundToInt

object AppleWebLinks {
    fun url(latitude: Double, longitude: Double, zoom: Double): String = Uri.Builder()
        .scheme("https").authority("maps.apple.com").appendPath("")
        .appendQueryParameter("ll", "$latitude,$longitude")
        .appendQueryParameter("z", zoom.roundToInt().coerceIn(3, 20).toString())
        .build().toString()

    fun allowedHost(host: String?): Boolean {
        val value = host?.lowercase() ?: return false
        return value == "apple.com" || value.endsWith(".apple.com") ||
            value == "apple-mapkit.com" || value.endsWith(".apple-mapkit.com") ||
            value.endsWith(".cdn-apple.com") || value.endsWith(".mzstatic.com")
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppleWebMap(
    modifier: Modifier = Modifier,
    cameraRequest: CameraRequest?,
    initialCamera: CameraSnapshot?,
    onMapError: (String?) -> Unit,
    onUnavailable: (String) -> Unit,
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val error by rememberUpdatedState(onMapError)
    val unavailable by rememberUpdatedState(onUnavailable)
    val state = remember { object { var cameraId: Long? = cameraRequest?.id; var loaded = false } }
    val webView = remember(context) {
        WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                setGeolocationEnabled(false)
            }
            contentDescription = "Mapa da Apple em modo de visualização."
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.scheme != "https" || !AppleWebLinks.allowedHost(request.url.host)

                override fun onPageFinished(view: WebView, url: String?) { error(null) }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, e: WebResourceError) {
                    if (request.isForMainFrame) unavailable("load-failed")
                }

                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    unavailable("render-process-gone")
                    return true
                }
            }
        }
    }
    AndroidView(
        modifier = modifier,
        factory = { webView },
        update = { view ->
            val request = cameraRequest
            val target = request?.target
            if (!state.loaded) {
                state.loaded = true
                val start = if (request != null && target != null && request.id != state.cameraId)
                    Triple(target.latitude, target.longitude, request.zoom ?: 15.0)
                else initialCamera?.let { Triple(it.latitude, it.longitude, it.zoom) }
                    ?: Triple(-23.5505, -46.6333, 12.0)
                view.loadUrl(AppleWebLinks.url(start.first, start.second, start.third))
                state.cameraId = request?.id
            } else if (request != null && request.id != state.cameraId) {
                state.cameraId = request.id
                if (target != null) view.loadUrl(AppleWebLinks.url(target.latitude, target.longitude, request.zoom ?: 15.0))
            }
        },
    )
    DisposableEffect(webView, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> webView.onResume()
                Lifecycle.Event.ON_PAUSE -> webView.onPause()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            webView.stopLoading()
            webView.destroy()
        }
    }
}
