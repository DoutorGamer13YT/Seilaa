package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.data.StateSerializer
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.AchievementCategory
import com.infinityclicker.game.AchievementDefs
import com.infinityclicker.game.BackgroundDefs
import com.infinityclicker.game.ChallengeDefs
import com.infinityclicker.game.GameState
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.PrestigeEntry
import com.infinityclicker.game.SkillPath
import com.infinityclicker.game.SkillTree
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class V3ProgressionTest {

    @Test
    fun achievementGalleryHasExactlyRequestedDistribution() {
        assertEquals(250, AchievementDefs.all.size)
        assertEquals(40, AchievementDefs.all.count { it.category == AchievementCategory.CLICKS })
        assertEquals(35, AchievementDefs.all.count { it.category == AchievementCategory.PRODUCTION })
        assertEquals(35, AchievementDefs.all.count { it.category == AchievementCategory.UPGRADES })
        assertEquals(30, AchievementDefs.all.count { it.category == AchievementCategory.PRESTIGE })
        assertEquals(30, AchievementDefs.all.count { it.category == AchievementCategory.ABILITIES })
        assertEquals(30, AchievementDefs.all.count { it.category == AchievementCategory.CHALLENGES })
        assertEquals(25, AchievementDefs.all.count { it.category == AchievementCategory.EXPLORATION })
        assertEquals(25, AchievementDefs.all.count { it.category == AchievementCategory.SECRET })
    }

    @Test
    fun everyAchievementHasAReachableGameStateCondition() {
        val state = fullyProgressedState()
        val missing = AchievementDefs.all.filterNot { it.achieved(state) }.map { it.id }
        assertTrue("conquistas não atingíveis no estado completo: $missing", missing.isEmpty())
    }

    @Test
    fun skillTreeHasFivePathsAndOneHundredFunctionalNodes() {
        assertEquals(100, SkillTree.all.size)
        assertEquals(5, SkillPath.entries.size)
        SkillPath.entries.forEach { path -> assertEquals(20, SkillTree.all.count { it.path == path }) }
        assertTrue(SkillTree.all.filter { it.id !in setOf(
            SkillTree.POWER_CORE, SkillTree.POWER_CRIT, SkillTree.POWER_COMBO,
            SkillTree.AUTO_CORE, SkillTree.AUTO_MILESTONE, SkillTree.AUTO_OFFLINE,
            SkillTree.TRANS_CORE, SkillTree.TRANS_PRESTIGE, SkillTree.TRANS_DIMENSION
        ) }.all { it.effect != null && it.effectPerLevel > 0.0 })
    }

    @Test
    fun v3SaveRoundTripKeepsNewPersistentSystems() {
        val source = fullyProgressedState().apply {
            equippedBackground = 4
            purchaseModeUses[3] = 9
            achievementsUnlockedAt["click_1k"] = 123L
            abilityUseCounts[AbilityDefs.SUPER_CLICK] = 77L
        }
        val restored = StateSerializer.deserialize(StateSerializer.serialize(source))!!
        assertEquals(source.backgroundsUnlocked.toList(), restored.backgroundsUnlocked.toList())
        assertEquals(4, restored.equippedBackground)
        assertEquals(9L, restored.purchaseModeUses[3])
        assertEquals(123L, restored.achievementsUnlockedAt["click_1k"])
        assertEquals(77L, restored.abilityUseCounts[AbilityDefs.SUPER_CLICK])
        assertEquals(source.challengeWins.toList(), restored.challengeWins.toList())
    }

    @Test
    fun manualChallengePaysOnceAfterItsRealClickTarget() {
        val engine = GameEngine(GameState.new(), Random(9))
        assertTrue(engine.startChallenge("manual_pulse", 1_000L))
        // A meta vem da definição (60 cliques × dificuldade global): um clique a menos não conclui o desafio.
        val target = com.infinityclicker.game.ChallengeDefs.byId.getValue("manual_pulse").target.toInt()
        repeat(target - 1) { index -> engine.tap(index * 100L, 1_000L + index * 100L) }
        assertEquals(0L, engine.state.challengeCompletions)
        engine.tap((target - 1) * 100L, 1_000L + (target - 1) * 100L)
        assertEquals(1L, engine.state.challengeCompletions)
        assertTrue(engine.consumeChallengeCompletion() != null)
        assertTrue(engine.consumeChallengeCompletion() == null)
    }

    private fun fullyProgressedState(): GameState = GameState.new().apply {
        energy = BigNum.of(10.0).pow(80.0)
        totalEnergy = energy
        runEnergy = energy
        totalClicks = 2_000_000L
        critClicks = 100_000L
        maxCombo = 200
        generatorsBought = 10_000L
        upgradeLevelsBought = 2_000L
        clickEnergy = energy
        productionEnergy = energy
        offlineEarned = energy
        highestProduction = energy
        highestTapMultiplier = 500.0
        bestClicksPerSecond = 50
        generators.fill(1_000L)
        highestGeneratorTierEver = GeneratorDefs.count - 1
        UpgradeDefs.all.forEach { upgradeLevels[it.id] = it.maxLevel }
        highestUpgradeLevelEver = UpgradeDefs.all.maxOf { it.maxLevel }
        prestigePoints = 5_000
        prestigeCount = 500
        prestigeHistory += PrestigeEntry(1L, 100, energy)
        SkillTree.all.forEach { skillLevels[it.id] = it.maxLevel }
        AbilityDefs.all.forEach {
            abilityLevels[it.id] = it.maxLevel
            abilityUseCounts[it.id] = 1_000L
        }
        abilitiesUsed = 10_000L
        dimensionUnlocked.fill(true)
        backgroundsUnlocked.fill(true)
        crystalsUnlocked.fill(true)
        dimensionTravelCount = 1_000L
        bossWins.fill(100)
        eventsTriggered = 100L
        challengeCompletions = 1_000L
        challengeFastestMs = 5_000L
        challengeWins.fill(10L)
        purchaseModeUses.fill(2_000L)
        AchievementDefs.all.forEach { achievementsClaimed += it.id; achievementsUnlockedAt[it.id] = 1L }
    }
}
