package com.infinityclicker.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.ui.CrystalUi
import com.infinityclicker.ui.DimensionUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun DimensionsScreen(
    ui: UiState,
    onUnlock: (Int) -> Unit,
    onTravel: (Int) -> Unit,
    onResonance: (Int) -> Unit,
    onStartBoss: () -> Unit,
    onEquipCrystal: (Int) -> Unit
) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Text("Mapa Cósmico", color = Neon.TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Viaje, melhore a ressonância local e desafie entidades cósmicas.", color = Neon.TextSecondary, fontSize = 13.sp)
        }
        items(ui.dimensions, key = { "dim-${it.def.id}" }) { dimension ->
            DimensionCard(
                row = dimension,
                f = ::f,
                alpha = ui.settings.panelOpacity,
                bossActive = ui.activeBoss != null,
                onUnlock = { onUnlock(dimension.def.id) },
                onTravel = { onTravel(dimension.def.id) },
                onResonance = { onResonance(dimension.def.id) },
                onStartBoss = onStartBoss
            )
        }
        item {
            Text("Cristais desbloqueáveis", color = Neon.TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text("Cada aparência também aplica seu bônus real por clique.", color = Neon.TextSecondary, fontSize = 13.sp)
        }
        items(ui.crystals, key = { "crystal-${it.def.id}" }) { crystal ->
            CrystalCard(crystal, ::f, ui.settings.panelOpacity, onEquipCrystal)
        }
    }
}

@Composable
private fun DimensionCard(
    row: DimensionUi,
    f: (com.infinityclicker.core.BigNum) -> String,
    alpha: Float,
    bossActive: Boolean,
    onUnlock: () -> Unit,
    onTravel: () -> Unit,
    onResonance: () -> Unit,
    onStartBoss: () -> Unit
) {
    val def = row.def
    GlassCard(Modifier.fillMaxWidth(), tint = def.tintColor, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(def.name, color = Neon.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text(if (row.current) "ATUAL" else if (row.unlocked) "ABERTA" else "SELADA", color = def.tintColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        when {
            !row.unlocked -> {
                Text("Requisito: ${f(row.unlockRequirement)} de energia total", color = Neon.Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Button(
                    onClick = onUnlock, enabled = row.canUnlock, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = def.tintColor.copy(alpha = 0.82f), contentColor = Neon.Bg)
                ) { Text(if (row.canUnlock) "Desbloquear dimensão" else "Continue produzindo", fontWeight = FontWeight.Bold) }
            }
            else -> {
                Text("Produção local ×${"%.2f".format(def.productionMultiplier * (1.0 + row.resonance * 0.15))}", color = def.tintColor, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp))
                Text("Fragmentos: ${row.shards} · Ressonância ${row.resonance}", color = Neon.TextSecondary, fontSize = 12.sp)
                if (row.current) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onResonance, enabled = row.shards >= row.resonanceCost, modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Neon.Violet.copy(alpha = 0.75f), contentColor = Neon.Bg)
                        ) { Text("Ressonar · ${row.resonanceCost} ◇", fontSize = 11.sp) }
                        Button(
                            onClick = onStartBoss, enabled = !bossActive, modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Neon.Pink.copy(alpha = 0.78f), contentColor = Neon.Bg)
                        ) { Text(if (bossActive) "Chefe ativo" else "Invocar chefe", fontSize = 11.sp) }
                    }
                    Text("${def.bossName}: ${f(def.bossHealth)} vida base · +${def.shardReward} fragmento(s)", color = Neon.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
                } else {
                    Button(
                        onClick = onTravel, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = def.tintColor.copy(alpha = 0.82f), contentColor = Neon.Bg)
                    ) { Text("Viajar para ${def.name}", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun CrystalCard(crystal: CrystalUi, f: (com.infinityclicker.core.BigNum) -> String, alpha: Float, onEquip: (Int) -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), tint = crystal.def.tintColor, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(crystal.def.name, color = Neon.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(crystal.def.detail, color = crystal.def.tintColor, fontSize = 12.sp)
                if (!crystal.unlocked) Text("Desbloqueia em ${f(crystal.def.unlockAt)} de energia total", color = Neon.TextSecondary, fontSize = 11.sp)
            }
            if (crystal.unlocked) {
                Button(
                    onClick = { onEquip(crystal.def.id) }, enabled = !crystal.equipped,
                    colors = ButtonDefaults.buttonColors(containerColor = crystal.def.tintColor.copy(alpha = 0.82f), contentColor = Neon.Bg)
                ) { Text(if (crystal.equipped) "Equipado" else "Equipar", fontSize = 11.sp) }
            }
        }
    }
}
