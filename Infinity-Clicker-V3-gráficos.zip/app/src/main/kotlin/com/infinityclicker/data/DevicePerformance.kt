package com.infinityclicker.data

import android.app.ActivityManager
import android.content.Context

/**
 * Escolhe um ponto de partida seguro para os gráficos sem depender de modelo, marca ou uma lista que envelhece.
 * RAM disponível ao app e núcleos do processador são os sinais que o Android expõe de forma estável. Se algum
 * serviço não estiver acessível, a decisão é deliberadamente Ultra: o jogador pediu o máximo como padrão.
 */
object DevicePerformance {
    fun recommendedGraphicsQuality(context: Context): GraphicsQuality {
        return try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                ?: return GraphicsQuality.ULTRA
            if (manager.isLowRamDevice) return GraphicsQuality.LOW

            val memoryClassMb = manager.memoryClass
            val cores = Runtime.getRuntime().availableProcessors()
            when {
                memoryClassMb >= 256 && cores >= 6 -> GraphicsQuality.ULTRA
                memoryClassMb >= 192 && cores >= 4 -> GraphicsQuality.HIGH
                memoryClassMb >= 128 && cores >= 4 -> GraphicsQuality.MEDIUM
                else -> GraphicsQuality.LOW
            }
        } catch (_: Exception) {
            // Não adivinha um perfil econômico quando não há dados: o padrão solicitado é visual máximo.
            GraphicsQuality.ULTRA
        }
    }
}
