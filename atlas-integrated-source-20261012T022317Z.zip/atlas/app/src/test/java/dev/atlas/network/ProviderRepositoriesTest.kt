package dev.atlas.network

import dev.atlas.core.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.Call
import okhttp3.EventListener
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** All responses are supplied by a test interceptor; no provider or network is contacted. */
class ProviderRepositoriesTest {
    private val origin = Coordinate(52.5, 13.4)
    private val destination = Coordinate(52.6, 13.5)
    private val osrm = "https://router.example.org/"
    private val ors = "https://api.example.org/openrouteservice/"

    @Test fun onlyCarIsEnabledWithoutOrsKey() = runBlocking {
        val repository = RealRoutingRepository(OkHttpClient(), osrm, ors, "")
        assertEquals(setOf(TransportMode.CAR), repository.supportedModes)
        val failure = runCatching { repository.routes(listOf(origin, destination), TransportMode.WALK) }.exceptionOrNull() as AppException
        assertEquals(ErrorKind.MISSING_KEY, failure.kind)
    }

    @Test fun configuredOrsEnablesRealFootAndBikeProfiles() {
        val repository = RealRoutingRepository(OkHttpClient(), osrm, ors, "test-only-token")
        assertEquals(TransportMode.entries.toSet(), repository.supportedModes)
    }

    @Test fun invalidStopsAreRejectedBeforeNetwork() = runBlocking {
        val repository = RealRoutingRepository(OkHttpClient(), osrm, ors, "")
        listOf(listOf(origin), listOf(origin, origin), List(9) { if (it % 2 == 0) origin else destination }).forEach { points ->
            val failure = runCatching { repository.routes(points, TransportMode.CAR) }.exceptionOrNull() as AppException
            assertEquals(ErrorKind.INVALID_INPUT, failure.kind)
        }
    }

    @Test fun searchEscapesQueryAndBiasAndCachesSuccessfulResponse() = runBlocking {
        var count = 0
        lateinit var captured: Request
        val client = client { request -> count++; captured = request; 200 to """{"features":[]}""" }
        val repository = RealPlacesRepository(client, "https://photon.example.org/", "https://overpass.example.org/api/interpreter")
        assertTrue(repository.search("x", origin).isEmpty())
        assertEquals(0, count)
        repository.search("Rua A & café", origin)
        repository.search("Rua A & café", origin)
        assertEquals(1, count)
        assertEquals("/api/", captured.url.encodedPath)
        assertEquals("Rua A & café", captured.url.queryParameter("q"))
        assertEquals("12", captured.url.queryParameter("limit"))
        assertEquals("52.5", captured.url.queryParameter("lat"))
        assertEquals("13.4", captured.url.queryParameter("lon"))
        assertNotNull(captured.header("User-Agent"))
    }

    @Test fun routingSendsAllWaypointsAndRequestsGeometryAndAlternatives() = runBlocking {
        lateinit var request: Request
        val repository = RealRoutingRepository(client { request = it; 200 to ProviderParsersTest.OSRM }, osrm, ors, "")
        val points = listOf(origin, Coordinate(52.55, 13.45), destination)
        val routes = repository.routes(points, TransportMode.CAR)
        assertEquals(points, routes.single().waypoints)
        assertTrue(request.url.encodedPath.contains("13.4,52.5;13.45,52.55;13.5,52.6"))
        assertEquals("geojson", request.url.queryParameter("geometries"))
        assertEquals("true", request.url.queryParameter("alternatives"))
        assertEquals("true", request.url.queryParameter("steps"))
    }

    @Test fun orsAuthUsesHeaderAndPreservesConfiguredBasePath() = runBlocking {
        lateinit var request: Request
        val repository = RealRoutingRepository(client { request = it; 404 to """{"error":{"code":2009}}""" }, osrm, ors, "test-only-token")
        val failure = runCatching { repository.routes(listOf(origin, destination), TransportMode.BIKE) }.exceptionOrNull() as AppException
        assertEquals(ErrorKind.NO_ROUTE, failure.kind)
        assertEquals("/openrouteservice/v2/directions/cycling-regular/geojson", request.url.encodedPath)
        assertEquals("test-only-token", request.header("Authorization"))
        assertFalse(request.url.toString().contains("test-only-token"))
        val buffer = okio.Buffer()
        request.body!!.writeTo(buffer)
        val body = JSONObject(buffer.readUtf8())
        assertEquals("pt", body.getString("language"))
        assertEquals(13.4, body.getJSONArray("coordinates").getJSONArray(0).getDouble(0), 0.0)
    }

    @Test fun rateLimitAndCredentialsProduceActionableErrorTypes() = runBlocking {
        listOf(429 to ErrorKind.RATE_LIMIT, 401 to ErrorKind.MISSING_KEY, 403 to ErrorKind.MISSING_KEY, 503 to ErrorKind.PROVIDER).forEach { (status, expected) ->
            val repository = RealPlacesRepository(client { status to "{}" }, "https://photon.example.org/", "https://overpass.example.org/api/interpreter")
            val failure = runCatching { repository.search("Berlin", null) }.exceptionOrNull() as AppException
            assertEquals(expected, failure.kind)
        }
    }

    @Test fun malformedResponseIsProviderFailure() = runBlocking {
        val repository = RealPlacesRepository(client { 200 to "not json" }, "https://photon.example.org/", "https://overpass.example.org/api/interpreter")
        val failure = runCatching { repository.search("Berlin", null) }.exceptionOrNull() as AppException
        assertEquals(ErrorKind.PROVIDER, failure.kind)
    }

    @Test fun untrustedPlaceIdentityCannotInjectOverpassQuery() = runBlocking {
        var calls = 0
        val repository = RealPlacesRepository(client { calls++; 200 to "{}" }, "https://photon.example.org/", "https://overpass.example.org/api/interpreter")
        val place = Place("node:12);out;", "External", origin)
        assertEquals(place, repository.details(place))
        assertEquals(0, calls)
    }

    @Test fun cancellationCancelsUnderlyingOkHttpCall() = runBlocking {
        val started = CompletableDeferred<Call>()
        val release = CountDownLatch(1)
        val client = client { release.await(5, TimeUnit.SECONDS); 200 to """{"features":[]}""" }
            .newBuilder().eventListener(object : EventListener() {
                override fun callStart(call: Call) { started.complete(call) }
            }).build()
        val repository = RealPlacesRepository(client, "https://photon.example.org/", "https://overpass.example.org/api/interpreter")
        val job = async(Dispatchers.Default) { repository.search("Berlin", null) }
        try {
            val call = withTimeout(2_000) { started.await() }
            job.cancelAndJoin()
            assertTrue(call.isCanceled())
        } finally { release.countDown() }
    }

    @Test fun cacheHasTtlStaleLimitAndLruBound() {
        var time = 0L
        val cache = ProviderCache<String>(2, 1_000) { time }
        cache.put("a", "A"); cache.put("b", "B")
        assertEquals("A", cache.get("a"))
        cache.put("c", "C")
        assertNull(cache.get("b"))
        time = 1_001_000_000
        assertNull(cache.get("a"))
        assertEquals("A", cache.get("a", allowStale = true))
        time = 86_400_001_000_000
        assertNull(cache.get("a", allowStale = true))
    }

    @Test fun providerUrlsMustBeHttpsWithoutEmbeddedCredentials() {
        listOf("http://example.org/", "https://user:password@example.org/", "https://example.org/?key=secret", "file:///tmp/data", "not a url").forEach { raw ->
            assertEquals(ErrorKind.INVALID_INPUT, assertThrows(AppException::class.java) { validatedBaseUrl(raw) }.kind)
        }
        assertEquals("https://example.org/prefix/", validatedBaseUrl("https://example.org/prefix").toString())
    }

    private fun client(respond: (Request) -> Pair<Int, String>): OkHttpClient = OkHttpClient.Builder().addInterceptor { chain ->
        val (code, body) = respond(chain.request())
        Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(code).message("test")
            .body(body.toResponseBody("application/json".toMediaType())).build()
    }.build()
}
