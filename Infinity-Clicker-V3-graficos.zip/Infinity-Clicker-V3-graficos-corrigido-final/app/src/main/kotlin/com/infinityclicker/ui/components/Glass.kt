package com.infinityclicker.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawOutline
import androidx.compose.ui.unit.dp

/**
 * Vidro líquido de baixo custo. A versão anterior usava `shadow(14.dp)` com cor própria em cada painel:
 * em superfícies translúcidas a sombra é recortada e redesenhada fora da forma, o que custava caro na
 * GPU do Galaxy A54 e era a principal causa de travadas na rolagem de listas com muitos cartões.
 *
 * Agora cada painel desenha, uma vez por tamanho (drawWithCache), só gradientes simples:
 * corpo translúcido, halo de cor na borda de baixo (no lugar da sombra), brilho especular no topo
 * e borda com refração. Nenhum blur, nenhuma sombra de elevação.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    borderAlpha: Float = 0.38f
): Modifier = this
    .clip(shape)
    .drawWithCache {
        val outline = shape.createOutline(size, layoutDirection, this)
        val body = Brush.linearGradient(
            0f to Color.White.copy(alpha = (alpha * 0.32f + 0.05f).coerceAtMost(0.20f)),
            0.24f to tint.copy(alpha = (alpha + 0.10f).coerceAtMost(0.42f)),
            0.66f to tint.copy(alpha = (alpha * 0.46f).coerceAtMost(0.25f)),
            1f to Color(0xFF050616).copy(alpha = (alpha * 0.72f).coerceAtLeast(0.05f))
        )
        // Brilho especular: faixa clara que some em ~45% da altura, como luz sobre vidro curvo.
        val sheen = Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.13f),
            0.45f to Color.Transparent
        )
        val glow = Brush.verticalGradient(
            0.62f to Color.Transparent,
            1f to tint.copy(alpha = (alpha * 0.9f).coerceIn(0.03f, 0.22f))
        )
        val border = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = borderAlpha.coerceIn(0f, 0.9f)),
                Color.White.copy(alpha = 0.05f),
                tint.copy(alpha = (borderAlpha * 0.74f).coerceIn(0f, 0.8f))
            )
        )
        val stroke = Stroke(1.2.dp.toPx())
        onDrawBehind {
            drawOutline(outline, body)
            drawOutline(outline, glow)
            drawOutline(outline, sheen)
            drawOutline(outline, border, style = stroke)
        }
    }

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier.glass(tint = tint, alpha = alpha).padding(14.dp),
        content = content
    )
}
