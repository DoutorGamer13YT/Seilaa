package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.data.StateSerializer
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.Formulas
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import com.infinityclicker.upgrades.UpgradeIds
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class GameEngineTest {

    private fun engine(seed: Int = 1, setup: (GameState) -> Unit = {}): GameEngine {
        val s = GameState.new()
        setup(s)
        return GameEngine(s, Random(seed))
    }

    // ------------------------------------------------------------------ cliques

    @Test
    fun everyTapIsCountedAndPaysEnergy() {
        val e = engine()
        var t = 0L
        repeat(1000) { e.tap(t); t += 5 } // 200 toques/s: nenhum pode se perder
        assertEquals(1000L, e.state.totalClicks)
        assertTrue(e.state.energy > BigNum.ZERO)
        assertEquals(e.state.energy, e.state.totalEnergy)
    }

    @Test
    fun comboBuildsInsideWindowAndResetsOutside() {
        val e = engine()
        e.tap(0); e.tap(300); e.tap(600)
        assertEquals(3, e.comboCount)
        assertEquals(1.04, e.comboMultiplier(), 1e-9)
        e.tap(600 + Formulas.COMBO_WINDOW_MS + 1)
        assertEquals(1, e.comboCount)
        assertEquals(1.0, e.comboMultiplier(), 1e-9)
    }

    @Test
    fun comboIsCappedAndDecays() {
        val e = engine()
        var t = 0L
        repeat(200) { e.tap(t); t += 50 }
        val lastTap = t - 50
        assertEquals(Formulas.BASE_COMBO_MAX, e.comboCount)
        e.decayCombo(lastTap + Formulas.COMBO_WINDOW_MS - 1)
        assertEquals(Formulas.BASE_COMBO_MAX, e.comboCount)
        e.decayCombo(lastTap + Formulas.COMBO_WINDOW_MS + 1)
        assertEquals(0, e.comboCount)
    }

    @Test
    fun critRateMatchesChanceStatistically() {
        val e = engine(seed = 7)
        var t = 0L
        val n = 20_000
        repeat(n) { e.tap(t); t += 2_000 } // sem combo
        val rate = e.state.critClicks.toDouble() / n
        assertEquals(Formulas.BASE_CRIT_CHANCE, rate, 0.01)
    }

    @Test
    fun critPaysMoreThanNormalClick() {
        val e = engine(seed = 3)
        var t = 0L
        var sawCrit = false
        repeat(500) {
            val r = e.tap(t); t += 2_000
            val expected = e.baseClickGain() * (if (r.crit) e.critMultiplier else 1.0)
            val ratio = (r.gain / expected).toDouble()
            assertEquals(1.0, ratio, 1e-9)
            if (r.crit) sawCrit = true
        }
        assertTrue(sawCrit)
    }

    // ------------------------------------------------------------------ geradores

    @Test
    fun generatorProductionAndAdvance() {
        val e = engine { it.energy = BigNum.of(1000.0); it.totalEnergy = BigNum.of(1000.0) }
        assertTrue(e.buyGenerator(0, BuyMode.X1))
        assertEquals(1L, e.state.generators[0])
        val ps = e.production.toDouble()
        assertEquals(GeneratorDefs.byId(0).baseProduction.toDouble(), ps, 1e-9)
        val before = e.state.energy
        e.advance(2_000)
        val gained = (e.state.energy - before).toDouble()
        assertEquals(ps * 2.0, gained, 1e-6)
    }

    @Test
    fun cannotBuyWhatYouCannotAffordOrHaveNotUnlocked() {
        val e = engine()
        assertFalse(e.buyGenerator(0, BuyMode.X1))
        val rich = engine { it.energy = BigNum.of(1e30) }
        assertFalse("gerador 5 exige possuir o 4", rich.buyGenerator(5, BuyMode.X1))
        assertEquals(0L, rich.state.generators[5])
    }

    @Test
    fun buyModesChargeExactlyThePlannedCost() {
        for (mode in listOf(BuyMode.X1, BuyMode.X10, BuyMode.X100, BuyMode.MAX)) {
            val e = engine { it.energy = BigNum.of(1e9) }
            val def = GeneratorDefs.byId(0)
            val plan = e.planGenerator(def, mode)
            assertTrue(plan.affordable)
            val before = e.state.energy
            assertTrue(e.buyGenerator(0, mode))
            assertEquals(plan.count, e.state.generators[0])
            val spent = (before - e.state.energy)
            val ratio = (spent / plan.cost).toDouble()
            assertEquals("modo $mode", 1.0, ratio, 1e-6)
        }
    }

    @Test
    fun maxBuysTheMostPossible() {
        val e = engine { it.energy = BigNum.of(1e7) }
        assertTrue(e.buyGenerator(0, BuyMode.MAX))
        val owned = e.state.generators[0]
        val def = GeneratorDefs.byId(0)
        assertTrue("sobrou o bastante para mais um", e.state.energy < Formulas.unitCost(def.baseCost, def.growth, owned))
    }

    @Test
    fun milestoneBoostsProduction() {
        val e = engine { it.generators[0] = 24L }
        val before = e.production.toDouble()
        e.state.generators[0] = 25L
        e.recompute()
        val after = e.production.toDouble()
        assertEquals(before / 24.0 * 25.0 * 2.0, after, after * 1e-9)
    }

    // ------------------------------------------------------------------ melhorias

    @Test
    fun upgradeLockedUntilRequirementMet() {
        val e = engine { it.energy = BigNum.of(1e6) }
        assertFalse(e.buyUpgrade(UpgradeIds.CRIT_CHANCE, BuyMode.X1)) // exige 500 de energia total
        e.state.totalEnergy = BigNum.of(500.0)
        assertTrue(e.buyUpgrade(UpgradeIds.CRIT_CHANCE, BuyMode.X1))
        assertEquals(1, e.state.level(UpgradeIds.CRIT_CHANCE))
        assertEquals(0.04, e.critChance, 1e-9)
    }

    @Test
    fun upgradesRespectMaxLevel() {
        val def = UpgradeDefs.byId.getValue(UpgradeIds.OFFLINE_EFF)
        val e = engine { it.energy = BigNum.of(1e60); it.totalEnergy = BigNum.of(1e60) }
        assertTrue(e.buyUpgrade(def.id, BuyMode.MAX))
        assertEquals(def.maxLevel, e.state.level(def.id))
        assertFalse(e.buyUpgrade(def.id, BuyMode.X1))
        assertEquals(1.0, e.offlineEfficiency, 1e-9)
    }

    @Test
    fun multipliersAndClickUpgradesAffectEconomy() {
        val e = engine {
            it.energy = BigNum.of(1e12); it.totalEnergy = BigNum.of(1e12); it.generators[0] = 10
        }
        val ps0 = e.production
        assertTrue(e.buyUpgrade(UpgradeIds.MULT_GLOBAL_1, BuyMode.X1))
        assertEquals(1.25, (e.production / ps0).toDouble(), 1e-9)
        assertTrue(e.buyUpgrade(UpgradeIds.generator(0), BuyMode.X1))
        assertEquals(1.25 * 2.0, (e.production / ps0).toDouble(), 1e-9)

        val click0 = e.clickBase
        assertTrue(e.buyUpgrade(UpgradeIds.CLICK_POWER, BuyMode.X1))
        assertTrue(e.clickBase > click0)
        val click1 = e.clickBase
        assertTrue(e.buyUpgrade(UpgradeIds.CLICK_MULT, BuyMode.X1))
        assertEquals(2.0, (e.clickBase / click1).toDouble(), 1e-9)
    }

    // ------------------------------------------------------------------ offline

    @Test
    fun offlineGivesHalfProductionAndNeverDuplicates() {
        val t0 = 1_000_000_000L
        val e = engine { it.generators[0] = 10; it.lastSessionMs = t0 }
        val ps = e.production.toDouble()
        val now = t0 + 3_600_000L // 1 hora
        val report = e.applyOffline(now)
        assertNotNull(report)
        assertEquals(3_600_000L, report!!.creditedMs)
        assertEquals(ps * 3600.0 * 0.5, report.gain.toDouble(), ps * 3600.0 * 1e-9)
        val energyAfter = e.state.energy
        // reabrir "no mesmo instante" não paga de novo
        assertNull(e.applyOffline(now))
        assertEquals(energyAfter, e.state.energy)
    }

    @Test
    fun offlineIsCappedAtEightHours() {
        val t0 = 1_000_000_000L
        val e = engine { it.generators[0] = 10; it.lastSessionMs = t0 }
        val report = e.applyOffline(t0 + 100L * 3_600_000L)!!
        assertEquals(8 * 3_600_000L, report.creditedMs)
        assertEquals(100L * 3_600_000L, report.elapsedMs)
    }

    @Test
    fun offlineCapGrowsWithUpgrade() {
        val t0 = 1_000_000_000L
        val e = engine {
            it.generators[0] = 10; it.lastSessionMs = t0
            it.energy = BigNum.of(1e9); it.totalEnergy = BigNum.of(1e9)
        }
        assertTrue(e.buyUpgrade(UpgradeIds.OFFLINE_CAP, BuyMode.X1))
        val report = e.applyOffline(t0 + 100L * 3_600_000L)!!
        assertEquals(10 * 3_600_000L, report.creditedMs)
    }

    @Test
    fun offlineIgnoresRewoundClockAndNewGames() {
        val e = engine { it.generators[0] = 10; it.lastSessionMs = 5_000_000L }
        val before = e.state.energy
        assertNull(e.applyOffline(1_000_000L)) // relógio voltou no tempo
        assertEquals(before, e.state.energy)
        // 3.8: a marca antiga é mantida, senão voltar e avançar a hora pagaria o offline de novo.
        assertEquals(5_000_000L, e.state.lastSessionMs)

        val fresh = engine()
        assertNull(fresh.applyOffline(123_456_789L)) // jogo novo: nada a pagar
        assertEquals(123_456_789L, fresh.state.lastSessionMs)
    }

    // ------------------------------------------------------------------ guia inicial

    @Test
    fun tutorialAdvancesOnlyInTheOrderItExplains() {
        val e = engine { it.energy = BigNum.of(1e9); it.totalEnergy = BigNum.of(1e9) }

        // Usar uma habilidade cedo não pode esconder toque e produção automática.
        assertTrue(e.useAbility(AbilityDefs.SUPER_CLICK, 0L).used)
        assertEquals(0, e.state.tutorialStep)

        e.tap(10L, 10L)
        assertEquals(1, e.state.tutorialStep)
        assertTrue(e.buyGenerator(0, BuyMode.X1, 20L))
        assertEquals(2, e.state.tutorialStep)
        assertTrue(e.useAbility(AbilityDefs.COSMIC_BURST, 30L).used)
        assertEquals(3, e.state.tutorialStep)

        e.state.runEnergy = Formulas.PRESTIGE_MIN_RUN_ENERGY
        assertNotNull(e.prestige(40L))
        assertEquals(4, e.state.tutorialStep)
    }

    @Test
    fun tutorialCanBeRestartedWithoutChangingTheRun() {
        val e = engine {
            it.tutorialStep = 4
            it.energy = BigNum.of(12345)
            it.totalEnergy = BigNum.of(67890)
            it.generators[0] = 7
        }

        assertTrue(e.restartTutorial())
        assertEquals(0, e.state.tutorialStep)
        assertEquals(BigNum.of(12345), e.state.energy)
        assertEquals(BigNum.of(67890), e.state.totalEnergy)
        assertEquals(7L, e.state.generators[0])
        assertFalse(e.restartTutorial())
    }

    // ------------------------------------------------------------------ salvamento

    @Test
    fun saveRoundTripKeepsEverything() {
        val e = engine { it.energy = BigNum.of(5e8); it.totalEnergy = BigNum.of(9e9) }
        e.buyGenerator(0, BuyMode.X10)
        e.buyGenerator(1, BuyMode.X1)
        e.buyUpgrade(UpgradeIds.CLICK_POWER, BuyMode.X10)
        var t = 0L
        repeat(25) { e.tap(t); t += 100 }
        e.state.lastSessionMs = 1_700_000_000_000L
        e.state.offlineEarned = BigNum.of(1234.5)

        val text = StateSerializer.serialize(e.state)
        val back = StateSerializer.deserialize(text)
        assertNotNull(back)
        back!!
        assertEquals(e.state.energy, back.energy)
        assertEquals(e.state.totalEnergy, back.totalEnergy)
        assertEquals(e.state.offlineEarned, back.offlineEarned)
        assertEquals(e.state.totalClicks, back.totalClicks)
        assertEquals(e.state.critClicks, back.critClicks)
        assertEquals(e.state.maxCombo, back.maxCombo)
        assertEquals(e.state.generatorsBought, back.generatorsBought)
        assertEquals(e.state.lastSessionMs, back.lastSessionMs)
        assertEquals(e.state.generators.toList(), back.generators.toList())
        assertEquals(e.state.upgradeLevels, back.upgradeLevels)
        // o motor reconstruído a partir do save produz a mesma economia
        assertEquals(e.production, GameEngine(back).production)
    }

    @Test
    fun corruptedOrTamperedSavesAreRejected() {
        val e = engine { it.energy = BigNum.of(100.0) }
        val good = StateSerializer.serialize(e.state)
        assertNotNull(StateSerializer.deserialize(good))
        assertNull(StateSerializer.deserialize(""))
        assertNull(StateSerializer.deserialize("lixo"))
        assertNull(StateSerializer.deserialize(good.dropLast(3)))                  // truncado
        assertNull(StateSerializer.deserialize(good.replace("energy=1.0", "energy=9.0"))) // editado
        assertNull(StateSerializer.deserialize(good.replace("v=${StateSerializer.VERSION}", "v=99"))) // versão futura (crc quebra)
    }

    @Test
    fun loadSanitizesOutOfRangeValues() {
        val s = GameState.new()
        s.generators[0] = 5
        s.upgradeLevels[UpgradeIds.CRIT_CHANCE] = 3
        val text = StateSerializer.serialize(s)
        val back = StateSerializer.deserialize(text)!!
        assertEquals(5L, back.generators[0])
        assertEquals(3, back.level(UpgradeIds.CRIT_CHANCE))
        assertEquals(0, back.level("id_que_nao_existe"))
    }
}
