package dev.atlas.core

import kotlin.math.*

data class Coordinate(val latitude: Double, val longitude: Double) {
    init { require(latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0) }
    fun distanceTo(other: Coordinate): Double {
        val dLat = Math.toRadians(other.latitude - latitude)
        val dLon = Math.toRadians(other.longitude - longitude)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(latitude)) * cos(Math.toRadians(other.latitude)) * sin(dLon / 2).pow(2)
        return 6371008.8 * 2 * atan2(sqrt(a.coerceIn(0.0, 1.0)), sqrt((1 - a).coerceIn(0.0, 1.0)))
    }
}

data class Place(
    val id: String, val name: String, val coordinate: Coordinate,
    val address: String = "", val category: String = "Lugar",
    val phone: String? = null, val website: String? = null,
    val openingHours: String? = null, val source: String = "OpenStreetMap",
)
enum class TransportMode(val label: String) { CAR("Carro"), WALK("A pé"), BIKE("Bicicleta") }
data class RouteStep(val instruction: String, val street: String, val distanceMeters: Double,
    val durationSeconds: Double, val coordinate: Coordinate, val maneuver: String = "straight")
data class Route(val id: String, val geometry: List<Coordinate>, val distanceMeters: Double,
    val durationSeconds: Double, val steps: List<RouteStep>, val mode: TransportMode,
    val source: String, val summary: String = "", val waypoints: List<Coordinate> = emptyList())
data class LocationFix(val coordinate: Coordinate, val accuracyMeters: Float, val bearing: Float?,
    val speedMetersPerSecond: Float?, val timestampMillis: Long)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class Units { METRIC, IMPERIAL }
data class AppSettings(val theme: ThemeMode = ThemeMode.SYSTEM, val units: Units = Units.METRIC,
    val voice: Boolean = true, val reduceMotion: Boolean = false, val haptics: Boolean = true)
data class SavedList(val id: Long, val name: String, val position: Int)
data class SavedPlace(val place: Place, val listIds: List<Long> = emptyList(), val savedAt: Long = 0L)
data class SearchHistory(val query: String, val timestampMillis: Long)
data class Shortcut(val kind: String, val place: Place)
enum class ErrorKind { NETWORK, RATE_LIMIT, MISSING_KEY, NO_RESULTS, NO_ROUTE, PROVIDER, INVALID_INPUT, STORAGE }
class AppException(val kind: ErrorKind, override val message: String, cause: Throwable? = null) : Exception(message, cause)

interface PlacesRepository {
    suspend fun search(query: String, center: Coordinate?): List<Place>
    suspend fun nearby(category: PlaceCategory, center: Coordinate): List<Place>
    suspend fun details(place: Place): Place
}
interface RoutingRepository {
    val supportedModes: Set<TransportMode>
    suspend fun routes(points: List<Coordinate>, mode: TransportMode): List<Route>
}
