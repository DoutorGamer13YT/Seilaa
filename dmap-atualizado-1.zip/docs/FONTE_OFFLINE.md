# Fonte offline atual

A fonte principal dos novos pacotes é Protomaps Basemaps, com dados OSM sob ODbL. Siga `DISTRIBUICAO_PROTOMAPS.md` para preparar e publicar regiões PMTiles, fontes, sprites e estilos em distribuição própria HTTPS.

O app não usa builds diários como endpoint permanente nem baixa tiles da Apple ou dos servidores comunitários OSM. Não existe URL regional padrão configurada nesta entrega.

A configuração de estilos autorizados da versão anterior foi mantida como opção avançada, assim como `server/serve_mbtiles.py`. Ela é independente dos pacotes PMTiles e não é necessária para a nova distribuição Protomaps. O operador continua responsável pelas licenças de qualquer fonte alternativa.
