package com.infinityclicker.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Efeitos do jogo. Todos são sintetizados no próprio app: não há arquivos de áudio nem internet. */
enum class Sfx { TAP, CRIT, BUY, ERROR, ABILITY, CLAIM, UNLOCK, BOSS_START, BOSS_DOWN, PRESTIGE, NAV }

/**
 * Sons sintetizados + trilha ambiente em loop, tocados por um SoundPool (vários sons ao mesmo tempo,
 * baixa latência — importante para toques rápidos). Os WAVs são gerados uma vez no cache do app,
 * em segundo plano, então a abertura do app não espera a síntese.
 */
object SoundFx {
    @Volatile private var sfxEnabled = true
    @Volatile private var musicEnabled = true
    @Volatile private var foreground = false

    private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<Sfx, Int>()
    private val loaded: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    private var musicId = 0
    private var musicStream = 0
    private var lastTapMs = 0L

    /** Idempotente: pode ser chamado a cada onStart. */
    @Synchronized
    fun init(context: Context) {
        if (pool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        sp.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) {
                loaded += id
                if (id == musicId) syncMusic()
            }
        }
        pool = sp
        val dir = File(context.applicationContext.cacheDir, "sfx").apply { mkdirs() }
        Thread({
            runCatching {
                for (sfx in Sfx.entries) {
                    val file = File(dir, "${sfx.name.lowercase()}.wav")
                    writeWav(file, Synth.render(sfx))
                    ids[sfx] = sp.load(file.absolutePath, 1)
                }
                val music = File(dir, "ambient.wav")
                writeWav(music, Synth.ambientLoop())
                musicId = sp.load(music.absolutePath, 1)
            }
        }, "sfx-synth").apply { isDaemon = true; start() }
    }

    fun configure(sfx: Boolean, music: Boolean) {
        sfxEnabled = sfx
        musicEnabled = music
        syncMusic()
    }

    fun setForeground(value: Boolean) {
        foreground = value
        syncMusic()
    }

    fun play(sfx: Sfx, rate: Float = 1f, volume: Float = 1f) {
        if (!sfxEnabled) return
        val sp = pool ?: return
        val id = ids[sfx] ?: return
        if (id !in loaded) return
        if (sfx == Sfx.TAP) { // evita "metralhadora" em autoclickers
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastTapMs < 28L) return
            lastTapMs = now
        }
        val v = volume.coerceIn(0f, 1f)
        sp.play(id, v, v, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    @Synchronized
    private fun syncMusic() {
        val sp = pool ?: return
        val want = musicEnabled && foreground && musicId != 0 && musicId in loaded
        if (want && musicStream == 0) {
            musicStream = sp.play(musicId, MUSIC_VOLUME, MUSIC_VOLUME, 0, -1, 1f)
        } else if (!want && musicStream != 0) {
            sp.stop(musicStream)
            musicStream = 0
        }
    }

    private const val MUSIC_VOLUME = 0.22f
    private const val SR = 22050

    private fun writeWav(file: File, pcm: ShortArray) {
        val data = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        pcm.forEach { data.putShort(it) }
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size * 2).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size * 2)
        file.outputStream().use { it.write(header.array()); it.write(data.array()) }
    }

    /** Osciladores simples somados com envelopes: o bastante para um som "cristalino" de jogo. */
    private object Synth {
        private const val TAU = (2.0 * PI).toFloat()

        private fun build(durMs: Int, gain: Float = 0.9f, gen: (t: Float, p: Float) -> Float): ShortArray {
            val n = SR * durMs / 1000
            val raw = FloatArray(n) { i -> gen(i / SR.toFloat(), i / n.toFloat()) }
            val peak = max(0.0001f, raw.maxOf { abs(it) })
            return ShortArray(n) { i ->
                // Fade curto nas pontas elimina estalos.
                val edge = min(1f, min(i, n - 1 - i) / 90f)
                (raw[i] / peak * gain * edge * Short.MAX_VALUE).toInt().toShort()
            }
        }

        private fun sine(f: Float, t: Float) = sin(TAU * f * t)
        private fun chirp(f0: Float, f1: Float, t: Float, total: Float) = sin(TAU * (f0 * t + (f1 - f0) * t * t / (2f * total)))
        private fun decay(p: Float, k: Float) = exp(-p * k)

        /** Sequência de notas: cada nota tem frequência e duração (s); sino com 2º harmônico. */
        private fun notes(freqs: List<Float>, noteSec: Float, lastSec: Float = noteSec, tail: Float = 9f, durMs: Int): ShortArray =
            build(durMs) { t, _ ->
                val idx = floor(t / noteSec).toInt().coerceAtMost(freqs.lastIndex)
                val start = idx * noteSec
                val local = (t - start) / (if (idx == freqs.lastIndex) lastSec else noteSec)
                val f = freqs[idx]
                (sine(f, t) + 0.35f * sine(f * 2f, t) + 0.12f * sine(f * 3f, t)) * decay(local, tail / 3f) * min(1f, (t - start) * 400f)
            }

        fun render(sfx: Sfx): ShortArray = when (sfx) {
            Sfx.TAP -> build(120, 0.8f) { t, p ->
                (0.8f * chirp(640f, 940f, t, 0.12f) + 0.25f * chirp(1280f, 1880f, t, 0.12f)) * decay(p, 7f) * min(1f, t * 700f)
            }
            Sfx.CRIT -> build(360, 0.9f) { t, p ->
                val env = decay(p, 3.6f) * min(1f, t * 600f)
                val second = if (t > 0.05f) 0.8f * sine(1760f, t) else 0f
                (sine(1318f, t) + second + 0.35f * sine(2637f, t)) * env
            }
            Sfx.BUY -> notes(listOf(523f, 659f, 784f), 0.085f, 0.2f, 9f, 330)
            Sfx.ERROR -> build(170, 0.55f) { t, p ->
                val f = 190f - 50f * p
                (sine(f, t) + 0.4f * sine(f * 3f, t)) * (if (p < 0.5f) 1f else 0.8f) * decay(p, 3f)
            }
            Sfx.ABILITY -> build(520, 0.85f) { t, p ->
                val vib = 1f + 0.03f * sin(TAU * 18f * t)
                val env = sin(PI.toFloat() * p) * (1f - 0.35f * p)
                (chirp(240f, 1500f, t, 0.52f) * vib + 0.3f * chirp(480f, 3000f, t, 0.52f)) * env
            }
            Sfx.CLAIM -> notes(listOf(659f, 784f, 988f, 1318f), 0.075f, 0.28f, 9f, 560)
            Sfx.UNLOCK -> build(420, 0.85f) { t, p ->
                (chirp(380f, 820f, t, 0.42f) + 0.6f * chirp(570f, 1230f, t, 0.42f) + 0.2f * sine(1640f, t)) * decay(p, 3.2f) * min(1f, t * 500f)
            }
            Sfx.BOSS_START -> build(780, 0.95f) { t, p ->
                val f = 150f - 80f * p
                val pulse = 0.75f + 0.25f * sin(TAU * 7f * t)
                (sine(f, t) + 0.5f * sine(f * 2f, t) + 0.3f * sine(f * 3f, t) + 0.18f * chirp(900f, 180f, t, 0.78f)) * pulse * decay(p, 1.8f) * min(1f, t * 300f)
            }
            Sfx.BOSS_DOWN -> notes(listOf(523f, 659f, 784f, 1047f, 1319f), 0.11f, 0.5f, 9f, 940)
            Sfx.PRESTIGE -> build(1500, 0.95f) { t, p ->
                val sweep = chirp(180f, 2600f, t, 1.5f)
                val sh = 0.35f * sine(1760f, t) * sin(TAU * 6f * t) + 0.3f * sine(2217f, t) * sin(TAU * 4.5f * t)
                (sweep * 0.8f + sh) * (if (p < 0.6f) p / 0.6f else decay((p - 0.6f) / 0.4f, 4f))
            }
            Sfx.NAV -> build(40, 0.5f) { t, p -> sine(1100f, t) * decay(p, 9f) }
        }

        /**
         * Pad ambiente de 8 s. Todas as frequências têm número inteiro de ciclos por segundo e as
         * modulações têm períodos que dividem 8 s, então o fim encaixa no começo sem emenda audível.
         */
        fun ambientLoop(): ShortArray = build(8000, 0.8f) { t, _ ->
            val swell = 0.65f + 0.35f * sin(TAU * 0.125f * t)
            val pad = sine(110f, t) + 0.8f * sine(111f, t) + 0.55f * sine(165f, t) + 0.5f * sine(220f, t) +
                0.32f * sine(330f, t) * (0.5f + 0.5f * sin(TAU * 0.25f * t)) + 0.2f * sine(440f, t) * (0.5f + 0.5f * sin(TAU * 0.5f * t + 1f))
            pad * swell
        }
    }
}
