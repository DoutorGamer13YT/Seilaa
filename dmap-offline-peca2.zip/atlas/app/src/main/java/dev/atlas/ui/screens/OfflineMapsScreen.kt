package dev.atlas.ui.screens

import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import dev.atlas.core.Coordinate
import dev.atlas.core.OfflineTiles
import dev.atlas.map.OfflineMapsState
import dev.atlas.map.OfflineRegionInfo
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OfflineMapsScreen(
    state: OfflineMapsState, center: Coordinate, online: Boolean,
    onBack: () -> Unit, onDownload: (Int) -> Unit, onPause: (Long) -> Unit,
    onResume: (Long) -> Unit, onDelete: (Long) -> Unit, onDismissError: () -> Unit,
) {
    var radius by rememberSaveable { mutableIntStateOf(OfflineTiles.radiiKm[1]) }
    var pendingDelete by remember { mutableStateOf<OfflineRegionInfo?>(null) }
    val full = state.regions.size >= OfflineTiles.MAX_REGIONS
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 36.dp),
            modifier = Modifier.fillMaxSize().safeDrawingPadding(), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            item { CollectionHeader("Mapas offline", onBack) }
            state.error?.let { message ->
                item {
                    GlassGroup {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(message, Modifier.weight(1f), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = onDismissError) { Text("Fechar") }
                        }
                    }
                }
            }
            item {
                OfflineSection("Baixar a área do mapa") {
                    OfflineTiles.radiiKm.forEachIndexed { index, km ->
                        val tiles = OfflineTiles.tileCount(OfflineTiles.box(center, km))
                        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
                            .selectable(radius == km, role = Role.RadioButton) { radius = km }
                            .padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Raio de $km km")
                                Text("Cerca de ${String.format(Locale.forLanguageTag("pt-BR"), "%,d", tiles)} blocos de mapa",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            RadioButton(radius == km, onClick = null)
                        }
                        if (index < OfflineTiles.radiiKm.lastIndex) OfflineDivider()
                    }
                    OfflineDivider()
                    val enabled = online && !state.busy && !full
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onDownload(radius) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                            Text(if (state.creating) "Preparando…" else "Baixar área atual")
                        }
                        Text(
                            when {
                                full -> "Limite de ${OfflineTiles.MAX_REGIONS} regiões. Apague uma para baixar outra."
                                !online -> "Conecte-se à internet para baixar mapas."
                                state.busy -> "Aguarde o download atual terminar."
                                else -> "A área é centralizada no ponto que estava no centro do mapa."
                            },
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                OfflineSection("Regiões baixadas") {
                    if (state.regions.isEmpty()) {
                        Text(if (state.loaded) "Nenhuma região baixada." else "Carregando…", Modifier.padding(20.dp),
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    state.regions.forEachIndexed { index, region ->
                        RegionRow(region, online, state.busy, onPause, onResume) { pendingDelete = region }
                        if (index < state.regions.lastIndex) OfflineDivider()
                    }
                }
            }
            item {
                OfflineSection("Sobre o uso offline") {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("O mapa das regiões baixadas é exibido sem conexão. Pesquisa de lugares, detalhes e novas rotas continuam exigindo internet.",
                            style = MaterialTheme.typography.bodyMedium)
                        Text("Os dados vêm do OpenFreeMap e do OpenStreetMap. Os blocos baixados ficam apenas neste aparelho e ocupam armazenamento até você apagar a região.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    pendingDelete?.let { region ->
        AlertDialog(onDismissRequest = { pendingDelete = null }, title = { Text("Apagar região?") },
            text = { Text("“${region.name}” será removida deste aparelho. Você poderá baixá-la novamente com internet.") },
            confirmButton = { TextButton(onClick = { onDelete(region.id); pendingDelete = null }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } })
    }
}

@Composable
private fun RegionRow(
    region: OfflineRegionInfo, online: Boolean, busy: Boolean,
    onPause: (Long) -> Unit, onResume: (Long) -> Unit, onDelete: () -> Unit,
) {
    val context = LocalContext.current
    val size = Formatter.formatShortFileSize(context, region.bytes)
    val date = if (region.createdAt > 0) DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.forLanguageTag("pt-BR")).format(Date(region.createdAt)) else null
    val status = when {
        region.complete -> "Disponível offline · $size"
        region.downloading -> "Baixando… ${(region.progress * 100).toInt()}% · $size"
        else -> "Download incompleto · $size"
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(region.name)
        Text(listOfNotNull(if (region.radiusKm > 0) "Raio de ${region.radiusKm} km" else null, date).joinToString(" · "),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (region.downloading) LinearProgressIndicator(progress = { region.progress }, modifier = Modifier.fillMaxWidth())
        region.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (region.downloading) TextButton(onClick = { onPause(region.id) }) { Text("Pausar") }
            else if (!region.complete) TextButton(onClick = { onResume(region.id) }, enabled = online && !busy) { Text("Continuar") }
            TextButton(onClick = onDelete) { Text("Apagar", color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun OfflineSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        GlassGroup(content = content)
    }
}

@Composable
private fun OfflineDivider() = HorizontalDivider(Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
