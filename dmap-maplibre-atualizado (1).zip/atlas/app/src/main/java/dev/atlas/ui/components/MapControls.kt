package dev.atlas.ui.components

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.MapOrientation
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.AtlasMotion
import dev.atlas.ui.theme.LocalAtlasColors
import dev.atlas.ui.theme.LocalAtlasReduceMotion

@Composable
fun CircularMapButton(
    icon: ImageVector, label: String, onClick: () -> Unit,
    selected: Boolean = false, modifier: Modifier = Modifier, enabled: Boolean = true,
) {
    val colors = LocalAtlasColors.current
    val isSelected = selected
    val background by animateColorAsState(if (selected) colors.accent else colors.glass, tween(if (LocalAtlasReduceMotion.current) 0 else AtlasDimens.ShortAnimationMillis), label = "control background")
    val interaction = remember { MutableInteractionSource() }
    Surface(
        onClick = onClick, enabled = enabled, interactionSource = interaction,
        modifier = modifier.size(AtlasDimens.ControlSize).pressScale(interaction).semantics { this.selected = isSelected },
        shape = CircleShape, color = background,
        contentColor = if (selected) colors.onAccent else colors.accent,
        border = BorderStroke(0.8.dp, colors.glassBorder),
        shadowElevation = AtlasDimens.FloatingElevation,
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = LocalContentColor.current.copy(alpha = if (enabled) 1f else 0.38f), modifier = Modifier.size(AtlasDimens.IconSize))
        }
    }
}

@Composable
fun CompassButton(
    mode: MapOrientation, bearing: () -> Float, onClick: () -> Unit, modifier: Modifier = Modifier,
    description: String? = null,
) {
    val colors = LocalAtlasColors.current
    val following = mode == MapOrientation.COMPASS
    val background by animateColorAsState(if (following) colors.accent else colors.glass, tween(if (LocalAtlasReduceMotion.current) 0 else AtlasDimens.ShortAnimationMillis), label = "compass background")
    val interaction = remember { MutableInteractionSource() }
    val state = description ?: when (mode) {
        MapOrientation.NORTH -> "Norte fixo. Toque para seguir a direção do aparelho."
        MapOrientation.FREE -> "Rotação livre. Toque para voltar ao norte."
        MapOrientation.COMPASS -> "Seguindo a direção do aparelho. Toque para voltar ao norte."
    }
    val needleNorth = if (following) colors.onAccent else Color(0xFFFF453A)
    val needleSouth = if (following) colors.onAccent.copy(alpha = 0.55f) else colors.secondaryText.copy(alpha = 0.7f)
    val letter = if (following) colors.onAccent else colors.text
    Surface(
        onClick = onClick, interactionSource = interaction,
        modifier = modifier.size(AtlasDimens.ControlSize).pressScale(interaction)
            .semantics { contentDescription = "Bússola"; stateDescription = state; role = Role.Button; selected = following },
        shape = CircleShape, color = background,
        border = BorderStroke(0.8.dp, colors.glassBorder),
        shadowElevation = AtlasDimens.FloatingElevation,
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = -bearing() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(22.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f + 3.dp.toPx())
                val half = size.width * 0.2f
                val reach = size.height * 0.42f
                drawPath(Path().apply {
                    moveTo(c.x, c.y - reach); lineTo(c.x + half, c.y); lineTo(c.x - half, c.y); close()
                }, needleNorth)
                drawPath(Path().apply {
                    moveTo(c.x, c.y + reach); lineTo(c.x + half, c.y); lineTo(c.x - half, c.y); close()
                }, needleSouth)
            }
            Text("N", Modifier.align(Alignment.TopCenter).padding(top = 5.dp),
                color = letter, fontSize = 9.sp, lineHeight = 9.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
    }
}

@Composable
fun SearchField(
    value: String, onValueChange: (String) -> Unit, onSearch: () -> Unit,
    onFocus: () -> Unit, onCancel: () -> Unit, active: Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = LocalAtlasColors.current
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val reduceMotion = LocalAtlasReduceMotion.current
    val fieldColor by animateColorAsState(
        if (active) colors.secondarySurface else colors.secondarySurface.copy(alpha = 0.86f),
        tween(if (reduceMotion) 0 else 180, easing = AtlasMotion.Standard), label = "search focus",
    )
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Surface(
            modifier = Modifier.weight(1f).heightIn(min = AtlasDimens.SearchHeight),
            color = fieldColor,
            shape = RoundedCornerShape(AtlasDimens.SearchRadius),
        ) {
            Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = colors.secondaryText, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(9.dp))
                BasicTextField(
                    value = value, onValueChange = onValueChange,
                    modifier = Modifier.weight(1f).padding(vertical = 13.dp).onFocusChanged { if (it.isFocused) onFocus() }
                        .semantics { contentDescription = "Pesquisar lugares e endereços" },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = colors.text),
                    cursorBrush = SolidColor(colors.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { keyboard?.hide(); onSearch() }),
                    decorationBox = { field ->
                        Box { if (value.isEmpty()) Text("Buscar no mapa", color = colors.secondaryText, style = MaterialTheme.typography.bodyLarge); field() }
                    },
                )
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = value.isNotEmpty(),
                        enter = if (reduceMotion) EnterTransition.None else fadeIn(tween(120)) + scaleIn(tween(180), initialScale = 0.86f),
                        exit = if (reduceMotion) ExitTransition.None else fadeOut(tween(100)) + scaleOut(tween(120), targetScale = 0.86f),
                    ) {
                        IconButton(onClick = { onValueChange("") }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Rounded.Close, "Limpar pesquisa", tint = colors.secondaryText, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = active,
            enter = if (reduceMotion) EnterTransition.None else fadeIn(tween(180, delayMillis = 50)) +
                expandHorizontally(spring(dampingRatio = 1f, stiffness = 450f), expandFrom = Alignment.End),
            exit = if (reduceMotion) ExitTransition.None else fadeOut(tween(110)) +
                shrinkHorizontally(tween(220, easing = AtlasMotion.Standard), shrinkTowards = Alignment.End),
        ) {
            TextButton(onClick = { keyboard?.hide(); focusManager.clearFocus(); onCancel() }, contentPadding = PaddingValues(start = 12.dp, end = 0.dp)) {
                Text("Cancelar", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun MapAttribution(modifier: Modifier = Modifier) {
    val colors = LocalAtlasColors.current
    var showCredits by rememberSaveable { mutableStateOf(false) }
    Surface(modifier = modifier.clickable(onClickLabel = "Ver créditos", role = Role.Button) { showCredits = true }.semantics {
        contentDescription = "Créditos do mapa: OpenStreetMap, OpenFreeMap e OpenMapTiles"
    }, shape = RoundedCornerShape(8.dp), color = colors.glass.copy(alpha = 0.92f)) {
        Text(
            "© OpenStreetMap · OpenFreeMap · OpenMapTiles",
            Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, lineHeight = 12.sp),
            color = colors.secondaryText, maxLines = 1,
        )
    }
    if (showCredits) MapCreditsDialog { showCredits = false }
}

@Composable
fun MapCreditsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val credits = remember {
        listOf(
            Triple("© OpenStreetMap contributors", "Dados geográficos · ODbL", "https://www.openstreetmap.org/copyright"),
            Triple("OpenFreeMap", "Mapas vetoriais e infraestrutura", "https://openfreemap.org/"),
            Triple("OpenMapTiles", "Cartografia · BSD e CC BY", "https://openmaptiles.org/copyright/"),
            Triple("MapLibre Native", "Renderização do mapa · BSD 2-Clause", "https://github.com/maplibre/maplibre-native/blob/main/LICENSE.md"),
            Triple("Photon", "Pesquisa de lugares · Apache 2.0", "https://github.com/komoot/photon"),
            Triple("Overpass API", "Consulta aos dados do OpenStreetMap", "https://wiki.openstreetmap.org/wiki/Overpass_API"),
            Triple("OSRM", "Cálculo de rotas · BSD 2-Clause", "https://project-osrm.org/"),
            Triple("openrouteservice", "Rotas a pé e de bicicleta", "https://openrouteservice.org/"),
            Triple("Noto Sans", "Tipografia dos mapas · SIL Open Font License", "https://openfontlicense.org/"),
            Triple("AndroidX e Jetpack Compose", "Interface e componentes Android · Apache 2.0", "https://source.android.com/docs/setup/about/licenses"),
            Triple("Kotlin e kotlinx.coroutines", "Linguagem e concorrência · Apache 2.0", "https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt"),
            Triple("OkHttp", "Comunicação de rede · Apache 2.0", "https://square.github.io/okhttp/"),
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Créditos do Dmap") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Dados, serviços e software livre usados pelo Dmap. Consulte os créditos e termos completos de cada projeto.")
                credits.forEach { (name, description, url) ->
                    TextButton(onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                        catch (_: ActivityNotFoundException) { Toast.makeText(context, "Nenhum aplicativo disponível para abrir o link.", Toast.LENGTH_LONG).show() }
                        catch (_: SecurityException) { Toast.makeText(context, "Não foi possível abrir este link.", Toast.LENGTH_LONG).show() }
                    }, contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(name, style = MaterialTheme.typography.labelLarge)
                            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Concluir") } },
    )
}
