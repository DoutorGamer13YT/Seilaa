# Provedores, configuração e limites reais

Revisão das fontes oficiais: **11 de outubro de 2026**. A integração abaixo usa dados reais; respostas de teste ficam somente em `src/test`. Nenhum serviço privado da Apple é utilizado.

## O que está implementado

| Recurso | Serviço | Dados enviados | Resultado usado |
|---|---|---|---|
| Texto de pesquisa | Photon | Consulta, até 200 caracteres; centro do mapa opcional | Até 12 lugares e endereços, na ordem de relevância do provedor |
| Categorias próximas | Overpass / OpenStreetMap | Categoria permitida e centro do mapa | Até 60 objetos OSM em raio de 3 km, ordenados localmente pela distância ao centro |
| Detalhes | Overpass / OpenStreetMap | Tipo OSM e identificador numérico exatos | Nome, endereço e contatos/horários quando cadastrados |
| Rota de carro | OSRM | Origem, destino e até seis paradas | Traçado GeoJSON, alternativas disponíveis, distância, duração e manobras |
| Rotas a pé e bicicleta | openrouteservice / HeiGIT | Coordenadas da rota e chave no cabeçalho Authorization | Traçado, instruções em português, distância e duração |

Os objetos mantêm a identidade `node:ID`, `way:ID` ou `relation:ID`. Dois resultados com nomes semelhantes não são fundidos. A consulta de detalhes utiliza esse identificador, sem tentar encontrar outro estabelecimento pelo nome. Objetos com coordenadas inválidas ou identidade inválida são descartados.

O limite de 60 objetos do Overpass ocorre no servidor: a ordenação posterior mostra os mais próximos **dentro do conjunto recebido**, sem prometer os 60 objetos globalmente mais próximos. As categorias utilizam tags OSM específicas; por exemplo, transporte público pesquisa plataformas e serviços públicos pesquisa prefeituras. A cobertura depende dos dados cadastrados; filtros compostos e um catálogo comercial completo não estão implementados.

## Configuração

Defina os valores em variáveis de ambiente ou em `local.properties`, ignorado pelo Git. Variáveis de ambiente têm precedência. Exemplo:

```properties
PHOTON_BASE_URL=https://photon.komoot.io/
OVERPASS_URL=https://overpass-api.de/api/interpreter
OSRM_BASE_URL=https://router.project-osrm.org/
ORS_BASE_URL=https://api.heigit.org/openrouteservice/
ORS_API_KEY=
```

`PHOTON_BASE_URL` é a raiz anterior a `/api/`; `OSRM_BASE_URL` é a raiz anterior a `/route/v1/driving/`; `OVERPASS_URL` inclui `/api/interpreter`; `ORS_BASE_URL` termina antes de `/v2/directions/`. Prefixos de caminho são preservados. URLs precisam ser HTTPS, sem usuário/senha, fragmento ou parâmetros de consulta embutidos.

Para habilitar caminhada e bicicleta, crie uma conta no [painel HeiGIT](https://account.heigit.org/), aceite os termos do provedor, obtenha uma chave que permita Directions e defina `ORS_API_KEY`. A presença da chave habilita os modos; a autorização, disponibilidade regional e quota são verificadas pelo servidor ao solicitar uma rota. Sem chave, o aplicativo oferece somente carro. Carro continua usando OSRM mesmo quando há chave ORS.

O endpoint antigo `api.openrouteservice.org` foi depreciado. A [comunicação oficial de migração](https://ask.openrouteservice.org/t/deprecating-api-openrouteservice-org-in-favour-of-api-heigit-org/7912) define a nova base acima e informa encerramento do endereço antigo entre 2 e 6 de novembro de 2026. A chave deve ser a da própria conta; este projeto não distribui uma chave compartilhada.

Uma chave gravada no APK **pode ser extraída**. Não a trate como segredo. Para distribuição, use as restrições que seu plano oferecer, monitore quotas e prefira um serviço intermediário autenticado quando precisar proteger credenciais de servidor. Não coloque chaves em URLs nem adicione interceptadores de log ao cliente OkHttp de produção.

## Serviços públicos não constituem infraestrutura de produção

- **Photon:** o [projeto oficial](https://github.com/komoot/photon#demo-server) permite uso moderado da instância de demonstração e pode restringir ou bloquear volume excessivo. Não oferece garantia de disponibilidade nem estabilidade do serviço. Para escala, hospede uma instância ou contrate serviço compatível.
- **OSRM:** a [política da demonstração](https://github.com/Project-OSRM/osrm-backend/wiki/Demo-server) limita o uso a casos razoáveis não comerciais, com no máximo uma requisição por segundo e sem garantias de latência, atualização ou disponibilidade. O cliente espaça solicitações em pelo menos 1,1 segundo por instância do repositório. Isso não resolve quotas agregadas de muitos aparelhos: um lançamento público/comercial exige trocar o endpoint por infraestrutura autorizada.
- **Overpass:** o [manual de recursos compartilhados](https://dev.overpass-api.de/overpass-doc/en/preface/commons.html) desencoraja aplicativos de público geral a usar instâncias públicas como seu backend permanente. Uso repetitivo e alto volume podem ser recusados. Para distribuição, configure instância própria ou serviço contratado. O cliente limita área, quantidade e duração e espaça solicitações em dois segundos; não faz varredura de mapas inteiros.
- **openrouteservice:** há limites por conta, tamanho de rota e opções; consulte [restrições atuais](https://openrouteservice.org/restrictions/) e o plano contratado. Alternativas só são solicitadas para duas coordenadas, com distância em linha reta abaixo de 40 km. Isso não garante que o percurso calculado fique dentro do limite de alternativas do servidor; uma resposta de limite é um erro tratável. Com paradas, o aplicativo não solicita alternativas ORS.

O aplicativo identifica suas requisições por User-Agent. Limites locais reduzem carga, mas não substituem contrato, autorização, atribuição ou dimensionamento do backend.

## Atribuição e qualidade dos dados

O campo `source` acompanha cada lugar e rota. Exiba OpenStreetMap e o motor correspondente, preservando a atribuição dos mapas. Referências: [direitos e licença dos dados OSM](https://www.openstreetmap.org/copyright), [OSRM](https://project-osrm.org/), [openrouteservice](https://openrouteservice.org/) e os termos do plano contratado. A licença da biblioteca de renderização não substitui a licença dos dados/tiles.

Horários são mostrados como o texto `opening_hours` cadastrado no OSM. O aplicativo não afirma “aberto agora”, não interpreta regras de feriados e não confirma a atualidade do cadastro. Telefones/sites aparecem apenas quando fornecidos. Avaliações, fotos, tráfego ao vivo, tarifas, pedágios, horários de transporte público e restrições de acesso detalhadas não são produzidos por estas integrações.

Distâncias e tempos de rota vêm do motor. O cálculo aproximado de distância entre posição e lugar é geodésico e deve ser identificado como aproximado. Manobras OSRM são traduzidas a partir do tipo/modificador/saída fornecidos; instruções ORS vêm do servidor em português. Chegadas intermediárias são rotuladas como paradas. Rota sem instruções completas e chegada final é recusada, sem fabricar manobras ausentes.

## Rede, cache e privacidade

- O cancelamento da coroutine cancela a chamada OkHttp. As consultas anteriores podem ser interrompidas pelo ViewModel ao editar a pesquisa ou trocar a seleção.
- Timeout de conexão: 12 segundos; leitura: 25 segundos; chamada inteira: 35 segundos. Respostas acima de 8 MiB são recusadas. JSON é interpretado fora da thread principal.
- Cache em memória: até 40 pesquisas por 10 minutos, 20 áreas por 5 minutos, 80 detalhes por uma hora e 12 rotas por um minuto. Erro de rede/limite/provedor pode recuperar lugares por até 24 horas, com `source` identificado como “cache temporário”. Rotas vencidas não são recuperadas após erro de recálculo.
- Esse cache **não sobrevive ao encerramento do processo**. Favoritos, histórico e configurações têm persistência separada; consulte [PERSISTENCE.md](PERSISTENCE.md). Não há download de áreas ou navegação offline completa.
- O observador de conectividade é registrado enquanto seu fluxo tem assinantes e removido ao cancelar o escopo. Conectividade validada pelo Android não garante que cada provedor esteja disponível.
- O repositório não registra buscas, coordenadas nem chaves em logs. Os servidores recebem o IP, a consulta/coordenadas necessárias e metadados HTTP; sua retenção é regida pelas políticas próprias. Centralizar/localizar no aparelho não envia automaticamente cada posição a todos os serviços; consultas e recálculos realizados pelo aplicativo enviam os pontos necessários.
- A ficha compartilha texto/link via seletor nativo Android, copia endereço/coordenadas via clipboard, abre sites somente HTTP(S) sem credenciais e usa `ACTION_DIAL`. Não realiza chamadas telefônicas diretamente. Cancelar o seletor de compartilhamento não é erro.

## Validação realmente realizada

Foram escritos testes JVM para identidade OSM, geometria, contatos seguros, limites de categorias, manobras OSRM/ORS, URL HTTPS, parâmetros de requisições, chave apenas no cabeçalho, erros HTTP, cancelamento OkHttp e cache TTL/LRU. As respostas de teste são fixtures controladas e interceptadas: não demonstram disponibilidade de um serviço real.

**Os testes não foram executados e nenhuma compilação foi realizada nesta etapa, por instrução do usuário.** Foi realizada revisão estática de contratos, fluxos de erro e validação de entradas. Uma tentativa anterior de smoke test HTTP a Photon/OSRM/Overpass falhou antes de chegar aos serviços porque o shell não conectou ao proxy do ambiente. Logo, pesquisa/rotas reais ainda precisam de validação end-to-end em aparelho autorizado. ORS também depende de chave válida; não houve chamada autenticada nem confirmação de quotas.

Documentação oficial foi consultada pela ferramenta de navegação. Isso valida as escolhas de integração e políticas descritas, mas não equivale a executar o aplicativo ou medir sua confiabilidade.
