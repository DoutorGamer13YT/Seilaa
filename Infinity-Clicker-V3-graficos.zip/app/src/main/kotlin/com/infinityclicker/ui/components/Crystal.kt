package com.infinityclicker.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import kotlin.math.abs
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.theme.Neon
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val size: Float, val color: Color
)
private class Shockwave(val x: Float, val y: Float, var life: Float, val maxLife: Float, val color: Color, val critical: Boolean)
private class FloatText(val x: Float, var y: Float, val text: String, val color: Color, var life: Float, val maxLife: Float, val big: Boolean)

/** Partículas e ondas com limites fixos para impedir crescimento de memória em autoclickers. */
private class ParticleField(private val maxParticles: Int, private val rnd: Random = Random(5)) {
    private val particles = ArrayList<Particle>()
    private val waves = ArrayList<Shockwave>()
    private val texts = ArrayList<FloatText>()

    fun burst(origin: Offset, color: Color, count: Int, crit: Boolean) {
        val n = if (crit) count * 2 else count
        repeat(n.coerceAtMost(60)) {
            if (particles.size >= maxParticles) particles.removeAt(0)
            val angle = rnd.nextFloat() * 2f * PI.toFloat()
            val speed = (if (crit) 500f else 310f) * (0.35f + rnd.nextFloat())
            val life = 0.42f + rnd.nextFloat() * 0.58f
            particles += Particle(origin.x, origin.y, cos(angle) * speed, sin(angle) * speed - 70f, life, life,
                2f + rnd.nextFloat() * if (crit) 5.5f else 3.5f, if (crit && rnd.nextBoolean()) Neon.Gold else color)
        }
        if (waves.size >= MAX_WAVES) waves.removeAt(0)
        waves += Shockwave(origin.x, origin.y, if (crit) 0.60f else 0.42f, if (crit) 0.60f else 0.42f, color, crit)
    }

    fun floatText(origin: Offset, text: String, color: Color, big: Boolean) {
        if (texts.size >= MAX_TEXTS) texts.removeAt(0)
        texts += FloatText(origin.x + (rnd.nextFloat() - 0.5f) * 60f, origin.y, text, color, 0.9f, 0.9f, big)
    }

    fun step(dt: Float) {
        val d = min(dt, 0.05f)
        for (i in particles.lastIndex downTo 0) {
            val p = particles[i]
            p.life -= d
            if (p.life <= 0f) particles.removeAt(i) else {
                p.vy += 590f * d; p.x += p.vx * d; p.y += p.vy * d
            }
        }
        for (i in waves.lastIndex downTo 0) {
            val wave = waves[i]
            wave.life -= d
            if (wave.life <= 0f) waves.removeAt(i)
        }
        for (i in texts.lastIndex downTo 0) {
            val text = texts[i]
            text.life -= d
            if (text.life <= 0f) texts.removeAt(i) else text.y -= 88f * d
        }
    }

    fun clear() { particles.clear(); waves.clear(); texts.clear(); lastNanos = -1L }

    private var lastNanos = -1L

    /** Avança a simulação até [nanos] (relógio do ticker): partículas andam na mesma cadência do desenho. */
    fun stepTo(nanos: Long) {
        if (lastNanos >= 0L && nanos > lastNanos) step((nanos - lastNanos) / 1_000_000_000f)
        lastNanos = nanos
    }

    fun draw(scope: DrawScope) {
        for (wave in waves) {
            val progress = 1f - wave.life / wave.maxLife
            scope.drawCircle(wave.color.copy(alpha = (1f - progress) * if (wave.critical) 0.70f else 0.45f),
                radius = (42f + progress * if (wave.critical) 180f else 120f), center = Offset(wave.x, wave.y), style = Stroke(width = if (wave.critical) 5f else 3f))
        }
        for (p in particles) {
            val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            val rr = p.size * (0.5f + 0.5f * alpha)
            if (particles.size < 140) scope.drawCircle(p.color.copy(alpha = alpha * 0.22f), rr * 2.8f, Offset(p.x, p.y))
            scope.drawCircle(p.color.copy(alpha = alpha), rr, Offset(p.x, p.y))
        }
    }

    fun forEachText(block: (Float, Float, String, Color, Float, Boolean) -> Unit) {
        for (text in texts) block(text.x, text.y, text.text, text.color, (text.life / text.maxLife).coerceIn(0f, 1f), text.big)
    }

    private companion object {
        const val MAX_WAVES = 12
        const val MAX_TEXTS = 14
    }
}

/**
 * Cristal 3D em Canvas: facetas em perspectiva, bordas especulares, núcleo volumétrico e órbitas.
 * Os cinco estilos alteram a geometria real (quantidade de faces/anel/núcleo), sem bitmap externo.
 */
@Composable
fun CrystalArea(
    tier: Int,
    crystalStyle: Int,
    baseColor: Color,
    comboFraction: Float,
    effectsIntensity: Float,
    particleLimit: Int,
    quality: GraphicsQuality,
    hapticsEnabled: Boolean,
    motionEnabled: Boolean,
    formatGain: (TapResult) -> String,
    onTap: () -> TapResult?,
    fleetSize: Int = 0,
    modifier: Modifier = Modifier
) {
    val field = remember(particleLimit) { ParticleField(particleLimit.coerceIn(24, 260)) }
    val textMeasurer = rememberTextMeasurer()
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val press = remember { Animatable(1f) }
    val ticker = LocalFrameTicker.current
    val detail = quality.detail
    // Frota decorativa (só visual): cresce com os geradores comprados; a quantidade visível respeita a qualidade gráfica.
    val fleetCap = when (detail) { 0 -> 6; 1 -> 12; 2 -> 20; else -> 28 }
    val fleetAnim = animateFloatAsState(
        if (motionEnabled) fleetSize.coerceIn(0, fleetCap).toFloat() else 0f, tween(700), label = "fleet"
    )
    // Brushes/efeitos criados uma vez por cor: criar um Brush por quadro gera um shader nativo novo a cada desenho.
    val gfx = remember(baseColor) { CrystalGfx(baseColor) }
    val bigStyle = remember { TextStyle(color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
    val smallStyle = remember { TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }

    LaunchedEffect(field, motionEnabled) { if (!motionEnabled) field.clear() }

    Box(
        modifier = modifier.pointerInput(effectsIntensity, baseColor, crystalStyle, motionEnabled, hapticsEnabled) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    for (change in event.changes) {
                        if (!change.changedToDown()) continue
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = min(size.width, size.height) * 0.31f
                        if (hypot(change.position.x - center.x, change.position.y - center.y) > radius * 1.45f) continue
                        change.consume()
                        val result = onTap()
                        if (result != null && hapticsEnabled) {
                            haptic.performHapticFeedback(if (result.crit) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
                        }
                        scope.launch {
                            press.snapTo(0.84f)
                            press.animateTo(1f, spring(dampingRatio = 0.34f, stiffness = Spring.StiffnessMedium))
                        }
                        if (result != null) {
                            val color = if (result.crit) Neon.Gold else baseColor
                            if (motionEnabled) {
                                field.burst(change.position, color, (12 * effectsIntensity).toInt().coerceAtLeast(3), result.crit)
                                field.floatText(change.position - Offset(0f, radius * 0.34f), (if (result.crit) "CRÍTICO! +" else "+") + formatGain(result), color, result.crit)
                                if (!result.bossDamage.isZero) field.floatText(change.position + Offset(0f, radius * 0.20f), "−${formatGain(result.copy(gain = result.bossDamage))}", Neon.Pink, false)
                            }
                        }
                    }
                }
            }
        }
    ) {
        // graphicsLayer isola a camada: sem ela, cada quadro invalidava (e regravava) a tela inteira.
        Canvas(Modifier.fillMaxSize().graphicsLayer { }) {
            // O relógio é lido só no desenho: a cena anima no ritmo do limite de FPS sem recompor nada.
            val nanos = ticker.value
            val spin = if (motionEnabled) phaseOf(nanos, 13_000L) else 0f
            val bob = if (motionEnabled) phaseOf(nanos, 4_100L) else 0f
            val pulse = if (motionEnabled) 0.91f + 0.09f * cos(phaseOf(nanos, 4_400L)) else 1f
            val center = Offset(size.width / 2f, size.height / 2f + sin(bob) * size.height * 0.016f)
            val radius = min(size.width, size.height) * 0.29f * press.value
            if (motionEnabled) field.stepTo(nanos)
            val flash = ((1f - press.value) / 0.16f).coerceIn(0f, 1f)
            if (flash > 0f) unitDisc(gfx.flash, center.x, center.y, radius * 1.9f, flash)
            val fleet = fleetAnim.value
            val orbitR = min(size.width, size.height) * 0.29f
            if (fleet > 0.01f) drawFleet(center, orbitR, nanos, fleet, baseColor, front = false)
            drawCrystalScene(gfx, center, radius, spin, pulse, comboFraction, baseColor, crystalStyle, tier, detail, if (motionEnabled) nanos else 0L)
            if (fleet > 0.01f) drawFleet(center, orbitR, nanos, fleet, baseColor, front = true)
            field.draw(this)
            field.forEachText { x, y, text, color, alpha, big ->
                // Estilo fixo (cache de layout do TextMeasurer acerta); cor e alfa vão no desenho.
                val layout = textMeasurer.measure(text, if (big) bigStyle else smallStyle)
                drawText(layout, color = color, topLeft = Offset(x - layout.size.width / 2f, y - layout.size.height / 2f), alpha = alpha)
            }
        }
    }
}

private const val U = 1000f
private const val MAX_FLEET = 28

/** Quantas naves aparecem para [totalOwned] geradores: cresce rápido no começo e devagar depois (logarítmico). */
fun fleetSizeFor(totalOwned: Long): Int =
    if (totalOwned <= 0L) 0 else max(1, (ln(1.0 + totalOwned.toDouble()) * 3.0).toInt()).coerceAtMost(MAX_FLEET)

private class ShipSeed(val lane: Float, val speed: Float, val dir: Float, val phase: Float, val fireEvery: Float, val fireOff: Float)

/** Parâmetros fixos de cada nave (órbita, velocidade, ritmo de tiro): a mesma nave sempre se comporta igual. */
private val shipSeeds: List<ShipSeed> = run {
    val rnd = Random(2718)
    List(MAX_FLEET) { i ->
        ShipSeed(
            lane = (i % 4) * 0.30f + rnd.nextFloat() * 0.12f,
            speed = 0.55f + rnd.nextFloat() * 0.65f,
            dir = if (i % 2 == 0) 1f else -1f,
            phase = rnd.nextFloat() * 2f * PI.toFloat(),
            fireEvery = 0.9f + rnd.nextFloat() * 1.6f,
            fireOff = rnd.nextFloat() * 3f
        )
    }
}

/**
 * Naves minúsculas que orbitam o cristal e atiram nele (efeito puramente visual: não gera energia).
 * Sem alocações: tudo é calculado a partir do relógio. [front] = false desenha as naves do fundo (e seus tiros)
 * antes do cristal, para ele cobri-las; true desenha as da frente e as faíscas de impacto por cima.
 */
private fun DrawScope.drawFleet(center: Offset, r: Float, nanos: Long, fleet: Float, base: Color, front: Boolean) {
    val twoPi = 2.0 * PI
    val t = nanos / 1_000_000_000.0
    val count = kotlin.math.ceil(fleet.toDouble()).toInt().coerceIn(0, MAX_FLEET)
    for (i in 0 until count) {
        val grow = (fleet - i).coerceIn(0f, 1f) // a nave mais nova "nasce" crescendo
        val seed = shipSeeds[i]
        val a = (seed.phase + seed.dir * seed.speed * 0.39 * t) % twoPi
        val sa = sin(a).toFloat()
        val isFront = sa >= 0f
        if (isFront != front) continue
        val ro = r * (1.95f + seed.lane)
        val px = center.x + cos(a).toFloat() * ro
        val py = center.y + sa * ro * 0.5f
        val depth = 0.82f + 0.22f * sa                      // mais perto = um pouco maior e mais clara
        val u = r * 0.055f * depth * grow
        if (u < 0.4f) continue
        var dx = center.x - px
        var dy = center.y - py
        val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        dx /= len; dy /= len                                 // aponta para o cristal
        val nx = px + dx * u * 1.4f
        val ny = py + dy * u * 1.4f
        val tx = px - dx * u * 1.1f
        val ty = py - dy * u * 1.1f
        val alpha = (0.55f + 0.45f * depth.coerceAtMost(1f)) * grow
        val flick = 0.7f + 0.3f * sin((t * 23.0 + i).toFloat())
        drawCircle(base.copy(alpha = 0.38f * flick * alpha), u * 1.05f, Offset(tx, ty))
        val wx = px - dx * u * 0.35f
        val wy = py - dy * u * 0.35f
        drawLine(base.copy(alpha = 0.92f * alpha), Offset(wx - dy * u, wy + dx * u), Offset(wx + dy * u, wy - dx * u), u * 0.55f, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.95f * alpha), Offset(tx, ty), Offset(nx, ny), u * 0.9f, StrokeCap.Round)

        // Tiro: um raio curto sai da nave e atinge a borda do cristal; depois uma faísca de impacto.
        val cycle = ((t + seed.fireOff) % seed.fireEvery).toFloat()
        val shotDur = 0.20f
        val tgtX = center.x - dx * r * 0.80f
        val tgtY = center.y - dy * r * 0.80f
        if (cycle < shotDur) {
            val p = cycle / shotDur
            val hx = nx + (tgtX - nx) * p
            val hy = ny + (tgtY - ny) * p
            val q = (p - 0.35f).coerceAtLeast(0f)
            val bx = nx + (tgtX - nx) * q
            val by = ny + (tgtY - ny) * q
            drawLine(base.copy(alpha = 0.40f * alpha), Offset(bx, by), Offset(hx, hy), u * 0.95f, StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.95f * alpha), Offset(bx, by), Offset(hx, hy), u * 0.38f, StrokeCap.Round)
        } else if (front && cycle < shotDur + 0.16f) {
            val q = (cycle - shotDur) / 0.16f
            drawCircle(base.copy(alpha = (1f - q) * 0.75f * alpha), r * (0.03f + q * 0.05f), Offset(tgtX, tgtY))
            drawCircle(Color.White.copy(alpha = (1f - q) * alpha), r * 0.02f * (1f - q), Offset(tgtX, tgtY))
        }
    }
}

/** Brushes em "espaço unitário" (centro 0,0, raio 1000): são movidos/escalados por transformação, nunca recriados. */
private class CrystalGfx(base: Color) {
    val halo = Brush.radialGradient(listOf(base, Color.Transparent), Offset.Zero, U)
    val bloom = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.05f), base.copy(alpha = 0.10f), Color.Transparent), Offset.Zero, U)
    val flash = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.40f), base.copy(alpha = 0.22f), Color.Transparent), Offset.Zero, U)
    val pool = Brush.radialGradient(listOf(base.copy(alpha = 0.34f), base.copy(alpha = 0.10f), Color.Transparent), Offset.Zero, U)
    val spec = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.72f), base.copy(alpha = 0.35f), Color.Transparent), Offset.Zero, U)
    val core = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), base.copy(alpha = 0.52f), Color.Transparent), Offset.Zero, U)

    private var tickEffect: PathEffect? = null
    private var tickRadius = -1f

    /** Anel tracejado (marcas de relógio) para o raio dado; só recria se o raio mudou mais de 2 px. */
    fun ticks(radius: Float, count: Int): PathEffect {
        val cached = tickEffect
        if (cached != null && abs(radius - tickRadius) < 2f) return cached
        val gap = (2f * PI.toFloat() * radius / count - 2.5f).coerceAtLeast(3f)
        return PathEffect.dashPathEffect(floatArrayOf(2.5f, gap)).also { tickEffect = it; tickRadius = radius }
    }
}

private inline fun DrawScope.unitDisc(brush: Brush, cx: Float, cy: Float, radius: Float, alpha: Float) {
    withTransform({ translate(cx, cy); scale(radius / U, radius / U, Offset.Zero) }) { drawCircle(brush, U, Offset.Zero, alpha) }
}

/**
 * Reaproveita objetos Path entre quadros: o cristal montava ~40 Paths nativos por quadro (≈5 mil/s a 120 fps),
 * gerando coleta de lixo e alocação nativa. O desenho roda numa só thread, e cada Path só vive dentro do quadro.
 */
private class PathPool {
    private val items = ArrayList<Path>()
    private var used = 0
    fun reset() { used = 0 }
    fun next(): Path {
        val p = if (used < items.size) items[used] else Path().also { items += it }
        used++
        p.rewind()
        return p
    }
}

private val pathPool = PathPool()

private fun DrawScope.drawCrystalScene(
    gfx: CrystalGfx, center: Offset, r: Float, spin: Float, pulse: Float, combo: Float, base: Color, style: Int, tier: Int, detail: Int, nanos: Long
) {
    pathPool.reset()
    val twoPi = 2f * PI.toFloat()
    val halo = r * (2.15f + combo * 0.6f)
    // 1) Raios de luz girando devagar atrás do cristal (um único Path, uma única chamada de desenho).
    if (detail >= 1) {
        val rays = if (detail >= 2) 14 else 8
        val path = pathPool.next()
        for (i in 0 until rays) {
            val a = spin * 0.55f + i * twoPi / rays
            val len = r * (2.35f + (i % 3) * 0.32f) * (0.92f + 0.08f * pulse)
            val w = 0.045f + (i % 2) * 0.02f
            path.moveTo(center.x, center.y)
            path.lineTo(center.x + cos(a - w) * len, center.y + sin(a - w) * len * 0.92f)
            path.lineTo(center.x + cos(a + w) * len, center.y + sin(a + w) * len * 0.92f)
            path.close()
        }
        drawPath(path, base.copy(alpha = 0.055f + combo * 0.07f))
    }
    // 2) Halo e bloom.
    unitDisc(gfx.halo, center.x, center.y, halo, (0.26f + combo * 0.26f) * pulse)
    if (detail >= 2) unitDisc(gfx.bloom, center.x, center.y, halo * 1.3f, pulse)
    // Anel de marcas girando e arco de combo: o combo ganha um medidor circular que acende em volta do cristal.
    if (detail >= 1) {
        val tickR = r * 1.66f
        if (detail >= 2) rotate(spin * 57.3f * 0.8f, center) {
            drawCircle(base.copy(alpha = 0.30f), tickR, center, style = Stroke(width = 4f, pathEffect = gfx.ticks(tickR, 72)))
        }
        val arcR = r * 1.56f
        val arcTop = Offset(center.x - arcR, center.y - arcR)
        val arcSize = Size(arcR * 2f, arcR * 2f)
        drawArc(Color.White.copy(alpha = 0.07f), 0f, 360f, false, arcTop, arcSize, style = Stroke(3.5f))
        if (combo > 0.01f) {
            drawArc(base.copy(alpha = 0.22f), -90f, 360f * combo, false, arcTop, arcSize, style = Stroke(9f, cap = StrokeCap.Round))
            drawArc(Color.White.copy(alpha = 0.85f), -90f, 360f * combo, false, arcTop, arcSize, style = Stroke(3f, cap = StrokeCap.Round))
        }
    }
    // 3) Pedestal de vidro com anéis de energia que se expandem.
    if (detail >= 1) drawPedestal(gfx, center, r, base, nanos, detail)
    // 4) Anel orbital: metade de trás antes do cristal, metade da frente depois.
    if (detail >= 1) drawOrbitRing(center, r, spin, base, back = true, style = style)
    if (style >= 2 && detail >= 1) drawOrbits(center, r, spin, base, style)
    drawFacetedCrystal(gfx, center, r, spin, base, style, tier, detail, nanos)
    if (detail >= 1) drawOrbitRing(center, r, spin, base, back = false, style = style)
    // 5) Fagulhas subindo do pedestal.
    if (detail >= 2) drawMotes(center, r, base, nanos, if (detail >= 3) 18 else 11)
    if (detail >= 3) { // Ultra: faíscas orbitando o cristal
        repeat(8) { i ->
            val a = spin * (1.6f + i * 0.11f) + i * (twoPi / 8f)
            val rr = r * (1.35f + 0.12f * (i % 3))
            drawCircle(Color.White.copy(alpha = 0.55f), 2.2f + (i % 3), Offset(center.x + cos(a) * rr, center.y + sin(a) * rr * 0.45f))
        }
    }
}

private fun DrawScope.drawPedestal(gfx: CrystalGfx, center: Offset, r: Float, base: Color, nanos: Long, detail: Int) {
    val cy = center.y + r * 1.34f
    val w = r * 1.95f
    val h = r * 0.46f
    // Poça de luz projetada pelo cristal.
    withTransform({ translate(center.x, cy); scale(w / U, w / U, Offset.Zero) }) {
        drawOval(gfx.pool, Offset(-U, -U * 0.236f), Size(U * 2f, U * 0.472f))
    }
    // Disco de vidro.
    drawOval(Color.White.copy(alpha = 0.055f), topLeft = Offset(center.x - w * 0.62f, cy - h * 0.62f), size = Size(w * 1.24f, h * 1.24f))
    drawOval(Color.White.copy(alpha = 0.34f),
        topLeft = Offset(center.x - w * 0.62f, cy - h * 0.62f), size = Size(w * 1.24f, h * 1.24f), style = Stroke(1.6f))
    drawOval(base.copy(alpha = 0.40f), topLeft = Offset(center.x - w * 0.46f, cy - h * 0.46f), size = Size(w * 0.92f, h * 0.92f), style = Stroke(1.1f))
    if (nanos > 0L) repeat(if (detail >= 2) 2 else 1) { k ->
        val p = ((nanos / 1_000_000L + k * 1_450L) % 2_900L) / 2_900f
        val sw = w * (0.55f + p * 0.75f)
        val sh = h * (0.55f + p * 0.75f)
        drawOval(base.copy(alpha = (1f - p) * 0.38f), topLeft = Offset(center.x - sw, cy - sh), size = Size(sw * 2f, sh * 2f), style = Stroke(1.5f))
    }
}

/** Anel inclinado com pontos luminosos; `back` desenha o arco de trás (acima do centro) ou o da frente. */
private fun DrawScope.drawOrbitRing(center: Offset, r: Float, spin: Float, base: Color, back: Boolean, style: Int) {
    val a = r * 1.95f
    val b = r * 0.46f
    val tilt = -13f
    rotate(tilt, center) {
        drawArc(
            if (back) base.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.50f),
            startAngle = if (back) 180f else 0f, sweepAngle = 180f, useCenter = false,
            topLeft = Offset(center.x - a, center.y - b), size = Size(a * 2f, b * 2f), style = Stroke(if (back) 1.2f else 2.0f)
        )
        val dots = if (style == 4) 4 else 3
        for (i in 0 until dots) {
            val th = spin * 2.1f + i * (2f * PI.toFloat() / dots)
            val sy = sin(th)
            if ((sy < 0f) != back) continue
            val pos = Offset(center.x + cos(th) * a, center.y + sy * b)
            drawCircle(base.copy(alpha = 0.28f), 9f, pos)
            drawCircle(Color.White.copy(alpha = 0.95f), 3.2f, pos)
        }
    }
}

private fun DrawScope.drawMotes(center: Offset, r: Float, base: Color, nanos: Long, count: Int) {
    val ms = nanos / 1_000_000L
    for (i in 0 until count) {
        val cycle = 5_200L + (i % 5) * 700L
        val p = ((ms + i * 977L) % cycle) / cycle.toFloat()
        val x = center.x + sin(i * 2.4f + p * 3.1f) * r * (0.55f + (i % 4) * 0.28f)
        val y = center.y + r * 1.30f - p * r * 2.9f
        val fade = sin(p * PI.toFloat())
        val c = if (i % 3 == 0) Color.White else base
        val size = 1.4f + (i % 3) * 0.9f
        drawCircle(c.copy(alpha = fade * 0.18f), size * 3.2f, Offset(x, y))
        drawCircle(c.copy(alpha = fade * 0.85f), size, Offset(x, y))
    }
}

private fun DrawScope.drawOrbits(center: Offset, r: Float, spin: Float, color: Color, style: Int) {
    repeat(if (style == 4) 3 else 1) { i ->
        val scale = 1f + i * 0.18f
        val tilt = 0.34f + i * 0.08f
        val rect = Rect(center.x - r * 1.18f * scale, center.y - r * tilt, center.x + r * 1.18f * scale, center.y + r * tilt)
        drawArc(color.copy(alpha = 0.30f - i * 0.06f), startAngle = (spin * 57.3f + i * 70f), sweepAngle = 210f,
            useCenter = false, topLeft = rect.topLeft, size = rect.size, style = Stroke(width = 1.6f))
    }
}

private fun DrawScope.drawFacetedCrystal(gfx: CrystalGfx, center: Offset, r: Float, spin: Float, base: Color, style: Int, tier: Int, detail: Int, nanos: Long) {
    val sides = when (style) { 0 -> 6; 1 -> 8; 2 -> 10; 3 -> 4; else -> 12 }
    val elongation = when (style) { 1 -> 1.25f; 3 -> 0.88f; 4 -> 1.08f; else -> 1f }
    val ringRadius = r * when (style) { 3 -> 0.92f; 4 -> 0.72f; else -> 0.82f }
    val top = Offset(center.x, center.y - r * 1.08f * elongation)
    val bottom = Offset(center.x, center.y + r * 1.18f * elongation)
    val ringY = center.y - r * 0.04f
    val squash = if (style == 3) 0.38f else 0.29f

    data class Point3(val point: Offset, val z: Float)
    data class Facet(val path: Path, val z: Float, val light: Float, val alpha: Float)
    val ring = List(sides) { i ->
        val a = spin + i * (2f * PI.toFloat() / sides)
        Point3(Offset(center.x + cos(a) * ringRadius, ringY + sin(a) * ringRadius * squash), sin(a))
    }
    val facets = ArrayList<Facet>(sides * 2)
    for (i in 0 until sides) {
        val p1 = ring[i]; val p2 = ring[(i + 1) % sides]
        val angle = spin + (i + 0.5f) * (2f * PI.toFloat() / sides)
        val z = sin(angle)
        val light = 0.42f + 0.58f * cos(angle - 5.25f)
        facets += Facet(pathPool.next().apply { moveTo(top.x, top.y); lineTo(p1.point.x, p1.point.y); lineTo(p2.point.x, p2.point.y); close() }, z, light, 0.91f)
        facets += Facet(pathPool.next().apply { moveTo(bottom.x, bottom.y); lineTo(p2.point.x, p2.point.y); lineTo(p1.point.x, p1.point.y); close() }, z, light * 0.72f, 0.82f)
    }
    facets.sortBy { it.z }
    val dark = lerp(base, Color(0xFF030411), 0.78f)
    val bright = lerp(base, Color.White, 0.64f)
    facets.forEach { facet ->
        val fill = lerp(dark, bright, facet.light.coerceIn(0f, 1f))
        drawPath(facet.path, fill.copy(alpha = if (facet.z > 0f) facet.alpha else facet.alpha * 0.45f))
        if (detail >= 1) drawPath(facet.path, Color.White.copy(alpha = if (facet.z > 0f) 0.52f else 0.15f), style = Stroke(width = 1.45f))
    }
    // Chanfro: triângulo menor e mais claro dentro de cada face da frente dá relevo de lapidação.
    if (detail >= 2) for (i in 0 until sides) {
        val p1 = ring[i].point; val p2 = ring[(i + 1) % sides].point
        val z = sin(spin + (i + 0.5f) * (2f * PI.toFloat() / sides))
        if (z <= 0.05f) continue
        val light = (0.42f + 0.58f * cos(spin + (i + 0.5f) * (2f * PI.toFloat() / sides) - 5.25f)).coerceIn(0f, 1f)
        val gx = (top.x + p1.x + p2.x) / 3f; val gy = (top.y + p1.y + p2.y) / 3f
        fun lerpPt(a: Offset) = Offset(gx + (a.x - gx) * 0.55f, gy + (a.y - gy) * 0.55f)
        val a = lerpPt(top); val b = lerpPt(p1); val c = lerpPt(p2)
        drawPath(pathPool.next().apply { moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); close() }, Color.White.copy(alpha = 0.10f + 0.20f * light * z))
    }
    // Aberração cromática na borda: contorno ciano/rosa deslocado 1,5 px, como vidro real.
    if (detail >= 2) {
        val rim = pathPool.next().apply { moveTo(top.x, top.y); lineTo(center.x + ringRadius, ringY); lineTo(bottom.x, bottom.y); lineTo(center.x - ringRadius, ringY); close() }
        translate(-1.6f, 0f) { drawPath(rim, Neon.Cyan.copy(alpha = 0.30f), style = Stroke(1.2f)) }
        translate(1.6f, 0f) { drawPath(rim, Neon.Pink.copy(alpha = 0.26f), style = Stroke(1.2f)) }
    }
    // Núcleo interno e reflexo especular: duas camadas dão volume sem blur caro.
    unitDisc(gfx.spec, center.x - r * 0.22f, center.y - r * 0.30f, r * 0.52f, 1f)
    if (detail >= 1) drawPath(pathPool.next().apply {
        moveTo(top.x, top.y + r * 0.12f); lineTo(center.x - r * 0.16f, center.y - r * 0.12f); lineTo(center.x - r * 0.03f, center.y - r * 0.47f); close()
    }, Color.White.copy(alpha = 0.46f))
    // Faixa de brilho que varre o cristal de tempos em tempos, recortada pela silhueta.
    if (detail >= 2 && nanos > 0L) {
        val cycle = 5_500L
        val p = ((nanos / 1_000_000L) % cycle) / cycle.toFloat()
        if (p < 0.38f) {
            val q = p / 0.38f
            val x = center.x - r * 1.2f + q * r * 2.4f
            val silhouette = pathPool.next().apply {
                moveTo(top.x, top.y); lineTo(center.x + ringRadius, ringY); lineTo(bottom.x, bottom.y); lineTo(center.x - ringRadius, ringY); close()
            }
            clipPath(silhouette) {
                val band = pathPool.next().apply {
                    moveTo(x - r * 0.10f, top.y); lineTo(x + r * 0.10f, top.y)
                    lineTo(x + r * 0.10f - r * 0.5f, bottom.y); lineTo(x - r * 0.10f - r * 0.5f, bottom.y); close()
                }
                drawPath(band, Color.White.copy(alpha = 0.34f * sin(q * PI.toFloat())))
            }
        }
    }
    if (style == 4 || tier >= 5) {
        unitDisc(gfx.core, center.x, center.y, r * 0.52f, 1f)
    }
}
