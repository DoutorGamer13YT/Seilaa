package com.infinityclicker.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.ui.theme.Neon

/** Interruptor no estilo iOS: trilho verde, bolinha branca que estica quando pressionada e volta com mola. */
@Composable
fun IosSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val t = animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.68f, stiffness = 650f), label = "swT")
    val grow = animateFloatAsState(if (pressed) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = 800f), label = "swGrow")
    Canvas(
        modifier.size(width = 51.dp, height = 31.dp)
            .clickable(interactionSource = source, indication = null, role = Role.Switch) { onCheckedChange(!checked) }
    ) {
        val off = Color.White.copy(alpha = 0.20f)
        val on = Color(0xFF34C759)
        drawRoundRect(lerp(off, on, t.value.coerceIn(0f, 1f)), cornerRadius = CornerRadius(size.height / 2f))
        val pad = 2.dp.toPx()
        val th = size.height - pad * 2f
        val tw = th + grow.value * 5.dp.toPx()
        val x = pad + (size.width - pad * 2f - tw) * t.value
        drawRoundRect(Color.Black.copy(alpha = 0.22f), Offset(x, pad + 1.5.dp.toPx()), Size(tw, th), CornerRadius(th / 2f))
        drawRoundRect(Color.White, Offset(x, pad), Size(tw, th), CornerRadius(th / 2f))
    }
}

/** Controle segmentado com indicador deslizante (mola). Cada opção ocupa a mesma largura. */
@Composable
fun SegmentedControl(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    height: Dp = 36.dp,
    fontSize: TextUnit = 12.sp
) {
    val n = options.size.coerceAtLeast(1)
    val pos = animateFloatAsState(selected.toFloat(), spring(dampingRatio = 0.74f, stiffness = 520f), label = "segPos")
    Box(
        modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.30f))
            .drawWithCache {
                // O degradê só depende do tamanho: criado uma vez, em vez de um shader novo a cada quadro do deslize.
                val pad = 3.dp.toPx()
                val h = size.height - pad * 2f
                val sheen = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent), pad, pad + h * 0.6f)
                val hairline = Stroke(1.dp.toPx())
                onDrawBehind {
                    val w = (size.width - pad * 2f) / n
                    val left = pad + pos.value * w
                    val r = CornerRadius(h / 2f)
                    drawRoundRect(tint.copy(alpha = 0.28f), Offset(left, pad), Size(w, h), r)
                    drawRoundRect(sheen, Offset(left, pad), Size(w, h), r)
                    drawRoundRect(Color.White.copy(alpha = 0.30f), Offset(left, pad), Size(w, h), r, style = hairline)
                }
            }
    ) {
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, role = Role.Tab) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label, fontSize = fontSize, fontWeight = FontWeight.SemiBold, maxLines = 1,
                        color = if (i == selected) Neon.TextPrimary else Neon.TextSecondary
                    )
                }
            }
        }
    }
}

/** Seção agrupada estilo Ajustes do iOS: título em caixa-alta, painel de vidro com linhas e rodapé explicativo. */
@Composable
fun SettingsGroup(
    title: String,
    panelAlpha: Float,
    modifier: Modifier = Modifier,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier.fillMaxWidth()) {
        Text(
            title.uppercase(), color = Neon.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp,
            modifier = Modifier.padding(start = 10.dp, bottom = 7.dp)
        )
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), tint = Color.White, alpha = panelAlpha), content = content)
        if (footer != null) Text(
            footer, color = Neon.TextSecondary, fontSize = 11.sp, lineHeight = 15.sp,
            modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 7.dp)
        )
    }
}

/** Quadradinho arredondado colorido com um símbolo, como os ícones dos Ajustes do iOS. */
@Composable
fun SettingsIcon(symbol: String, tint: Color) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.98f), tint.copy(alpha = 0.66f)))),
        contentAlignment = Alignment.Center
    ) {
        val ink = Color(0xFF05060F)
        if (hasGlyphIcon(symbol)) GlyphIcon(symbol, ink, 18.dp)
        else Text(symbol, color = ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

private fun Modifier.rowDivider(show: Boolean): Modifier = if (!show) this else this.drawBehind {
    val y = size.height - 0.5.dp.toPx()
    drawLine(Color.White.copy(alpha = 0.10f), Offset(58.dp.toPx(), y), Offset(size.width, y), 1.dp.toPx())
}

/** Linha de ajuste: ícone, título, descrição curta e um controle à direita (interruptor, seta, valor...). */
@Composable
fun SettingsRow(
    symbol: String,
    tint: Color,
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    divider: Boolean = true,
    onClick: (() -> Unit)? = null,
    titleColor: Color = Neon.TextPrimary,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        modifier.fillMaxWidth().rowDivider(divider)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SettingsIcon(symbol, tint)
        Column(Modifier.weight(1f)) {
            Text(title, color = titleColor, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 15.sp)
        }
        trailing()
    }
}

/** Linha com interruptor. Tocar em qualquer lugar da linha alterna. */
@Composable
fun SettingsToggle(symbol: String, tint: Color, title: String, checked: Boolean, onChange: (Boolean) -> Unit, subtitle: String? = null, divider: Boolean = true) {
    SettingsRow(symbol, tint, title, subtitle = subtitle, divider = divider, onClick = { onChange(!checked) }) {
        IosSwitch(checked, onChange)
    }
}

/** Linha com título + valor atual e um controle segmentado embaixo (qualidade, FPS...). */
@Composable
fun SettingsChoice(
    symbol: String, tint: Color, title: String, valueText: String,
    options: List<String>, selected: Int, onSelect: (Int) -> Unit,
    caption: String? = null, divider: Boolean = true
) {
    Column(Modifier.fillMaxWidth().rowDivider(divider).padding(horizontal = 14.dp, vertical = 11.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SettingsIcon(symbol, tint)
            Text(title, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(valueText, color = Neon.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        SegmentedControl(options, selected, onSelect, Modifier.padding(top = 10.dp))
        if (caption != null) Text(caption, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

/** Linha com título + valor em % e um controle deslizante. */
@Composable
fun SettingsSlider(
    symbol: String, tint: Color, title: String, valueText: String,
    value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit,
    divider: Boolean = true
) {
    Column(Modifier.fillMaxWidth().rowDivider(divider).padding(start = 14.dp, end = 14.dp, top = 11.dp, bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SettingsIcon(symbol, tint)
            Text(title, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(valueText, color = Neon.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Neon.Cyan, inactiveTrackColor = Color.White.copy(alpha = 0.18f)
            )
        )
    }
}
