package dev.atlas.map

import android.content.Context
import dev.atlas.core.Coordinate
import dev.atlas.core.OfflineTiles
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition

data class OfflineRegionInfo(
    val id: Long, val name: String, val radiusKm: Int, val center: Coordinate?, val createdAt: Long,
    val completedResources: Long = 0, val requiredResources: Long = 0, val bytes: Long = 0,
    val complete: Boolean = false, val downloading: Boolean = false, val error: String? = null,
) {
    val progress: Float get() = if (requiredResources > 0) (completedResources.toFloat() / requiredResources).coerceIn(0f, 1f) else 0f
}

data class OfflineMapsState(
    val regions: List<OfflineRegionInfo> = emptyList(),
    val loaded: Boolean = false,
    val creating: Boolean = false,
    val error: String? = null,
) { val busy: Boolean get() = creating || regions.any { it.downloading } }

class OfflineMaps(private val context: Context, private val styleUrl: String) {
    private val mutable = MutableStateFlow(OfflineMapsState())
    val state: StateFlow<OfflineMapsState> = mutable.asStateFlow()
    private val handles = HashMap<Long, OfflineRegion>()

    private fun manager(): OfflineManager {
        MapLibre.getInstance(context)
        return OfflineManager.getInstance(context)
    }

    fun refresh() {
        manager().listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                val regions = offlineRegions.orEmpty()
                val previous = mutable.value.regions.associateBy { it.id }
                handles.clear()
                regions.forEach { handles[it.id] = it }
                mutable.update { current ->
                    current.copy(loaded = true, error = null,
                        regions = regions.map { previous[it.id] ?: info(it) }.sortedByDescending { it.createdAt })
                }
                regions.forEach { region ->
                    region.getStatus(object : OfflineRegion.OfflineRegionStatusCallback {
                        override fun onStatus(status: OfflineRegionStatus?) { status?.let { apply(region.id, it) } }
                        override fun onError(error: String?) = Unit
                    })
                }
            }

            override fun onError(error: String) {
                mutable.update { it.copy(loaded = true, error = "Não foi possível ler os mapas offline: $error") }
            }
        })
    }

    fun download(center: Coordinate, radiusKm: Int, name: String) {
        val current = mutable.value
        if (current.busy) return
        val box = OfflineTiles.box(center, radiusKm)
        val bounds = LatLngBounds.Builder()
            .include(LatLng(box.north, box.east))
            .include(LatLng(box.south, box.west))
            .build()
        val definition = OfflineTilePyramidRegionDefinition(
            styleUrl, bounds, OfflineTiles.MIN_ZOOM.toDouble(), OfflineTiles.MAX_ZOOM.toDouble(),
            context.resources.displayMetrics.density,
        )
        val metadata = JSONObject()
            .put("name", name).put("radiusKm", radiusKm).put("createdAt", System.currentTimeMillis())
            .put("latitude", center.latitude).put("longitude", center.longitude)
            .toString().toByteArray(Charsets.UTF_8)
        mutable.update { it.copy(creating = true, error = null) }
        manager().createOfflineRegion(definition, metadata, object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(offlineRegion: OfflineRegion) {
                handles[offlineRegion.id] = offlineRegion
                observe(offlineRegion)
                mutable.update { state ->
                    state.copy(creating = false,
                        regions = (listOf(info(offlineRegion).copy(downloading = true)) + state.regions).sortedByDescending { it.createdAt })
                }
                offlineRegion.setDownloadState(OfflineRegion.STATE_ACTIVE)
            }

            override fun onError(error: String) {
                mutable.update { it.copy(creating = false, error = "Não foi possível iniciar o download: $error") }
            }
        })
    }

    fun resume(id: Long) {
        val region = handles[id] ?: return
        if (mutable.value.busy) return
        observe(region)
        update(id) { it.copy(downloading = true, error = null) }
        region.setDownloadState(OfflineRegion.STATE_ACTIVE)
    }

    fun pause(id: Long) {
        val region = handles[id] ?: return
        region.setDownloadState(OfflineRegion.STATE_INACTIVE)
        update(id) { it.copy(downloading = false) }
    }

    fun delete(id: Long) {
        val region = handles[id] ?: return
        region.setDownloadState(OfflineRegion.STATE_INACTIVE)
        region.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
            override fun onDelete() {
                handles.remove(id)
                mutable.update { state -> state.copy(regions = state.regions.filterNot { it.id == id }) }
                manager().packDatabase(null)
            }

            override fun onError(error: String) {
                mutable.update { it.copy(error = "Não foi possível apagar a região: $error") }
            }
        })
    }

    fun dismissError() = mutable.update { it.copy(error = null) }

    private fun observe(region: OfflineRegion) {
        region.setObserver(object : OfflineRegion.OfflineRegionObserver {
            override fun onStatusChanged(status: OfflineRegionStatus) {
                apply(region.id, status)
                if (status.isComplete && status.isRequiredResourceCountPrecise) {
                    region.setDownloadState(OfflineRegion.STATE_INACTIVE)
                    update(region.id) { it.copy(downloading = false) }
                }
            }

            override fun onError(error: OfflineRegionError) {
                update(region.id) { it.copy(error = error.message.ifBlank { "Falha de rede durante o download." }) }
            }

            override fun mapboxTileCountLimitExceeded(limit: Long) {
                region.setDownloadState(OfflineRegion.STATE_INACTIVE)
                update(region.id) { it.copy(downloading = false, error = "Limite de blocos do mapa excedido.") }
            }
        })
    }

    private fun apply(id: Long, status: OfflineRegionStatus) = update(id) {
        it.copy(
            completedResources = status.completedResourceCount,
            requiredResources = status.requiredResourceCount,
            bytes = status.completedResourceSize,
            complete = status.isComplete && status.isRequiredResourceCountPrecise && status.requiredResourceCount > 0,
            downloading = status.downloadState == OfflineRegion.STATE_ACTIVE && !status.isComplete,
        )
    }

    private fun update(id: Long, transform: (OfflineRegionInfo) -> OfflineRegionInfo) =
        mutable.update { state -> state.copy(regions = state.regions.map { if (it.id == id) transform(it) else it }) }

    private fun info(region: OfflineRegion): OfflineRegionInfo {
        val data = runCatching { JSONObject(String(region.metadata, Charsets.UTF_8)) }.getOrNull()
        val center = data?.takeIf { it.has("latitude") && it.has("longitude") }?.let {
            runCatching { Coordinate(it.getDouble("latitude"), it.getDouble("longitude")) }.getOrNull()
        }
        return OfflineRegionInfo(
            id = region.id,
            name = data?.optString("name").orEmpty().ifBlank { "Região offline" },
            radiusKm = data?.optInt("radiusKm", 0) ?: 0,
            center = center,
            createdAt = data?.optLong("createdAt", 0L) ?: 0L,
        )
    }
}
