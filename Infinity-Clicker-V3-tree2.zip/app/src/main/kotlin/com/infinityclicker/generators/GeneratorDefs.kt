package com.infinityclicker.generators

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.Rarity
import kotlin.math.pow

data class GeneratorDef(
    val id: Int,
    val name: String,
    val description: String,
    val rarity: Rarity,
    val baseCost: BigNum,
    /** Crescimento geométrico do preço a cada unidade comprada. */
    val growth: Double,
    /** Energia por segundo de UMA unidade, sem multiplicadores. */
    val baseProduction: BigNum
)

/**
 * Os 10 geradores cósmicos.
 *  V3: custo base: 20 × 12,4^i
 *  produção:     0,5 × 8^i por segundo (o retorno do investimento piora ~1,5× a cada tier)
 *  crescimento:  1,155 + 0,006·i por unidade (tiers altos encarecem mais rápido)
 *  A curva aumenta em torno de 60% o esforço nos tiers tardios sem punir o primeiro gerador.
 * Marcos: a cada 25 unidades possuídas a produção do gerador dobra (ver Formulas.milestoneMultiplier).
 */
object GeneratorDefs {

    private val data = listOf(
        Triple("Fragmento Estelar", "Cacos de estrela que pulsam energia pura.", Rarity.COMUM),
        Triple("Núcleo Energético", "Um reator compacto de energia cósmica.", Rarity.COMUM),
        Triple("Estrela", "Uma estrela inteira trabalhando para você.", Rarity.INCOMUM),
        Triple("Nebulosa", "Nuvens de gás ionizado que se condensam em energia.", Rarity.INCOMUM),
        Triple("Sistema Solar", "Planetas e luas orbitando um motor de energia.", Rarity.RARO),
        Triple("Galáxia", "Centenas de bilhões de estrelas em sintonia.", Rarity.EPICO),
        Triple("Aglomerado Galáctico", "Galáxias unidas pela gravidade e pelo lucro.", Rarity.LENDARIO),
        Triple("Universo", "Um universo completo dedicado a produzir energia.", Rarity.MITICO),
        Triple("Multiverso", "Infinitos universos somando suas forças.", Rarity.COSMICO),
        Triple("Dimensão Infinita", "O limite do possível — e além dele.", Rarity.TRANSCENDENTAL)
    )

    val all: List<GeneratorDef> = data.mapIndexed { i, (name, desc, rarity) ->
        GeneratorDef(
            id = i,
            name = name,
            description = desc,
            rarity = rarity,
            baseCost = BigNum.of(20.0 * 12.4.pow(i)),
            growth = 1.155 + 0.006 * i,
            baseProduction = BigNum.of(0.5 * 8.0.pow(i))
        )
    }

    val count: Int get() = all.size

    fun byId(id: Int): GeneratorDef = all[id]
}
