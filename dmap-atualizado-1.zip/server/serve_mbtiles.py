#!/usr/bin/env python3
"""HTTPS source for a licensed raster MBTiles archive; never fetches upstream tiles."""
import argparse
from contextlib import closing
import json
import re
import sqlite3
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


def archive_metadata(path):
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        metadata = dict(db.execute('SELECT name,value FROM metadata'))
        columns = {row[1] for row in db.execute('PRAGMA table_info(tiles)')}
        if not {'zoom_level', 'tile_column', 'tile_row', 'tile_data'} <= columns:
            raise ValueError('Missing MBTiles tiles table or view')
    fmt = metadata.get('format', '').lower()
    if fmt not in ('png', 'jpg', 'jpeg', 'webp'):
        raise ValueError('This server accepts raster MBTiles (png, jpg, webp), not vector PBF')
    bounds = [float(v) for v in metadata['bounds'].split(',')]
    if len(bounds) != 4 or not (-180 <= bounds[0] < bounds[2] <= 180 and -85.051129 <= bounds[1] < bounds[3] <= 85.051129):
        raise ValueError('MBTiles bounds are missing or invalid')
    minimum, maximum = int(metadata['minzoom']), int(metadata['maxzoom'])
    if not 0 <= minimum <= maximum <= 16:
        raise ValueError('Use MBTiles zoom levels in 0..16')
    return metadata, fmt, bounds, minimum, maximum


def handler_for(path, origin, attribution, tile_size):
    metadata, fmt, bounds, minimum, maximum = archive_metadata(path)
    tile_json = {'tilejson': '3.0.0', 'name': metadata.get('name', 'Dmaps'),
                 'tiles': [origin + '/tiles/{z}/{x}/{y}.' + fmt], 'scheme': 'xyz',
                 'bounds': bounds, 'minzoom': minimum, 'maxzoom': maximum,
                 'attribution': attribution}
    style = {'version': 8, 'name': 'Dmaps raster offline',
             'sources': {'local': {'type': 'raster', 'url': origin + '/tiles.json', 'tileSize': tile_size}},
             'layers': [{'id': 'background', 'type': 'background', 'paint': {'background-color': '#eaf0f2'}},
                        {'id': 'map', 'type': 'raster', 'source': 'local'}]}
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        def reply(self, status, body=b'', mime='application/json'):
            self.send_response(status)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'public, max-age=31536000, immutable' if status == 200 else 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(body)
        def do_HEAD(self):
            self.do_GET()
        def do_GET(self):
            route = urlsplit(self.path).path
            if route in ('/style.json', '/tiles.json'):
                self.reply(200, json.dumps(style if route == '/style.json' else tile_json).encode())
                return
            match = re.fullmatch(r'/tiles/(\d{1,2})/(\d{1,6})/(\d{1,6})\.' + fmt, route)
            if not match:
                self.reply(404); return
            z, x, y = map(int, match.groups())
            if not (minimum <= z <= maximum and 0 <= x < 2**z and 0 <= y < 2**z):
                self.reply(404); return
            try:
                with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
                    tile = db.execute('SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?',
                                      (z, x, (1 << z) - 1 - y)).fetchone()
                if tile is None:
                    self.reply(404); return
                if len(tile[0]) > 4 * 1024 * 1024:
                    self.reply(413); return
                self.reply(200, tile[0], {'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp'}[fmt])
            except sqlite3.Error:
                self.reply(503)
        def log_message(self, fmt, *args):
            pass
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mbtiles', required=True, type=Path)
    parser.add_argument('--origin', required=True, help='Public HTTPS origin, e.g. https://maps.your-domain')
    parser.add_argument('--attribution', required=True, help='Required credits and license for YOUR data')
    parser.add_argument('--cert', required=True, type=Path)
    parser.add_argument('--key', required=True, type=Path)
    parser.add_argument('--port', type=int, default=8443)
    parser.add_argument('--tile-size', type=int, choices=[256, 512], default=256)
    args = parser.parse_args()
    origin = args.origin.rstrip('/')
    parsed = urlsplit(origin)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.path or parsed.query or parsed.fragment:
        parser.error('origin must be an HTTPS origin without a path or credentials')
    handler = handler_for(args.mbtiles.resolve(strict=True), origin, args.attribution, args.tile_size)
    server = ThreadingHTTPServer(('0.0.0.0', args.port), handler)
    server.daemon_threads = True
    server.request_queue_size = 16
    tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.minimum_version = ssl.TLSVersion.TLSv1_2
    tls.load_cert_chain(args.cert, args.key)
    server.socket = tls.wrap_socket(server.socket, server_side=True)
    print('Style URL:', origin + '/style.json', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
