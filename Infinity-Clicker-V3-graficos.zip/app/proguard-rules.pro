# Regras mínimas: as bibliotecas AndroidX já trazem as suas próprias (consumer rules).
-keep class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class * extends androidx.lifecycle.AndroidViewModel { <init>(android.app.Application); }
-keepattributes SourceFile,LineNumberTable
-dontwarn org.jetbrains.annotations.**
