package com.infinityclicker.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclicker.core.BigNum
import com.infinityclicker.data.GameRepository
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.data.StateSerializer
import com.infinityclicker.data.UserSettings
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.AchievementDefs
import com.infinityclicker.game.BackgroundDefs
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.ChallengeDefs
import com.infinityclicker.game.CrystalDefs
import com.infinityclicker.game.CosmicEventDefs
import com.infinityclicker.game.DailyMissionDefs
import com.infinityclicker.game.DimensionDefs
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.game.SkillTree
import com.infinityclicker.game.TapResult
import com.infinityclicker.audio.Sfx
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Ponte sincronizada entre o motor puro, persistência local e Compose. */
class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(app)
    private val lock = Any()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var engine: GameEngine? = null
    @Volatile private var settings = UserSettings()
    private var recovered = false
    private var buyMode = BuyMode.X1
    @Volatile private var offlineToShow: com.infinityclicker.game.OfflineReport? = null
    @Volatile private var notice: String? = null

    @Volatile private var activeTab = 0
    private var foreground = false
    private var loopJob: Job? = null
    private val tapHistory = ArrayDeque<Long>()
    @Volatile private var liveClicksPerSecond = 0
    @Volatile private var lastPublishAt = 0L

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            val loaded = repo.load()
            synchronized(lock) {
                engine = GameEngine(loaded.state)
                settings = loaded.settings
                recovered = loaded.recoveredFromBackup
            }
            SoundFx.configure(settings.soundEnabled, settings.musicEnabled)
            beginSessionIfReady()
        }
    }

    // ------------------------------------------------------------ ciclo de vida

    fun onForeground() {
        foreground = true
        beginSessionIfReady()
    }

    fun onBackground() {
        foreground = false
        loopJob?.cancel()
        loopJob = null
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
    }

    private fun beginSessionIfReady() {
        if (!foreground || loopJob != null) return
        val text = synchronized(lock) {
            val e = engine ?: return
            val now = System.currentTimeMillis()
            val report = e.applyOffline(now)
            e.refreshDaily(now)
            if (report != null && report.creditedMs >= MIN_OFFLINE_REPORT_MS) offlineToShow = report
            serializeLocked(e, now)
        }
        ioScope.launch { repo.saveText(text) }
        publish(includeShop = true)
        startLoop()
    }

    private fun startLoop() {
        loopJob = viewModelScope.launch(Dispatchers.Default) {
            var last = SystemClock.elapsedRealtime()
            var sinceSave = 0L
            var sincePublish = 0L
            var publishes = 0
            while (isActive) {
                delay(ENGINE_TICK_MS)
                val nowElapsed = SystemClock.elapsedRealtime()
                val dt = nowElapsed - last
                last = nowElapsed
                val wall = System.currentTimeMillis()
                synchronized(lock) {
                    engine?.advance(dt, wall)
                    engine?.decayCombo(nowElapsed)
                }
                sinceSave += dt
                if (sinceSave >= AUTOSAVE_MS) {
                    sinceSave = 0L
                    saveNow()
                }
                // O motor é baseado em tempo (dt), então não precisa rodar na taxa da tela. Os números
                // só são publicados na cadência abaixo: publicar a cada 8–17 ms recompunha a tela inteira
                // 60–120×/s e era o que travava a rolagem. As animações (Canvas) têm relógio próprio.
                sincePublish += dt
                if (sincePublish >= currentPublishMs()) {
                    sincePublish = 0L
                    publishes++
                    publish(includeShop = activeTab == 1 && publishes % 3 == 0, full = activeTab == 2 || activeTab == 4 || publishes % 15 == 0)
                }
            }
        }
    }

    /** Intervalo entre publicações do estado: mais rápido onde há números mudando à vista. */
    private fun currentPublishMs(): Long = when {
        settings.batterySaver -> 250L
        activeTab == 0 -> 66L
        activeTab == 1 -> 100L
        else -> 200L
    }

    // ------------------------------------------------------------ ações econômicas

    /** Chamado na thread principal a cada toque; todos os toques válidos chegam ao motor. */
    fun tap(): TapResult? {
        val nowElapsed = SystemClock.elapsedRealtime()
        val result = synchronized(lock) {
            val outcome = engine?.tap(nowElapsed, System.currentTimeMillis())
            tapHistory.addLast(nowElapsed)
            while (tapHistory.isNotEmpty() && nowElapsed - tapHistory.first() > 1_000L) tapHistory.removeFirst()
            liveClicksPerSecond = tapHistory.size
            engine?.consumeChallengeCompletion()?.let { completion ->
                notice = "Desafio concluído: ${completion.name} · +${completion.energy} e +${completion.prestigePoints} PP."
            }
            outcome
        }
        if (result != null) {
            when {
                result.bossDefeated -> SoundFx.play(Sfx.BOSS_DOWN)
                result.crit -> SoundFx.play(Sfx.CRIT)
                // O tom sobe com o combo: tocar rápido soa cada vez mais agudo e recompensador.
                else -> SoundFx.play(Sfx.TAP, rate = 0.92f + 0.55f * (result.combo.coerceIn(0, 30) / 30f), volume = 0.8f)
            }
        }
        if (result?.bossDefeated == true) notice = "Chefe derrotado! +${result.bossReward} de energia e fragmentos."
        // Toques muito rápidos (autoclicker) não reconstroem a UI a cada toque: o laço publica em seguida.
        if (result?.bossDefeated == true || nowElapsed - lastPublishAt > MIN_TAP_PUBLISH_GAP_MS) publish(includeShop = false)
        return result
    }

    fun setActiveTab(tab: Int) {
        activeTab = tab.coerceIn(0, 5)
        publish(includeShop = activeTab == 1)
    }

    fun setBuyMode(mode: BuyMode) {
        buyMode = mode
        publish(includeShop = true)
    }

    fun buyGenerator(id: Int) {
        val ok = synchronized(lock) { engine?.buyGenerator(id, buyMode, System.currentTimeMillis()) == true }
        SoundFx.play(if (ok) Sfx.BUY else Sfx.ERROR)
        if (ok) saveAndPublish(shop = true)
    }

    fun buyUpgrade(id: String) {
        val ok = synchronized(lock) { engine?.buyUpgrade(id, buyMode, System.currentTimeMillis()) == true }
        SoundFx.play(if (ok) Sfx.BUY else Sfx.ERROR)
        if (ok) saveAndPublish(shop = true)
    }

    fun useAbility(id: String) {
        var challengeNotice: String? = null
        val result = synchronized(lock) {
            val used = engine?.useAbility(id, System.currentTimeMillis())
            engine?.consumeChallengeCompletion()?.let { completion ->
                challengeNotice = "Desafio concluído: ${completion.name} · +${completion.energy} e +${completion.prestigePoints} PP."
            }
            used
        }
        if (result?.used == true) {
            SoundFx.play(Sfx.ABILITY)
            notice = challengeNotice ?: if (result.gain > BigNum.ZERO) "Explosão Cósmica: +${result.gain}" else "${AbilityDefs.byId[id]?.name ?: "Habilidade"} ativada."
            saveAndPublish()
        }
    }

    fun upgradeAbility(id: String) {
        val ok = synchronized(lock) { engine?.upgradeAbility(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun buySkill(id: String) {
        val ok = synchronized(lock) { engine?.buySkill(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun unlockDimension(id: Int) {
        val ok = synchronized(lock) { engine?.unlockDimension(id) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Dimensão desbloqueada."
            saveAndPublish()
        }
    }

    fun travelDimension(id: Int) {
        val ok = synchronized(lock) { engine?.travelDimension(id, System.currentTimeMillis()) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Viagem dimensional concluída."
            saveAndPublish()
        }
    }

    fun buyResonance(id: Int) {
        val ok = synchronized(lock) { engine?.buyResonance(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun startBoss() {
        val result = synchronized(lock) { engine?.startBoss(System.currentTimeMillis()) }
        if (result?.started == true) {
            SoundFx.play(Sfx.BOSS_START)
            notice = "Chefe manifestado. Seus cliques agora causam dano."
            saveAndPublish()
        }
    }

    fun equipCrystal(id: Int) {
        val ok = synchronized(lock) { engine?.equipCrystal(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.UNLOCK)
        if (ok) saveAndPublish()
    }

    fun equipBackground(id: Int) {
        val ok = synchronized(lock) { engine?.equipBackground(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.UNLOCK)
        if (ok) saveAndPublish()
    }

    fun startChallenge(id: String) {
        val ok = synchronized(lock) { engine?.startChallenge(id, System.currentTimeMillis()) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Desafio iniciado. O prazo continua válido mesmo se você sair do app."
            saveAndPublish()
        }
    }

    fun abandonChallenge() {
        val ok = synchronized(lock) { engine?.abandonChallenge() == true }
        if (ok) saveAndPublish()
    }

    fun claimDaily(index: Int) {
        val reward = synchronized(lock) { engine?.claimDaily(index, System.currentTimeMillis()) }
        if (reward != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Missão concluída: +$reward de energia."
            saveAndPublish()
        }
    }

    fun claimLogin() {
        val reward = synchronized(lock) { engine?.claimLogin(System.currentTimeMillis()) }
        if (reward != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Recompensa de login recebida: +$reward."
            saveAndPublish()
        }
    }

    fun claimAchievement(id: String) {
        val points = synchronized(lock) { engine?.claimAchievement(id, System.currentTimeMillis()) }
        if (points != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Conquista resgatada: +$points pontos de prestígio."
            saveAndPublish()
        }
    }

    fun prestige() {
        val result = synchronized(lock) { engine?.prestige(System.currentTimeMillis()) }
        if (result != null) {
            SoundFx.play(Sfx.PRESTIGE)
            notice = "Renascimento completo: +${result.pointsGained} pontos de prestígio."
            saveAndPublish(shop = true)
        }
    }

    // ------------------------------------------------------------ preferências e recuperação

    fun dismissOfflineReport() {
        offlineToShow = null
        publish(includeShop = false)
    }

    fun dismissNotice() {
        notice = null
        publish(includeShop = false)
    }

    fun setScientific(enabled: Boolean) = updateSettings { it.copy(scientificNotation = enabled) }
    fun setGraphicsQuality(quality: GraphicsQuality) = updateSettings { it.copy(graphicsQuality = quality) }
    fun setFrameRate(cap: Int) = updateSettings {
        it.copy(frameRateCap = if (cap in setOf(30, 60, 90, 120)) cap else 60)
    }
    fun setBatterySaver(enabled: Boolean) = updateSettings { it.copy(batterySaver = enabled) }
    fun setEffectsIntensity(value: Float) = updateSettings { it.copy(effectsIntensity = value.coerceIn(0.25f, 1.5f)) }
    fun setPanelOpacity(value: Float) = updateSettings { it.copy(panelOpacity = value.coerceIn(0.06f, 0.30f)) }
    fun setHaptics(enabled: Boolean) = updateSettings { it.copy(hapticsEnabled = enabled) }
    fun setSound(enabled: Boolean) = updateSettings { it.copy(soundEnabled = enabled) }
    fun setMusic(enabled: Boolean) = updateSettings { it.copy(musicEnabled = enabled) }

    private fun updateSettings(transform: (UserSettings) -> UserSettings) {
        settings = transform(settings)
        val snapshot = settings
        SoundFx.configure(snapshot.soundEnabled, snapshot.musicEnabled)
        ioScope.launch { repo.saveSettings(snapshot) }
        publish(includeShop = false)
    }

    /** Apaga o save local somente depois da confirmação feita pela tela. */
    fun hardReset() {
        val text = synchronized(lock) {
            val fresh = GameState.new()
            fresh.lastSessionMs = System.currentTimeMillis()
            val freshEngine = GameEngine(fresh)
            engine = freshEngine
            serializeLocked(freshEngine, System.currentTimeMillis())
        }
        offlineToShow = null
        notice = "Novo universo criado."
        ioScope.launch { repo.replaceAll(text) }
        publish(includeShop = true)
    }

    /** Texto assinado por checksum que pode ser salvo pelo seletor de arquivos do Android. */
    fun exportSaveText(): String? = snapshotForSave()

    /** Importa apenas textos que passam no checksum/versionamento; o save atual vira backup local. */
    fun importSaveText(text: String) {
        val imported = StateSerializer.deserialize(text)
        if (imported == null) {
            notice = "Arquivo inválido ou corrompido; seu progresso atual foi preservado."
            publish(includeShop = false)
            return
        }
        val serialized = synchronized(lock) {
            val restored = GameEngine(imported)
            engine = restored
            offlineToShow = null
            recovered = false
            serializeLocked(restored, System.currentTimeMillis())
        }
        ioScope.launch { repo.importText(serialized) }
        notice = "Progresso importado com segurança. O save anterior ficou no backup local."
        publish(includeShop = activeTab == 1)
    }

    fun reportExportResult(success: Boolean) {
        notice = if (success) "Backup exportado com sucesso." else "Não foi possível exportar o backup; seu save local continua intacto."
        publish(includeShop = false)
    }

    fun reportImportReadFailure() {
        notice = "Não foi possível ler o arquivo selecionado; seu progresso atual foi preservado."
        publish(includeShop = false)
    }

    // ------------------------------------------------------------ internos

    private fun saveAndPublish(shop: Boolean = false) {
        saveNow()
        publish(includeShop = shop || activeTab == 1)
    }

    private fun saveNow() {
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
    }

    private fun snapshotForSave(): String? = synchronized(lock) {
        val e = engine ?: return@synchronized null
        serializeLocked(e, System.currentTimeMillis())
    }

    private fun serializeLocked(e: GameEngine, now: Long): String {
        e.state.lastSessionMs = now
        e.state.lastModifiedMs = now
        e.state.saveRevision++
        return StateSerializer.serialize(e.state)
    }

    /**
     * [full] = false (usado pelo laço de 66 ms) reaproveita dimensões, cristais e fundos do estado anterior:
     * eles só mudam por ações do jogador (que publicam com full = true), por desbloqueios automáticos
     * (revalidados a cada ~1 s) ou enquanto a aba que os mostra está aberta.
     */
    private fun publish(includeShop: Boolean, full: Boolean = true) {
        lastPublishAt = SystemClock.elapsedRealtime()
        val next = synchronized(lock) {
            val e = engine ?: return
            val s = e.state
            val now = System.currentTimeMillis()
            e.refreshTimedEffects(now)
            e.refreshDaily(now)
            val previous = _ui.value
            val showMissions = activeTab == 3
            val showProfile = activeTab == 4
            val generators = if (includeShop) {
                GeneratorDefs.all.map { def ->
                    val owned = s.generators[def.id]
                    val unit = e.unitProduction(def)
                    GeneratorRow(
                        def = def,
                        owned = owned,
                        plan = e.planGenerator(def, buyMode),
                        unitProduction = unit,
                        totalProduction = unit * BigNum.of(owned),
                        unlocked = e.isGeneratorUnlocked(def.id),
                        nextMilestone = (owned / e.milestoneStep() + 1) * e.milestoneStep()
                    )
                }
            } else previous.generators
            val upgrades = if (includeShop) {
                UpgradeDefs.all.map { def ->
                    val level = s.level(def.id)
                    UpgradeRow(def, level, e.isUnlocked(def.requirement), level >= def.maxLevel, e.planUpgrade(def, buyMode))
                }
            } else previous.upgrades

            // A árvore (100 nós) e a galeria (250 itens) só são reconstruídas quando visíveis.
            // Isso impede trabalho de Compose a cada frame da tela inicial.
            val skills = if (showProfile) SkillTree.all.map { def ->
                SkillNodeUi(def, s.skillLevel(def.id), e.canBuySkill(def.id), def.prerequisites.all { s.skillLevel(it) > 0 })
            } else previous.skills
            val abilities = AbilityDefs.all.map { def ->
                AbilityUi(
                    def = def,
                    level = e.abilityLevel(def.id),
                    canUse = e.canUseAbility(def.id, now),
                    activeRemainingMs = (e.abilityActiveUntil(def.id) - now).coerceAtLeast(0L),
                    cooldownRemainingMs = (e.abilityCooldownUntil(def.id) - now).coerceAtLeast(0L),
                    canUpgrade = e.canUpgradeAbility(def.id)
                )
            }
            val dimensions = if (!full && previous.dimensions.isNotEmpty()) previous.dimensions else DimensionDefs.all.map { def ->
                DimensionUi(
                    def = def,
                    unlocked = s.dimensionUnlocked[def.id],
                    canUnlock = e.canUnlockDimension(def.id),
                    unlockRequirement = e.dimensionRequirement(def.id),
                    current = s.currentDimension == def.id,
                    shards = s.dimensionShards[def.id],
                    resonance = s.dimensionResonance[def.id],
                    resonanceCost = e.resonanceCost(def.id),
                    bossWins = s.bossWins[def.id]
                )
            }
            val crystals = if (!full && previous.crystals.isNotEmpty()) previous.crystals else CrystalDefs.all.map { CrystalUi(it, s.crystalsUnlocked[it.id], s.equippedCrystal == it.id) }
            val backgrounds = if (!full && previous.backgrounds.isNotEmpty()) previous.backgrounds else BackgroundDefs.all.map { BackgroundUi(it, s.backgroundsUnlocked[it.id], s.equippedBackground == it.id) }
            val boss = s.activeBoss?.takeIf { it.deadlineMs > now }?.let { active ->
                val def = DimensionDefs.byId(active.dimensionId)
                BossUi(active, def.bossHealth * (1.0 + s.bossWins[def.id] * 0.35), (active.deadlineMs - now).coerceAtLeast(0L))
            }
            val activeEvent = s.activeEvent?.takeIf { it.endsAtMs > now }?.let { active ->
                CosmicEventDefs.byId[active.eventId]?.let { CosmicEventUi(it, (active.endsAtMs - now).coerceAtLeast(0L)) }
            }
            val missions = if (showMissions) DailyMissionDefs.all.mapIndexed { index, def ->
                val progress = s.dailyProgress[index]
                DailyMissionUi(def, progress, s.dailyClaimed[index], !s.dailyClaimed[index] && progress >= def.target)
            } else previous.dailyMissions
            val challenges = if (showMissions) ChallengeDefs.all.mapIndexed { index, def ->
                val active = s.activeChallenge
                ChallengeUi(
                    def = def,
                    available = active == null && def.available(s),
                    active = active?.challengeId == def.id,
                    progress = if (active?.challengeId == def.id) active.progress else 0L,
                    remainingMs = if (active?.challengeId == def.id) (active.deadlineMs - now).coerceAtLeast(0L) else 0L,
                    wins = s.challengeWins[index]
                )
            } else previous.challenges
            val achievements = if (showMissions) AchievementDefs.all.map { def ->
                val unlocked = def.id in s.achievementsUnlockedAt || def.achieved(s)
                AchievementUi(
                    def = def,
                    unlocked = unlocked,
                    claimed = def.id in s.achievementsClaimed,
                    canClaim = e.canClaimAchievement(def.id),
                    progress = def.progress(s),
                    unlockedAtMs = s.achievementsUnlockedAt[def.id]
                )
            } else previous.achievements

            UiState(
                loaded = true,
                energy = s.energy,
                production = e.production,
                clickGain = e.baseClickGain(),
                critChance = e.critChance,
                critMultiplier = e.critMultiplier,
                combo = e.comboCount,
                maxCombo = e.maxCombo,
                comboMultiplier = e.comboMultiplier(),
                buyMode = buyMode,
                generators = generators,
                upgrades = upgrades,
                skills = skills,
                abilities = abilities,
                dimensions = dimensions,
                crystals = crystals,
                backgrounds = backgrounds,
                activeBoss = boss,
                activeEvent = activeEvent,
                challenges = challenges,
                dailyMissions = missions,
                achievements = achievements,
                loginReward = e.loginRewardPreview(now),
                loginStreak = s.loginStreak,
                prestige = e.prestigePreview(),
                stats = StatsUi(
                    totalClicks = s.totalClicks,
                    critClicks = s.critClicks,
                    maxCombo = s.maxCombo,
                    generatorsBought = s.generatorsBought,
                    upgradeLevelsBought = s.upgradeLevelsBought,
                    playTimeMs = s.playTimeMs,
                    totalEnergy = s.totalEnergy,
                    runEnergy = s.runEnergy,
                    offlineEarned = s.offlineEarned,
                    prestigePoints = s.prestigePoints,
                    prestigeCount = s.prestigeCount,
                    abilitiesUsed = s.abilitiesUsed,
                    bossWins = s.bossWins.sum(),
                    clicksPerSecond = liveClicksPerSecond,
                    highestTapMultiplier = s.highestTapMultiplier,
                    highestProduction = s.highestProduction,
                    clickEnergy = s.clickEnergy,
                    productionEnergy = s.productionEnergy,
                    eventsTriggered = s.eventsTriggered,
                    challengeCompletions = s.challengeCompletions,
                    achievementsUnlocked = s.achievementsUnlockedAt.size,
                    achievementsClaimed = s.achievementsClaimed.size,
                    completionFraction = s.achievementsClaimed.size.toFloat() / AchievementDefs.all.size.toFloat()
                ),
                tutorialStep = s.tutorialStep,
                settings = settings,
                offlineReport = offlineToShow,
                recoveredFromBackup = recovered,
                notice = notice
            )
        }
        _ui.value = next
    }

    override fun onCleared() {
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
        super.onCleared()
    }

    private companion object {
        const val AUTOSAVE_MS = 10_000L
        const val ENGINE_TICK_MS = 33L
        const val MIN_TAP_PUBLISH_GAP_MS = 45L
        const val MIN_OFFLINE_REPORT_MS = 60_000L
    }
}
