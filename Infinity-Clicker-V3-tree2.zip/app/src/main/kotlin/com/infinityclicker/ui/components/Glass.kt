package com.infinityclicker.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Vidro líquido de baixo custo: transparência real, camada de sombra, refração simulada e reflexo
 * diagonal. O blur global foi evitado deliberadamente porque degrada o Galaxy A54; cada painel
 * continua sendo uma camada pequena e previsível para a GPU.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    borderAlpha: Float = 0.38f
): Modifier = this
    .shadow(14.dp, shape, ambientColor = tint.copy(alpha = 0.20f), spotColor = Color.Black.copy(alpha = 0.48f))
    .clip(shape)
    .background(
        Brush.linearGradient(
            0f to Color.White.copy(alpha = (alpha * 0.32f + 0.04f).coerceAtMost(0.18f)),
            0.24f to tint.copy(alpha = (alpha + 0.10f).coerceAtMost(0.42f)),
            0.66f to tint.copy(alpha = (alpha * 0.46f).coerceAtMost(0.25f)),
            1f to Color(0xFF050616).copy(alpha = (alpha * 0.72f).coerceAtLeast(0.05f))
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = borderAlpha.coerceIn(0f, 0.9f)),
                Color.White.copy(alpha = 0.06f),
                tint.copy(alpha = (borderAlpha * 0.74f).coerceIn(0f, 0.8f))
            )
        ),
        shape
    )

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier.glass(tint = tint, alpha = alpha).padding(14.dp),
        content = content
    )
}
