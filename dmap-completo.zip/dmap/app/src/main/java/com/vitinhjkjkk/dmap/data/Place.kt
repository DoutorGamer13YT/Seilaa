package com.vitinhjkjkk.dmap.data

data class Place(
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val category: String = "",
)
