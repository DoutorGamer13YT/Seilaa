package dev.atlas.network

import dev.atlas.core.AppException
import dev.atlas.core.ErrorKind
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal fun validatedBaseUrl(raw: String): HttpUrl {
    val url = raw.toHttpUrlOrNull()
        ?: throw AppException(ErrorKind.INVALID_INPUT, "O endereço do serviço está inválido.")
    if (!url.isHttps || url.username.isNotEmpty() || url.password.isNotEmpty() ||
        url.fragment != null || url.query != null) {
        throw AppException(ErrorKind.INVALID_INPUT, "Configure um endereço HTTPS válido para o serviço.")
    }
    return url.newBuilder().apply {
        if (!url.encodedPath.endsWith('/')) addPathSegment("")
    }.build()
}

internal class ProviderHttp(client: OkHttpClient) {
    private val client = client.newBuilder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .followSslRedirects(false)
        .build()

    suspend fun execute(request: Request, allowRoutingErrorBody: Boolean = false): String = suspendCancellableCoroutine { continuation ->
        val call = client.newCall(request.newBuilder()
            .header("User-Agent", "AtlasAndroid/1.0 (dev.atlas; personal maps client)")
            .header("Accept", "application/json")
            .build())
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!continuation.isActive) return
                val message = if (e is SocketTimeoutException || e.message?.contains("timeout", true) == true)
                    "O serviço demorou para responder. Tente novamente."
                else "Não foi possível conectar. Verifique sua conexão e tente novamente."
                continuation.resumeWithException(AppException(ErrorKind.NETWORK, message, e))
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val result = response.use {
                        if (!response.isSuccessful && !(allowRoutingErrorBody && response.code in setOf(400, 404))) throw when (response.code) {
                            429 -> AppException(ErrorKind.RATE_LIMIT, "O serviço atingiu o limite de consultas. Aguarde antes de tentar novamente.")
                            401, 403 -> AppException(ErrorKind.MISSING_KEY, "A chave do serviço não foi aceita ou não tem acesso a este recurso.")
                            408, 504 -> AppException(ErrorKind.NETWORK, "O serviço demorou para responder. Tente novamente.")
                            else -> AppException(ErrorKind.PROVIDER, "O serviço está indisponível no momento. Tente novamente.")
                        }
                        val body = response.body ?: throw AppException(ErrorKind.PROVIDER, "O serviço enviou uma resposta vazia.")
                        val maxBytes = 8L * 1024 * 1024
                        if (body.contentLength() > maxBytes || body.source().request(maxBytes + 1))
                            throw AppException(ErrorKind.PROVIDER, "A resposta do serviço excedeu o tamanho permitido.")
                        body.string()
                    }
                    if (continuation.isActive) continuation.resume(result)
                } catch (e: Exception) {
                    if (!continuation.isActive) return
                    continuation.resumeWithException(when (e) {
                        is AppException -> e
                        is IOException -> AppException(ErrorKind.NETWORK, "A conexão foi interrompida. Tente novamente.", e)
                        else -> AppException(ErrorKind.PROVIDER, "Não foi possível ler a resposta do serviço.", e)
                    })
                }
            }
        })
    }
}

internal class RequestPacer(private val intervalMillis: Long) {
    private val mutex = Mutex()
    private var lastRequestNanos = 0L
    suspend fun awaitTurn() = mutex.withLock {
        val elapsed = (System.nanoTime() - lastRequestNanos) / 1_000_000
        if (lastRequestNanos != 0L && elapsed < intervalMillis) delay(intervalMillis - elapsed)
        lastRequestNanos = System.nanoTime()
    }
}

internal class ProviderCache<T>(private val capacity: Int, private val ttlMillis: Long, private val nanoTime: () -> Long = System::nanoTime) {
    private data class Entry<T>(val value: T, val created: Long)
    private val entries = LinkedHashMap<String, Entry<T>>(capacity, 0.75f, true)
    @Synchronized fun get(key: String, allowStale: Boolean = false): T? {
        val entry = entries[key] ?: return null
        val age = (nanoTime() - entry.created) / 1_000_000
        val maxAge = if (allowStale) 24 * 60 * 60 * 1000L else ttlMillis
        return entry.value.takeIf { age <= maxAge }
    }
    @Synchronized fun put(key: String, value: T) {
        entries[key] = Entry(value, nanoTime())
        while (entries.size > capacity) entries.remove(entries.keys.first())
    }
}
