# Otimizações V3.1

## Energia
- **EnergyGovernor** (novo, `ui/components/EnergyGovernor.kt`): escuta o status térmico do
  PowerManager e rebaixa o teto de FPS (120→60 no MODERATE, →30 em SEVERE/CRITICAL/EMERGENCY)
  antes do throttling do SoC. Integrado ao `GameApp`: `effectiveFps` passa a ser
  `min(configuração do usuário, teto térmico)`, e o plano de refresh rate é reaplicado a cada
  mudança térmica. BatterySaver manual continua forçando 30 fps.
- `gradle.properties`: `android.enableR8.fullMode=true` (menos código morto, cold start menor).

## Animações / desenho
- **Crystal**: cálculo das facetas sem alocação por quadro. `Point3`/`Facet` (data classes criadas
  a cada desenho) foram substituídos por `FacetScratch` (arrays reutilizados + selection sort,
  n ≤ 12). A ordem de pintura (painter's algorithm) é idêntica à anterior.
- **SpaceBackground**: cintilação das estrelas tabelada — 16 amostras de `sin()` pré-computadas por
  estrela; o desenho só indexa a rampa, sem `sin()` por estrela por quadro (mesma curva visual).

## Tela Dev
- `@vitinhjkjkk` continua sendo o handle exibido (Instagram do criador).

# Fluidez e animações (V3.3)
- Transições de aba/seção ~25% mais curtas (a aba que sai some em 70 ms; a nova entra com mola de desaceleração).
- Barra Liquid Glass: visibilidade lida só na camada (sem recompor o GameApp a cada quadro), lente sem relançar
  animação a cada evento de arraste, mola de assentamento mais firme e háptico ao tocar numa aba.
- Molas e curvas compartilhadas (bouncyClick, bumpOnChange, enterAnimation): nada é alocado por recomposição.
- Início: estilo do número de energia e textos de crítico/combo só são refeitos quando mudam.
- Loja: upgrades agrupados por categoria uma vez; Missões: listas de filtro e contagem memorizadas.
- Fundo: relógio a 60 fps (Ultra) / 40 (Alta) / 30, limitado pelo governador térmico.
- Feedback tátil: agora usa o Vibrator direto (novo `Haptics.kt` + permissão VIBRATE). O háptico do Compose
  não vibrava em vários aparelhos. Toque no cristal = pulso médio, crítico = forte, arrastar a barra = leve.
- Dimensões: texto de multiplicador local memorizado (sem formatar a cada atualização).

# Gráficos (V3.4)
- GlowBar: reflexo de luz que atravessa o preenchimento em laço (shader em espaço unitário, sem alocação por quadro).
- Cristal: rastro de cometa nos pontos orbitais e faixa de luz anamórfica que cresce com o combo (qualidade Alta+).
- Fundo: planeta distante com anel, sombreado e com borda iluminada (desenhado uma vez no cache; qualidade Média+).
- Estrelas: laço por índice (sem iterador por quadro).

# V3.3
- Versão agora vem de um só lugar (`AppInfo.VERSION_NUMBER`); `versionName`/`versionCode` são automáticos no Gradle.
- Novos `AGENTS.md` e `CLAUDE.md` + aviso no `AppInfo.kt`: toda IA deve aumentar a versão 1 vez a cada mudança.
- Lente da barra: dispersão de cor (fios ciano/rosa) no aro enquanto toca ou arrasta.

# V3.4
- Habilidades: a lista só é substituída quando algo realmente mudou (menos recomposição na tela inicial).
- Estrela cadente: cauda desenhada em segmentos, sem criar um Brush/shader novo por quadro.

# V3.5
- Estabilidade: o laço do motor e o toque no cristal agora têm rede de segurança. Um erro raro de cálculo descarta só
  aquele quadro (e avisa uma vez) em vez de fechar o app no meio da partida.

# V3.6
- Backup automático: `allowBackup` ligado com regras (`res/xml/backup_rules.xml`, `data_extraction_rules.xml`) que levam
  só o save (DataStore). O progresso volta ao reinstalar o app ou trocar de aparelho (backup do Google ligado no sistema).
- Economia de energia do sistema e "remover animações": o jogo entra sozinho no modo economia de bateria (novo
  `SystemMotion.kt`), sem alterar a configuração salva do jogador.

# Versão 3.7 — correções e loja mais inteligente
Correções:
- **Conquistas**: uma conquista já registrada como desbloqueada continua resgatável mesmo se o requisito cair depois
  (PP gastos na árvore, geradores zerados no prestígio). Antes aparecia como desbloqueada mas o botão não funcionava.
  `GameEngine.canClaimAchievement`.
- **Missões diárias e recompensa de login** agora viram à meia-noite do fuso do aparelho (antes era meia-noite UTC,
  21h no Brasil). `GameEngine.floorDay`. Na primeira abertura depois da atualização o dia pode mudar uma vez.
- **Cristal**: o detector de toque usava lambdas e partículas velhas depois de trocar a qualidade gráfica ou a
  notação científica. Agora usa `rememberUpdatedState` e o campo de partículas entra nas chaves do `pointerInput`.
- **Avisos** (chefe, Explosão Cósmica, missão, login, desafio) mostram os números no formato escolhido
  (antes saía o texto cru do BigNum, tipo `1.0e2`). `GameViewModel.fmt`.

Novo:
- **Melhor compra** na loja: o gerador que paga o próprio preço mais rápido recebe o selo "★ MELHOR COMPRA".
  O cálculo (`GameEngine.bestGeneratorId`) divide o preço de 1 unidade pelo ganho real de produção, incluindo o salto
  dos marcos ×2.
- **Tempo até poder comprar**: quando falta energia, o botão de compra do gerador mostra "em Xmin Ys"
  (`GameEngine.secondsUntilAffordable`). Sem produção, não mostra tempo.

Testes: `V37Test` (6 testes). Validados com kotlinc fora do Gradle em UTC e America/Sao_Paulo (84 aprovados).
Os arquivos de interface (Compose) não foram compilados em ambiente com Android SDK.

# Versão 3.8 — proteção contra relógio alterado e CI
- **Offline**: voltar a hora do aparelho não "recarrega" mais o ganho offline. A marca de fim de sessão só anda para
  frente (`GameEngine.touchSession`, usada em `applyOffline` e em todo salvamento). Marca mais de 48 h no futuro
  (hora errada por engano) é descartada para o offline não travar.
- **Missões diárias**: `refreshDaily` só avança o dia; voltar a hora não zera as missões já resgatadas.
- **Recompensa de login**: não pode ser resgatada de novo em um dia igual ou anterior ao último resgate.
- **CI** (`.github/workflows/build-apk.yml`): `android-actions/setup-android` voltou para `@v3`, versão que sei que existe
  (a `@v4` não pôde ser verificada).
- Teste antigo `offlineIgnoresRewoundClockAndNewGames` atualizado: ele exigia que a marca voltasse junto com o relógio.
- Novos testes `V38ClockTest` (3). Suíte pura: 87 aprovados em UTC e America/Sao_Paulo (kotlinc, fora do Gradle).

# Versão 3.9 — hora automática e nuvem em destaque como "em desenvolvimento"
- **Hora do celular, sincronizada com o país**: o jogo continua contando pelo relógio do aparelho (e pelo fuso dele),
  mas agora só confia nele quando o Android está com "Data e hora automáticas" e "Fuso horário automático" ligados
  (`data/DeviceClock.kt`, leitura de `Settings.Global.AUTO_TIME` e `AUTO_TIME_ZONE`, sem permissão e sem internet no jogo).
  Se o ajuste estiver manual: missões diárias, recompensa de login e ganho offline ficam pausados, aparece um aviso na
  tela Missões e uma mensagem ao abrir o jogo. A checagem é refeita sempre que o app volta ao primeiro plano e a cada
  tentativa de resgate. Se o Android não expuser os ajustes, o jogo assume "sincronizado" para não bloquear ninguém.
- `GameEngine.clockTrusted`: com hora manual, o dia das missões não avança (uma hora errada no futuro não trava os
  resets diários depois de corrigida).
- **Nuvem**: o grupo agora se chama "Nuvem · em desenvolvimento", tem uma linha dourada "Nuvem em desenvolvimento" com o
  selo EM DESENVOLVIMENTO, e as linhas de sincronização ficam esmaecidas com o selo INDISPONÍVEL / EM BREVE. Continua sem
  nenhum botão que finja funcionar: não existe servidor conectado.
- Teste novo `V39ClockTrustTest`. Suíte pura: 88 aprovados em UTC e America/Sao_Paulo (kotlinc, fora do Gradle).
  `DeviceClock`, `GameViewModel`, `MissionsScreen` e `CloudSyncGroup` não foram compilados com Android SDK.

# Versão 3.10 — cristal mais realista (`ui/components/Crystal.kt`)
Só desenho em Canvas, sem bitmap novo, sem blur e sem shader novo por quadro (reaproveita os brushes e o `PathPool` existentes):
- **Sombra de contato** sob o cristal: três elipses de alfa baixo formam uma penumbra suave na plataforma (todas as qualidades que desenham o pedestal).
- **Reflexo no vidro polido** (qualidade Alta/Ultra): a ponta do cristal toca primeiro o chão e abre para baixo, recortado pelo disco do pedestal.
- **Transmissão de luz**: a cor do cristal se acumula na parte de baixo, recortada pela silhueta, como luz atravessando um sólido translúcido.
- **Luz-chave do alto à esquerda**: a aresta voltada para a luz ganha reflexo de borda (Fresnel) mais claro, e a aresta oposta recebe um fio escuro que separa o cristal do fundo.
- O fundo já tinha vinheta, planeta com sombreamento, paralaxe e estrelas; não foi alterado.
- Não compilado com Android SDK; conferido à mão (imports `Rect`, `clipPath`, `StrokeCap` já existiam). Testes puros seguem em 88 aprovados.

# Versão 3.11 — evento raríssimo "Aurora Eterna"
- **Chance**: 0,001% (1 em 100 mil) a cada toque e a cada segundo de jogo. Cada sorteio usa gerador aleatório próprio
  (não altera a sequência dos críticos nem dos eventos comuns). Fica fora do sorteio dos eventos comuns, pode substituir
  um evento comum em andamento e não reinicia uma Aurora que já está acontecendo. Offline não sorteia.
- **Dura 90 s e muda tudo**: produção ×7, valor do toque ×5, chance de crítico +20 pontos (respeita o teto), força do combo
  +0,03 por toque e dano em chefes +150% (os bônus de evento das habilidades também valem). `GameEngine.recompute`, `eventBonus`.
- **Visual** (`ui/components/AuroraOverlay.kt`): cortinas de aurora onduladas, véu colorido e chuva de brilhos cobrem a
  tela atrás da interface (não captura toques, entra em 2,6 s e sai em 3,5 s), e o brilho do fundo troca de cor a cada 7 s
  (verde, violeta, rosa, ciano, dourado). Com economia de bateria ligada o desenho fica parado. Fora do evento o custo é ~0.
- **Aviso e som** ao começar: "✦ AURORA ETERNA!" + som de desbloqueio. O cartão de evento na tela inicial mostra nome e tempo restante.
- **Save**: usa o campo `activeEvent` que já existia (só o id novo `aurora_eterna`), então saves antigos continuam válidos.
- No motor puro a Aurora vem **desligada** (`auroraChance = 0`); o `GameViewModel` liga (`enableAurora()`) nos 3 pontos em que cria o
  motor. Assim os testes automáticos nunca disparam um evento aleatório (um teste estatístico de crítico falhou uma vez
  porque uma Aurora real disparou por sorte durante ~100 mil toques).
- Testes novos `V310AuroraTest` (4). Suíte pura: 92 aprovados, repetida 6 vezes (UTC e America/Sao_Paulo), kotlinc fora do Gradle.
  `AuroraOverlay`, `GameApp` e `GameViewModel` não foram compilados com Android SDK.

# Versão 3.12 — visual mais refinado e gráficos novos
- **Gráfico de energia** (novo, `ui/components/Charts.kt`): no Perfil, o cartão "De onde vem sua energia" mostra um anel de
  vidro com a fatia manual (cliques) e a automática (geradores), pontas arredondadas, brilho por baixo, fio de luz na borda
  e animação de mola. A legenda ao lado traz os valores.
- **Barras de renascimento** (`PointsBars`): o histórico de renascimentos ganhou barras com degradê e entrada escalonada,
  com a mais recente em destaque (últimos 12).
- **Fundos dos cenários** (`SpaceBackground.kt`): Galáxia Espiral agora tem braços de pontos que giram e núcleo luminoso;
  Buraco Negro ganhou brilho de acreção, anel de fótons e a metade da frente do disco cruzando o horizonte; Quântico tem nós
  pulsando nos cruzamentos da grade; Temporal tem marcas de relógio e ponteiro; Nebulosa tem nuvens extras; Realidade
  Transcendental tem estrela central em camadas com clarão em cruz.
- **Laço sem emenda**: as rotações dos fundos (buraco negro, temporal, quântico) agora fecham exatamente uma volta por
  período; antes davam um pequeno "pulo" quando o ciclo reiniciava.
- **Ícones**: o "⚠" do chefe e o "✦" do evento (que dependiam da fonte do aparelho) viraram ícones desenhados (`GlyphIcon`),
  iguais em qualquer celular.
- Não compilado com Android SDK (sem compilador neste ambiente): conferidos imports, chaves e assinaturas à mão.

# Versão 3.13 — virada de versão em 3.100 -> 4.0
- Regra nova: a parte depois do ponto só vai até 99. Quando a próxima versão seria `3.100`, ela passa a ser `4.0`
  (`3.99` -> `4.0`). Escrito em `AGENTS.md`, `CLAUDE.md`, `AppInfo.kt` e `app/build.gradle.kts`.
- Teste novo `VersionRolloverTest`: falha se o `VERSION_NUMBER` tiver parte depois do ponto maior que 99 e confere que
  o `versionCode` calculado de `4.0` é maior que o de `3.99`.

# Versão 3.14 — polimento de animações e fluidez
- **Compra com resposta**: o cartão da loja dá um clarão curto (~0,5 s) quando a compra é feita, junto do "pulinho" que o
  contador já dava (`Modifier.flashOnChange` em `Motion.kt`). A opacidade é lida só no desenho, sem recompor.
- **Rolagem rápida**: itens além do 6º de uma lista entram com animação mais curta (220 ms, subida de 10 dp) em vez de
  380 ms, então nada fica apagado esperando enquanto você rola a loja de 110 geradores.
- **Textos flutuantes dos cliques**: o cache de layout de texto do cristal subiu de 8 para 32 entradas. Com combo e críticos
  aparecem vários textos ao mesmo tempo; o cache pequeno recalculava o layout a cada quadro.
- Não compilado com Android SDK; conferidos imports e chaves à mão.

# Versão 3.15 — menos trabalho por quadro
- **GlowBar** (`Glass.kt`): o degradê do preenchimento era recriado (lista + shader) a cada quadro em toda barra com o brilho
  correndo. Agora o `Brush` é criado uma vez por cor e ocupa a largura do trecho desenhado, então o shader só é refeito se a
  largura mudar. Visual idêntico.
- **Ícone de missão/conquista** (`MissionsScreen.kt`): o brilho radial que pulsa usava um `Brush` novo por quadro. Passou a ser
  um brush em espaço unitário criado uma vez e só movido/escalado/alterado em opacidade.
- **Fundos**: os brilhos das estrelas da Galáxia Espiral e os nós pulsantes do cenário Quântico só aparecem em qualidade Alta
  ou Ultra; em Econômica/Média o fundo desenha bem menos primitivas por quadro.
- Não compilado com Android SDK; conferidos imports e chaves à mão. Quadros perdidos só dá para medir no aparelho.

# Versão 3.16 — menos alocação por quadro e menos trabalho na thread de toque
Pedido: otimização profunda (CPU/GPU/RAM/latência) **sem** mexer em FPS, mecânicas, saves nem qualidade visual.
Nenhum limite, configuração ou limitador de FPS foi tocado; nenhum efeito foi removido ou reduzido.

Gargalos encontrados na leitura do código e corrigidos:
- **Naves** (`Fleet.kt`): o `lerp` de cor do Compose converte para Oklab (cria objetos de conversão e faz `pow`/`cbrt`) e rodava
  3× por nave por quadro (+1 por passada de desenho), até ~86 chamadas por quadro com a frota cheia. As cores só dependem da
  cor-base do cristal, então são calculadas uma vez e refeitas só quando a cor-base muda. Cores idênticas.
- **Cristal** (`Crystal.kt`): mesmo problema, 14 `lerp` por quadro (2 + um por lado). Agora há uma tabela de 256 cores por
  cor-base (feita com o mesmo `lerp`, uma vez por cristal equipado); o desenho só indexa. Erro máximo da tabela: menos de meio
  nível de 8 bits (medido em simulação com 400 cores-base × 40 luzes: 0,45 nível).
- **Partículas** (`Physics.kt`): `draw`, `burst` e `forEachText` usavam `for (x in lista)`, que cria um `Iterator` por chamada
  (até 3 por quadro). Passaram a laços por índice. Mesma ordem e mesmo resultado.
- **Vibração** (`Haptics.kt`): cada toque (até ~33/s em autoclicker) alocava um `VibrationEffect` e chamava `vibrate()` — um
  binder síncrono — na thread de toque, antes de o cristal reagir. Os 3 efeitos agora são criados uma vez e o `vibrate()` roda
  numa thread própria (`haptics`). `hasVibrator()` também deixou de ser consultado a cada toque (em Android 10/11 é binder).
- **Música** (`SoundFx.kt`): o "diretor" rodava a cada 33 ms na thread principal e chamava `MediaPlayer.setVolume` (binder ao
  serviço de mídia) todas as vezes, mesmo com o volume parado. Agora só envia quando o volume mudou mais que 0,0015
  (inaudível). Em simulação do diretor (60 s): de 1819 chamadas para 26–78. A escada de notas do toque (`tapRate`) deixou de
  criar um `IntArray` por toque.
- **Barra de navegação** (`GameApp.kt`): cada ícone montava `Path`s, um `Stroke` e uma `List` a cada quadro em que a lente se
  movia. A geometria (grade 24×24) agora é criada uma vez.
- **Relatório offline** (`OfflineDialog.kt`): enquanto o relatório ficava aberto, cada quadro criava um `PathEffect`, um
  `Stroke` e um `Brush.sweepGradient` (shader nativo) novos. Agora são criados uma vez (o shader só é refeito se o centro mudar).

Não alterado de propósito: motor do jogo, `BigNum`, `NumberFormatter`, saves, FPS, blur/vidro, partículas, fundos.
Examinado e deixado como está (sem medição no aparelho não dá para provar ganho): brushes de vidro por painel (`glass`),
brushes da lente da barra de navegação, `Modifier.composed` (`bouncyClick`/`enterAnimation`), áudio sintetizado (`LayerSynth`).

Verificação: sem compilador Kotlin/Android SDK neste ambiente, então **não foi compilado** e o jogo não foi executado.
Conferidos à mão: imports, assinaturas e balanceamento de chaves/parênteses dos 7 arquivos editados. Os testes
(`PhysicsTest` exercita `burst`) não mudam de comportamento. Ganhos de quadros perdidos, CPU, GPU e RAM só dá para medir no
aparelho (Perfetto / Android Studio Profiler / dumpsys gfxinfo) com o APK release.

# Versão 3.17 — fluidez: menos trabalho na thread principal e menos recomposição
Pedido: otimização profunda sem mexer em FPS, limitadores, mecânicas, APIs, saves nem qualidade gráfica. Nada disso foi tocado.

- **Publicação do estado fora da thread principal** (`GameViewModel.publishAsync`): toque, troca de aba, mudança de quantidade de compra,
  ajustes (sliders) e avisos montavam o `UiState` (e, nas compras, serializavam o save inteiro) dentro da thread de toque/UI. Agora vão para
  `Dispatchers.Default`, com fusão de pedidos (rajada de toques ou de arraste de slider vira uma publicação só) e salvamento fundido nas
  compras em sequência. A revisão do save (`saveRevision`) continua garantindo a ordem das gravações.
- **GameApp parou de recompor ~15×/s**: a casca (fundo, barra, avisos, diálogo offline) lê só `ShellState` (recorte pequeno que quase não muda);
  cada tela lê o `UiState` completo por conta própria (`rememberScreenUi`). O humor da música é coletado fora da composição.
  `EnergyGovernor.thermalStatus` virou estado do Compose, então o teto térmico continua sendo reaplicado sem depender dessas recomposições.
- **Loja**: linhas idênticas à publicação anterior reaproveitam a mesma instância (`sameOrNew`), e a lista inteira é reaproveitada se nada mudou.
  Cartões que dá para comprar (ou bloqueados/no máximo) não recebem mais a energia atual, então não recompõem a cada publicação;
  formatador e animação de entrada são memorizados por cartão.
- **Partículas** (`Physics.kt`): `stepTo` limita o salto de tempo a 0,25 s. Ao voltar do segundo plano o relógio saltava minutos e a simulação
  rodava milhares de subpassos de uma vez (travada ao reabrir o app).
- **Controle segmentado** (`Settings.kt`): o degradê de brilho do indicador era um shader novo por quadro do deslize; agora é criado uma vez por tamanho.
- Examinado e deixado como está: motor (`GameEngine`), BigNum, vidro (`glass`), lente da barra (brushes dependem da velocidade a cada quadro),
  árvore de habilidades (pan/zoom já é só transformação de camada), fundos, aurora.
- Verificação: sem Android SDK neste ambiente. Os arquivos editados foram passados pelo kotlinc 2.0.21 só para checar sintaxe (sem erros
  de sintaxe; os demais erros são só as bibliotecas Android/Compose ausentes). Não compilado com Gradle e não medido no aparelho.

# Versão 3.18 — Missões, Dimensões e cristais com menos recomposição
- `GameViewModel`: missões diárias, desafios, conquistas (250), dimensões, cristais e fundos reaproveitam a instância das linhas que não mudaram
  (`reuseRows`). A lista de conquistas deixou de ser refiltrada e reordenada a cada publicação (200 ms) e os cartões iguais pulam a recomposição.
- `MissionsScreen` / `DimensionsScreen`: formatador memorizado e animação de entrada memorizada por item (antes eram objetos novos a cada
  recomposição, o que impedia o Compose de pular os cartões).
- Não compilado com Android SDK; só checagem de sintaxe com kotlinc.

# Versão 3.19 — rolagem das listas
- Loja, Missões e Dimensões: `contentType` em todas as listas preguiçosas. O Compose passa a reaproveitar a composição de cartões do mesmo tipo
  ao rolar (em vez de compor do zero cada cartão que entra), o que reduz travadas na rolagem rápida.
- `enterAnimation`: itens fundos da lista (que entram durante a rolagem) começam com 40% de opacidade em vez de 0%, então não "pipocam" na tela.
- Não compilado com Android SDK; só checagem de sintaxe com kotlinc.

# Versão 3.20 — correção: planeta sobrepondo as telas
- `SpaceBackground`: o planeta distante (com anel) ficava no meio da tela (x 94%, y 64%, raio 17% da largura) e aparecia através dos cartões de
  vidro em todas as abas. Agora é menor (raio 13%) e fica encostado no canto inferior direito, atrás da barra de navegação. Mesmo desenho e
  mesma qualidade (Média+); só a posição e o tamanho mudaram. Não compilado com Android SDK.

# Versão 3.21 — planeta removido do fundo
- `SpaceBackground`: o planeta com anel deixou de ser desenhado. Mesmo no canto, a esfera e o anel apareciam através dos cartões de vidro.
  As variáveis do planeta ficaram sem uso (não afetam o resultado). Não compilado com Android SDK.
