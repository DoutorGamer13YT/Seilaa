package com.infinityclicker.ui.screens

import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.infinityclicker.ui.components.GlowBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.game.AchievementCategory
import com.infinityclicker.game.Rarity
import com.infinityclicker.ui.AchievementUi
import com.infinityclicker.ui.ChallengeUi
import com.infinityclicker.ui.DailyMissionUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.color

@Composable
fun MissionsScreen(
    ui: UiState,
    onClaimDaily: (Int) -> Unit,
    onClaimLogin: () -> Unit,
    onClaimAchievement: (String) -> Unit,
    onStartChallenge: (String) -> Unit,
    onAbandonChallenge: () -> Unit
) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    var categoryFilter by rememberSaveable { mutableIntStateOf(0) }
    var rarityFilter by rememberSaveable { mutableIntStateOf(0) }
    val categoryOptions = listOf("Todas") + AchievementCategory.entries.map { it.label }
    val rarityOptions = listOf("Todas") + Rarity.entries.map { it.label }
    val filteredAchievements = ui.achievements.filter { row ->
        (categoryFilter == 0 || row.def.category == AchievementCategory.entries[categoryFilter - 1]) &&
            (rarityFilter == 0 || row.def.rarity == Rarity.entries[rarityFilter - 1])
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Text("Missões", color = Neon.TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Objetivos locais são resetados por dia e cada recompensa é registrada uma única vez.", color = Neon.TextSecondary, fontSize = 13.sp)
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
                Text("Galeria de conquistas", color = Neon.Violet, fontWeight = FontWeight.Bold)
                Text("${ui.stats.achievementsClaimed}/${ui.achievements.size} resgatadas · ${ui.stats.achievementsUnlocked} desbloqueadas", color = Neon.TextSecondary, fontSize = 12.sp)
                GlowBar(
                    progress = { ui.stats.completionFraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                    color = Neon.Violet, trackColor = Color.White.copy(alpha = .12f)
                )
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), tint = Neon.Gold, alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Sequência de login", color = Neon.Gold, fontWeight = FontWeight.Bold)
                        Text("Dia ${ui.loginStreak.coerceAtLeast(1)} · recompensa diária", color = Neon.TextSecondary, fontSize = 12.sp)
                    }
                    Button(
                        onClick = onClaimLogin, enabled = !ui.loginReward.isZero,
                        colors = ButtonDefaults.buttonColors(containerColor = Neon.Gold.copy(alpha = 0.85f), contentColor = Neon.Bg)
                    ) { Text(if (ui.loginReward.isZero) "Coletada" else "+${f(ui.loginReward)}", fontSize = 11.sp) }
                }
            }
        }
        item { Text("Diárias", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp)) }
        itemsIndexed(ui.dailyMissions, key = { _, row -> row.def.id }) { index, row ->
            DailyCard(row, ::f, ui.settings.panelOpacity) { onClaimDaily(index) }
        }
        item { Text("Desafios cósmicos", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
        itemsIndexed(ui.challenges, key = { _, row -> row.def.id }) { _, row ->
            ChallengeCard(row, ui.settings.panelOpacity, onStartChallenge, onAbandonChallenge)
        }
        item { Text("Conquistas", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
        item {
            FilterStrip(categoryOptions, categoryFilter) { categoryFilter = it }
            FilterStrip(rarityOptions, rarityFilter, tintByIndex = true) { rarityFilter = it }
        }
        itemsIndexed(filteredAchievements, key = { _, row -> row.def.id }) { _, row ->
            AchievementCard(row, ui.settings.panelOpacity) { onClaimAchievement(row.def.id) }
        }
    }
}

@Composable
private fun DailyCard(row: DailyMissionUi, f: (com.infinityclicker.core.BigNum) -> String, alpha: Float, onClaim: () -> Unit) {
    val fraction = (row.progress.toFloat() / row.def.target).coerceIn(0f, 1f)
    GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(row.def.title, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text("${row.progress}/${row.def.target}", color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text("+${f(row.def.reward)}", color = Neon.Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        GlowBar(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
            color = Neon.Cyan, trackColor = Color.White.copy(alpha = 0.12f)
        )
        Button(
            onClick = onClaim, enabled = row.canClaim, modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Neon.Cyan.copy(alpha = 0.80f), contentColor = Neon.Bg)
        ) { Text(if (row.claimed) "Recompensa coletada" else if (row.canClaim) "Coletar recompensa" else "Progresso insuficiente", fontSize = 12.sp) }
    }
}

@Composable
private fun ChallengeCard(row: ChallengeUi, alpha: Float, onStart: (String) -> Unit, onAbandon: () -> Unit) {
    val fraction = (row.progress.toFloat() / row.def.target.toFloat()).coerceIn(0f, 1f)
    GlassCard(Modifier.fillMaxWidth(), tint = if (row.active) Neon.Pink else Neon.Gold, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(row.def.name, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text(row.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text("${row.wins}×", color = Neon.Gold, fontWeight = FontWeight.Bold)
        }
        if (row.active) {
            Text("${row.progress}/${row.def.target} · ${NumberFormatter.duration(row.remainingMs)}", color = Neon.Pink, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            GlowBar(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), color = Neon.Pink, trackColor = Color.White.copy(alpha = .12f))
        }
        Button(
            onClick = if (row.active) onAbandon else { { onStart(row.def.id) } },
            enabled = row.active || row.available,
            modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
            colors = ButtonDefaults.buttonColors(containerColor = (if (row.active) Neon.Pink else Neon.Gold).copy(alpha = .82f), contentColor = Neon.Bg)
        ) { Text(if (row.active) "Abandonar desafio" else if (row.available) "Iniciar desafio" else "Indisponível", fontSize = 12.sp) }
    }
}

@Composable
private fun FilterStrip(options: List<String>, selected: Int, tintByIndex: Boolean = false, onSelect: (Int) -> Unit) {
    LazyRow(Modifier.padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(options) { index, label ->
            val active = index == selected
            val tint = if (tintByIndex && index > 0) Rarity.entries[index - 1].color() else Neon.Cyan
            Text(
                label,
                color = if (active) Neon.Bg else Neon.TextPrimary,
                fontSize = 11.sp,
                modifier = Modifier.bouncyClick { onSelect(index) }.glass(tint = tint, alpha = if (active) .82f else .08f)
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun AchievementCard(row: AchievementUi, alpha: Float, onClaim: () -> Unit) {
    val secretLocked = row.def.secret && !row.unlocked
    val tint = when {
        row.claimed -> Neon.Green
        secretLocked -> Neon.TextSecondary
        else -> row.def.rarity.color()
    }
    GlassCard(Modifier.fillMaxWidth(), tint = tint, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            AchievementEmblem(tint = tint, active = row.canClaim, secret = secretLocked)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(if (secretLocked) "Conquista secreta" else row.def.title, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text(if (secretLocked) "????" else row.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
                if (!secretLocked) {
                    Text(row.def.rarity.label + " · " + row.progress.label, color = tint, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    GlowBar(progress = { row.progress.fraction }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = tint, trackColor = Color.White.copy(alpha = .12f))
                }
            }
            Button(
                onClick = onClaim, enabled = row.canClaim,
                colors = ButtonDefaults.buttonColors(containerColor = tint.copy(alpha = 0.82f), contentColor = Neon.Bg)
            ) { Text(if (row.claimed) "Obtida" else if (row.canClaim) "+${row.def.reward} PP" else "Bloqueada", fontSize = 11.sp) }
        }
    }
}

/** Medalha vetorial para tornar cada conquista reconhecível sem carregar imagens adicionais. */
@Composable
private fun AchievementEmblem(tint: Color, active: Boolean, secret: Boolean) {
    val transition = rememberInfiniteTransition(label = "achievementEmblem")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (active) 360f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (active) 5_800 else 1_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "achievementOrbit"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.84f,
        targetValue = if (active) 1.08f else 0.84f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (active) 1_250 else 1_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "achievementPulse"
    )
    Canvas(Modifier.size(44.dp)) {
        val c = center
        val r = size.minDimension * 0.5f
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = 0.33f * pulse), Color.Transparent), c, r),
            radius = r,
            center = c
        )
        if (active) rotate(rotation, c) {
            drawArc(
                tint.copy(alpha = 0.72f), 12f, 92f, false,
                Offset(c.x - r * .86f, c.y - r * .86f), androidx.compose.ui.geometry.Size(r * 1.72f, r * 1.72f),
                style = Stroke(width = 1.7f)
            )
            drawArc(
                Color.White.copy(alpha = 0.52f), 192f, 54f, false,
                Offset(c.x - r * .72f, c.y - r * .72f), androidx.compose.ui.geometry.Size(r * 1.44f, r * 1.44f),
                style = Stroke(width = 1.2f)
            )
        }
        drawCircle(Color(0xFF0A0D1D).copy(alpha = 0.78f), r * .57f, c)
        drawCircle(Color.White.copy(alpha = 0.44f), r * .57f, c, style = Stroke(width = 1.2f))
        if (secret) {
            drawCircle(tint.copy(alpha = 0.78f), r * .13f, c)
            drawLine(tint.copy(alpha = 0.78f), Offset(c.x, c.y - r * .33f), Offset(c.x, c.y + r * .33f), 2.1f)
        } else {
            drawCircle(tint.copy(alpha = 0.95f), r * .18f, c)
            drawLine(Color.White.copy(alpha = 0.82f), Offset(c.x - r * .30f, c.y), Offset(c.x + r * .30f, c.y), 1.35f)
            drawLine(Color.White.copy(alpha = 0.82f), Offset(c.x, c.y - r * .30f), Offset(c.x, c.y + r * .30f), 1.35f)
        }
    }
}
