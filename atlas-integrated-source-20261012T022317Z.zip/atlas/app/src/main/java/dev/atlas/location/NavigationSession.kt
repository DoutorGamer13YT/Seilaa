package dev.atlas.location

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import dev.atlas.core.LocationFix
import dev.atlas.core.NavigationProgress
import dev.atlas.core.Route
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

data class NavigationState(
    val route: Route? = null,
    val progress: NavigationProgress? = null,
    val fix: LocationFix? = null,
    val muted: Boolean = false,
    val gpsLost: Boolean = true,
    val active: Boolean = false,
    val error: String? = null,
    val sessionId: Long = 0L,
    val recalculating: Boolean = false,
    val routeError: String? = null,
)

/** In-process state, deliberately not persisted: navigation never silently restarts after process death. */
object NavigationSession {
    private val mutableState = MutableStateFlow(NavigationState())
    private val sessionSequence = AtomicLong()
    val state: StateFlow<NavigationState> = mutableState.asStateFlow()

    /** Call only after an explicit user action while the activity is visible and permission is granted. */
    fun start(context: Context, route: Route, voice: Boolean) {
        if (!validRoute(route)) {
            mutableState.update { it.copy(error = "Esta rota não tem um traçado válido para navegação.") }
            return
        }
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            mutableState.update { it.copy(error = "Permita a localização para iniciar a navegação.") }
            return
        }
        val sessionId = sessionSequence.incrementAndGet()
        mutableState.value = NavigationState(route = route, muted = !voice, active = true, sessionId = sessionId)
        try {
            val intent = Intent(context, NavigationService::class.java).setAction(NavigationService.ACTION_START)
                .putExtra(NavigationService.EXTRA_SESSION_ID, sessionId)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        } catch (_: SecurityException) {
            fail("Permita a localização para iniciar a navegação.", sessionId)
        } catch (_: IllegalStateException) {
            fail("Abra o aplicativo para iniciar a navegação.", sessionId)
        }
    }

    fun updateRoute(route: Route, expectedSessionId: Long, expectedRoute: Route? = null): Boolean {
        if (!validRoute(route)) return false
        while (true) {
            val current = mutableState.value
            if (!current.active || current.sessionId != expectedSessionId ||
                (expectedRoute != null && current.route != expectedRoute)) return false
            val updated = current.copy(route = route, progress = null, recalculating = false, routeError = null)
            if (mutableState.compareAndSet(current, updated)) return true
        }
    }

    fun setMuted(muted: Boolean) { mutableState.update { it.copy(muted = muted) } }

    fun stop(context: Context) {
        mutableState.value = NavigationState(sessionId = sessionSequence.incrementAndGet())
        context.stopService(Intent(context, NavigationService::class.java))
    }

    internal fun update(transform: (NavigationState) -> NavigationState) = mutableState.update(transform)
    internal fun fail(message: String, sessionId: Long) {
        mutableState.update { if (it.sessionId == sessionId) it.copy(active = false, gpsLost = true, recalculating = false, error = message) else it }
    }
    internal fun serviceStopped(sessionId: Long) {
        mutableState.update { if (it.sessionId == sessionId) it.copy(active = false, gpsLost = true, recalculating = false) else it }
    }
    private fun validRoute(route: Route): Boolean = route.geometry.size >= 2 &&
        route.geometry.any { it != route.geometry.first() } &&
        route.distanceMeters.isFinite() && route.distanceMeters > 0 &&
        route.durationSeconds.isFinite() && route.durationSeconds >= 0
}
