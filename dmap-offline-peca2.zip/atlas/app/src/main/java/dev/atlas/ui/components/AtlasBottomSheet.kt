package dev.atlas.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.LocalAtlasColors
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class SheetPosition(val accessibilityLabel: String) {
    Collapsed("Recolhido"), Peek("Parcialmente expandido"), Half("Intermediário"), Expanded("Expandido")
}

@Composable
fun AtlasBottomSheet(
    position: SheetPosition,
    onPositionChange: (SheetPosition) -> Unit,
    modifier: Modifier = Modifier,
    reduceMotion: Boolean = false,
    onHeightChanged: (Float) -> Unit = {},
    content: @Composable () -> Unit,
) {
    val colors = LocalAtlasColors.current
    val density = LocalDensity.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()
    val currentOnPositionChange by rememberUpdatedState(onPositionChange)
    val currentOnHeightChanged by rememberUpdatedState(onHeightChanged)
    val bottomInset = maxOf(WindowInsets.navigationBars.getBottom(density), WindowInsets.ime.getBottom(density))
    val topInset = WindowInsets.statusBars.getTop(density)
    val keyboardVisible = WindowInsets.ime.getBottom(density) > WindowInsets.navigationBars.getBottom(density)

    BoxWithConstraints(modifier.fillMaxSize()) {
        val fullHeightPx = constraints.maxHeight.toFloat()
        val maxSheetHeight = (fullHeightPx - bottomInset - topInset - with(density) { 12.dp.toPx() }).coerceAtLeast(1f)
        val anchors = remember(maxSheetHeight, density) {
            val collapsed = minOf(with(density) { 128.dp.toPx() }, maxSheetHeight * 0.65f)
            val remaining = maxSheetHeight - collapsed
            val peek = minOf(with(density) { 290.dp.toPx() }, maxSheetHeight * 0.50f)
                .coerceIn(collapsed + remaining * 0.20f, collapsed + remaining * 0.60f)
            val half = maxOf(peek + remaining * 0.15f, maxSheetHeight * 0.72f).coerceAtMost(maxSheetHeight)
            linkedMapOf(SheetPosition.Collapsed to collapsed, SheetPosition.Peek to peek,
                SheetPosition.Half to half, SheetPosition.Expanded to maxSheetHeight)
        }
        val minimum = anchors.getValue(SheetPosition.Collapsed)
        val maximum = anchors.getValue(SheetPosition.Expanded)
        var heightPx by remember { mutableFloatStateOf(anchors.getValue(position)) }
        var animation by remember { mutableStateOf<Job?>(null) }
        var nestedDragConsumed by remember { mutableStateOf(false) }
        val visualHeight = heightPx.coerceIn(minimum, maximum)
        val effectivePosition = if (keyboardVisible) SheetPosition.Expanded else position

        fun stopAnimation() { animation?.cancel(); animation = null }
        fun animateHeight(target: Float, velocity: Float = 0f) {
            stopAnimation()
            if (reduceMotion) { heightPx = target; return }
            animation = scope.launch {
                Animatable(heightPx.coerceIn(minimum, maximum)).animateTo(
                    target, spring(dampingRatio = AtlasDimens.PanelDamping, stiffness = AtlasDimens.PanelStiffness),
                    initialVelocity = velocity,
                ) { heightPx = value.coerceIn(minimum, maximum) }
            }
        }
        fun moveBy(deltaY: Float): Float {
            stopAnimation()
            val previous = heightPx.coerceIn(minimum, maximum)
            heightPx = (previous - deltaY).coerceIn(minimum, maximum)
            return previous - heightPx
        }
        fun settle(velocityY: Float) {
            val current = heightPx.coerceIn(minimum, maximum)
            val stops = anchors.entries.toList()
            val fastFling = abs(velocityY) > with(density) { 650.dp.toPx() }
            val target = if (fastFling && velocityY < 0f) {
                stops.firstOrNull { it.value > current + 1f } ?: stops.last()
            } else if (fastFling) {
                stops.lastOrNull { it.value < current - 1f } ?: stops.first()
            } else {
                stops.minBy { abs(it.value - (current - velocityY * 0.10f)) }
            }
            if (keyboardVisible && target.key != SheetPosition.Expanded) keyboard?.hide()
            animateHeight(target.value, -velocityY)
            currentOnPositionChange(target.key)
        }

        LaunchedEffect(effectivePosition, anchors, reduceMotion) { animateHeight(anchors.getValue(effectivePosition)) }
        LaunchedEffect(visualHeight, bottomInset) { currentOnHeightChanged(visualHeight + bottomInset) }
        DisposableEffect(Unit) { onDispose { animation?.cancel() } }

        val nestedScroll = remember(anchors, reduceMotion, keyboardVisible) {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (source != NestedScrollSource.UserInput || available.y >= 0f || heightPx >= maximum) return Offset.Zero
                    val consumed = moveBy(available.y)
                    if (consumed != 0f) nestedDragConsumed = true
                    return Offset(0f, consumed)
                }
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (source != NestedScrollSource.UserInput || available.y <= 0f) return Offset.Zero
                    val amount = moveBy(available.y)
                    if (amount != 0f) nestedDragConsumed = true
                    return Offset(0f, amount)
                }
                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (!nestedDragConsumed) return Velocity.Zero
                    nestedDragConsumed = false
                    settle(available.y)
                    return Velocity(0f, available.y)
                }
                override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                    if (nestedDragConsumed) { nestedDragConsumed = false; settle(available.y); return Velocity(0f, available.y) }
                    return Velocity.Zero
                }
            }
        }
        val drag = rememberDraggableState { delta -> moveBy(delta) }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = with(density) { bottomInset.toDp() })
                .fillMaxWidth().height(with(density) { visualHeight.toDp() })
                .nestedScroll(nestedScroll)
                .draggable(state = drag, orientation = Orientation.Vertical,
                    onDragStarted = { stopAnimation() }, onDragStopped = { settle(it) }),
            shape = RoundedCornerShape(topStart = AtlasDimens.SheetRadius, topEnd = AtlasDimens.SheetRadius),
            color = colors.glass, border = BorderStroke(0.8.dp, colors.glassBorder), shadowElevation = 14.dp,
        ) {
            Column {
                Box(
                    Modifier.fillMaxWidth().height(48.dp).semantics {
                        contentDescription = "Painel de mapas"
                        stateDescription = effectivePosition.accessibilityLabel
                        if (effectivePosition != SheetPosition.Expanded) expand {
                            val next = SheetPosition.entries[(effectivePosition.ordinal + 1).coerceAtMost(3)]
                            currentOnPositionChange(next); true
                        }
                        if (effectivePosition != SheetPosition.Collapsed) collapse {
                            keyboard?.hide()
                            val next = SheetPosition.entries[(effectivePosition.ordinal - 1).coerceAtLeast(0)]
                            currentOnPositionChange(next); true
                        }
                    }, contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.width(36.dp).height(5.dp).background(colors.secondaryText.copy(alpha = 0.36f), RoundedCornerShape(3.dp)))
                }
                Box(Modifier.fillMaxWidth().weight(1f, fill = true)) { content() }
            }
        }
    }
}
