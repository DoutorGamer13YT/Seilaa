package dev.atlas.map

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.atlas.core.Coordinate
import dev.atlas.core.HeadingMath
import dev.atlas.core.LocationFix
import dev.atlas.core.MapOrientation
import dev.atlas.core.Place
import dev.atlas.core.Route
import dev.atlas.location.CompassState
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun AppleMap(
    modifier: Modifier = Modifier,
    token: String,
    origin: String,
    dark: Boolean,
    places: List<Place>,
    selectedPlace: Place?,
    route: Route?,
    location: LocationFix?,
    cameraRequest: CameraRequest?,
    bottomPaddingDp: () -> Float,
    reduceMotion: Boolean,
    onPlaceClick: (Place) -> Unit,
    onMapLongPress: (Coordinate) -> Unit,
    onCenterChanged: (Coordinate) -> Unit,
    onMapError: (String?) -> Unit,
    onUserGesture: () -> Unit = {},
    leftPaddingDp: Float = 0f,
    orientation: MapOrientation = MapOrientation.NORTH,
    compass: StateFlow<CompassState>? = null,
    navigating: Boolean = false,
    onBearingChanged: (Float) -> Unit = {},
    onUserRotated: () -> Unit = {},
    initialCamera: CameraSnapshot? = null,
    onCameraChanged: (CameraSnapshot) -> Unit = {},
    onUnavailable: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val click by rememberUpdatedState(onPlaceClick)
    val longPress by rememberUpdatedState(onMapLongPress)
    val centerChanged by rememberUpdatedState(onCenterChanged)
    val error by rememberUpdatedState(onMapError)
    val gesture by rememberUpdatedState(onUserGesture)
    val bearingChanged by rememberUpdatedState(onBearingChanged)
    val rotated by rememberUpdatedState(onUserRotated)
    val cameraChanged by rememberUpdatedState(onCameraChanged)
    val unavailable by rememberUpdatedState(onUnavailable)
    val controller = remember(context, token, origin) { AppleMapController(context, token, origin, initialCamera) }
    controller.placeClick = { click(it) }
    controller.longPress = { longPress(it) }
    controller.centerChanged = { centerChanged(it) }
    controller.mapError = { error(it) }
    controller.gesture = { gesture() }
    controller.bearingChanged = { bearingChanged(it) }
    controller.rotated = { rotated() }
    controller.cameraChanged = { cameraChanged(it) }
    controller.unavailable = { unavailable(it) }
    AndroidView(
        modifier = modifier,
        factory = { controller.view },
        update = {
            controller.update(AppleContent(dark, places, selectedPlace, route, location, cameraRequest,
                bottomPaddingDp(), leftPaddingDp, reduceMotion, orientation, navigating))
        },
    )
    if (compass != null) LaunchedEffect(controller, compass) {
        compass.collect { controller.onHeading(it.heading) }
    }
    DisposableEffect(controller, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> controller.resume()
                Lifecycle.Event.ON_PAUSE -> controller.pause()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        controller.resume()
        onDispose {
            lifecycle.removeObserver(observer)
            controller.destroy()
        }
    }
}

private data class AppleContent(
    val dark: Boolean, val places: List<Place>, val selected: Place?, val route: Route?,
    val location: LocationFix?, val camera: CameraRequest?, val bottomDp: Float, val leftDp: Float,
    val reduceMotion: Boolean, val orientation: MapOrientation, val navigating: Boolean,
)

@SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
private class AppleMapController(
    private val context: Context,
    private val token: String,
    private val origin: String,
    private val initialCamera: CameraSnapshot?,
) {
    val view = WebView(context)
    var placeClick: (Place) -> Unit = {}
    var longPress: (Coordinate) -> Unit = {}
    var centerChanged: (Coordinate) -> Unit = {}
    var mapError: (String?) -> Unit = {}
    var gesture: () -> Unit = {}
    var bearingChanged: (Float) -> Unit = {}
    var rotated: () -> Unit = {}
    var cameraChanged: (CameraSnapshot) -> Unit = {}
    var unavailable: (String) -> Unit = {}
    private val main = Handler(Looper.getMainLooper())
    private val pending = JSONObject()
    private var ready = false
    private var seeded = false
    private var destroyed = false
    private var content: AppleContent? = null
    private var lastPlaces: Pair<List<Place>, Place?>? = null
    private var lastRoute: Route? = null
    private var lastLocation: LocationFix? = null
    private var lastDark: Boolean? = null
    private var lastOrientation: MapOrientation? = null
    private var lastPadding: Pair<Int, Int>? = null
    private var lastCameraId: Long? = null
    private var lastHeading = Float.NaN
    private var lastCenter: Coordinate? = null
    private var sentAnimate: Boolean? = null
    private val timeout = Runnable {
        if (!destroyed && !ready) fail("timeout")
    }

    init {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        view.isVerticalScrollBarEnabled = false
        view.isHorizontalScrollBarEnabled = false
        view.overScrollMode = WebView.OVER_SCROLL_NEVER
        view.contentDescription = "Mapa interativo. Arraste para explorar; toque em um lugar para ver detalhes."
        view.addJavascriptInterface(Bridge(), "AtlasBridge")
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val scheme = request.url.scheme?.lowercase()
                return if (scheme == "https" || scheme == "data" || scheme == "blob" || scheme == "about") null
                else WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) main.post { fail("load-failed") }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                main.post { fail("render-process-gone") }
                return true
            }
        }
        val html = runCatching {
            context.assets.open("apple/mapkit.html").bufferedReader().use { it.readText() }
        }.getOrNull()
        if (html == null) {
            main.post { fail("asset-missing") }
        } else {
            val page = html
                .replace("__TOKEN__", JSONObject.quote(token).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))
                .replace("__LANGUAGE__", JSONObject.quote("pt-BR"))
            view.loadDataWithBaseURL(origin, page, "text/html", "utf-8", null)
            main.postDelayed(timeout, 15_000)
        }
        initialCamera?.let {
            pending.put("camera", JSONObject()
                .put("id", -1L).put("lat", it.latitude).put("lon", it.longitude)
                .put("zoom", it.zoom).put("bearing", it.bearing).put("animate", false))
        }
    }

    private fun fail(reason: String) {
        if (destroyed) return
        main.removeCallbacks(timeout)
        unavailable(reason)
    }

    fun resume() {
        if (!destroyed) view.onResume()
    }

    fun pause() {
        if (!destroyed) view.onPause()
    }

    fun destroy() {
        if (destroyed) return
        destroyed = true
        main.removeCallbacksAndMessages(null)
        view.removeJavascriptInterface("AtlasBridge")
        view.stopLoading()
        view.destroy()
    }

    fun update(next: AppleContent) {
        content = next
        if (!seeded) {
            seeded = true
            if (initialCamera != null) lastCameraId = next.camera?.id
        }
        if (destroyed) return
        val payload = JSONObject()
        if (lastDark != next.dark) { lastDark = next.dark; payload.put("dark", next.dark) }
        if (sentAnimate != !next.reduceMotion) { sentAnimate = !next.reduceMotion; payload.put("animate", !next.reduceMotion) }
        if (lastOrientation != next.orientation) { lastOrientation = next.orientation; payload.put("orientation", next.orientation.name) }
        val padding = Pair(next.leftDp.roundToInt(), next.bottomDp.roundToInt())
        val previousPadding = lastPadding
        if (previousPadding == null || abs(padding.second - previousPadding.second) >= 2 || padding.first != previousPadding.first) {
            lastPadding = padding
            payload.put("padding", JSONObject().put("top", 72).put("left", padding.first).put("bottom", padding.second))
        }
        val placeState = next.places to next.selected
        if (lastPlaces != placeState) {
            lastPlaces = placeState
            payload.put("places", JSONArray(next.places.filterNot { it.id == next.selected?.id }.take(250).map(::placeJson)))
            payload.put("selected", next.selected?.let(::placeJson) ?: JSONObject.NULL)
        }
        if (lastRoute != next.route) {
            lastRoute = next.route
            val geometry = next.route?.geometry.orEmpty()
            payload.put("route", JSONArray(if (geometry.size < 2) emptyList<JSONArray>() else geometry.map(::pair)))
            payload.put("waypoints", JSONArray(next.route?.waypoints.orEmpty().map(::pair)))
        }
        if (lastLocation != next.location) {
            lastLocation = next.location
            payload.put("location", next.location?.let {
                JSONObject().put("lat", it.coordinate.latitude).put("lon", it.coordinate.longitude)
                    .put("acc", it.accuracyMeters.toDouble())
            } ?: JSONObject.NULL)
        }
        next.camera?.takeIf { it.id != lastCameraId }?.let { request ->
            lastCameraId = request.id
            payload.put("camera", cameraJson(request, !next.reduceMotion))
        }
        if (payload.length() > 0) send(payload)
    }

    private fun send(payload: JSONObject) {
        if (!ready) {
            payload.keys().forEach { pending.put(it, payload.get(it)) }
            return
        }
        val script = "atlas.update(" + payload.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029") + ")"
        view.evaluateJavascript(script, null)
    }

    fun onHeading(heading: Float?) {
        if (!ready || destroyed) return
        val orientation = content?.orientation
        if (orientation != MapOrientation.COMPASS || heading == null) {
            if (!lastHeading.isNaN()) {
                lastHeading = Float.NaN
                view.evaluateJavascript("atlas.cone(null)", null)
            }
            return
        }
        if (lastHeading.isNaN() || abs(HeadingMath.shortestDelta(lastHeading, heading)) >= 1f) {
            lastHeading = heading
            view.evaluateJavascript("atlas.heading($heading)", null)
        }
    }

    private fun placeJson(place: Place) = JSONObject()
        .put("id", place.id).put("name", place.name)
        .put("lat", place.coordinate.latitude).put("lon", place.coordinate.longitude)

    private fun pair(point: Coordinate) = JSONArray().put(point.latitude).put(point.longitude)

    private fun cameraJson(request: CameraRequest, animate: Boolean): JSONObject {
        val json = JSONObject().put("id", request.id).put("animate", animate)
        request.target?.let { json.put("lat", it.latitude).put("lon", it.longitude) }
        if (request.points.size >= 2) json.put("points", JSONArray(request.points.map(::pair)))
        request.zoom?.let { json.put("zoom", it) }
        request.bearing?.let { json.put("bearing", it) }
        return json
    }

    private inner class Bridge {
        @JavascriptInterface
        fun onReady() {
            main.post {
                if (destroyed) return@post
                ready = true
                main.removeCallbacks(timeout)
                mapError(null)
                if (pending.length() > 0) {
                    val flush = JSONObject(pending.toString())
                    pending.keys().asSequence().toList().forEach { pending.remove(it) }
                    send(flush)
                }
            }
        }

        @JavascriptInterface
        fun onError(reason: String?) {
            main.post { fail(reason ?: "error") }
        }

        @JavascriptInterface
        fun onCamera(latitude: Double, longitude: Double, zoom: Double, bearing: Double) {
            main.post {
                if (destroyed || !latitude.isFinite() || !longitude.isFinite()) return@post
                val coordinate = Coordinate(latitude.coerceIn(-90.0, 90.0), wrapLongitude(longitude))
                cameraChanged(CameraSnapshot(coordinate.latitude, coordinate.longitude, zoom, bearing, 0.0))
                bearingChanged(bearing.toFloat())
                if (lastCenter?.distanceTo(coordinate)?.let { it >= 5.0 } != false) {
                    lastCenter = coordinate
                    centerChanged(coordinate)
                }
            }
        }

        @JavascriptInterface
        fun onPlace(id: String?) {
            main.post {
                val current = content ?: return@post
                val place = if (current.selected?.id == id) current.selected else current.places.find { it.id == id }
                if (place != null) placeClick(place)
            }
        }

        @JavascriptInterface
        fun onLongPress(latitude: Double, longitude: Double) {
            main.post {
                if (destroyed || !latitude.isFinite() || !longitude.isFinite()) return@post
                longPress(Coordinate(latitude.coerceIn(-90.0, 90.0), wrapLongitude(longitude)))
            }
        }

        @JavascriptInterface
        fun onGesture() { main.post { if (!destroyed) gesture() } }

        @JavascriptInterface
        fun onRotated() { main.post { if (!destroyed && content?.orientation == MapOrientation.NORTH) rotated() } }
    }

    private fun wrapLongitude(value: Double): Double {
        var longitude = value
        while (longitude > 180.0) longitude -= 360.0
        while (longitude < -180.0) longitude += 360.0
        return longitude
    }
}
