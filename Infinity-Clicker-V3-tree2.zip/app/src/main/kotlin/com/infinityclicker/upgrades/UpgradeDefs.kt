package com.infinityclicker.upgrades

import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.game.Rarity
import java.util.Locale

enum class ShopCategory(val label: String) {
    CLICKS("Cliques"),
    PRODUCTION("Produção"),
    MULTIPLIERS("Multiplicadores"),
    PERMANENT("Permanentes")
}

sealed class Requirement {
    object None : Requirement()
    data class TotalEnergy(val amount: BigNum) : Requirement()
    data class GeneratorOwned(val generatorId: Int, val count: Long) : Requirement()

    fun describe(): String = when (this) {
        None -> ""
        is TotalEnergy -> "Produza ${NumberFormatter.format(amount)} de energia no total"
        is GeneratorOwned -> "Possua $count × ${GeneratorDefs.byId(generatorId).name}"
    }
}

data class UpgradeDef(
    val id: String,
    val category: ShopCategory,
    val name: String,
    val description: String,
    val rarity: Rarity,
    val baseCost: BigNum,
    val growth: Double,
    val maxLevel: Int,
    val requirement: Requirement,
    /** Texto do efeito acumulado para um dado nível. */
    val effectText: (Int) -> String
)

object UpgradeIds {
    const val CLICK_POWER = "click_power"
    const val CLICK_MULT = "click_mult"
    const val CRIT_CHANCE = "crit_chance"
    const val CRIT_POWER = "crit_power"
    const val COMBO_CAP = "combo_cap"
    const val CLICK_PS = "click_ps"
    const val MULT_GLOBAL_1 = "mult_global_1"
    const val MULT_GLOBAL_2 = "mult_global_2"
    const val MULT_GLOBAL_3 = "mult_global_3"
    const val OFFLINE_CAP = "offline_cap"
    const val OFFLINE_EFF = "offline_eff"

    fun generator(id: Int) = "gen_up_$id"
}

object UpgradeDefs {

    private fun big(v: Double) = BigNum.of(v)
    private fun pow2(level: Int) = NumberFormatter.format(BigNum.of(2.0).pow(level.toDouble()))
    private fun mult(base: Double, level: Int) = NumberFormatter.format(BigNum.of(base).pow(level.toDouble()))
    private fun pct(v: Double) = String.format(Locale.US, "%.0f%%", v)

    private val generatorRarity = listOf(
        Rarity.COMUM, Rarity.COMUM, Rarity.INCOMUM, Rarity.INCOMUM, Rarity.RARO,
        Rarity.EPICO, Rarity.LENDARIO, Rarity.MITICO, Rarity.COSMICO, Rarity.TRANSCENDENTAL
    )

    private val clicks = listOf(
        UpgradeDef(
            UpgradeIds.CLICK_POWER, ShopCategory.CLICKS, "Toque Reforçado",
            "+1 de energia base por clique a cada nível.",
            Rarity.COMUM, big(30.0), 1.31, 200, Requirement.None
        ) { l -> "+$l por clique" },
        UpgradeDef(
            UpgradeIds.CLICK_MULT, ShopCategory.CLICKS, "Pulso Duplo",
            "Dobra a energia por clique a cada nível.",
            Rarity.INCOMUM, big(3_300.0), 8.25, 40, Requirement.TotalEnergy(big(1_000.0))
        ) { l -> "×${pow2(l)} nos cliques" },
        UpgradeDef(
            UpgradeIds.CRIT_CHANCE, ShopCategory.CLICKS, "Sorte Estelar",
            "+1% de chance de clique crítico por nível.",
            Rarity.RARO, big(540.0), 1.47, 40, Requirement.TotalEnergy(big(500.0))
        ) { l -> "+${l}% de chance crítica" },
        UpgradeDef(
            UpgradeIds.CRIT_POWER, ShopCategory.CLICKS, "Fenda Crítica",
            "+0,5× no multiplicador de cliques críticos por nível.",
            Rarity.EPICO, big(2_100.0), 1.53, 100, Requirement.TotalEnergy(big(2_000.0))
        ) { l -> "+${String.format(Locale.US, "%.1f", l * 0.5)}× no crítico" },
        UpgradeDef(
            UpgradeIds.COMBO_CAP, ShopCategory.CLICKS, "Ressonância",
            "+5 no combo máximo por nível (cada passo de combo dá +2% nos cliques).",
            Rarity.RARO, big(1_040.0), 1.73, 50, Requirement.TotalEnergy(big(800.0))
        ) { l -> "combo máx. ${30 + 5 * l}" },
        UpgradeDef(
            UpgradeIds.CLICK_PS, ShopCategory.CLICKS, "Sifão Cósmico",
            "Cada clique também rende +0,05% da sua produção por segundo, por nível.",
            Rarity.LENDARIO, big(300_000.0), 2.25, 50, Requirement.TotalEnergy(big(50_000.0))
        ) { l -> "+${String.format(Locale.US, "%.2f", l * 0.05)}% da produção/s por clique" }
    )

    private val production: List<UpgradeDef> = GeneratorDefs.all.map { g ->
        UpgradeDef(
            UpgradeIds.generator(g.id), ShopCategory.PRODUCTION, "Otimização: ${g.name}",
            "Dobra a produção de ${g.name} a cada nível.",
            generatorRarity[g.id], g.baseCost * 36.0, 6.2, 30,
            Requirement.GeneratorOwned(g.id, 10)
        ) { l -> "×${pow2(l)} em ${g.name}" }
    }

    private val multipliers = listOf(
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_1, ShopCategory.MULTIPLIERS, "Matriz de Fótons",
            "Multiplica TODA a produção por 1,25 a cada nível.",
            Rarity.RARO, big(7_000.0), 3.12, 60, Requirement.TotalEnergy(big(3_000.0))
        ) { l -> "×${mult(1.25, l)} na produção" },
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_2, ShopCategory.MULTIPLIERS, "Eco do Vazio",
            "Dobra TODA a produção a cada nível.",
            Rarity.MITICO, big(1.55e11), 26.0, 40, Requirement.TotalEnergy(big(1e10))
        ) { l -> "×${pow2(l)} na produção" },
        UpgradeDef(
            UpgradeIds.MULT_GLOBAL_3, ShopCategory.MULTIPLIERS, "Singularidade",
            "Multiplica TODA a produção por 10 a cada nível.",
            Rarity.TRANSCENDENTAL, big(1.70e25), 1_050.0, 20, Requirement.TotalEnergy(big(1e22))
        ) { l -> "×${mult(10.0, l)} na produção" }
    )

    private val permanent = listOf(
        UpgradeDef(
            UpgradeIds.OFFLINE_CAP, ShopCategory.PERMANENT, "Câmara Temporal",
            "+2h no limite de ganhos offline por nível (base: 8h).",
            Rarity.EPICO, big(27_000.0), 2.25, 22, Requirement.TotalEnergy(big(10_000.0))
        ) { l -> "limite offline: ${8 + 2 * l}h" },
        UpgradeDef(
            UpgradeIds.OFFLINE_EFF, ShopCategory.PERMANENT, "Condensador de Vácuo",
            "+5% de eficiência dos ganhos offline por nível (base: 50%).",
            Rarity.RARO, big(140_000.0), 3.6, 10, Requirement.TotalEnergy(big(50_000.0))
        ) { l -> "eficiência offline: ${pct(50.0 + 5.0 * l)}" }
    )

    val all: List<UpgradeDef> = clicks + production + multipliers + permanent

    val byId: Map<String, UpgradeDef> = all.associateBy { it.id }

    fun inCategory(category: ShopCategory): List<UpgradeDef> = all.filter { it.category == category }
}
