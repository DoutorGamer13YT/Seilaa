package com.infinityclicker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.infinityclicker.game.Rarity

object Neon {
    val Bg = Color(0xFF04050D)
    val BgMid = Color(0xFF0A0C1F)
    val Cyan = Color(0xFF52E5FF)
    val Violet = Color(0xFFB07CFF)
    val Pink = Color(0xFFFF5FD2)
    val Gold = Color(0xFFFFD36B)
    val Green = Color(0xFF6BFFB0)
    val TextPrimary = Color(0xFFF2F6FF)
    val TextSecondary = Color(0xFFA7B1D6)
}

fun Rarity.color(): Color = when (this) {
    Rarity.COMUM -> Color(0xFFB8C2DC)
    Rarity.INCOMUM -> Color(0xFF6BFFB0)
    Rarity.RARO -> Color(0xFF52A8FF)
    Rarity.EPICO -> Color(0xFFB07CFF)
    Rarity.LENDARIO -> Color(0xFFFFB347)
    Rarity.MITICO -> Color(0xFFFF5F7A)
    Rarity.COSMICO -> Color(0xFFFF5FD2)
    Rarity.TRANSCENDENTAL -> Color(0xFF52E5FF)
}

@Composable
fun InfinityTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.Cyan,
            secondary = Neon.Violet,
            tertiary = Neon.Pink,
            background = Neon.Bg,
            surface = Neon.BgMid,
            onPrimary = Neon.Bg,
            onBackground = Neon.TextPrimary,
            onSurface = Neon.TextPrimary
        ),
        content = content
    )
}
