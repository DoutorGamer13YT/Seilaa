package dev.atlas.core

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class FormattingTest {
    @Test fun metricDistancesUseBrazilianNumbersAndCorrectThresholds() {
        assertEquals("0 m", formatDistance(0.0, Units.METRIC))
        assertEquals("< 1 m", formatDistance(0.2, Units.METRIC))
        assertEquals("1 m", formatDistance(1.0, Units.METRIC))
        assertEquals("125 m", formatDistance(125.3, Units.METRIC))
        assertEquals("999 m", formatDistance(999.4, Units.METRIC))
        assertEquals("1,0 km", formatDistance(999.5, Units.METRIC))
        assertEquals("1,6 km", formatDistance(1_600.0, Units.METRIC))
        assertEquals("12 km", formatDistance(12_100.0, Units.METRIC))
    }

    @Test fun imperialDistancesConvertMetersToActualFeetAndMiles() {
        assertEquals("0 pés", formatDistance(0.0, Units.IMPERIAL))
        assertEquals("< 1 pé", formatDistance(0.1, Units.IMPERIAL))
        assertEquals("1 pé", formatDistance(0.3048, Units.IMPERIAL))
        assertEquals("100 pés", formatDistance(30.48, Units.IMPERIAL))
        assertEquals("1,0 mi", formatDistance(1_609.344, Units.IMPERIAL))
        assertEquals("10 mi", formatDistance(16_093.44, Units.IMPERIAL))
    }

    @Test fun invalidDistanceIsUnavailableInsteadOfZero() {
        listOf(-1.0, Double.NaN, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY).forEach { value ->
            Units.entries.forEach { units -> assertEquals("—", formatDistance(value, units)) }
        }
    }

    @Test fun durationsRoundUpWithoutClaimingZeroForShortTrips() {
        assertEquals("0 min", formatDuration(0.0))
        assertEquals("< 1 min", formatDuration(59.9))
        assertEquals("1 min", formatDuration(60.0))
        assertEquals("2 min", formatDuration(60.1))
        assertEquals("1 h", formatDuration(3_599.0))
        assertEquals("1 h", formatDuration(3_600.0))
        assertEquals("1 h 1 min", formatDuration(3_601.0))
        assertEquals("25 h", formatDuration(90_000.0))
    }

    @Test fun invalidDurationsAndOverflowDoNotCrash() {
        listOf(-1.0, Double.NaN, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, Double.MAX_VALUE).forEach {
            assertEquals("—", formatDuration(it))
            assertEquals("—", formatArrival(it, 0L))
        }
        assertEquals("—", formatArrival(1.0, Long.MAX_VALUE))
    }

    @Test fun arrivalUsesLocalTimeAndHandlesMidnight() {
        val now = LocalDateTime.of(2026, 10, 10, 23, 55).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        assertEquals("23:55", formatArrival(0.0, now))
        assertEquals("00:10", formatArrival(15 * 60.0, now))
    }

    @Test fun coordinateLabelsAreUnambiguousAndNormalizeNegativeZero() {
        assertEquals("-23.550520, -46.633308", coordinateLabel(Coordinate(-23.55052, -46.633308)))
        assertEquals("0.000000, 0.000000", coordinateLabel(Coordinate(-0.0, -0.00000001)))
        assertEquals("90.000000, 180.000000", coordinateLabel(Coordinate(90.0, 180.0)))
    }
}
