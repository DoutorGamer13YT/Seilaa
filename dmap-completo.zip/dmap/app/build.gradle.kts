import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

val localConfig = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use(::load)
}
fun quotedConfig(name: String): String {
    val value = localConfig.getProperty(name, "")
    val escaped = value.replace("\\", "\\\\").replace("\"", "\\\"")
    return "\"$escaped\""
}

android {
    namespace = "com.vitinhjkjkk.dmap"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.vitinhjkjkk.dmap"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("String", "GEOAPIFY_API_KEY", quotedConfig("GEOAPIFY_API_KEY"))
        buildConfigField("String", "MAP_STYLE_URL", quotedConfig("MAP_STYLE_URL"))
        buildConfigField("String", "MAPKIT_TOKEN_URL", quotedConfig("MAPKIT_TOKEN_URL"))
        buildConfigField("String", "MAPKIT_WEB_ORIGIN", quotedConfig("MAPKIT_WEB_ORIGIN"))
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.maplibre.android)
    debugImplementation(libs.androidx.compose.ui.tooling)
}
