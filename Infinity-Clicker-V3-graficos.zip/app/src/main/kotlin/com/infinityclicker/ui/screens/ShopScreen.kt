package com.infinityclicker.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.game.BuyMode
import com.infinityclicker.ui.GeneratorRow
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.UpgradeRow
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.color
import com.infinityclicker.upgrades.ShopCategory

private val sections = listOf("Geradores") + ShopCategory.values().map { it.label }

@Composable
fun ShopScreen(
    ui: UiState,
    onBuyMode: (BuyMode) -> Unit,
    onBuyGenerator: (Int) -> Unit,
    onBuyUpgrade: (String) -> Unit
) {
    var section by rememberSaveable { mutableIntStateOf(0) }
    val sci = ui.settings.scientificNotation
    fun f(n: BigNum) = NumberFormatter.format(n, sci)

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = ui.settings.panelOpacity) {
            Text("Energia: ${f(ui.energy)}", color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("+${f(ui.production)} / s", color = Neon.Cyan, fontSize = 14.sp)
        }

        LazyRow(
            Modifier.padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(BuyMode.values().toList()) { m ->
                Chip(m.label, selected = ui.buyMode == m, color = Neon.Violet) { onBuyMode(m) }
            }
        }
        LazyRow(
            Modifier.padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(sections.indices.toList()) { i ->
                Chip(sections[i], selected = section == i, color = Neon.Cyan) { section = i }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            if (section == 0) {
                items(ui.generators, key = { it.def.id }) { row ->
                    GeneratorCard(row, ::f, ui.settings.panelOpacity) { onBuyGenerator(row.def.id) }
                }
            } else {
                val cat = ShopCategory.values()[section - 1]
                val visible = remember(ui.upgrades, cat) { ui.upgrades.filter { it.def.category == cat } }
                items(visible, key = { it.def.id }) { row ->
                    UpgradeCard(row, ::f, ui.settings.panelOpacity) { onBuyUpgrade(row.def.id) }
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Neon.Bg else Neon.TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .glass(RoundedCornerShape(50), tint = if (selected) color else Color.White, alpha = if (selected) 0.85f else 0.10f)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun GeneratorCard(row: GeneratorRow, f: (BigNum) -> String, alpha: Float, onBuy: () -> Unit) {
    val tint = row.def.rarity.color()
    GlassCard(Modifier.fillMaxWidth(), tint = tint, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(row.def.name, color = Neon.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("×${row.owned}", color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Text(row.def.rarity.label, color = tint, fontSize = 12.sp)
        Text(row.def.description, color = Neon.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        Text(
            "Cada um: ${f(row.unitProduction)}/s · Total: ${f(row.totalProduction)}/s",
            color = Neon.TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            "Próximo marco (produção ×2): ${row.nextMilestone} unidades",
            color = Neon.Gold, fontSize = 12.sp
        )
        if (!row.unlocked) {
            Text("Bloqueado: compre o gerador anterior.", color = Neon.Pink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            BuyButton(
                label = if (row.plan.affordable || row.plan.count > 0)
                    "Comprar ${row.plan.count} · ${f(row.plan.cost)}" else "Indisponível",
                enabled = row.plan.affordable && row.plan.count > 0,
                tint = tint, onClick = onBuy
            )
        }
    }
}

@Composable
private fun UpgradeCard(row: UpgradeRow, f: (BigNum) -> String, alpha: Float, onBuy: () -> Unit) {
    val tint = row.def.rarity.color()
    GlassCard(Modifier.fillMaxWidth(), tint = tint, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(row.def.name, color = Neon.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("${row.level}/${row.def.maxLevel}", color = tint, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Text(row.def.rarity.label, color = tint, fontSize = 12.sp)
        Text(row.def.description, color = Neon.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        Text("Efeito atual: ${row.def.effectText(row.level)}", color = Neon.TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        when {
            row.maxed -> Text("Nível máximo", color = Neon.Green, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            !row.unlocked -> Text(
                "Bloqueado: ${row.def.requirement.describe()}",
                color = Neon.Pink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            else -> BuyButton(
                label = "Evoluir +${row.plan.count} · ${f(row.plan.cost)}",
                enabled = row.plan.affordable && row.plan.count > 0,
                tint = tint, onClick = onBuy
            )
        }
    }
}

@Composable
private fun BuyButton(label: String, enabled: Boolean, tint: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = tint.copy(alpha = 0.85f),
            contentColor = Neon.Bg,
            disabledContainerColor = Color.White.copy(alpha = 0.10f),
            disabledContentColor = Neon.TextSecondary
        )
    ) { Text(label, fontWeight = FontWeight.Bold) }
}
