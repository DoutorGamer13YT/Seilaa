#!/usr/bin/env python3
"""Read-only source/config validation. Does not invoke Gradle, compile, download or run Android."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "{http://schemas.android.com/apk/res/android}"


def inspect() -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    checked: list[str] = []
    main = ROOT / "app/src/main"
    for required in ("settings.gradle.kts", "build.gradle.kts", "app/build.gradle.kts", "gradle.properties", "app/proguard-rules.pro"):
        if not (ROOT / required).is_file():
            errors.append(f"Missing build configuration: {required}")
    parsed_xml = {}
    for path in sorted(main.rglob("*.xml")):
        try:
            parsed_xml[path] = ET.parse(path).getroot()
            checked.append(str(path.relative_to(ROOT)))
        except ET.ParseError as error:
            errors.append(f"Invalid XML {path.relative_to(ROOT)}: {error}")
    resources: set[tuple[str, str]] = set()
    for path, node in parsed_xml.items():
        if "res" not in path.parts:
            continue
        kind = path.parent.name.split("-")[0]
        if kind == "values":
            resources.update((child.tag, child.attrib["name"]) for child in node if "name" in child.attrib)
        else:
            resources.add((kind, path.stem))
    for path, node in parsed_xml.items():
        for child in node.iter():
            for value in child.attrib.values():
                match = re.fullmatch(r"@([a-z]+)/([\w.]+)", value)
                if match and tuple(match.groups()) not in resources:
                    errors.append(f"Unresolved resource {value} in {path.relative_to(ROOT)}")
    manifest = parsed_xml.get(main / "AndroidManifest.xml")
    if manifest is None:
        errors.append("AndroidManifest.xml missing or invalid")
    else:
        permissions = {node.attrib.get(ANDROID + "name") for node in manifest.findall("uses-permission")}
        needed = {"INTERNET", "ACCESS_NETWORK_STATE", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_LOCATION", "POST_NOTIFICATIONS"}
        for permission in sorted(needed):
            if "android.permission." + permission not in permissions:
                errors.append(f"Missing permission required by current implementation: {permission}")
        if "android.permission.ACCESS_BACKGROUND_LOCATION" in permissions:
            errors.append("Unexpected background location permission")
        application = manifest.find("application")
        if application is None:
            errors.append("Missing application entry")
        else:
            if application.attrib.get(ANDROID + "usesCleartextTraffic") != "false":
                errors.append("Application must reject cleartext HTTP")
            if application.attrib.get(ANDROID + "allowBackup") != "false":
                errors.append("Location database backup policy differs from documented disabled backup")
            class_nodes = [application] + list(application.findall("activity")) + list(application.findall("service"))
            for node in class_nodes:
                class_name = node.attrib.get(ANDROID + "name", "")
                full_name = "dev.atlas" + class_name if class_name.startswith(".") else class_name
                if full_name and not (main / "java" / (full_name.replace(".", "/") + ".kt")).is_file():
                    errors.append(f"Manifest component source missing: {class_name}")
            services = application.findall("service")
            navigation = next((node for node in services if node.attrib.get(ANDROID + "name") == ".location.NavigationService"), None)
            if navigation is None or navigation.attrib.get(ANDROID + "foregroundServiceType") != "location" or navigation.attrib.get(ANDROID + "exported") != "false":
                errors.append("NavigationService must be private and declare location foreground type")
            schemes = {node.attrib.get(ANDROID + "scheme") for node in application.findall("activity/intent-filter/data")}
            if not {"geo", "atlas"}.issubset(schemes):
                errors.append("Documented geo/atlas deep-link schemes not both declared")
        if not any(node.attrib.get(ANDROID + "name") == "android.intent.action.TTS_SERVICE" for node in manifest.findall("queries/intent/action")):
            errors.append("Missing TTS engine package visibility query")
    for style_name in ("atlas-light.json", "atlas-dark.json"):
        path = main / "assets/styles" / style_name
        if not path.is_file():
            errors.append(f"Map references missing style asset: {style_name}")
            continue
        try:
            value = json.loads(path.read_text())
            if value.get("version") != 8 or not isinstance(value.get("sources"), dict) or not isinstance(value.get("layers"), list):
                errors.append(f"Map style {style_name} lacks v8 structure")
            checked.append(str(path.relative_to(ROOT)))
        except (json.JSONDecodeError, UnicodeDecodeError) as error:
            errors.append(f"Invalid map JSON {style_name}: {error}")
    app_gradle = ROOT / "app/build.gradle.kts"
    if app_gradle.is_file():
        gradle = app_gradle.read_text()
        declared = set(re.findall(r'buildConfigField\("\w+",\s*"(\w+)"', gradle))
        generated = {"DEBUG", "APPLICATION_ID", "BUILD_TYPE", "FLAVOR", "VERSION_CODE", "VERSION_NAME"}
        for source in sorted((main / "java").rglob("*.kt")):
            for field in set(re.findall(r"BuildConfig\.(\w+)", source.read_text())) - declared - generated:
                errors.append(f"Undeclared BuildConfig.{field}: {source.relative_to(ROOT)}")
        for field in sorted(declared):
            if field.endswith("_URL"):
                pattern = r'configured\("' + re.escape(field) + r'",\s*"([^"]+)"\)'
                match = re.search(pattern, gradle)
                if match and not match.group(1).startswith("https://"):
                    errors.append(f"Provider default {field} must use HTTPS")
        if 'arg("room.schemaLocation"' not in gradle:
            errors.append("Room exportSchema requires a schema output location")
    wrapper_files = ["gradlew", "gradlew.bat", "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties"]
    missing_wrapper = [str(path) for path in wrapper_files if not (ROOT / path).is_file()]
    if missing_wrapper:
        warnings.append("Gradle Wrapper absent/incomplete; setup required as documented in docs/BUILD.md")
    warnings.append("This source check does not validate Kotlin/Gradle compilation, resolved dependencies, APKs or device behavior")
    return {"check": "source configuration only", "files_parsed": len(checked), "errors": errors, "warnings": warnings, "passed": not errors}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="Print machine-readable report")
    arguments = parser.parse_args()
    report = inspect()
    if arguments.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Static source/config checks: {'PASS' if report['passed'] else 'FAIL'}; {report['files_parsed']} XML/JSON files parsed")
        for level in ("errors", "warnings"):
            for issue in report[level]:
                print(f"{level[:-1].upper()}: {issue}")
        print("No compilation, Gradle, SDK downloads or Android execution performed.")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
