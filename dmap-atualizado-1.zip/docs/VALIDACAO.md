# Validação desta continuação

Somente verificações estáticas. Não foram executados Gradle, compilador Kotlin, Android lint, APK, emulador, dispositivo ou GitHub Actions. Nenhum workflow foi alterado e nenhum serviço foi publicado.

## Verificações realizadas

- Parsing XML de manifest e recursos Android.
- Parsing de sintaxe Kotlin/KTS com tree-sitter. Isso não resolve tipos nem substitui compilação.
- Parsing Python por `ast` dos scripts do servidor e verificadores. Os scripts de extração, serviço e publicação não foram executados.
- `node --check server/generate_styles.mjs`: análise sintática, sem executar o gerador ou instalar suas dependências.
- Validação JSON dos arquivos estáticos, integridade estrutural do ZIP final e presença das licenças obrigatórias no pacote de código.
- Verificação de estrutura, permissões, exclusão de APK/DEX/SO e hash do wrapper existente.
- Consulta à documentação oficial da Protomaps e do MapLibre para confirmar PMTiles local e limitação do OfflineManager. Inspeção das assinaturas publicadas do gerador de estilos e dos nomes/ranges dos assets oficiais.

Resultados mecânicos em `STATIC_CHECK_REPORT.txt`. As verificações foram aplicadas às alterações desta entrega e à estrutura necessária; não foi repetida a análise do APK/projeto original.

## Ainda não testado

- Compilação e resolução de tipos/dependências Android.
- Preparação real de um recorte Protomaps e compatibilidade visual dos estilos gerados no MapLibre Android 13.6.1.
- Download HTTPS real contra a futura hospedagem, HTTP Range, If-Range, interrupção durante hashing/extração, servidor que ignora Range, arquivo alterado, sem espaço, bateria restrita e reinicialização.
- Renderização em modo avião de ruas, rótulos, ícones e idiomas; captura de tráfego para confirmar ausência de requisições de recursos do mapa local.
- GPS/bússola em aparelho real, precisão, calibração, animações, consumo e sensores ausentes.
- Apple Maps na versão de Android System WebView do aparelho, permissões de localização, pesquisa, rotas, gestos e restauração de câmera.
- Troca de rede/portal cativo/intermitência, retorno automático, modo manual e preservação de rotas online.
- Rotação do aparelho, processo encerrado, mudança de tema, navegação por abas, gestos e opacidade do painel inferior.
- Atualização com versão anterior instalada, exclusão em uso e arquivos corrompidos.

Para validar depois: publicar um pacote pequeno real, baixar e conferir o tamanho/hash, ativar modo avião, reabrir o aplicativo, alternar claro/escuro, testar GPS e bússola, reiniciar, verificar integridade e excluir. Repetir com interrupção de download e rede tarifada. Usar um aparelho intermediário, como Galaxy A54, para conferir fluidez e bateria.
