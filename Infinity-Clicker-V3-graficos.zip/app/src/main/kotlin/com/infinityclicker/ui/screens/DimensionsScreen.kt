package com.infinityclicker.ui.screens

import androidx.compose.foundation.lazy.itemsIndexed
import com.infinityclicker.ui.components.enterAnimation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.ui.CrystalUi
import com.infinityclicker.ui.DimensionUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun DimensionsScreen(
    ui: UiState,
    onUnlock: (Int) -> Unit,
    onTravel: (Int) -> Unit,
    onResonance: (Int) -> Unit,
    onStartBoss: () -> Unit,
    onEquipCrystal: (Int) -> Unit
) {
    val sci = ui.settings.scientificNotation
    val f: (com.infinityclicker.core.BigNum) -> String = androidx.compose.runtime.remember(sci) { { n: com.infinityclicker.core.BigNum -> NumberFormatter.format(n, sci) } }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Column(Modifier.padding(end = 52.dp).enterAnimation(0)) {
                Text("Mapa Cósmico", color = Neon.TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Viaje, melhore a ressonância local e desafie entidades cósmicas.", color = Neon.TextSecondary, fontSize = 13.sp)
            }
        }
        itemsIndexed(ui.dimensions, key = { _, item -> "dim-${item.def.id}" }, contentType = { _, _ -> "dimension" }) { index, dimension ->
            DimensionCard(
                modifier = Modifier.animateItem().then(androidx.compose.runtime.remember(index) { Modifier.enterAnimation(index + 1) }),
                row = dimension,
                f = f,
                alpha = ui.settings.panelOpacity,
                bossActive = ui.activeBoss != null,
                onUnlock = { onUnlock(dimension.def.id) },
                onTravel = { onTravel(dimension.def.id) },
                onResonance = { onResonance(dimension.def.id) },
                onStartBoss = onStartBoss
            )
        }
        item {
            Text("Cristais desbloqueáveis", color = Neon.TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text("Cada aparência também aplica seu bônus real por clique.", color = Neon.TextSecondary, fontSize = 13.sp)
        }
        itemsIndexed(ui.crystals, key = { _, item -> "crystal-${item.def.id}" }, contentType = { _, _ -> "crystal" }) { index, crystal ->
            CrystalCard(crystal, f, ui.settings.panelOpacity, onEquipCrystal, Modifier.animateItem().then(androidx.compose.runtime.remember(index) { Modifier.enterAnimation(index) }))
        }
    }
}

@Composable
private fun DimensionCard(
    modifier: Modifier,
    row: DimensionUi,
    f: (com.infinityclicker.core.BigNum) -> String,
    alpha: Float,
    bossActive: Boolean,
    onUnlock: () -> Unit,
    onTravel: () -> Unit,
    onResonance: () -> Unit,
    onStartBoss: () -> Unit
) {
    val def = row.def
    GlassCard(modifier.fillMaxWidth(), tint = def.tintColor, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(def.name, color = Neon.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text(if (row.current) "ATUAL" else if (row.unlocked) "ABERTA" else "SELADA", color = def.tintColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        when {
            !row.unlocked -> {
                Text("Requisito: ${f(row.unlockRequirement)} de energia total", color = Neon.Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                BuyButton(
                    if (row.canUnlock) "Desbloquear dimensão" else "Dimensão selada", null, row.canUnlock, def.tintColor, onUnlock,
                    Modifier.fillMaxWidth().padding(top = 10.dp), subtitle = if (row.canUnlock) null else "Continue produzindo energia"
                )
            }
            else -> {
                Text(remember(row.localMultiplier) { "Produção local ×${"%.2f".format(row.localMultiplier)}" }, color = def.tintColor, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp))
                Text("Fragmentos: ${row.shards} · Ressonância ${row.resonance}", color = Neon.TextSecondary, fontSize = 12.sp)
                if (row.current) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val canRes = row.shards >= row.resonanceCost
                        BuyButton(
                            "Ressonar", "${row.resonanceCost} frag.", canRes, Neon.Violet, onResonance, Modifier.weight(1f),
                            subtitle = if (canRes) null else "Você tem ${row.shards}", progress = (row.shards.toFloat() / row.resonanceCost.coerceAtLeast(1)).coerceIn(0f, 1f)
                        )
                        BuyButton(
                            if (bossActive) "Chefe ativo" else "Invocar chefe", null, !bossActive, Neon.Pink, onStartBoss, Modifier.weight(1f)
                        )
                    }
                    Text("${def.bossName}: ${f(row.bossHealth)} de vida · +${def.shardReward} fragmento(s)", color = Neon.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
                } else {
                    BuyButton("Viajar para ${def.name}", null, true, def.tintColor, onTravel, Modifier.fillMaxWidth().padding(top = 10.dp))
                }
            }
        }
    }
}

@Composable
private fun CrystalCard(crystal: CrystalUi, f: (com.infinityclicker.core.BigNum) -> String, alpha: Float, onEquip: (Int) -> Unit, modifier: Modifier) {
    GlassCard(modifier.fillMaxWidth(), tint = crystal.def.tintColor, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(crystal.def.name, color = Neon.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(crystal.def.detail, color = crystal.def.tintColor, fontSize = 12.sp)
                if (!crystal.unlocked) Text("Desbloqueia em ${f(crystal.def.unlockAt)} de energia total", color = Neon.TextSecondary, fontSize = 11.sp)
            }
            if (crystal.unlocked) {
                BuyButton(
                    if (crystal.equipped) "Equipado" else "Equipar", null, !crystal.equipped, crystal.def.tintColor,
                    { onEquip(crystal.def.id) }, Modifier.width(118.dp), height = 42.dp
                )
            }
        }
    }
}
