# Infinity Clicker 3.2 Developer Version

Jogo incremental cósmico para Android, feito em Kotlin + Jetpack Compose. O projeto preserva o pacote `com.infinityclicker`, Android 10+ (API 29), alvo Android 16 (API 36), Java 17 e salvamento local sem exigir conta ou internet.

## O que funciona nesta versão

- Cristal em Canvas com geometria facetada 3D, cinco estilos desbloqueáveis, rotação, flutuação, reflexos, núcleo luminoso, ondas de energia, compressão com mola, críticos, partículas limitadas por qualidade e feedback tátil opcional.
- Oito ambientes equipáveis (espaço profundo, nebulosa, galáxia, buraco negro, quântico, temporal, infinito e transcendental), todos renderizados localmente em Canvas e desbloqueados pela progressão.
- Cliques sem debounce, combo, críticos, eventos cósmicos locais, ganhos passivos, 10 geradores, marcos, compra ×1/×10/×100/máximo e melhorias existentes.
- Habilidades reais: Super Clique, Aceleração Temporal, Explosão Cósmica e Sobrecarga Quântica. Todas têm recarga persistida; as duas que dependem de produção ficam desabilitadas enquanto não teriam efeito.
- Renascimento com prévia exata do que será perdido e preservado, pontos permanentes e histórico salvo.
- Árvore com **100 nós funcionais** em cinco caminhos: Poder, Automação, Sorte, Cósmico e Temporal. Cada nó atua no motor econômico; o mapa suporta zoom, arraste e cinco rotas conectadas.
- Cinco dimensões com requisitos, viagem, multiplicadores locais, ressonância comprada com fragmentos, chefes com vida/cronômetro/dano por clique/recompensas e coleção de cristais.
- Missões diárias locais, login diário, seis desafios opcionais com prazo persistido, cinco eventos locais e **250 conquistas** funcionais (40/35/35/30/30/30/25/25 por categoria), com raridade, filtro, progresso, histórico de desbloqueio e proteção contra recompensa duplicada.
- DataStore com checksum CRC32, backup anterior, revisão do save e migração transparente V1 → V2 → V3. Exportar/importar usa o seletor de arquivos Android e preserva o save atual como backup antes de importar.
- Notação abreviada ou científica, qualidade de partículas/fundo, intensidade de efeitos, transparência de vidro, modo de economia de bateria e solicitação de 30/60/90/120 Hz ao Android.
- Ícone vetorial adaptativo renovado e interface Liquid Glass de custo controlado: transparência, iluminação, reflexos e profundidade sem blur global pesado.
- Perfil de desempenho: listas pesadas da árvore/galeria só são reconstruídas quando suas abas estão abertas; partículas, estrelas e ciclos se adaptam à qualidade e economia de bateria.

## Limites conhecidos, declarados sem simulação

- **Sincronização na nuvem: em desenvolvimento.** Não há login Google, Firebase/Firestore nem servidor neste repositório. O perfil (Ajustes › Nuvem) mostra a funcionalidade marcada como "em desenvolvimento", com linhas apenas informativas e esmaecidas — nenhum botão finge sincronizar. Já existem o contrato de provedor e a política de conflito (`data/CloudSync.kt`, com testes); o modo offline local continua sendo a única fonte de verdade.
- Não há áudio porque não foram adicionados recursos sonoros licenciados. Não há controles de áudio inertes.
- Room não foi introduzido: o progresso é um único estado transacional no DataStore, com backup e checksum. Não foi adicionada uma dependência de banco sem uso.
- Eventos sazonais/remotos, mais dimensões além das cinco iniciais e um mapa visual com conteúdo remoto continuam fora deste build.
- A qualidade/FPS é uma preferência efetivamente aplicada ao loop e à janela, mas nenhuma tela Android pode garantir 120 FPS constantes.
- A compilação local precisa de Android SDK 36, Build Tools 36.0.0, JDK 17 e internet/cache Gradle na primeira execução.

Consulte [STATUS_V3.md](STATUS_V3.md) para a separação completa de implementado e pendente, e [FIREBASE_SETUP.md](FIREBASE_SETUP.md) para o plano seguro de uma futura integração de nuvem.

## Compilar

```bash
./gradlew testDebugUnitTest assembleDebug
```

O APK de depuração será criado em `app/build/outputs/apk/debug/`.

O workflow [build-apk.yml](.github/workflows/build-apk.yml) instala Java 17/SDK, executa os testes, monta o APK debug e o publica como artefato. Erros não são ignorados.

## Testes

`app/src/test` verifica BigNum, formatação, custos, produção, compra máxima, combo, críticos, ganhos offline, corrupção de save, migração V1→V2, persistência V2, habilidades, chefe, árvore, cristal e renascimento.

## Assinatura e atualização de uma instalação anterior

O identificador do aplicativo foi preservado. Para instalar por cima de um APK já instalado, o novo APK precisa ser assinado com a mesma chave privada do APK anterior. A chave de assinatura não está incluída neste código-fonte; um APK debug criado localmente terá outra assinatura e o Android exigirá desinstalar a instalação anterior antes de instalá-lo.
