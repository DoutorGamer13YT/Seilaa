package dev.atlas.core

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

enum class MapOrientation { NORTH, FREE, COMPASS }

object HeadingMath {
    fun normalize(degrees: Float): Float {
        val value = degrees % 360f
        return if (value < 0f) value + 360f else value
    }

    fun shortestDelta(from: Float, to: Float): Float {
        val delta = (to - from) % 360f
        return when {
            delta > 180f -> delta - 360f
            delta < -180f -> delta + 360f
            else -> delta
        }
    }

    fun smooth(previous: Float?, raw: Float): Float {
        if (previous == null) return normalize(raw)
        val delta = shortestDelta(previous, raw)
        if (abs(delta) < 0.4f) return previous
        val alpha = (0.12f + abs(delta) / 90f).coerceIn(0.12f, 0.65f)
        return normalize(previous + delta * alpha)
    }

    fun headingDegrees(rotation: FloatArray, displayRotation: Int): Float? {
        if (rotation.size < 9 || rotation.any { !it.isFinite() }) return null
        val up = when (displayRotation) {
            1 -> Triple(-rotation[0], -rotation[3], -rotation[6])
            2 -> Triple(-rotation[1], -rotation[4], -rotation[7])
            3 -> Triple(rotation[0], rotation[3], rotation[6])
            else -> Triple(rotation[1], rotation[4], rotation[7])
        }
        val backEast = -rotation[2]
        val backNorth = -rotation[5]
        val flat = smoothStep(0.55f, 0.85f, abs(rotation[8]))
        val east = flat * up.first + (1f - flat) * backEast
        val north = flat * up.second + (1f - flat) * backNorth
        if (hypot(east, north) < 1e-3f) return null
        return normalize(Math.toDegrees(atan2(east, north).toDouble()).toFloat())
    }

    private fun smoothStep(edge0: Float, edge1: Float, value: Float): Float {
        val t = ((value - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}

object CameraPolicy {
    const val MIN_COURSE_SPEED = 1.5f

    fun navigationZoom(speedMetersPerSecond: Float?): Double {
        val speed = speedMetersPerSecond?.takeIf { it.isFinite() && it >= 0f } ?: 0f
        return when {
            speed < 4f -> 17.6
            speed < 11f -> 17.0
            speed < 20f -> 16.4
            speed < 28f -> 15.8
            else -> 15.2
        }
    }

    fun courseOrNull(bearing: Float?, speedMetersPerSecond: Float?): Float? {
        val value = bearing?.takeIf { it.isFinite() } ?: return null
        val speed = speedMetersPerSecond?.takeIf { it.isFinite() } ?: return null
        return if (speed >= MIN_COURSE_SPEED) HeadingMath.normalize(value) else null
    }
}
