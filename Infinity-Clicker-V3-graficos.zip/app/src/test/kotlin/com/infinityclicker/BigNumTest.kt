package com.infinityclicker

import com.infinityclicker.core.BigNum
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BigNumTest {

    private fun close(expected: Double, actual: BigNum, rel: Double = 1e-9) {
        val a = actual.toDouble()
        assertTrue("esperado $expected, obtido $a", Math.abs(a - expected) <= Math.abs(expected) * rel + 1e-300)
    }

    @Test
    fun zeroBehaves() {
        assertTrue(BigNum.ZERO.isZero)
        assertEquals(BigNum.of(5.0), BigNum.ZERO + BigNum.of(5.0))
        assertEquals(BigNum.ZERO, BigNum.of(5.0) * BigNum.ZERO)
        assertEquals(BigNum.ZERO, BigNum.of(-3.0))
        assertEquals(BigNum.ZERO, BigNum.of(Double.NaN))
    }

    @Test
    fun basicArithmetic() {
        close(7.0, BigNum.of(3.0) + BigNum.of(4.0))
        close(1.0, BigNum.of(4.0) - BigNum.of(3.0))
        close(12.0, BigNum.of(3.0) * BigNum.of(4.0))
        close(2.5, BigNum.of(10.0) / BigNum.of(4.0))
        close(1024.0, BigNum.of(2.0).pow(10.0))
        close(0.5, BigNum.of(2.0).pow(-1.0))
    }

    @Test
    fun subtractionNeverGoesNegative() {
        assertEquals(BigNum.ZERO, BigNum.of(3.0) - BigNum.of(10.0))
        assertEquals(BigNum.ZERO, BigNum.of(3.0) - BigNum.of(3.0))
    }

    @Test
    fun handlesHugeMagnitudesBeyondDouble() {
        val a = BigNum.of(1e300) * BigNum.of(1e300) * BigNum.of(1e300)
        assertEquals(900L, a.exponent)
        val back = a / BigNum.of(1e300) / BigNum.of(1e300)
        close(1e300, back)
        val p = BigNum.of(10.0).pow(5000.0)
        assertEquals(5000L, p.exponent)
        assertTrue(p > a)
    }

    @Test
    fun additionAcrossVeryDifferentScalesKeepsLarger() {
        val big = BigNum.of(1e100)
        val tiny = BigNum.of(1.0)
        assertEquals(big, big + tiny)
        assertEquals(big, big - tiny)
    }

    @Test
    fun comparison() {
        assertTrue(BigNum.of(1e10) > BigNum.of(9.99e9))
        assertTrue(BigNum.of(5.0) < BigNum.of(50.0))
        assertTrue(BigNum.ZERO < BigNum.of(1e-20))
        assertEquals(0, BigNum.of(123.0).compareTo(BigNum.of(123.0)))
    }

    @Test
    fun serializationRoundTrip() {
        val values = listOf(BigNum.ZERO, BigNum.of(1.0), BigNum.of(123456.789), BigNum.of(10.0).pow(777.0) * 3.3)
        for (v in values) {
            val back = BigNum.parse(v.serialize())
            assertEquals(v, back)
        }
        assertNull(BigNum.parse("abc"))
        assertNull(BigNum.parse("1.0:xyz"))
        assertNull(BigNum.parse("-5.0:2"))
        assertNull(BigNum.parse("NaN:2"))
    }

    @Test
    fun divisionByZeroThrows() {
        var thrown = false
        try {
            BigNum.of(1.0) / BigNum.ZERO
        } catch (e: ArithmeticException) {
            thrown = true
        }
        assertTrue(thrown)
    }

    @Test
    fun repeatedAdditionStaysAccurate() {
        var acc = BigNum.ZERO
        repeat(100_000) { acc += BigNum.of(0.1) }
        close(10_000.0, acc, 1e-9)
        assertFalse(acc.isZero)
    }

    @Test
    fun saturatingLongConversion() {
        assertEquals(1234L, BigNum.of(1234.9).toLongSaturated())
        assertEquals(Long.MAX_VALUE, BigNum.of(1e30).toLongSaturated())
    }

    @Test
    fun exponentArithmeticSaturatesInsteadOfWrapping() {
        val huge = BigNum.of(10.0).pow(Double.MAX_VALUE)
        val tiny = BigNum.of(10.0).pow(-Double.MAX_VALUE)
        assertEquals(Long.MAX_VALUE, huge.exponent)
        assertEquals(Long.MIN_VALUE, tiny.exponent)
        assertEquals(Long.MAX_VALUE, (huge * BigNum.of(10.0)).exponent)
        assertEquals(Long.MIN_VALUE, (tiny / BigNum.of(10.0)).exponent)
        assertEquals(huge, huge + tiny)
    }
}
