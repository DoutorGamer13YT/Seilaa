package dev.atlas.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
internal interface AtlasDao {
    @Upsert suspend fun upsertPlace(place: PlaceEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Transaction @Query("SELECT * FROM favorites ORDER BY savedAt DESC, placeId ASC")
    fun observeFavorites(): Flow<List<FavoriteWithRelations>>

    @Query("DELETE FROM favorites WHERE placeId = :placeId")
    suspend fun deleteFavorite(placeId: String)

    @Query("SELECT * FROM saved_lists ORDER BY position ASC, id ASC")
    fun observeLists(): Flow<List<SavedListEntity>>

    @Query("SELECT * FROM saved_lists ORDER BY position ASC, id ASC")
    suspend fun allLists(): List<SavedListEntity>

    @Insert suspend fun insertList(list: SavedListEntity): Long

    @Query("UPDATE saved_lists SET name = :name, normalizedName = :normalizedName WHERE id = :id")
    suspend fun renameList(id: Long, name: String, normalizedName: String)

    @Query("UPDATE saved_lists SET position = :position WHERE id = :id")
    suspend fun updateListPosition(id: Long, position: Int)

    @Query("DELETE FROM saved_lists WHERE id = :id") suspend fun deleteList(id: Long)

    @Query("DELETE FROM list_memberships WHERE placeId = :placeId")
    suspend fun deleteMemberships(placeId: String)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMemberships(memberships: List<ListMembershipEntity>)

    @Query("SELECT * FROM search_history ORDER BY timestampMillis DESC, normalizedQuery ASC")
    fun observeHistory(): Flow<List<SearchHistoryEntity>>

    @Upsert suspend fun upsertHistory(entry: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE normalizedQuery = :normalizedQuery")
    suspend fun deleteHistory(normalizedQuery: String)

    @Query("DELETE FROM search_history") suspend fun clearHistory()

    @Query("DELETE FROM search_history WHERE normalizedQuery NOT IN " +
        "(SELECT normalizedQuery FROM search_history ORDER BY timestampMillis DESC, normalizedQuery ASC LIMIT 30)")
    suspend fun trimHistory()

    @Query("SELECT MAX(timestampMillis) FROM search_history")
    suspend fun lastSearchTimestamp(): Long?

    @Transaction @Query("SELECT * FROM shortcuts ORDER BY kind ASC")
    fun observeShortcuts(): Flow<List<ShortcutWithPlace>>

    @Upsert suspend fun upsertShortcut(shortcut: ShortcutEntity)

    @Query("DELETE FROM shortcuts WHERE kind = :kind") suspend fun deleteShortcut(kind: String)

    @Query("DELETE FROM places WHERE id NOT IN (SELECT placeId FROM favorites) " +
        "AND id NOT IN (SELECT placeId FROM shortcuts)")
    suspend fun deleteUnreferencedPlaces()
}

@Database(entities = [PlaceEntity::class, FavoriteEntity::class, SavedListEntity::class,
    ListMembershipEntity::class, SearchHistoryEntity::class, ShortcutEntity::class],
    version = 1, exportSchema = true)
internal abstract class AtlasDatabase : RoomDatabase() {
    abstract fun dao(): AtlasDao

    companion object {
        @Volatile private var instance: AtlasDatabase? = null

        fun get(context: Context): AtlasDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AtlasDatabase::class.java,
                "atlas.db").build().also { instance = it }
        }
    }
}
