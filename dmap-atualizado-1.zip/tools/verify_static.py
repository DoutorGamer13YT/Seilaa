#!/usr/bin/env python3
import ast
import hashlib
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors = []
xmls = list((root / 'app/src/main').rglob('*.xml'))
for path in xmls:
    try:
        ET.parse(path)
    except ET.ParseError as error:
        errors.append(f'{path.relative_to(root)}: {error}')

for path in root.rglob('*.py'):
    try:
        ast.parse(path.read_text(), filename=str(path))
    except SyntaxError as error:
        errors.append(str(error))

required = ['settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts', 'gradlew',
            'gradlew.bat', 'gradle/wrapper/gradle-wrapper.jar', 'app/src/main/AndroidManifest.xml']
for name in required:
    if not (root / name).is_file():
        errors.append('Missing ' + name)

expected_wrapper = '81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f'
if hashlib.sha256((root / 'gradle/wrapper/gradle-wrapper.jar').read_bytes()).hexdigest() != expected_wrapper:
    errors.append('Gradle Wrapper SHA-256 mismatch')

manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
for permission in ['WRITE_EXTERNAL_STORAGE', 'READ_EXTERNAL_STORAGE', 'ACCESS_BACKGROUND_LOCATION', 'WRITE_SECURE_SETTINGS']:
    if permission in manifest:
        errors.append('Unnecessary permission: ' + permission)
if 'foregroundServiceType="dataSync"' not in manifest:
    errors.append('Missing dataSync foreground service declaration')
if 'usesCleartextTraffic="false"' not in manifest:
    errors.append('Cleartext not disabled')

for path in root.rglob('*'):
    if path.suffix in ('.apk', '.dex', '.so') or path.name == 'build-apk.yml':
        errors.append('Unexpected generated or protected artifact: ' + str(path.relative_to(root)))

kotlin = list(root.rglob('*.kt')) + list(root.rglob('*.kts'))
try:
    from tree_sitter import Language, Parser
    import tree_sitter_kotlin
except ImportError:
    print('Kotlin parser unavailable. Install tree-sitter and tree-sitter-kotlin to enable syntax checks.', file=sys.stderr)
    sys.exit(2)
parser = Parser(Language(tree_sitter_kotlin.language()))
for path in kotlin:
    tree = parser.parse(path.read_bytes())
    pending = [tree.root_node]
    while pending:
        node = pending.pop()
        if node.type == 'ERROR' or node.is_missing:
            errors.append(f'{path.relative_to(root)}:{node.start_point.row + 1}: Kotlin parse error')
        pending.extend(node.children)

print('STATIC REVIEW ONLY — no Gradle, Kotlin compiler, APK or Actions executed')
print(f'XML parsed: {len(xmls)}')
print(f'Kotlin/KTS parsed: {len(kotlin)}')
print('Python source parsed with ast; scripts were not executed by this check')
print('Gradle Wrapper hash matches official Gradle 8.13 checksum')
print('Project structure, permission restrictions and artifact exclusions checked')
print('Type resolution, Android lint, compilation, device behavior and map downloads: NOT TESTED')
for error in errors:
    print('ERROR:', error)
print('Result:', 'FAIL' if errors else 'PASS (static checks only)')
sys.exit(1 if errors else 0)
