package dev.atlas.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import dev.atlas.core.*
import dev.atlas.ui.components.AtlasBottomSheet
import dev.atlas.ui.components.SheetPosition
import dev.atlas.ui.screens.PlaceDetailPanel
import dev.atlas.ui.screens.RoutePanel
import dev.atlas.ui.screens.SearchResults
import dev.atlas.ui.theme.AtlasTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Isolated UI behavior: no network, GPS or map provider requests. Not executed in this workspace. */
class MapPanelsTest {
    @get:Rule val compose = createComposeRule()
    private val place = Place("test:1", "Ponto de teste", Coordinate(-23.5, -46.6), "Endereço de teste", source = "Fixture de teste")

    @Test fun routeOriginPickerPreservesItsSearchRoleAndHidesUnsupportedModes() {
        var selected: SearchTarget? = null
        compose.setContent {
            AtlasTheme {
                RoutePanel(MapScreenState(destination = place), Units.METRIC, setOf(TransportMode.CAR),
                    onClose = {}, onSearch = { selected = it }, onUseLocation = {}, onSwap = {},
                    onRemoveStop = {}, onMode = {}, onSelectRoute = {}, onRetry = {}, onStart = {}, onMessage = {})
            }
        }
        compose.onNodeWithText("Escolher origem").performClick()
        compose.runOnIdle { assertEquals(SearchTarget.ORIGIN, selected) }
        compose.onNodeWithText("A pé").assertDoesNotExist()
        compose.onNodeWithText("Bicicleta").assertDoesNotExist()
        compose.onNodeWithText("Iniciar").assertDoesNotExist()
    }

    @Test fun selectingSearchResultReturnsItsIdentityWithoutNameGuessing() {
        val other = place.copy(id = "test:2", name = "Ponto de teste em outra cidade", coordinate = Coordinate(-22.0, -45.0))
        var selected: Place? = null
        compose.setContent {
            AtlasTheme {
                SearchResults(MapScreenState(query = "Ponto", searched = true, results = listOf(place, other)),
                    emptyList(), emptyList(), Units.METRIC, null, { selected = it }, {}, {}, {})
            }
        }
        compose.onNodeWithText(other.name).performClick()
        compose.runOnIdle { assertEquals(other, selected) }
    }

    @Test fun emptySearchShowsRecoveryWithoutFabricatedResults() {
        compose.setContent {
            AtlasTheme {
                SearchResults(MapScreenState(query = "Lugar ausente", searched = true),
                    emptyList(), emptyList(), Units.METRIC, null, {}, {}, {}, {})
            }
        }
        compose.onNodeWithText("Nenhum lugar encontrado").assertIsDisplayed()
        compose.onNodeWithText("Tente incluir a cidade ou pesquisar outro endereço.").assertIsDisplayed()
    }

    @Test fun networkFailureCanBeRetriedWithoutRecreatingTheScreen() {
        var retries = 0
        compose.setContent {
            AtlasTheme {
                SearchResults(MapScreenState(query = "Rua", searched = true, error = "Sem conexão."),
                    emptyList(), emptyList(), Units.METRIC, null, {}, { retries++ }, {}, {})
            }
        }
        compose.onNodeWithText("Tentar novamente").performClick()
        compose.runOnIdle { assertEquals(1, retries) }
        compose.onNodeWithText("Sem conexão.").assertExists()
    }

    @Test fun placeWithoutCommercialMetadataStillOffersDirections() {
        var routed = false
        compose.setContent {
            AtlasTheme {
                PlaceDetailPanel(place, saved = false, loading = false, error = null, distance = null,
                    onClose = {}, onRoute = { routed = true }, onFavorite = {}, onCenter = {}, onRetry = {}, onShortcut = {}, onMessage = {})
            }
        }
        compose.onNodeWithText("Como chegar").performClick()
        compose.runOnIdle { assertTrue(routed) }
        compose.onNodeWithText("Telefone").assertDoesNotExist()
        compose.onNodeWithText("Site").assertDoesNotExist()
    }

    @Test fun sheetCanReachAllFourPositionsThroughAccessibilityActions() {
        compose.setContent {
            AtlasTheme(reduceMotion = true) {
                var position by remember { mutableStateOf(SheetPosition.Collapsed) }
                Box(Modifier.fillMaxSize()) {
                    AtlasBottomSheet(position, { position = it }, reduceMotion = true) { Text("Conteúdo do painel") }
                }
            }
        }
        val handle = compose.onNodeWithContentDescription("Painel de mapas")
        for (position in SheetPosition.entries) {
            handle.assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, position.accessibilityLabel))
            if (position != SheetPosition.Expanded) handle.performSemanticsAction(SemanticsActions.Expand) { it() }
        }
        handle.performSemanticsAction(SemanticsActions.Collapse) { it() }
        handle.assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, SheetPosition.Half.accessibilityLabel))
    }
}
