package dev.atlas.core

import org.junit.Assert.assertEquals
import org.junit.Test

class MapSourceTest {
    @Test fun offlineUsesOpenStreetMap() {
        assertEquals(MapSource.OPEN_STREET_MAP, MapSourcePolicy.choose(online = false, hasToken = true, appleFailed = false))
        assertEquals(MapSource.OPEN_STREET_MAP, MapSourcePolicy.choose(online = false, hasToken = false, appleFailed = false))
    }

    @Test fun onlineWithTokenUsesMapKit() =
        assertEquals(MapSource.APPLE, MapSourcePolicy.choose(online = true, hasToken = true, appleFailed = false))

    @Test fun onlineWithoutTokenUsesAppleViewer() =
        assertEquals(MapSource.APPLE_VIEW, MapSourcePolicy.choose(online = true, hasToken = false, appleFailed = false))

    @Test fun appleFailureFallsBackToOpenStreetMap() {
        assertEquals(MapSource.OPEN_STREET_MAP, MapSourcePolicy.choose(online = true, hasToken = true, appleFailed = true))
        assertEquals(MapSource.OPEN_STREET_MAP, MapSourcePolicy.choose(online = true, hasToken = false, appleFailed = true))
    }
}
