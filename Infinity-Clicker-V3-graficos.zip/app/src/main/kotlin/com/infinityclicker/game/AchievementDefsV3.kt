package com.infinityclicker.game

import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.upgrades.UpgradeIds
import kotlin.math.roundToInt

enum class AchievementCategory(val label: String) {
    CLICKS("Cliques"),
    PRODUCTION("Produção"),
    UPGRADES("Melhorias"),
    PRESTIGE("Prestígio"),
    ABILITIES("Habilidades"),
    CHALLENGES("Desafios"),
    EXPLORATION("Exploração"),
    SECRET("Secretas")
}

data class AchievementProgress(val fraction: Float, val label: String)

/** Condição, progresso e recompensa ficam no domínio; a tela só apresenta dados reais. */
data class AchievementDef(
    val id: String,
    val category: AchievementCategory,
    val rarity: Rarity,
    val title: String,
    val description: String,
    val reward: Int,
    val secret: Boolean = false,
    val achieved: (GameState) -> Boolean,
    val progress: (GameState) -> AchievementProgress
)

/** Galeria V3: 250 conquistas divididas nas oito categorias solicitadas. */
object AchievementDefs {
    private data class LongSeed(val id: String, val title: String, val target: Long)
    private data class BigSeed(val id: String, val title: String, val target: BigNum)
    private data class DoubleSeed(val id: String, val title: String, val target: Double)

    val all: List<AchievementDef> = buildList {
        addAll(clicks())
        addAll(production())
        addAll(upgrades())
        addAll(prestige())
        addAll(abilities())
        addAll(challenges())
        addAll(exploration())
        addAll(secrets())
        check(size == 250) { "A galeria V3 deve conter 250 conquistas; recebeu $size" }
        check(map { it.id }.toSet().size == size) { "IDs de conquistas V3 precisam ser únicos" }
    }
    val byId: Map<String, AchievementDef> = all.associateBy { it.id }

    private fun clicks(): List<AchievementDef> = buildList {
        addAll(longSeries(AchievementCategory.CLICKS, "Clique em qualquer ponto do cristal.", { it.totalClicks }, listOf(
            LongSeed("click_spark", "Primeira Centelha", 1),
            LongSeed("click_rhythm", "Ritmo Desperto", 10),
            LongSeed("click_hand", "Mão Persistente", 50),
            LongSeed("click_pulse", "Pulso Contínuo", 250),
            LongSeed("click_1k", "Mil Pulsos", 1_000),
            LongSeed("click_sculptor", "Escultor de Éter", 5_000),
            LongSeed("click_orbit", "Órbita Incansável", 25_000),
            LongSeed("click_legacy", "Legado dos Dedos", 100_000)
        )))
        addAll(longSeries(AchievementCategory.CLICKS, "Encontre o brilho dourado de um clique crítico.", { it.critClicks }, listOf(
            LongSeed("crit_first", "Reflexo Dourado", 1),
            LongSeed("crit_ten", "Sorte em Movimento", 10),
            LongSeed("crit_fifty", "Olhar Prismático", 50),
            LongSeed("crit_hunter", "Caçador de Centelhas", 250),
            LongSeed("crit_thousand", "Constelação Crítica", 1_000),
            LongSeed("crit_storm", "Tempestade de Ouro", 5_000),
            LongSeed("crit_myth", "Mito Improvável", 25_000)
        )))
        addAll(longSeries(AchievementCategory.CLICKS, "Mantenha toques dentro da janela de combo.", { it.maxCombo.toLong() }, listOf(
            LongSeed("combo_pair", "Dois em Sintonia", 2),
            LongSeed("combo_five", "Ritmo Lunar", 5),
            LongSeed("combo_ten", "Decálogo de Luz", 10),
            LongSeed("combo_twenty", "Espiral Veloz", 20),
            LongSeed("combo_thirty", "Ressonância Total", 30),
            LongSeed("combo_fifty", "Chuva de Toques", 50),
            LongSeed("combo_seventyfive", "Dança de Quasares", 75),
            LongSeed("combo_hundred", "Pulso Infinito", 100)
        )))
        addAll(longSeries(AchievementCategory.CLICKS, "Alcance esta velocidade real em uma janela de um segundo.", { it.bestClicksPerSecond.toLong() }, listOf(
            LongSeed("cps_two", "Batida Dupla", 2),
            LongSeed("cps_four", "Metrônomo Estelar", 4),
            LongSeed("cps_six", "Dedos Fotônicos", 6),
            LongSeed("cps_eight", "Surto Manual", 8),
            LongSeed("cps_ten", "Ritmo Impossível", 10)
        )))
        addAll(bigSeries(AchievementCategory.CLICKS, "Acumule esta energia proveniente de cliques.", { it.clickEnergy }, listOf(
            BigSeed("click_energy_100", "Fagulhas Guardadas", BigNum.of(100.0)),
            BigSeed("click_energy_1k", "Carga Pessoal", BigNum.of(1_000.0)),
            BigSeed("click_energy_100k", "Mão de Nebulosa", BigNum.of(100_000.0)),
            BigSeed("click_energy_1m", "Artista Cósmico", BigNum.of(1e6)),
            BigSeed("click_energy_1b", "Titã do Toque", BigNum.of(1e9)),
            BigSeed("click_energy_1t", "Arquitetura Manual", BigNum.of(1e12))
        )))
        addAll(doubleSeries(AchievementCategory.CLICKS, "Registre este multiplicador real em um único toque.", { it.highestTapMultiplier }, listOf(
            DoubleSeed("tap_mult_15", "Impacto Crescente", 1.5),
            DoubleSeed("tap_mult_2", "Dobra de Energia", 2.0),
            DoubleSeed("tap_mult_5", "Prisma Afiado", 5.0),
            DoubleSeed("tap_mult_10", "Golpe de Supernova", 10.0),
            DoubleSeed("tap_mult_25", "Fenda de Poder", 25.0),
            DoubleSeed("tap_mult_100", "Mão Transcendental", 100.0)
        )))
        check(size == 40)
    }

    private fun production(): List<AchievementDef> = buildList {
        addAll(bigSeries(AchievementCategory.PRODUCTION, "Produza energia por qualquer fonte.", { it.totalEnergy }, listOf(
            BigSeed("energy_1k", "Massa Inicial", BigNum.of(1e3)),
            BigSeed("energy_10k", "Câmara Carregada", BigNum.of(1e4)),
            BigSeed("energy_100k", "Núcleo Vivo", BigNum.of(1e5)),
            BigSeed("energy_1m", "Massa Crítica", BigNum.of(1e6)),
            BigSeed("energy_100m", "Forno Nebular", BigNum.of(1e8)),
            BigSeed("energy_10b", "Céu Industrial", BigNum.of(1e10)),
            BigSeed("energy_1t", "Escala Estelar", BigNum.of(1e12)),
            BigSeed("energy_1qa", "Horizonte Econômico", BigNum.of(1e15))
        )))
        addAll(bigSeries(AchievementCategory.PRODUCTION, "Alcance esta produção por segundo em algum momento.", { it.highestProduction }, listOf(
            BigSeed("ps_1", "Primeiro Gerador", BigNum.of(1.0)),
            BigSeed("ps_10", "Fluxo Estável", BigNum.of(10.0)),
            BigSeed("ps_100", "Reator Desperto", BigNum.of(100.0)),
            BigSeed("ps_1k", "Esteira Estelar", BigNum.of(1e3)),
            BigSeed("ps_100k", "Cidade de Estrelas", BigNum.of(1e5)),
            BigSeed("ps_10m", "Rede Galáctica", BigNum.of(1e7)),
            BigSeed("ps_1b", "Forja Universal", BigNum.of(1e9)),
            BigSeed("ps_1t", "Motor Multiversal", BigNum.of(1e12))
        )))
        addAll(bigSeries(AchievementCategory.PRODUCTION, "Receba esta energia dos geradores enquanto joga.", { it.productionEnergy }, listOf(
            BigSeed("auto_100", "Máquinas Acordadas", BigNum.of(100.0)),
            BigSeed("auto_10k", "Rotina Cósmica", BigNum.of(1e4)),
            BigSeed("auto_1m", "Fábrica de Nebulosas", BigNum.of(1e6)),
            BigSeed("auto_100m", "Sinfonia Mecânica", BigNum.of(1e8)),
            BigSeed("auto_10b", "Economia Autônoma", BigNum.of(1e10)),
            BigSeed("auto_1t", "Civilização de Máquinas", BigNum.of(1e12))
        )))
        addAll(longSeries(AchievementCategory.PRODUCTION, "Compre geradores para ampliar a malha automática.", { it.generatorsBought }, listOf(
            LongSeed("gen_1", "Engenheiro Iniciante", 1),
            LongSeed("gen_10", "Colecionador de Núcleos", 10),
            LongSeed("gen_50", "Oficina Estelar", 50),
            LongSeed("generators_100", "Engenheiro de Estrelas", 100),
            LongSeed("gen_500", "Construtor de Universos", 500)
        )))
        addAll(longSeries(AchievementCategory.PRODUCTION, "Alcance este tier de gerador em qualquer corrida.", { it.highestGeneratorTierEver.toLong() + 1L }, listOf(
            LongSeed("tier_1", "Fragmento Domado", 1),
            LongSeed("tier_3", "Sol Particular", 3),
            LongSeed("tier_6", "Galáxia Operária", 6),
            LongSeed("tier_10", "Porta do Infinito", 10)
        )))
        addAll(bigSeries(AchievementCategory.PRODUCTION, "Receba esta energia por ganhos offline válidos.", { it.offlineEarned }, listOf(
            BigSeed("offline_1k", "Sono Produtivo", BigNum.of(1e3)),
            BigSeed("offline_100k", "Descanso Estelar", BigNum.of(1e5)),
            BigSeed("offline_10m", "Tempo Bem Dobrado", BigNum.of(1e7)),
            BigSeed("offline_1b", "Relógio Cósmico", BigNum.of(1e9))
        )))
        check(size == 35)
    }

    private fun upgrades(): List<AchievementDef> = buildList {
        addAll(longSeries(AchievementCategory.UPGRADES, "Compre níveis de melhoria reais.", { it.upgradeLevelsBought }, listOf(
            LongSeed("up_1", "Primeiro Ajuste", 1), LongSeed("up_5", "Ferramenta Afinada", 5),
            LongSeed("up_15", "Laboratório Ativo", 15), LongSeed("up_30", "Matriz Melhorada", 30),
            LongSeed("up_60", "Engenharia de Vácuo", 60), LongSeed("up_100", "Oficina Cósmica", 100),
            LongSeed("up_250", "Ciência Persistente", 250), LongSeed("up_500", "Mestre de Melhorias", 500)
        )))
        addAll(longSeries(AchievementCategory.UPGRADES, "Eleve uma melhoria individual até este nível.", { it.highestUpgradeLevelEver.toLong() }, listOf(
            LongSeed("up_level_1", "Ajuste Fino", 1), LongSeed("up_level_5", "Circuito Maduro", 5),
            LongSeed("up_level_10", "Calibração Profunda", 10), LongSeed("up_level_25", "Arquitetura de Poder", 25),
            LongSeed("up_level_50", "Perfeição Recursiva", 50)
        )))
        addAll(longSeries(AchievementCategory.UPGRADES, "Desbloqueie melhorias de tipos diferentes.", { it.upgradeLevels.count { entry -> entry.value > 0 }.toLong() }, listOf(
            LongSeed("up_unique_2", "Ferramentas Cruzadas", 2), LongSeed("up_unique_5", "Caixa de Ferramentas", 5),
            LongSeed("up_unique_10", "Estratégia Modular", 10), LongSeed("up_unique_15", "Biblioteca de Projetos", 15)
        )))
        addAll(longSeries(AchievementCategory.UPGRADES, "Use o modo de compra ×1 em operações reais.", { it.purchaseModeUses.getOrElse(0) { 0L } }, listOf(
            LongSeed("buy_one_10", "Paciência de Artesão", 10), LongSeed("buy_one_50", "Detalhista Cósmico", 50),
            LongSeed("buy_one_250", "Ritual de Precisão", 250), LongSeed("buy_one_1k", "Mestre do Unitário", 1_000)
        )))
        addAll(listOf(
            longAchievement("buy_ten", AchievementCategory.UPGRADES, Rarity.INCOMUM, "Compra em Bloco", "Use o modo ×10 uma vez.", 2, { it.purchaseModeUses.getOrElse(1) { 0L } }, 1),
            longAchievement("buy_hundred", AchievementCategory.UPGRADES, Rarity.RARO, "Armazém Estelar", "Use o modo ×100 uma vez.", 3, { it.purchaseModeUses.getOrElse(2) { 0L } }, 1),
            longAchievement("buy_max", AchievementCategory.UPGRADES, Rarity.EPICO, "Tudo o que Couber", "Use o modo Máx uma vez.", 4, { it.purchaseModeUses.getOrElse(3) { 0L } }, 1)
        ))
        addAll(longSeries(AchievementCategory.UPGRADES, "Mantenha este número de geradores simultaneamente após uma compra.", { it.generators.sum() }, listOf(
            LongSeed("owned_25", "Constelação Pequena", 25), LongSeed("owned_100", "Malha de Geradores", 100), LongSeed("owned_500", "Frota de Produção", 500)
        )))
        val specific = listOf(
            Triple("upgrade_click", "Punho Reforçado", UpgradeIds.CLICK_POWER), Triple("upgrade_crit", "Olho Estelar", UpgradeIds.CRIT_CHANCE),
            Triple("upgrade_combo", "Maestro de Combo", UpgradeIds.COMBO_CAP), Triple("upgrade_siphon", "Sifão Vivo", UpgradeIds.CLICK_PS),
            Triple("upgrade_global", "Matriz de Fótons", UpgradeIds.MULT_GLOBAL_1), Triple("upgrade_offline", "Câmara Temporal", UpgradeIds.OFFLINE_CAP),
            Triple("upgrade_gen", "Primeira Otimização", UpgradeIds.generator(0)), Triple("upgrade_void", "Eco do Vazio", UpgradeIds.MULT_GLOBAL_2)
        )
        specific.forEachIndexed { index, (id, title, upgradeId) ->
            add(longAchievement(id, AchievementCategory.UPGRADES, rarityAt(index + 5, specific.size + 6), title, "Compre esta melhoria estratégica ao menos uma vez.", rewardFor(rarityAt(index + 5, specific.size + 6)), { it.level(upgradeId).toLong() }, 1))
        }
        check(size == 35)
    }

    private fun prestige(): List<AchievementDef> = buildList {
        addAll(longSeries(AchievementCategory.PRESTIGE, "Renove o universo para acumular pontos permanentes.", { it.prestigeCount.toLong() }, listOf(
            LongSeed("prestige_first", "Além do Véu", 1), LongSeed("prestige_three", "Trilogia de Renascimentos", 3),
            LongSeed("prestige_ten", "Decálogo Eterno", 10), LongSeed("prestige_twentyfive", "Ciclo de Prata", 25),
            LongSeed("prestige_fifty", "Fênix Galáctica", 50), LongSeed("prestige_hundred", "Roda do Infinito", 100),
            LongSeed("prestige_250", "Memória de 250 Vidas", 250)
        )))
        addAll(longSeries(AchievementCategory.PRESTIGE, "Guarde pontos de prestígio para a árvore cósmica.", { it.prestigePoints.toLong() }, listOf(
            LongSeed("pp_1", "Moeda Eterna", 1), LongSeed("pp_10", "Pequena Constelação", 10), LongSeed("pp_25", "Reserva Transcendente", 25),
            LongSeed("pp_75", "Cofre Cósmico", 75), LongSeed("pp_200", "Tesouro de Éter", 200), LongSeed("pp_500", "Herança Infinita", 500)
        )))
        addAll(longSeries(AchievementCategory.PRESTIGE, "Invista níveis na árvore de habilidades.", { it.skillLevels.values.sum().toLong() }, listOf(
            LongSeed("skill_1", "Primeira Escolha", 1), LongSeed("skill_10", "Ramo Crescente", 10), LongSeed("skill_25", "Copa Cósmica", 25),
            LongSeed("skill_60", "Árvore Viva", 60), LongSeed("skill_120", "Bosque Transcendental", 120)
        )))
        SkillPath.entries.forEachIndexed { index, path ->
            add(longAchievement("path_${path.name.lowercase()}", AchievementCategory.PRESTIGE, rarityAt(index + 2, SkillPath.entries.size + 5), "Caminho ${path.label}", "Compre ao menos um nó do caminho ${path.label}.", rewardFor(rarityAt(index + 2, SkillPath.entries.size + 5)), { s -> SkillTree.all.count { it.path == path && s.skillLevel(it.id) > 0 }.toLong() }, 1))
        }
        addAll(longSeries(AchievementCategory.PRESTIGE, "Realize renascimentos com esta pontuação em uma única entrada do histórico.", { state -> state.prestigeHistory.maxOfOrNull { it.points }?.toLong() ?: 0L }, listOf(
            LongSeed("prestige_quality_1", "Salto Calculado", 1), LongSeed("prestige_quality_5", "Horizonte Brilhante", 5), LongSeed("prestige_quality_15", "Reinício Monumental", 15), LongSeed("prestige_quality_40", "Vértice Eterno", 40)
        )))
        addAll(doubleSeries(AchievementCategory.PRESTIGE, "Alcance este bônus permanente calculado pelos seus pontos e nós.", { permanentMultiplier(it) }, listOf(
            DoubleSeed("perm_125", "Memória Ativa", 1.25), DoubleSeed("perm_2", "Universo Mais Forte", 2.0), DoubleSeed("perm_5", "Legado Imenso", 5.0)
        )))
        check(size == 30)
    }

    private fun abilities(): List<AchievementDef> = buildList {
        addAll(longSeries(AchievementCategory.ABILITIES, "Ative habilidades quando elas tiverem efeito real.", { it.abilitiesUsed }, listOf(
            LongSeed("ability_1", "Primeira Canalização", 1), LongSeed("ability_5", "Pulso Treinado", 5),
            LongSeed("ability_15", "Ritual de Energia", 15), LongSeed("ability_50", "Arsenal Cósmico", 50),
            LongSeed("ability_150", "Operador Temporal", 150), LongSeed("ability_500", "Mestre de Recargas", 500),
            LongSeed("ability_2k", "Sinfonia de Poderes", 2_000), LongSeed("ability_10k", "Canal Infinito", 10_000)
        )))
        addAll(longSeries(AchievementCategory.ABILITIES, "Evolua o total de níveis das suas habilidades.", { it.abilityLevels.values.sum().toLong() + AbilityDefs.all.count { def -> it.abilityLevels[def.id] == null }.toLong() }, listOf(
            LongSeed("ability_level_5", "Kit Desperto", 5), LongSeed("ability_level_10", "Circuito Afinado", 10),
            LongSeed("ability_level_18", "Talento Dimensional", 18), LongSeed("ability_level_25", "Poder Lapidado", 25), LongSeed("ability_level_32", "Arsenal Máximo", 32)
        )))
        AbilityDefs.all.forEachIndexed { index, ability ->
            add(longAchievement("ability_seen_${ability.id}", AchievementCategory.ABILITIES, rarityAt(index, AbilityDefs.count + 3), "${ability.name} Desperto", "Use ${ability.name} ao menos uma vez.", rewardFor(rarityAt(index, AbilityDefs.count + 3)), { it.abilityUseCounts[ability.id] ?: 0L }, 1))
        }
        AbilityDefs.all.forEachIndexed { index, ability ->
            add(longAchievement("ability_master_${ability.id}", AchievementCategory.ABILITIES, rarityAt(index + 3, AbilityDefs.count + 5), "Mestre: ${ability.name}", "Use ${ability.name} 25 vezes.", rewardFor(rarityAt(index + 3, AbilityDefs.count + 5)), { it.abilityUseCounts[ability.id] ?: 0L }, 25))
        }
        AbilityDefs.all.forEachIndexed { index, ability ->
            add(longAchievement("ability_rank_${ability.id}", AchievementCategory.ABILITIES, rarityAt(index + 4, AbilityDefs.count + 6), "Núcleo: ${ability.name}", "Eleve ${ability.name} ao nível 4.", rewardFor(rarityAt(index + 4, AbilityDefs.count + 6)), { (it.abilityLevels[ability.id] ?: 1).toLong() }, 4))
        }
        add(longAchievement("ability_all_rank_two", AchievementCategory.ABILITIES, Rarity.EPICO, "Sintonia Completa", "Eleve todas as habilidades ao menos ao nível 2.", 4, { s -> AbilityDefs.all.count { (s.abilityLevels[it.id] ?: 1) >= 2 }.toLong() }, AbilityDefs.count.toLong()))
        add(longAchievement("ability_all_rank_max", AchievementCategory.ABILITIES, Rarity.TRANSCENDENTAL, "Arsenal Absoluto", "Eleve todas as habilidades ao nível máximo.", 12, { s -> AbilityDefs.all.count { (s.abilityLevels[it.id] ?: 1) >= it.maxLevel }.toLong() }, AbilityDefs.count.toLong()))
        addAll(longSeries(AchievementCategory.ABILITIES, "Descubra habilidades diferentes em uso.", { s -> AbilityDefs.all.count { (s.abilityUseCounts[it.id] ?: 0L) > 0L }.toLong() }, listOf(
            LongSeed("ability_variety_2", "Dueto de Poder", 2), LongSeed("ability_variety_3", "Tríade de Energia", 3), LongSeed("ability_variety_4", "Quatro Faces do Infinito", 4)
        )))
        check(size == 30)
    }

    private fun challenges(): List<AchievementDef> = buildList {
        ChallengeDefs.all.forEachIndexed { index, challenge ->
            add(longAchievement("challenge_first_${challenge.id}", AchievementCategory.CHALLENGES, rarityAt(index + 1, ChallengeDefs.count + 4), "${challenge.name} Concluído", "Complete o desafio ${challenge.name} uma vez.", rewardFor(rarityAt(index + 1, ChallengeDefs.count + 4)), { it.challengeWins[index] }, 1))
        }
        addAll(longSeries(AchievementCategory.CHALLENGES, "Complete desafios opcionais válidos.", { it.challengeCompletions }, listOf(
            LongSeed("challenge_total_1", "Aceitou o Chamado", 1), LongSeed("challenge_total_3", "Três Provas", 3),
            LongSeed("challenge_total_7", "Semana de Provas", 7), LongSeed("challenge_total_15", "Viajante Disciplinado", 15),
            LongSeed("challenge_total_30", "Veterano de Desafios", 30), LongSeed("challenge_total_60", "Campeão Cósmico", 60),
            LongSeed("challenge_total_120", "Lenda das Provas", 120), LongSeed("challenge_total_300", "Infinito Testado", 300)
        )))
        addAll(longSeries(AchievementCategory.CHALLENGES, "Complete um desafio dentro deste tempo.", { if (it.challengeFastestMs == Long.MAX_VALUE) 0L else it.challengeFastestMs }, listOf(
            LongSeed("challenge_time_120", "Ritmo Seguro", 120_000), LongSeed("challenge_time_75", "Passo Acelerado", 75_000),
            LongSeed("challenge_time_45", "Voo de Cometa", 45_000), LongSeed("challenge_time_20", "Segundo Impossível", 20_000)
        ), lessIsBetter = true))
        ChallengeDefs.all.forEachIndexed { index, challenge ->
            add(longAchievement("challenge_repeat2_${challenge.id}", AchievementCategory.CHALLENGES, Rarity.RARO, "${challenge.name} Revisitado", "Complete ${challenge.name} duas vezes.", 3, { it.challengeWins[index] }, 2))
            add(longAchievement("challenge_repeat5_${challenge.id}", AchievementCategory.CHALLENGES, Rarity.EPICO, "Mestre de ${challenge.name}", "Complete ${challenge.name} cinco vezes.", 4, { it.challengeWins[index] }, 5))
        }
        check(size == 30)
    }

    private fun exploration(): List<AchievementDef> = buildList {
        addAll(longSeries(AchievementCategory.EXPLORATION, "Abra dimensões do mapa cósmico.", { it.dimensionUnlocked.count { open -> open }.toLong() }, listOf(
            LongSeed("dimension_1", "Primeira Casa", 1), LongSeed("dimension_2", "Mapa em Expansão", 2),
            LongSeed("dimension_3", "Nuvens Abertas", 3), LongSeed("dimension_4", "Espiral Visitada", 4), LongSeed("dimension_5", "Probabilidade Livre", 5)
        )))
        addAll(longSeries(AchievementCategory.EXPLORATION, "Desbloqueie cenários que mudam o fundo real do jogo.", { it.backgroundsUnlocked.count { open -> open }.toLong() }, listOf(
            LongSeed("background_1", "Olhos no Espaço", 1), LongSeed("background_2", "Nebulosa Escolhida", 2), LongSeed("background_3", "Braços de Galáxia", 3),
            LongSeed("background_4", "Horizonte Escuro", 4), LongSeed("background_5", "Campo Quântico", 5), LongSeed("background_6", "Tempo Visível", 6),
            LongSeed("background_7", "Reino Sem Fim", 7), LongSeed("background_8", "Realidade Reescrita", 8)
        )))
        addAll(longSeries(AchievementCategory.EXPLORATION, "Colecione aparências de cristal com bônus de clique reais.", { it.crystalsUnlocked.count { own -> own }.toLong() }, listOf(
            LongSeed("crystal_1", "Éter Inicial", 1), LongSeed("crystal_2", "Aurora Solar", 2), LongSeed("crystal_3", "Névoa Rosa", 3),
            LongSeed("crystal_4", "Vórtice Equipado", 4), LongSeed("crystal_5", "Singularidade Vestida", 5)
        )))
        addAll(longSeries(AchievementCategory.EXPLORATION, "Viaje entre dimensões desbloqueadas.", { it.dimensionTravelCount }, listOf(
            LongSeed("travel_1", "Primeira Travessia", 1), LongSeed("travel_10", "Turista do Vazio", 10), LongSeed("travel_50", "Cartógrafo Cósmico", 50), LongSeed("travel_200", "Navegador Infinito", 200)
        )))
        addAll(longSeries(AchievementCategory.EXPLORATION, "Derrote entidades cósmicas em qualquer dimensão.", { it.bossWins.sum().toLong() }, listOf(
            LongSeed("boss_first", "Caçador Cósmico", 1), LongSeed("boss_10", "Guardião de Dimensões", 10), LongSeed("boss_25", "Lenda dos Chefes", 25)
        )))
        check(size == 25)
    }

    private fun secrets(): List<AchievementDef> = buildList {
        fun secret(id: String, title: String, description: String, rarity: Rarity, achieved: (GameState) -> Boolean, progress: (GameState) -> AchievementProgress) {
            add(AchievementDef(id, AchievementCategory.SECRET, rarity, title, description, rewardFor(rarity), true, achieved, progress))
        }
        secret("secret_42", "Resposta Pulsante", "O cristal reconheceu a resposta universal nos seus toques.", Rarity.RARO, { it.totalClicks >= 42 }, { longProgress(it.totalClicks, 42) })
        secret("secret_combo_13", "Número de Órbitas", "Um combo pouco comum se formou ao redor do cristal.", Rarity.INCOMUM, { it.maxCombo >= 13 }, { longProgress(it.maxCombo.toLong(), 13) })
        secret("secret_crit_7", "Sete Reflexos", "Sete brilhos dourados foram registrados.", Rarity.RARO, { it.critClicks >= 7 }, { longProgress(it.critClicks, 7) })
        secret("secret_event_3", "Céu Instável", "Você sobreviveu a eventos suficientes para notar o padrão.", Rarity.EPICO, { it.eventsTriggered >= 3 }, { longProgress(it.eventsTriggered, 3) })
        secret("secret_cps_7", "Sete Batidas", "O tempo quase parou durante uma sequência veloz.", Rarity.RARO, { it.bestClicksPerSecond >= 7 }, { longProgress(it.bestClicksPerSecond.toLong(), 7) })
        secret("secret_bg_7", "Além do Cenário", "O reino infinito deixou de ser apenas uma hipótese.", Rarity.MITICO, { it.backgroundsUnlocked.getOrElse(6) { false } }, { booleanProgress(it.backgroundsUnlocked.getOrElse(6) { false }) })
        secret("secret_quantum", "Observador Quântico", "Você chegou à dimensão em que a chance tem massa.", Rarity.LENDARIO, { it.dimensionUnlocked.getOrElse(4) { false } }, { booleanProgress(it.dimensionUnlocked.getOrElse(4) { false }) })
        secret("secret_max_buy", "Sem Deixar Poeira", "O estoque foi drenado de uma só vez.", Rarity.INCOMUM, { it.purchaseModeUses.getOrElse(3) { 0L } > 0L }, { longProgress(it.purchaseModeUses.getOrElse(3) { 0L }, 1) })
        secret("secret_challenge_3", "Três Portais", "Três provas revelaram uma rota alternativa.", Rarity.EPICO, { it.challengeCompletions >= 3 }, { longProgress(it.challengeCompletions, 3) })
        secret("secret_crystal_all", "Coleção Prismática", "Todos os cristais conhecidos respondem ao seu chamado.", Rarity.MITICO, { it.crystalsUnlocked.all { unlocked -> unlocked } }, { longProgress(it.crystalsUnlocked.count { unlocked -> unlocked }.toLong(), CrystalDefs.count.toLong()) })
        secret("secret_click_energy", "Calor das Mãos", "Sua energia manual deixou marca no vazio.", Rarity.EPICO, { it.clickEnergy >= BigNum.of(1e7) }, { bigProgress(it.clickEnergy, BigNum.of(1e7)) })
        secret("secret_offline", "Enquanto Você Dormia", "O universo trabalhou por você durante muito tempo.", Rarity.RARO, { it.offlineEarned >= BigNum.of(1e6) }, { bigProgress(it.offlineEarned, BigNum.of(1e6)) })
        secret("secret_skill_20", "Raízes Invisíveis", "A árvore cresceu além do que os olhos veem.", Rarity.LENDARIO, { it.skillLevels.values.sum() >= 20 }, { longProgress(it.skillLevels.values.sum().toLong(), 20) })
        secret("secret_boss_5", "Assinatura de Caçador", "Cinco entidades conhecem o peso do seu toque.", Rarity.EPICO, { it.bossWins.sum() >= 5 }, { longProgress(it.bossWins.sum().toLong(), 5) })
        secret("secret_event_10", "Meteorologista do Vazio", "O céu já não guarda surpresas para você.", Rarity.LENDARIO, { it.eventsTriggered >= 10 }, { longProgress(it.eventsTriggered, 10) })
        secret("secret_prestige_7", "Sete Renascimentos", "Uma constelação se fechou no seu histórico.", Rarity.MITICO, { it.prestigeCount >= 7 }, { longProgress(it.prestigeCount.toLong(), 7) })
        secret("secret_ability_all", "Quadrado de Energia", "As quatro habilidades foram chamadas ao menos uma vez.", Rarity.EPICO, { s -> AbilityDefs.all.all { (s.abilityUseCounts[it.id] ?: 0L) > 0L } }, { s -> longProgress(AbilityDefs.all.count { (s.abilityUseCounts[it.id] ?: 0L) > 0L }.toLong(), AbilityDefs.count.toLong()) })
        secret("secret_manual", "Sem Máquinas", "Você concluiu uma prova confiando somente na própria mão.", Rarity.EPICO, { it.challengeWins.getOrElse(0) { 0L } > 0L }, { longProgress(it.challengeWins.getOrElse(0) { 0L }, 1) })
        secret("secret_fast_trial", "Velocidade de Escape", "Uma prova foi concluída antes de o vazio notar.", Rarity.MITICO, { it.challengeFastestMs <= 20_000L }, { if (it.challengeFastestMs == Long.MAX_VALUE) AchievementProgress(0f, "—") else AchievementProgress((20_000.0 / it.challengeFastestMs).toFloat().coerceIn(0f, 1f), NumberFormatter.duration(it.challengeFastestMs)) })
        secret("secret_upgrade_25", "Projeto Proibido", "Uma melhoria superou o nível 25.", Rarity.LENDARIO, { it.highestUpgradeLevelEver >= 25 }, { longProgress(it.highestUpgradeLevelEver.toLong(), 25) })
        secret("secret_storm", "Produção de Tempestade", "Seu motor atingiu uma escala que pode alterar climas cósmicos.", Rarity.MITICO, { it.highestProduction >= BigNum.of(1e9) }, { bigProgress(it.highestProduction, BigNum.of(1e9)) })
        secret("secret_travel_42", "A Rota 42", "Quarenta e duas viagens dobraram o mapa sobre si mesmo.", Rarity.LENDARIO, { it.dimensionTravelCount >= 42 }, { longProgress(it.dimensionTravelCount, 42) })
        secret("secret_cosmic_path", "Discípulo do Centro", "O caminho cósmico recebeu uma dedicação rara.", Rarity.TRANSCENDENTAL, { s -> SkillTree.all.count { it.path == SkillPath.COSMIC && s.skillLevel(it.id) > 0 } >= 10 }, { s -> longProgress(SkillTree.all.count { it.path == SkillPath.COSMIC && s.skillLevel(it.id) > 0 }.toLong(), 10) })
        secret("secret_reality", "Realidade Destravada", "A realidade transcendental foi alcançada sem atalhos externos.", Rarity.TRANSCENDENTAL, { it.backgroundsUnlocked.getOrElse(7) { false } }, { booleanProgress(it.backgroundsUnlocked.getOrElse(7) { false }) })
        secret("secret_universe", "Universo de Bolso", "O tier Universo respondeu às suas máquinas.", Rarity.COSMICO, { it.highestGeneratorTierEver >= 7 }, { longProgress((it.highestGeneratorTierEver + 1).toLong(), 8) })
        check(size == 25)
    }

    private fun longSeries(
        category: AchievementCategory,
        description: String,
        metric: (GameState) -> Long,
        seeds: List<LongSeed>,
        lessIsBetter: Boolean = false
    ): List<AchievementDef> = seeds.mapIndexed { index, seed ->
        val rarity = rarityAt(index, seeds.size)
        val text = if (lessIsBetter) "$description Conclua em ${NumberFormatter.duration(seed.target)} ou menos." else "$description Meta: ${seed.target}."
        if (lessIsBetter) {
            AchievementDef(seed.id, category, rarity, seed.title, text, rewardFor(rarity), false,
                achieved = { state -> val value = metric(state); value > 0L && value <= seed.target },
                progress = { state -> val value = metric(state); if (value <= 0L) AchievementProgress(0f, "—") else AchievementProgress((seed.target.toDouble() / value).toFloat().coerceIn(0f, 1f), NumberFormatter.duration(value)) }
            )
        } else {
            longAchievement(seed.id, category, rarity, seed.title, text, rewardFor(rarity), metric, seed.target)
        }
    }

    private fun bigSeries(category: AchievementCategory, description: String, metric: (GameState) -> BigNum, seeds: List<BigSeed>): List<AchievementDef> =
        seeds.mapIndexed { index, seed ->
            val rarity = rarityAt(index, seeds.size)
            AchievementDef(seed.id, category, rarity, seed.title, "$description Meta: ${NumberFormatter.format(seed.target)}.", rewardFor(rarity), false,
                achieved = { metric(it) >= seed.target }, progress = { bigProgress(metric(it), seed.target) })
        }

    private fun doubleSeries(category: AchievementCategory, description: String, metric: (GameState) -> Double, seeds: List<DoubleSeed>): List<AchievementDef> =
        seeds.mapIndexed { index, seed ->
            val rarity = rarityAt(index, seeds.size)
            AchievementDef(seed.id, category, rarity, seed.title, "$description Meta: ×${"%.2f".format(seed.target)}.", rewardFor(rarity), false,
                achieved = { metric(it) >= seed.target }, progress = { state -> val value = metric(state); AchievementProgress((value / seed.target).toFloat().coerceIn(0f, 1f), "×${"%.2f".format(value)} / ×${"%.2f".format(seed.target)}") })
        }

    private fun longAchievement(
        id: String,
        category: AchievementCategory,
        rarity: Rarity,
        title: String,
        description: String,
        reward: Int,
        metric: (GameState) -> Long,
        target: Long
    ) = AchievementDef(id, category, rarity, title, description, reward, false,
        achieved = { metric(it) >= target }, progress = { longProgress(metric(it), target) })

    private fun longProgress(value: Long, target: Long): AchievementProgress =
        AchievementProgress((value.toDouble() / target.toDouble()).toFloat().coerceIn(0f, 1f), "$value/$target")

    private fun bigProgress(value: BigNum, target: BigNum): AchievementProgress =
        AchievementProgress(if (value.isZero) 0f else (value / target).toDouble().toFloat().coerceIn(0f, 1f), "${NumberFormatter.format(value)} / ${NumberFormatter.format(target)}")

    private fun booleanProgress(value: Boolean): AchievementProgress = AchievementProgress(if (value) 1f else 0f, if (value) "Descoberta" else "—")

    private fun rarityAt(index: Int, total: Int): Rarity {
        val ratio = index.toFloat() / total.coerceAtLeast(1)
        return when {
            ratio < .18f -> Rarity.COMUM
            ratio < .34f -> Rarity.INCOMUM
            ratio < .50f -> Rarity.RARO
            ratio < .64f -> Rarity.EPICO
            ratio < .76f -> Rarity.LENDARIO
            ratio < .86f -> Rarity.MITICO
            ratio < .94f -> Rarity.COSMICO
            else -> Rarity.TRANSCENDENTAL
        }
    }

    private fun rewardFor(rarity: Rarity): Int = when (rarity) {
        Rarity.COMUM -> 1
        Rarity.INCOMUM -> 2
        Rarity.RARO -> 3
        Rarity.EPICO -> 4
        Rarity.LENDARIO -> 5
        Rarity.MITICO -> 7
        Rarity.COSMICO -> 9
        Rarity.TRANSCENDENTAL -> 12
    }

    private fun permanentMultiplier(s: GameState): Double =
        1.0 + s.prestigePoints * (0.05 + 0.10 * s.skillLevel(SkillTree.TRANS_CORE))
}
