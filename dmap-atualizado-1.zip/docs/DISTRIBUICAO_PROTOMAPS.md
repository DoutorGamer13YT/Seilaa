# Distribuição regional Protomaps — configuração pendente

O aplicativo não tem catálogo ou serviço habilitado por padrão. Nenhum download de região foi realizado nesta entrega. Os endereços do serviço descritos aqui são o contrato do servidor incluído, não endpoints atribuídos à Protomaps.

## O que falta para habilitar downloads

1. Disponibilizar hospedagem HTTPS estável para `catalog.json` e arquivos ZIP regionais, com GET, Content-Length e HTTP Range. URLs finais, sem redirecionamentos, autenticação embutida ou expiração. O serviço de recortes pode usar o mesmo domínio; seu token só vai para esse serviço.
2. Instalar Python 3.11+, Node.js 20+ e o executável oficial `pmtiles` em um servidor próprio. Não são dependências do APK. Reservar disco e limitar recursos do serviço; cada pacote pode ter até 8 GiB, e a preparação pode exigir mais espaço temporário. Não executar como root.
3. Obter uma URL real de build compatível com basemap v4 em https://maps.protomaps.com/builds. Usá-la somente no servidor, como origem de extrações por HTTP Range. Não baixar o planeta inteiro nem gravar essa URL no app. Builds podem expirar: o operador deve manter a origem acessível ou um espelho próprio autorizado.
4. Obter `protomaps/basemaps-assets`, preferencialmente no commit `028c18f713baecad011301ff7a69acc39bcc2ae7`. Preservar os diretórios `fonts` e `sprites/v4`. Copiar `server/licenses/Icons-MIT.txt` para `sprites/LICENSE.txt` desse checkout. As fontes Noto e sprites são distribuídos com cada região; não entram como dependência remota no mapa offline.
5. Na pasta `server`, instalar as dependências de `package.json` e executar `node generate_styles.mjs /caminho/styles`. A versão fixada de `@protomaps/basemaps` é 5.7.2. Isso gera os estilos oficiais claro/escuro com rótulos em português e referências locais. Nada disso foi executado nesta entrega.
6. Preparar cidades/estados reais com o comando abaixo, publicar os arquivos e gerar o catálogo. O nome e os limites devem representar a região real escolhida. Nenhum catálogo fictício foi preenchido.
7. No Dmap: Configurações → Protomaps → informar URL HTTPS final do catálogo → Salvar e atualizar. Para recortes personalizados, configurar também URL base e token do serviço próprio.

## Preparar uma cidade ou um estado

Defina as variáveis com valores reais do seu ambiente. A ordem de `BBOX` é oeste,sul,leste,norte. O limite desta implementação é 15° por lado, sem cruzar o antimeridiano; estados maiores devem ser divididos em regiões. O zoom máximo aceito é 15.

```bash
python3 prepare_region.py \
  --source "$PROTOMAPS_BUILD_URL" \
  --output "$DMAP_PACKAGES" \
  --public-base "$DMAP_PUBLIC_BASE" \
  --assets "$DMAP_ASSETS" \
  --styles "$DMAP_STYLES" \
  --id "$REGION_ID" --version "$DMAP_MAP_VERSION" \
  --name "$REGION_NAME" --kind city --bbox="$BBOX" --zoom 14
python3 build_catalog.py "$DMAP_PACKAGES" "$DMAP_CATALOG_FILE"
```

Troque `city` por `state` para estados. Para um catálogo público, mantenha um arquivo de metadados por ID na pasta de entrada; conserve versões antigas de ZIP em sua hospedagem para downloads já iniciados. Uma versão é imutável: mudanças de dados, estilos ou assets exigem nova versão. O pacote mantém o PMTiles sem recompressão e comprime apenas recursos auxiliares. O catálogo informa bytes reais, tamanho instalado e SHA-256.

A etapa `pmtiles extract` obtém somente os intervalos necessários à região, embora possa usar tiles de baixa resolução além da borda exata. O retângulo do catálogo é a área de interesse, não um recorte vetorial de cada geometria. A câmera fica limitada à área escolhida.

## Serviço opcional de recortes personalizados

`distribution_service.py` escuta somente em `127.0.0.1:8787`. Coloque-o atrás do seu servidor HTTPS. `nginx-locations.conf.example` é um fragmento para um virtual host TLS existente; ajuste os caminhos. Não habilite compressão HTTP dos ZIPs: os bytes transferidos devem corresponder ao hash e ao tamanho publicados.

Variáveis obrigatórias:

| Variável | Conteúdo |
|---|---|
| `DMAP_REQUEST_TOKEN` | Token privado de pelo menos 32 caracteres, criado pelo operador e informado no app |
| `PROTOMAPS_BUILD_URL` | URL real de build autorizado, usada exclusivamente pelo servidor |
| `DMAP_PUBLIC_BASE` | URL HTTPS estável da pasta pública de pacotes |
| `DMAP_ASSETS` | Caminho absoluto do checkout de fontes/sprites |
| `DMAP_STYLES` | Caminho absoluto dos dois estilos gerados |
| `DMAP_MAP_VERSION` | Identificador imutável de versão, até 80 caracteres alfanuméricos, `_` ou `-` |
| `DMAP_DATA` | Diretório persistente, por exemplo `/srv/dmap/distribution` |

Inicie com `python3 distribution_service.py`. Use apenas uma instância do serviço por banco SQLite. A fila é persistente e retoma preparações interrompidas. Um recorte é preparado por vez, com até 32 aguardando. Após interrupção do processo, a extração no servidor recomeça; a retomada byte a byte é para o download do pacote no Android.

Contrato implementado: `POST /requests`, Authorization Bearer, JSON com `requestId` UUID, `name`, `bounds` e `maxZoom`. Repetir o mesmo pedido consulta seu estado, sem criar outro. Estados: `queued`, `running`, `ready`, `failed`. `ready` inclui `package` com o mesmo formato do catálogo. O app consulta via WorkManager e só baixa após confirmação do tamanho final. A consulta pode ser retomada pela tela Downloads.

O token atual é adequado a uma distribuição controlada. Para liberar o serviço publicamente, ainda faltam autenticação individual, cotas por usuário, limitação de taxa no proxy, monitoramento e política de retenção. A geração já iniciada no servidor não tem botão de cancelamento nesta versão; os downloads Android têm pausa e cancelamento. O serviço não foi hospedado ou testado ponta a ponta nesta entrega.

## Formato local e segurança

O ZIP inclui `map.pmtiles`, `styles/light.json`, `styles/dark.json`, glyphs completos das fontes utilizadas, sprites 1x/2x, licenças e `pack.json`. O manifesto lista tamanho e SHA-256 de cada arquivo. O Android verifica hash do ZIP, limites de tamanho, travessia de diretórios, duplicatas, manifesto, recursos e cabeçalho PMTiles v3 MVT antes de promover a pasta temporária a instalada.

O MapLibre recebe `pmtiles://file:///.../map.pmtiles`, glyphs e sprites `file:///...`. Não há servidor HTTP local nem API PMTiles inventada. O PMTiles local é suportado pelo MapLibre Android desde 11.7; o projeto mantém 13.6.1. `OfflineManager` não baixa PMTiles: o novo WorkManager faz o download de arquivos independentemente do mecanismo anterior.

O hash publicado por um catálogo HTTPS protege integridade de transferência, mas não é assinatura independente. A confiança continua no operador do catálogo/servidor. URLs com credenciais ou hosts Apple/OSM comunitário/builds Protomaps são recusadas para distribuição no cliente.

## Referências oficiais

- https://docs.protomaps.com/basemaps/downloads
- https://docs.protomaps.com/pmtiles/cli
- https://docs.protomaps.com/basemaps/maplibre
- https://github.com/protomaps/basemaps
- https://github.com/protomaps/basemaps-assets
- https://maplibre.org/maplibre-native/android/examples/data/PMTiles/
