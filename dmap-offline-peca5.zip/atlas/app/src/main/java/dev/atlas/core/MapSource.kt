package dev.atlas.core

enum class MapSource { APPLE, APPLE_VIEW, OPEN_STREET_MAP }

object MapSourcePolicy {
    fun choose(online: Boolean, hasToken: Boolean, appleFailed: Boolean): MapSource = when {
        !online || appleFailed -> MapSource.OPEN_STREET_MAP
        hasToken -> MapSource.APPLE
        else -> MapSource.APPLE_VIEW
    }
}
