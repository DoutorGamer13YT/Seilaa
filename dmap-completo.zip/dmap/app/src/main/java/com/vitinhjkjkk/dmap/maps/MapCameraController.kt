package com.vitinhjkjkk.dmap.maps

import android.webkit.WebView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vitinhjkjkk.dmap.location.Coordinates
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap

class MapCameraController {
    private var map: MapLibreMap? = null
    private var webView: WebView? = null
    var lastCenter by mutableStateOf<Coordinates?>(null)
        private set

    fun center(coordinates: Coordinates) {
        lastCenter = coordinates
        map?.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(coordinates.latitude, coordinates.longitude), 14.0,
            ),
        )
        webView?.evaluateJavascript(
            "window.dmapCenter && window.dmapCenter(${coordinates.latitude}, ${coordinates.longitude}, 14);",
            null,
        )
    }

    fun attachMap(value: MapLibreMap?) {
        map = value
        lastCenter?.let { center(it) }
    }

    fun attachWebView(value: WebView?) {
        webView = value
        lastCenter?.let { center(it) }
    }
}
