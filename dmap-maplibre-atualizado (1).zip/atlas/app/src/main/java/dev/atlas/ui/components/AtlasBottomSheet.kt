package dev.atlas.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.LocalAtlasColors
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class SheetPosition(val accessibilityLabel: String) {
    Collapsed("Recolhido"), Peek("Parcialmente expandido"), Half("Intermediário"), Expanded("Expandido")
}

@Composable
fun AtlasBottomSheet(
    position: SheetPosition,
    onPositionChange: (SheetPosition) -> Unit,
    modifier: Modifier = Modifier,
    reduceMotion: Boolean = false,
    onHeightChanged: (Float) -> Unit = {},
    onViewportHeightChanged: (Float) -> Unit = {},
    onInteractionChanged: (Boolean) -> Unit = {},
    content: @Composable () -> Unit,
) {
    val colors = LocalAtlasColors.current
    val density = LocalDensity.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()
    val currentOnPositionChange by rememberUpdatedState(onPositionChange)
    val currentOnHeightChanged by rememberUpdatedState(onHeightChanged)
    val currentOnViewportHeightChanged by rememberUpdatedState(onViewportHeightChanged)
    val currentOnInteractionChanged by rememberUpdatedState(onInteractionChanged)
    val navigationInset = WindowInsets.navigationBars.getBottom(density)
    val imeInset = WindowInsets.ime.getBottom(density)
    val bottomInset = maxOf(navigationInset, imeInset)
    val topInset = WindowInsets.statusBars.getTop(density)
    val keyboardVisible = imeInset > navigationInset

    BoxWithConstraints(modifier.fillMaxSize()) {
        val fullHeight = constraints.maxHeight.toFloat()
        val available = (fullHeight - bottomInset - topInset - 12 * density.density).coerceAtLeast(1f)
        val anchors = remember(fullHeight, available, bottomInset, density) {
            val collapsed = minOf(128 * density.density, available * 0.65f)
            val remaining = available - collapsed
            val peek = minOf(290 * density.density, available * 0.50f)
                .coerceIn(collapsed + remaining * 0.20f, collapsed + remaining * 0.60f)
            val half = maxOf(peek + remaining * 0.15f, available * 0.72f).coerceAtMost(available)
            linkedMapOf(SheetPosition.Collapsed to collapsed, SheetPosition.Peek to peek,
                SheetPosition.Half to half, SheetPosition.Expanded to available)
                .mapValues { (_, height) -> fullHeight - bottomInset - height }
        }
        val minimum = anchors.getValue(SheetPosition.Expanded)
        val maximum = anchors.getValue(SheetPosition.Collapsed)
        val resistance = 24 * density.density
        val effectivePosition = if (keyboardVisible) SheetPosition.Expanded else position
        var topPx by remember { mutableFloatStateOf(anchors.getValue(effectivePosition)) }
        var rawDragTop by remember { mutableFloatStateOf(topPx) }
        var animation by remember { mutableStateOf<Job?>(null) }
        var animationTarget by remember { mutableStateOf<Float?>(null) }
        var animationVelocity by remember { mutableFloatStateOf(0f) }
        var dragging by remember { mutableStateOf(false) }
        var nestedDragConsumed by remember { mutableStateOf(false) }
        val visualTop = topPx.coerceIn((minimum - resistance).coerceAtLeast(0f), maximum + resistance)

        fun stopAnimation() {
            animation?.cancel()
            animation = null
            animationTarget = null
        }
        fun animateTop(target: Float, releaseVelocity: Float? = null) {
            if (animation?.isActive == true && animationTarget == target) return
            val velocity = releaseVelocity ?: if (animation?.isActive == true) animationVelocity else 0f
            stopAnimation()
            animationTarget = target
            currentOnViewportHeightChanged(fullHeight - target)
            if (reduceMotion) { topPx = target; return }
            animation = scope.launch {
                Animatable(topPx).animateTo(
                    target, spring(dampingRatio = AtlasDimens.PanelDamping, stiffness = AtlasDimens.PanelStiffness,
                        visibilityThreshold = 0.5f),
                    initialVelocity = velocity.coerceIn(-8000 * density.density, 8000 * density.density),
                ) { topPx = value; animationVelocity = this.velocity }
                animationTarget = null
            }
        }
        fun beginDrag() {
            stopAnimation()
            rawDragTop = topPx
            dragging = true
            currentOnInteractionChanged(true)
        }
        fun moveBy(deltaY: Float, resist: Boolean): Float {
            if (!dragging) beginDrag()
            val previous = topPx
            rawDragTop += deltaY
            topPx = if (!resist) rawDragTop.coerceIn(minimum, maximum) else {
                val edge = rawDragTop.coerceIn(minimum, maximum)
                val excess = rawDragTop - edge
                edge + excess / (1f + abs(excess) / resistance)
            }
            if (!resist) rawDragTop = topPx
            return topPx - previous
        }
        fun settle(velocityY: Float) {
            dragging = false
            currentOnInteractionChanged(false)
            val current = topPx.coerceIn(minimum, maximum)
            val projected = (current + velocityY * 0.16f).coerceIn(minimum, maximum)
            val stops = anchors.entries.sortedBy { it.value }
            var target = stops.minBy { abs(it.value - projected) }
            if (abs(velocityY) > 650 * density.density) {
                if (velocityY < 0 && target.value >= current) target = stops.lastOrNull { it.value < current - 1 } ?: stops.first()
                if (velocityY > 0 && target.value <= current) target = stops.firstOrNull { it.value > current + 1 } ?: stops.last()
            }
            if (keyboardVisible && target.key != SheetPosition.Expanded) keyboard?.hide()
            animateTop(target.value, velocityY)
            currentOnPositionChange(target.key)
        }

        val targetTop = anchors.getValue(effectivePosition)
        LaunchedEffect(targetTop, reduceMotion) {
            if (!dragging) animateTop(targetTop)
        }
        LaunchedEffect(fullHeight) {
            snapshotFlow { fullHeight - topPx }.distinctUntilChanged().collect { currentOnHeightChanged(it) }
        }
        DisposableEffect(Unit) { onDispose { animation?.cancel(); currentOnInteractionChanged(false) } }

        val nestedScroll = remember(anchors, reduceMotion, keyboardVisible) {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (source != NestedScrollSource.UserInput || available.y >= 0f || topPx <= minimum) return Offset.Zero
                    val consumed = moveBy(available.y, resist = false)
                    if (consumed != 0f) nestedDragConsumed = true
                    return Offset(0f, consumed)
                }
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (source != NestedScrollSource.UserInput || available.y <= 0f || topPx >= maximum) return Offset.Zero
                    val amount = moveBy(available.y, resist = false)
                    if (amount != 0f) nestedDragConsumed = true
                    return Offset(0f, amount)
                }
                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (!nestedDragConsumed) return Velocity.Zero
                    nestedDragConsumed = false
                    val atExpanded = topPx <= minimum + 1f && available.y < 0
                    settle(if (atExpanded) 0f else available.y)
                    return if (atExpanded) Velocity.Zero else Velocity(0f, available.y)
                }
                override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                    if (nestedDragConsumed) {
                        nestedDragConsumed = false
                        settle(available.y)
                        return Velocity(0f, available.y)
                    }
                    return Velocity.Zero
                }
            }
        }
        val drag = rememberDraggableState { delta -> moveBy(delta, resist = true) }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter)
                .fillMaxWidth().height(with(density) { (fullHeight - visualTop).coerceAtLeast(1f).toDp() })
                .nestedScroll(nestedScroll)
                .draggable(state = drag, orientation = Orientation.Vertical,
                    startDragImmediately = animation?.isActive == true,
                    onDragStarted = { beginDrag() }, onDragStopped = { settle(it) }),
            shape = RoundedCornerShape(topStart = AtlasDimens.SheetRadius, topEnd = AtlasDimens.SheetRadius),
            color = colors.glass.copy(alpha = 1f), border = BorderStroke(0.8.dp, colors.glassBorder), shadowElevation = 14.dp,
        ) {
            Column(Modifier.padding(bottom = with(density) { bottomInset.toDp() })) {
                Box(
                    Modifier.fillMaxWidth().height(48.dp).semantics {
                        contentDescription = "Painel de mapas"
                        stateDescription = effectivePosition.accessibilityLabel
                        if (effectivePosition != SheetPosition.Expanded) expand {
                            currentOnPositionChange(SheetPosition.entries[(effectivePosition.ordinal + 1).coerceAtMost(3)])
                            true
                        }
                        if (effectivePosition != SheetPosition.Collapsed) collapse {
                            keyboard?.hide()
                            currentOnPositionChange(SheetPosition.entries[(effectivePosition.ordinal - 1).coerceAtLeast(0)])
                            true
                        }
                    }, contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.width(36.dp).height(5.dp).background(colors.secondaryText.copy(alpha = 0.36f), RoundedCornerShape(3.dp)))
                }
                Box(Modifier.fillMaxWidth().weight(1f, fill = true)) { content() }
            }
        }
    }
}
