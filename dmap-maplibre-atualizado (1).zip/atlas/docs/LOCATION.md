# Localização e navegação

O mapa usa `LocationTracker`, apoiado em `LocationManager` do Android, sem Google Play Services. A Activity solicita localização aproximada/precisa somente por uma ação contextual do usuário. Ao sair de primeiro plano, deve chamar `stop()`; durante navegação, o serviço é o único proprietário das atualizações. `refresh()` atualiza permissões/provedores ao retornar das configurações.

- Exploração: GPS a cada 5 s / 5 m e rede a cada 10 s / 15 m, se disponíveis.
- Navegação: GPS a cada 1 s / 1 m e rede a cada 5 s / 5 m, se disponíveis. Leituras de rede muito menos precisas não substituem imediatamente uma leitura GPS recente.
- Precisão aproximada usa somente provedor de rede. Em aparelhos sem provedor de rede, informe indisponibilidade e ofereça permissão precisa/configurações; não fabrique uma localização.
- Idade é medida com relógio monotônico do Android. Após 15 s sem leitura válida na navegação, `gpsLost` torna-se verdadeiro; a posição anterior é preservada, mas instruções faladas e avanço são suspensos. No mapa, `isStale` usa 60 s.
- Precisão pior que 100 m também suspende o avanço e a voz da navegação, com orientação textual para habilitar localização precisa. O mapa ainda pode mostrar a posição aproximada e seu raio de precisão.
- O serviço `NavigationService` é iniciado apenas pelo botão explícito de navegação, mantém notificação persistente com ação Encerrar e usa tipo `location`. Não solicita `ACCESS_BACKGROUND_LOCATION`. A permissão de notificações no Android 13+ deve ser apresentada contextualmente; se recusada, o Android ainda mostra o serviço no gerenciador de tarefas.
- Sem reinício automático após morte do processo: `START_NOT_STICKY`; a navegação em memória não é reconstruída silenciosamente. Favoritos/configurações não dependem desse estado.
- Ao encerrar: remove listeners/receptor, cancela coroutines, remove notificação e encerra TextToSpeech. O usuário também pode encerrar pela notificação com tela apagada.
- Ao confirmar chegada, o GPS é desligado; o cartão de chegada e a ação Encerrar permanecem. Selecionar uma nova rota reinicia as atualizações. A voz é processada pelo mecanismo TTS configurado no Android; mecanismos e vozes de rede podem processar o texto fora do aparelho conforme suas próprias configurações.

## Progresso e limites

`NavigationEngine` projeta o GPS sobre segmentos reais da geometria. A janela de avanço considera tempo transcorrido e modo de transporte, reduzindo saltos em cruzamentos e trajetos que retornam à mesma rua. Retrocesso de até 40 m é tolerado. Dois fixes consecutivos fora do limiar (mínimo 45 m carro / 30 m demais modos, ampliado pela precisão) marcam desvio; a recuperação usa histerese.

O **serviço de navegação** solicita o recálculo após desvio confirmado, mantendo essa capacidade quando a Activity ou seu ViewModel são encerrados. Há uma única requisição por vez e intervalo mínimo de 25 s entre tentativas, medido pelo relógio monotônico. O cálculo usa o mesmo modo/provedor e preserva as paradas ainda à frente do `segmentIndex`: cada parada é associada sequencialmente à geometria, sem considerar uma parada visitada apenas porque o GPS passou perto dela. Geometrias simplificadas ou trajetos sobrepostos ainda exigem validação de campo.

Encerrar, iniciar outra sessão, substituir a rota, perder GPS utilizável ou voltar ao trajeto cancela a requisição pendente. A resposta só pode substituir a rota original da mesma sessão, com `NavigationSession.updateRoute(route, expectedSessionId, expectedRoute)`. `NavigationState.recalculating` e `routeError` representam exclusivamente o recálculo; falhas de rede não apagam os estados independentes de GPS/TTS em `error`. As mudanças desses campos não disparam outra consulta. A notificação também indica recálculo/falha quando a tela está apagada.

As instruções são as manobras do provedor. Distâncias restantes são proporcionais ao avanço na geometria e à distância informada pelo provedor; o tempo restante combina as durações dos trechos e é uma **estimativa sem tráfego em tempo real**. O algoritmo não é map matching de nível automotivo e ainda exige validação de campo em túneis, vias paralelas, cruzamentos, rotatórias e GPS ruidoso. Chegada requer proximidade real do fim da geometria e precisão de até 50 m.

TTS usa a voz pt-BR instalada no aparelho; idiomas/vozes dependem do mecanismo do Android. Falta de voz mantém instruções visuais. Não há dados de localização nos logs. Coordenadas da rota/localização são enviadas somente aos provedores de rotas documentados no planejamento explícito ou no recálculo de uma navegação ativa, inclusive em segundo plano enquanto sua notificação está visível.

## Verificação

Os testes `NavigationProgressTest` exercitam progresso, desvio, chegada, saltos em cruzamentos, dados inválidos e longitude internacional. A execução real consta em `DEVELOPMENT_STATUS.md`. Sem emulador/dispositivo, não se consideram verificados GPS real, permissão aproximada/precisa, serviço em tela apagada, TTS, notificação ou autonomia de bateria.

`NavigationRecalculationTest` contém oito cenários escritos para preservação/remoção de paradas, retorno à mesma coordenada, ausência de metadados, índices inválidos e destino ausente. Esses testes **não foram executados**, respeitando a instrução de não compilar. O cancelamento do cliente HTTP, a troca rápida de sessão e o recálculo sem Activity ainda requerem verificação de integração em aparelho.

Teste de campo pendente: conceder/negar/revogar permissão; ligar/desligar GPS; apagar tela navegando; tirar aplicativo de foco; matar processo; aproximar-se de cruzamentos; desviar e recalcular; interromper pela notificação; negar notificações; conferir falha TTS; observar posição imprecisa e bateria. Nenhuma navegação offline é anunciada: a rota carregada continua em memória, mas novo cálculo exige rede.
