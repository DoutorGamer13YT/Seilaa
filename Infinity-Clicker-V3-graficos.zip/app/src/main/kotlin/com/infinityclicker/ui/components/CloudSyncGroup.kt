package com.infinityclicker.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.data.CloudSync
import com.infinityclicker.ui.theme.Neon

/** Selo pequeno em vidro (versão, "DEV", "Em breve"). */
@Composable
fun DevBadge(text: String, tint: Color = Neon.Gold, modifier: Modifier = Modifier) {
    Text(
        text, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp, maxLines = 1,
        modifier = modifier.glass(RoundedCornerShape(50), tint = tint, alpha = 0.18f, borderAlpha = 0.50f)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

/**
 * Sincronização na nuvem — EM DESENVOLVIMENTO. Deliberadamente sem nenhum botão que finja funcionar:
 * não existe servidor conectado (ver FIREBASE_SETUP.md), então as linhas são apenas informativas e
 * esmaecidas. O progresso continua salvo no aparelho, com backup e exportar/importar na seção Dados.
 */
@Composable
fun CloudSyncGroup(panelAlpha: Float) {
    val status = CloudSync.provider.status
    val dimmed = Modifier.graphicsLayer { alpha = 0.5f }
    SettingsGroup(
        "Nuvem · em desenvolvimento", panelAlpha,
        footer = "${status.label.uppercase()}: ainda não há servidor conectado. Seu progresso continua salvo só neste aparelho, " +
            "com backup automático. Para trocar de aparelho agora, use Exportar e Importar em Dados."
    ) {
        SettingsRow("◈", Neon.Gold, "Nuvem em desenvolvimento", subtitle = "Indisponível nesta versão: nada é enviado para a internet", titleColor = Neon.Gold) {
            DevBadge("EM DESENVOLVIMENTO")
        }
        SettingsRow("◈", Neon.Cyan, "Sincronização na nuvem", modifier = dimmed, subtitle = "Guardar o progresso na sua conta") {
            DevBadge("INDISPONÍVEL", Neon.TextSecondary)
        }
        SettingsRow("↻", Neon.Green, "Sincronizar agora", modifier = dimmed, subtitle = "Envia ou baixa o save mais recente") {
            DevBadge("EM BREVE", Neon.TextSecondary)
        }
        SettingsRow("≋", Neon.Violet, "Resolver conflitos", modifier = dimmed, subtitle = "Você escolhe entre o local e a nuvem", divider = false) {
            DevBadge("EM BREVE", Neon.TextSecondary)
        }
    }
}
