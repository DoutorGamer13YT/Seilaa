package com.infinityclicker.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.remember
import com.infinityclicker.ui.BossUi
import com.infinityclicker.ui.CosmicEventUi
import com.infinityclicker.ui.components.Motion
import com.infinityclicker.ui.components.bumpOnChange
import com.infinityclicker.ui.components.enterAnimation
import com.infinityclicker.ui.components.pulseOverlay

import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import com.infinityclicker.ui.components.glass
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.infinityclicker.ui.components.GlowBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.CrystalArea
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.GlyphIcon
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun HomeScreen(ui: UiState, onTap: () -> TapResult?, onUseAbility: (String) -> Unit) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    val crystal = ui.crystals.firstOrNull { it.equipped }?.def
    val dimension = ui.dimensions.firstOrNull { it.current }?.def
    // Só a camada do número pulsa; não há animação de layout nem alteração do ritmo do jogo.
    val numberMotion = rememberInfiniteTransition(label = "energyReadout")
    val numberScale by numberMotion.animateFloat(
        initialValue = 1f,
        targetValue = 1.012f,
        animationSpec = infiniteRepeatable(
            animation = tween(1_850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "energyBreath"
    )

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val accent = dimension?.tintColor ?: Neon.Cyan
        // Estilo do número de energia e textos formatados: criados só quando algo muda (antes, a cada publicação do estado).
        val energyStyle = remember(accent) {
            TextStyle(
                brush = Brush.verticalGradient(listOf(Color.White, Color.White, accent.copy(alpha = 0.85f))),
                fontSize = 42.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, fontFeatureSettings = "tnum",
                shadow = Shadow(accent.copy(alpha = 0.55f), Offset(0f, 0f), 22f)
            )
        }
        val critText = remember(ui.critChance, ui.critMultiplier) { "${"%.0f".format(ui.critChance * 100)}% · ×${"%.1f".format(ui.critMultiplier)}" }
        val comboText = remember(ui.combo, ui.maxCombo, ui.comboMultiplier) { "${ui.combo}/${ui.maxCombo} · ×${"%.2f".format(ui.comboMultiplier)}" }
        // Cabeçalho: a energia é a estrela da tela, centralizada e com degradê; o resto vira etiquetas de vidro.
        Column(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Tag(dimension?.name ?: "Primordial", accent)
                Tag(crystal?.name ?: "Éter Azul", crystal?.tintColor ?: Neon.Cyan)
            }
            Text("ENERGIA", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 10.dp))
            Text(
                f(ui.energy),
                style = energyStyle,
                maxLines = 1,
                modifier = Modifier.bumpOnChange(ui.stats.totalClicks, peak = 1.06f).graphicsLayer { scaleX = numberScale; scaleY = numberScale }
            )
            Text(
                "+${f(ui.production)} / s", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 2.dp).glass(RoundedCornerShape(50), tint = accent, alpha = 0.18f, borderAlpha = 0.45f)
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }

        val renderQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
        val fleet = androidx.compose.runtime.remember(ui.generators) { com.infinityclicker.ui.components.fleetSizeFor(ui.generators.sumOf { it.owned }) }
        CrystalArea(
            tier = (ui.stats.totalEnergy.exponent / 3L).toInt(),
            crystalStyle = crystal?.id ?: 0,
            baseColor = crystal?.tintColor ?: Neon.Cyan,
            comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f,
            effectsIntensity = ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.5f else renderQuality.particleScale,
            particleLimit = (150f * ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.3f else renderQuality.particleScale).toInt(),
            quality = renderQuality,
            hapticsEnabled = ui.settings.hapticsEnabled,
            motionEnabled = !ui.settings.batterySaver,
            formatGain = { r -> f(r.gain) },
            onTap = onTap,
            fleetSize = fleet,
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        // Um único filho do Column principal (chefe + evento + habilidades): assim o espaçamento entre blocos não ganha
        // vãos fantasmas quando chefe e evento estão fechados; cada cartão carrega o próprio respiro de baixo.
        Column(Modifier.fillMaxWidth()) {
        // Chefe e evento entram expandindo a altura (o cristal cede espaço com suavidade) e saem do mesmo jeito.
        // O último valor fica guardado só para o cartão não esvaziar durante a animação de saída.
        val bossNow = ui.activeBoss
        val bossHold = remember { arrayOfNulls<BossUi>(1) }
        if (bossNow != null) bossHold[0] = bossNow
        AnimatedVisibility(
            visible = bossNow != null,
            enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(tween(260)),
            exit = shrinkVertically(tween(260, easing = Motion.Emphasized)) + fadeOut(tween(160))
        ) {
            (bossNow ?: bossHold[0])?.let { boss ->
                val fraction = (boss.active.health / boss.maxHealth).toDouble().toFloat().coerceIn(0f, 1f)
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlyphIcon("⚠", Neon.Pink, 16.dp)
                            Text(
                                ui.dimensions.firstOrNull { it.def.id == boss.active.dimensionId }?.def?.bossName ?: "Chefe",
                                color = Neon.Pink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 7.dp)
                            )
                        }
                        Text("${NumberFormatter.duration(boss.remainingMs)}", color = Neon.Gold, fontSize = 12.sp)
                    }
                    GlowBar(
                        progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(7.dp),
                        color = Neon.Pink, trackColor = Color.White.copy(alpha = 0.12f)
                    )
                    Text("Vida: ${f(boss.active.health)} · cada toque causa dano real", color = Neon.TextSecondary, fontSize = 12.sp)
                }
            }
        }

        val eventNow = ui.activeEvent
        val eventHold = remember { arrayOfNulls<CosmicEventUi>(1) }
        if (eventNow != null) eventHold[0] = eventNow
        AnimatedVisibility(
            visible = eventNow != null,
            enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(tween(260)),
            exit = shrinkVertically(tween(260, easing = Motion.Emphasized)) + fadeOut(tween(160))
        ) {
            (eventNow ?: eventHold[0])?.let { event ->
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), tint = Color(event.def.tintArgb), alpha = ui.settings.panelOpacity) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlyphIcon("✦", Color(event.def.tintArgb), 16.dp)
                            Text(event.def.name, color = Color(event.def.tintArgb), fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 7.dp))
                        }
                        Text(NumberFormatter.duration(event.remainingMs), color = Neon.Gold, fontSize = 12.sp)
                    }
                    Text(event.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
                }
            }
        }

        AbilityStrip(ui.abilities, sci, onUseAbility, Modifier.enterAnimation(1))
        }

        val comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f
        Column(
            Modifier.fillMaxWidth().enterAnimation(2).glass(RoundedCornerShape(26.dp), tint = Neon.Violet, alpha = ui.settings.panelOpacity + 0.04f, borderAlpha = 0.45f)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Metric("CLIQUE", "+${f(ui.clickGain)}", Neon.TextPrimary)
                Metric("CRÍTICO", critText, Neon.Gold, Alignment.CenterHorizontally)
                Metric("COMBO", comboText, Neon.Green, Alignment.End, Modifier.bumpOnChange(ui.combo, peak = 1.10f))
            }
            GlowBar(progress = { comboFraction }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), color = Neon.Cyan)
        }
        AnimatedContent(
            targetState = tutorialText(ui.tutorialStep),
            transitionSpec = {
                (fadeIn(tween(260, delayMillis = 90)) + slideInVertically(tween(300, delayMillis = 90, easing = Motion.Emphasized)) { it / 2 }) togetherWith
                    (fadeOut(tween(110)) + slideOutVertically(tween(140)) { -it / 2 })
            },
            modifier = Modifier.fillMaxWidth().enterAnimation(3)
                .glass(RoundedCornerShape(16.dp), tint = Neon.Violet, alpha = 0.07f, borderAlpha = 0.24f),
            label = "tutorialText"
        ) { text ->
            Text(
                text, color = Neon.TextSecondary, fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp, maxLines = 1,
        modifier = Modifier.glass(RoundedCornerShape(50), tint = color, alpha = 0.14f, borderAlpha = 0.40f).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
private fun Metric(label: String, value: String, color: Color, align: Alignment.Horizontal = Alignment.Start, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = align) {
        Text(label, color = Neon.TextSecondary, fontSize = 9.sp, letterSpacing = 1.5.sp)
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun AbilityStrip(abilities: List<AbilityUi>, scientific: Boolean, onUse: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        abilities.forEach { ability ->
            val text = when {
                ability.activeRemainingMs > 0L -> "Ativa ${NumberFormatter.duration(ability.activeRemainingMs)}"
                ability.cooldownRemainingMs > 0L -> "Recarga ${NumberFormatter.duration(ability.cooldownRemainingMs)}"
                else -> "Usar"
            }
            val active = ability.activeRemainingMs > 0L
            val tint = when { active -> Neon.Green; ability.canUse -> Neon.Cyan; else -> Color.White }
            Column(
                Modifier.bouncyClick(enabled = ability.canUse) { onUse(ability.def.id) }
                    .glass(RoundedCornerShape(20.dp), tint = tint, alpha = if (ability.canUse || active) 0.30f else 0.07f, borderAlpha = if (ability.canUse || active) 0.62f else 0.22f)
                    .then(if (active) Modifier.pulseOverlay(Neon.Green, 20.dp, 900L, 1.4f) else if (ability.canUse) Modifier.pulseOverlay(Neon.Cyan, 20.dp, 2_400L, 0.7f) else Modifier)
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(ability.def.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ability.canUse || active) Neon.TextPrimary else Neon.TextSecondary, maxLines = 1)
                Text(text, fontSize = 10.sp, color = if (active) Neon.Green else if (ability.canUse) Neon.Cyan else Neon.TextSecondary, maxLines = 1)
            }
        }
    }
}

private fun tutorialText(step: Int): String = when (step) {
    0 -> "Toque no cristal para gerar energia."
    1 -> "Abra a Loja e compre um Fragmento Estelar para iniciar a produção automática."
    2 -> "Use as habilidades no painel acima — elas alteram os ganhos de verdade."
    3 -> "Explore Dimensões, enfrente um chefe e prepare o primeiro renascimento."
    else -> "Seu universo renasceu. Invista pontos na árvore para acelerar a próxima corrida."
}
