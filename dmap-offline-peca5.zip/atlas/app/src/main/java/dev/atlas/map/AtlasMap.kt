package dev.atlas.map

import android.content.Context
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.Choreographer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.atlas.core.Coordinate
import dev.atlas.core.CameraPolicy
import dev.atlas.core.HeadingMath
import dev.atlas.core.MapOrientation
import dev.atlas.location.CompassState
import kotlinx.coroutines.flow.StateFlow
import dev.atlas.core.LocationFix
import dev.atlas.core.Place
import dev.atlas.core.Route
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import kotlin.math.*

@Composable
fun AtlasMap(
    modifier: Modifier = Modifier,
    dark: Boolean,
    places: List<Place>,
    selectedPlace: Place?,
    route: Route?,
    location: LocationFix?,
    cameraRequest: CameraRequest?,
    bottomPaddingDp: () -> Float,
    reduceMotion: Boolean,
    onPlaceClick: (Place) -> Unit,
    onMapLongPress: (Coordinate) -> Unit,
    onCenterChanged: (Coordinate) -> Unit,
    onMapError: (String?) -> Unit,
    onUserGesture: () -> Unit = {},
    leftPaddingDp: Float = 0f,
    orientation: MapOrientation = MapOrientation.NORTH,
    compass: StateFlow<CompassState>? = null,
    navigating: Boolean = false,
    onBearingChanged: (Float) -> Unit = {},
    onUserRotated: () -> Unit = {},
    initialCamera: CameraSnapshot? = null,
    onCameraChanged: (CameraSnapshot) -> Unit = {},
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val density = LocalDensity.current.density
    val click by rememberUpdatedState(onPlaceClick)
    val longPress by rememberUpdatedState(onMapLongPress)
    val centerChanged by rememberUpdatedState(onCenterChanged)
    val error by rememberUpdatedState(onMapError)
    val userGesture by rememberUpdatedState(onUserGesture)
    val bearingChanged by rememberUpdatedState(onBearingChanged)
    val userRotated by rememberUpdatedState(onUserRotated)
    val cameraChanged by rememberUpdatedState(onCameraChanged)
    var latitude by rememberSaveable { mutableStateOf(initialCamera?.latitude ?: -23.5505) }
    var longitude by rememberSaveable { mutableStateOf(initialCamera?.longitude ?: -46.6333) }
    var zoom by rememberSaveable { mutableStateOf(initialCamera?.zoom ?: 12.0) }
    var bearing by rememberSaveable { mutableStateOf(initialCamera?.bearing ?: 0.0) }
    var tilt by rememberSaveable { mutableStateOf(initialCamera?.tilt ?: 0.0) }
    val controller = remember(context, density) {
        MapLibre.getInstance(context)
        MapController(context, density, initialCamera != null)
    }
    controller.placeClick = { click(it) }
    controller.longPress = { longPress(it) }
    controller.onError = { error(it) }
    controller.userGesture = { userGesture() }
    controller.onBearing = { bearingChanged(it) }
    controller.onUserRotated = { userRotated() }
    controller.onCenterChanged = { centerChanged(it) }
    controller.onCameraIdle = { position ->
        position.target?.let { target ->
            latitude = target.latitude
            longitude = target.longitude
            zoom = position.zoom
            bearing = position.bearing
            tilt = position.tilt
            cameraChanged(CameraSnapshot(latitude, longitude, zoom, bearing, tilt))
        }
    }
    AndroidView(
        modifier = modifier,
        factory = {
            controller.create()
            controller.view.getMapAsync { map ->
                controller.attach(map, CameraPosition.Builder()
                    .target(LatLng(latitude, longitude)).zoom(zoom).bearing(bearing).tilt(tilt).build())
            }
            controller.view
        },
        update = {
            controller.update(MapContent(dark, places, selectedPlace, route, location,
                cameraRequest, bottomPaddingDp(), leftPaddingDp, reduceMotion, orientation, navigating))
        },
    )
    if (compass != null) LaunchedEffect(controller, compass) {
        compass.collect { controller.onHeading(it.heading) }
    }
    DisposableEffect(controller, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> controller.start()
                Lifecycle.Event.ON_RESUME -> controller.resume()
                Lifecycle.Event.ON_PAUSE -> controller.pause()
                Lifecycle.Event.ON_STOP -> controller.stop()
                Lifecycle.Event.ON_DESTROY -> controller.destroy()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            controller.destroy()
        }
    }
}

private data class MapContent(
    val dark: Boolean, val places: List<Place>, val selected: Place?, val route: Route?,
    val location: LocationFix?, val camera: CameraRequest?, val bottomDp: Float, val leftDp: Float,
    val reduceMotion: Boolean, val orientation: MapOrientation, val navigating: Boolean,
)

private class MapController(private val context: Context, private val density: Float, private val seedCameraId: Boolean = false) {
    val view = MapView(context)
    var placeClick: (Place) -> Unit = {}
    var longPress: (Coordinate) -> Unit = {}
    var onCameraIdle: (CameraPosition) -> Unit = {}
    var onCenterChanged: (Coordinate) -> Unit = {}
    var onError: (String?) -> Unit = {}
    var userGesture: () -> Unit = {}
    var onBearing: (Float) -> Unit = {}
    var onUserRotated: () -> Unit = {}
    private var map: MapLibreMap? = null
    private var style: Style? = null
    private var content: MapContent? = null
    private var requestedStyle: String? = null
    private var cameraId: Long? = null
    private var cameraSeeded = false
    private var lastRetryId: Long? = null
    private var destroyed = false
    private var created = false
    private var started = false
    private var resumed = false
    private var failed = false
    private var styleGeneration = 0
    private var lastReportedCenter: Coordinate? = null
    private var previousPlaces: Pair<List<Place>, Place?>? = null
    private var previousRoute: Route? = null
    private var previousLocation: Pair<LocationFix?, Boolean>? = null
    private var followHeading = false
    private var rotationAllowed = true
    private var orientationMode = MapOrientation.NORTH
    private var targetHeading: Float? = null
    private var gestureActive = false
    private var programmaticAnimation = false
    private var followerScheduled = false
    private var gestureStartBearing = 0f
    private var rotationReported = false
    private var lastReportedBearing = Float.NaN
    private var coneVisible = false
    private var coneHeading = Float.NaN
    private val choreographer: Choreographer by lazy { Choreographer.getInstance() }
    private val frameCallback = Choreographer.FrameCallback {
        followerScheduled = false
        stepHeading()
    }
    private var previousPadding: Pair<Int, Int>? = null
    private val failureListener = MapView.OnDidFailLoadingMapListener {
        if (!destroyed) {
            failed = true
            onError("Não foi possível carregar o mapa. Verifique sua conexão e tente novamente.")
        }
    }
    private val finishedListener = MapView.OnDidFinishLoadingMapListener {
        if (!destroyed) {
            failed = false
            onError(null)
        }
    }
    private val memoryCallbacks = object : ComponentCallbacks2 {
        override fun onConfigurationChanged(newConfig: Configuration) = Unit
        override fun onLowMemory() { if (created && !destroyed) view.onLowMemory() }
        override fun onTrimMemory(level: Int) {
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) onLowMemory()
        }
    }

    init {
        view.addOnDidFailLoadingMapListener(failureListener)
        view.addOnDidFinishLoadingMapListener(finishedListener)
        view.contentDescription = "Mapa interativo. Arraste para explorar; toque em um lugar para ver detalhes."
        view.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (!destroyed && (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop)) {
                content?.let(::render)
            }
        }
    }

    fun create() {
        if (created || destroyed) return
        view.onCreate(null)
        created = true
        context.applicationContext.registerComponentCallbacks(memoryCallbacks)
    }

    fun start() {
        if (destroyed || started) return
        create()
        view.onStart()
        started = true
    }

    fun resume() {
        if (destroyed || resumed) return
        start()
        view.onResume()
        resumed = true
    }

    fun pause() {
        if (resumed && !destroyed) view.onPause()
        resumed = false
    }

    fun stop() {
        pause()
        if (started && !destroyed) view.onStop()
        started = false
    }

    fun attach(map: MapLibreMap, initial: CameraPosition) {
        if (destroyed) return
        this.map = map
        map.cameraPosition = initial
        map.uiSettings.apply {
            isCompassEnabled = false
            isLogoEnabled = false
            isAttributionEnabled = false
            isRotateGesturesEnabled = rotationAllowed
            isTiltGesturesEnabled = true
        }
        map.addOnCameraMoveListener {
            if (!destroyed) {
                val bearing = map.cameraPosition.bearing.toFloat()
                if (lastReportedBearing.isNaN() || abs(HeadingMath.shortestDelta(lastReportedBearing, bearing)) >= 0.25f) {
                    lastReportedBearing = bearing
                    onBearing(bearing)
                }
                if (gestureActive && !rotationReported && orientationMode == MapOrientation.NORTH &&
                    abs(HeadingMath.shortestDelta(gestureStartBearing, bearing)) > 1.5f) {
                    rotationReported = true
                    onUserRotated()
                }
            }
        }
        map.addOnCameraIdleListener {
            if (!destroyed) {
                gestureActive = false
                val position = map.cameraPosition
                onBearing(position.bearing.toFloat())
                lastReportedBearing = position.bearing.toFloat()
                onCameraIdle(position)
                scheduleHeading()
                position.target?.let { point ->
                    val coordinate = Coordinate(point.latitude.coerceIn(-90.0, 90.0), wrapLongitude(point.longitude))
                    if (lastReportedCenter?.distanceTo(coordinate)?.let { it >= 5.0 } != false) {
                        lastReportedCenter = coordinate
                        onCenterChanged(coordinate)
                    }
                }
            }
        }
        map.addOnCameraMoveStartedListener { reason ->
            if (!destroyed && reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) {
                gestureActive = true
                rotationReported = false
                gestureStartBearing = map.cameraPosition.bearing.toFloat()
                userGesture()
            }
        }
        map.addOnMapLongClickListener {
            longPress(Coordinate(it.latitude.coerceIn(-90.0, 90.0), wrapLongitude(it.longitude)))
            true
        }
        map.addOnMapClickListener { point ->
            if (destroyed || style == null) return@addOnMapClickListener false
            val screen = map.projection.toScreenLocation(point)
            val radius = 24 * density
            val features = map.queryRenderedFeatures(android.graphics.RectF(
                screen.x - radius, screen.y - radius, screen.x + radius, screen.y + radius),
                "atlas-selected", "atlas-places")
            val id = features.firstOrNull()?.getStringProperty("id")
            val current = content
            val place = if (current?.selected?.id == id) current.selected else current?.places?.find { it.id == id }
            if (place != null) placeClick(place)
            place != null
        }
        content?.let(::update)
    }

    fun update(next: MapContent) {
        content = next
        if (!cameraSeeded) {
            cameraSeeded = true
            if (seedCameraId) cameraId = next.camera?.id
        }
        val map = map ?: return
        if (destroyed) return
        applyOrientation(next.orientation, next.navigating, map)
        val styleName = if (next.dark) "dark" else "light"
        if (requestedStyle != styleName || (failed && next.camera != null && lastRetryId != next.camera.id)) {
            val generation = ++styleGeneration
            requestedStyle = styleName
            style = null
            previousPlaces = null
            previousRoute = null
            previousLocation = null
            val json = try {
                context.assets.open("styles/atlas-$styleName.json")
                    .bufferedReader().use { it.readText() }
            } catch (_: java.io.IOException) {
                failed = true
                onError("O estilo do mapa não está disponível. Reinstale o aplicativo.")
                return
            }
            if (failed) lastRetryId = next.camera?.id
            failed = false
            map.setStyle(Style.Builder().fromJson(json)) { loaded ->
                if (!destroyed && generation == styleGeneration) {
                    style = loaded
                    addOverlayLayers(loaded)
                    content?.let(::render)
                }
            }
        }
        render(next)
    }

    private fun render(next: MapContent) {
        val map = map ?: return
        val style = style ?: return
        val top = (72 * density).roundToInt().coerceAtMost(
            (view.height - (100 * density).roundToInt()).coerceAtLeast(0))
        val padding = (next.bottomDp * density).roundToInt().coerceIn(0,
            (view.height - top - (100 * density).roundToInt()).coerceAtLeast(0))
        val left = (next.leftDp * density).roundToInt().coerceIn(0,
            (view.width - (100 * density).roundToInt()).coerceAtLeast(0))
        val lastPadding = previousPadding
        if (lastPadding == null || abs(padding - lastPadding.first) >= 2 || left != lastPadding.second) {
            previousPadding = padding to left
            map.setPadding(left, top, 0, padding)
        }
        val placeState = next.places to next.selected
        if (previousPlaces != placeState) {
            previousPlaces = placeState
            style.getSourceAs<GeoJsonSource>("atlas-places-source")?.setGeoJson(collection(next.places
                .filterNot { it.id == next.selected?.id }.take(250).map(::placeFeature)))
            style.getSourceAs<GeoJsonSource>("atlas-selected-source")?.setGeoJson(collection(listOfNotNull(next.selected?.let(::placeFeature))))
        }
        if (previousRoute != next.route) {
            previousRoute = next.route
            val geometry = next.route?.geometry.orEmpty()
            style.getSourceAs<GeoJsonSource>("atlas-route-source")?.setGeoJson(collection(
                if (geometry.size < 2) emptyList() else listOf(feature("LineString", JSONArray(geometry.map(::position))))))
            style.getSourceAs<GeoJsonSource>("atlas-waypoints-source")?.setGeoJson(collection(
                next.route?.waypoints.orEmpty().map { feature("Point", position(it)) }))
        }
        if (previousLocation != (next.location to next.navigating)) {
            previousLocation = next.location to next.navigating
            style.getSourceAs<GeoJsonSource>("atlas-location-source")?.setGeoJson(collection(
                listOfNotNull(next.location?.let { fix ->
                    val properties = JSONObject()
                    if (next.navigating) CameraPolicy.courseOrNull(fix.bearing, fix.speedMetersPerSecond)?.let { properties.put("course", it.toDouble()) }
                    feature("Point", position(fix.coordinate), properties)
                })))
            style.getSourceAs<GeoJsonSource>("atlas-accuracy-source")?.setGeoJson(collection(
                listOfNotNull(next.location?.takeIf { it.accuracyMeters.isFinite() && it.accuracyMeters > 0 }?.let(::accuracyFeature))))
        }
        showCone(targetHeading)
        val request = next.camera ?: return
        if (view.width <= 0 || view.height <= 0) return
        if (request.id == cameraId) return
        cameraId = request.id
        val unique = request.points.distinct()
        val update = if (unique.size > 1) {
            val bounds = LatLngBounds.Builder().includes(unique.map { LatLng(it.latitude, it.longitude) }).build()
            CameraUpdateFactory.newLatLngBounds(bounds, (44 * density).roundToInt())
        } else {
            val position = CameraPosition.Builder(map.cameraPosition)
            (request.target ?: unique.firstOrNull())?.let { position.target(LatLng(it.latitude, it.longitude)) }
            request.zoom?.let { position.zoom(it.coerceIn(1.0, 20.0)) }
            request.bearing?.let { position.bearing(it) }
            request.tilt?.let { position.tilt(it.coerceIn(0.0, 60.0)) }
            CameraUpdateFactory.newCameraPosition(position.build())
        }
        if (next.reduceMotion) map.moveCamera(update) else {
            programmaticAnimation = true
            map.animateCamera(update, 700, object : MapLibreMap.CancelableCallback {
                override fun onCancel() { programmaticAnimation = false; scheduleHeading() }
                override fun onFinish() { programmaticAnimation = false; scheduleHeading() }
            })
        }
    }

    private fun applyOrientation(mode: MapOrientation, navigating: Boolean, map: MapLibreMap) {
        orientationMode = mode
        val follow = mode == MapOrientation.COMPASS && !navigating
        if (follow != followHeading) {
            followHeading = follow
            if (!follow) showCone(null)
        }
        if (rotationAllowed == follow) {
            rotationAllowed = !follow
            map.uiSettings.isRotateGesturesEnabled = rotationAllowed
        }
        if (follow) scheduleHeading()
    }

    fun onHeading(heading: Float?) {
        targetHeading = heading
        showCone(heading)
        if (heading != null) scheduleHeading()
    }

    private fun scheduleHeading() {
        if (destroyed || !followHeading || followerScheduled || targetHeading == null) return
        followerScheduled = true
        choreographer.postFrameCallback(frameCallback)
    }

    private fun stepHeading() {
        val map = map ?: return
        if (destroyed || !followHeading || gestureActive || programmaticAnimation) return
        val target = targetHeading ?: return
        val current = map.cameraPosition.bearing.toFloat()
        val delta = HeadingMath.shortestDelta(current, target)
        if (abs(delta) < 0.3f) return
        val factor = if (content?.reduceMotion == true) 0.5f else 0.2f
        val next = HeadingMath.normalize(current + delta * factor)
        map.moveCamera(CameraUpdateFactory.bearingTo(next.toDouble()))
        scheduleHeading()
    }

    private fun showCone(heading: Float?) {
        val layer = style?.getLayerAs<SymbolLayer>("atlas-heading") ?: return
        if (heading == null || !followHeading) {
            if (coneVisible) {
                layer.setProperties(visibility(Property.NONE))
                coneVisible = false
                coneHeading = Float.NaN
            }
            return
        }
        if (!coneVisible || coneHeading.isNaN() || abs(HeadingMath.shortestDelta(coneHeading, heading)) >= 1f) {
            layer.setProperties(iconRotate(heading), visibility(Property.VISIBLE))
            coneVisible = true
            coneHeading = heading
        }
    }

    private fun addOverlayLayers(style: Style) {
        listOf("places", "selected", "route", "waypoints", "accuracy", "location").forEach {
            style.addSource(GeoJsonSource("atlas-$it-source", collection(emptyList())))
        }
        style.addLayer(FillLayer("atlas-accuracy", "atlas-accuracy-source").withProperties(
            fillColor("#0A84FF"), fillOpacity(0.12f), fillOutlineColor("#75B7F8")))
        style.addLayer(LineLayer("atlas-route-casing", "atlas-route-source").withProperties(
            lineColor("#FFFFFF"), lineOpacity(.95f), lineWidth(10f), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(LineLayer("atlas-route", "atlas-route-source").withProperties(
            lineColor("#087AFF"), lineWidth(6f), lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(CircleLayer("atlas-waypoints", "atlas-waypoints-source").withProperties(
            circleColor("#FFFFFF"), circleRadius(5f), circleStrokeColor("#087AFF"), circleStrokeWidth(3f)))
        style.addLayer(CircleLayer("atlas-places", "atlas-places-source").withProperties(
            circleColor(Expression.get("color")), circleRadius(9f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(2.5f)))
        style.addLayer(CircleLayer("atlas-selected-halo", "atlas-selected-source").withProperties(
            circleColor("#087AFF"), circleRadius(22f), circleOpacity(.14f)))
        style.addLayer(CircleLayer("atlas-selected", "atlas-selected-source").withProperties(
            circleColor("#087AFF"), circleRadius(13f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(3.5f)))
        style.addLayer(SymbolLayer("atlas-selected-label", "atlas-selected-source").withProperties(
            textField(Expression.get("name")), textFont(arrayOf("Noto Sans Regular")), textSize(13f),
            textOffset(arrayOf(0f, 2.2f)), textColor(if (content?.dark == true) "#F4F4F6" else "#24262B"),
            textHaloColor(if (content?.dark == true) "#242830" else "#FFFFFF"), textHaloWidth(2f), textMaxWidth(15f)))
        style.addImage("atlas-heading-cone", headingCone(density))
        style.addImage("atlas-course-arrow", courseArrow(density))
        coneVisible = false
        coneHeading = Float.NaN
        style.addLayer(SymbolLayer("atlas-heading", "atlas-location-source").withProperties(
            iconImage("atlas-heading-cone"), iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconAllowOverlap(true), iconIgnorePlacement(true), visibility(Property.NONE)))
        val noCourse = Expression.not(Expression.has("course"))
        style.addLayer(CircleLayer("atlas-location-halo", "atlas-location-source").withProperties(
            circleColor("#087AFF"), circleOpacity(.16f), circleRadius(15f)).also { it.setFilter(noCourse) })
        style.addLayer(CircleLayer("atlas-location", "atlas-location-source").withProperties(
            circleColor("#0A84FF"), circleRadius(7f), circleStrokeColor("#FFFFFF"), circleStrokeWidth(3f)).also { it.setFilter(noCourse) })
        style.addLayer(SymbolLayer("atlas-course", "atlas-location-source").withProperties(
            iconImage("atlas-course-arrow"), iconRotate(Expression.get("course")),
            iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
            iconAllowOverlap(true), iconIgnorePlacement(true)).also { it.setFilter(Expression.has("course")) })
    }

    fun destroy() {
        if (destroyed) return
        stop()
        destroyed = true
        choreographer.removeFrameCallback(frameCallback)
        followerScheduled = false
        map?.cancelTransitions()
        view.removeOnDidFailLoadingMapListener(failureListener)
        view.removeOnDidFinishLoadingMapListener(finishedListener)
        if (created) {
            context.applicationContext.unregisterComponentCallbacks(memoryCallbacks)
            view.onDestroy()
        }
        map = null
        style = null
    }
}

private fun headingCone(density: Float): Bitmap {
    val size = (120 * density).roundToInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bitmap.density = (160 * density).roundToInt()
    val center = size / 2f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(center, center, center,
            intArrayOf(0xA60A84FF.toInt(), 0x000A84FF), floatArrayOf(0.08f, 1f), Shader.TileMode.CLAMP)
    }
    Canvas(bitmap).drawArc(RectF(0f, 0f, size.toFloat(), size.toFloat()), -90f - 34f, 68f, true, paint)
    return bitmap
}

private fun courseArrow(density: Float): Bitmap {
    val size = (44 * density).roundToInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    bitmap.density = (160 * density).roundToInt()
    val s = size / 44f
    val path = Path().apply {
        moveTo(22f * s, 5f * s)
        lineTo(36f * s, 37f * s)
        lineTo(22f * s, 30f * s)
        lineTo(8f * s, 37f * s)
        close()
    }
    val canvas = Canvas(bitmap)
    canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * s; strokeJoin = Paint.Join.ROUND; color = AndroidColor.WHITE
    })
    canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A84FF.toInt() })
    return bitmap
}

private fun wrapLongitude(value: Double): Double = ((value + 180) % 360 + 360) % 360 - 180
private fun position(value: Coordinate) = JSONArray().put(value.longitude).put(value.latitude)
private fun feature(type: String, coordinates: JSONArray, properties: JSONObject = JSONObject()) = JSONObject()
    .put("type", "Feature").put("properties", properties)
    .put("geometry", JSONObject().put("type", type).put("coordinates", coordinates))
private fun collection(features: List<JSONObject>) = JSONObject().put("type", "FeatureCollection")
    .put("features", JSONArray(features)).toString()
private fun placeFeature(place: Place): JSONObject {
    val category = place.category.lowercase()
    val color = when {
        listOf("restaur", "café", "cafe", "food").any(category::contains) -> "#EF8D32"
        listOf("park", "parque", "nature").any(category::contains) -> "#48A865"
        listOf("hosp", "farm", "health").any(category::contains) -> "#E56475"
        listOf("hotel", "lodging").any(category::contains) -> "#986DC9"
        else -> "#647ED1"
    }
    return feature("Point", position(place.coordinate), JSONObject().put("id", place.id).put("name", place.name).put("color", color))
}

private fun accuracyFeature(fix: LocationFix): JSONObject {
    val distance = fix.accuracyMeters.coerceAtMost(100_000f) / 6_371_008.8
    val latitude = Math.toRadians(fix.coordinate.latitude)
    val longitude = Math.toRadians(fix.coordinate.longitude)
    val ring = JSONArray()
    for (i in 0..48) {
        val angle = i * 2.0 * Math.PI / 48
        val lat = asin(sin(latitude) * cos(distance) + cos(latitude) * sin(distance) * cos(angle))
        val lon = longitude + atan2(sin(angle) * sin(distance) * cos(latitude), cos(distance) - sin(latitude) * sin(lat))
        ring.put(JSONArray().put(wrapLongitude(Math.toDegrees(lon))).put(Math.toDegrees(lat)))
    }
    return feature("Polygon", JSONArray().put(ring))
}
