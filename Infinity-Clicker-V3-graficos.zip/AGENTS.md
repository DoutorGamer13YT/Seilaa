# Regras para IAs que alterarem este projeto

Estas regras valem para qualquer assistente de código (Claude, ChatGPT, Gemini, Copilot, Cursor etc.) e para pessoas.

## 1. Sempre aumente a versão do jogo (obrigatório)
- Toda vez que fizer **qualquer mudança** no projeto (código, visual, balanceamento, correção, otimização), aumente a
  versão **uma vez** por tarefa. Exemplo: `3.1` → `3.2`, `3.2` → `3.3`, `3.9` → `3.10`.
- **Virada de versão:** a parte depois do ponto vai só até `99`. Quando a próxima versão seria `3.100`, ela vira `4.0`
  (e `4.100` viraria `5.0`, e assim por diante). Ou seja: `3.98` → `3.99` → `4.0`. Nunca escreva `3.100`.
- Não aumente uma vez por arquivo editado: é **um** incremento por tarefa/entrega.
- Edite **somente** `VERSION_NUMBER` em `app/src/main/kotlin/com/infinityclicker/core/AppInfo.kt`.
- `versionName` e `versionCode` do app são calculados automaticamente a partir desse arquivo pelo
  `app/build.gradle.kts`. **Não mexa neles** e não escreva a versão em outro lugar (os testes e a tela leem do `AppInfo`).
- Depois, registre o que mudou em `OTIMIZACOES-V3.1.md` (ou no changelog) com o número novo no título da seção.
- Atualize o título do `README.md` para o mesmo número.

## 2. Entrega
- Ao entregar o ZIP do projeto, use o nome `project.zip`.

## 3. Cuidados
- Sem acesso a compilador, mantenha as edições pequenas e confira imports e chaves.
- Não use `remember` dentro de blocos de `LazyColumn { }` (não são `@Composable`).
