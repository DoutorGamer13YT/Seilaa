package dev.atlas.map

import dev.atlas.core.Coordinate

/** A new id applies the camera once, avoiding recomposition-driven camera jumps. */
data class CameraRequest(
    val id: Long,
    val target: Coordinate? = null,
    val points: List<Coordinate> = emptyList(),
    val bearing: Double? = null,
    val tilt: Double? = null,
    val zoom: Double? = null,
)
