# Atlas — acompanhamento do desenvolvimento

## Objetivo
Aplicativo Android nativo de mapas com identidade independente. A referência visual foi atualizada para o Apple Maps do iOS 27 por instrução do usuário. Nenhum recurso ou marca proprietária será distribuído.

## Auditoria inicial — 11/10/2026
- Workspace examinado, incluindo arquivos ocultos: nenhum projeto, código, manifesto, biblioteca ou configuração de build existente.
- Não há implementação anterior a substituir nem histórico Git gravável na raiz.
- Java OpenJDK 21 disponível. Gradle, SDK Android, adb e emulador não encontrados inicialmente.
- Rede HTTP disponível via proxy configurado, sem credenciais de provedores.
- Não há `/dev/kvm`; execução de emulador será investigada.

## Arquitetura e decisões
- Kotlin, Jetpack Compose, MVVM, coroutines/StateFlow, Room e DataStore.
- Injeção explícita por contêiner da aplicação: evita um plugin adicional sem benefício neste porte.
- MapLibre Native com estilo vetorial próprio e dados OpenFreeMap/OpenStreetMap.
- Photon para geocodificação; Overpass para categorias/detalhes; OSRM para carro; OpenRouteService opcional para caminhada/bicicleta.
- Serviços públicos de desenvolvimento são configuráveis e sujeitos às políticas, disponibilidade e limites de cada operador. Produção requer escolha operacional de provedores.
- UI em português, tema claro/escuro, painéis com quatro posições e componentes reutilizáveis.

## Tarefas
- [x] Auditoria dos arquivos e ferramentas existentes.
- [ ] Instalar ferramentas de build e produzir compilação reproduzível.
- [ ] Implementar e integrar dados reais e persistência.
- [ ] Implementar e integrar mapa, GPS, rotas e navegação.
- [ ] Implementar e refinar fluxos visuais completos.
- [ ] Executar testes automatizados e correções.
- [ ] Inspeção em emulador/dispositivo, se disponível.
- [ ] Gerar APK e documentação de configuração/privacidade.

## Evidências
Nenhuma compilação, teste ou inspeção visual foi executada neste ponto. Resultados serão registrados após execução.

## Retomada e preservação — 11/10/2026, 21:14 UTC

O trabalho dos seis agentes foi interrompido pelo limite de uso, não por conclusão do aplicativo. Foram encontrados e preservados **50 arquivos, 248.192 bytes**. Nenhum código foi apagado ou reiniciado.

- Backup: `/workspace/checkpoints/atlas-before-skills-20261011T211423Z.tar.gz`.
- Inventário SHA-256: `/workspace/checkpoints/atlas-before-skills-20261011T211423Z.json`.
- Todos os 50 arquivos extraídos do arquivo compactado foram conferidos contra o inventário, sem divergências.
- Ambiente e sessão preservados; não foi solicitado reinício.

| Frente/agente | Trabalho encontrado em disco | Pendências verificadas |
| --- | --- | --- |
| build | Gradle Kotlin DSL, manifesto, recursos/ícone, ProGuard, exemplo de configuração | SDK e Gradle Wrapper ainda ausentes; build nunca executado |
| providers | Photon, Overpass, OSRM, ORS, conectividade, tratamento de erros e testes de parsers/repositórios | ficha de lugar ainda ausente; integrações ao vivo não testadas |
| storage | Room, DataStore, favoritos/listas/histórico/atalhos, Biblioteca e Configurações | execução de testes e revisão integrada das telas pendentes |
| location | GPS, serviço foreground, notificação/TTS, progresso de navegação, links profundos e formatação | cenários reais de GPS/voz/tela apagada não executados |
| map | AtlasMap e CameraRequest com MapLibre, camadas e câmera | arquivos de estilo cartográfico não encontrados; integração e ciclo de vida precisam revisão |
| design | tokens/tema claro-escuro e controles de busca/mapa | AtlasBottomSheet e PlaceRow ainda ausentes; sem inspeção visual em aparelho |
| integração principal | Application, MainActivity, ViewModel, rotas de telas e ExplorePanel | MapScreen, ficha de lugar, painel de rotas e overlay de navegação ainda ausentes |

### Verificação real até esta retomada
- 61 métodos anotados com `@Test` em 6 arquivos JVM; 10 em 2 arquivos instrumentados.
- **Nenhum desses testes foi executado.** Contagem não significa aprovação.
- Referências a componentes ausentes são impedimentos concretos de integração. Não há APK gerado.
- Shell isolado não conseguiu alcançar o proxy; pedidos adicionais de rede ficaram pendentes e foram interrompidos. O conector GitHub funciona para leitura do repositório de skills.
- Possíveis defeitos a revisar: ciclo de vida inicial do MapView, respostas atrasadas de pesquisa, atualização de rota após encerrar navegação, acessibilidade e tamanhos de tela.

### Instrução mais recente do usuário
**Continuar exatamente do ponto interrompido e NÃO compilar o app.** A ordem anterior para gerar APK fica suspensa. Não executar Gradle, tasks de build ou testes Android que compilem o aplicativo até nova instrução. Prosseguir com preservação, instalação de skills, implementação e verificações estáticas.

### Próxima sequência
1. Skills instaladas e verificadas: 10 arquivos originais no commit `1983bef1bf8609fc8030d371224ee9e9a5d4bd61`; detalhes em `docs/SKILLS_INSTALLATION.md`.
2. Componentes anteriormente ausentes acrescentados, preservando os contratos e arquivos existentes.
3. Continuar apenas as ligações pendentes, sem repetir a auditoria global — instrução de 12/10/2026.
4. Compilação/APK permanecem suspensos por solicitação do usuário.

## Integração retomada — 12/10/2026

### Concluído em código nesta etapa
- `MapScreen` conecta mapa, busca, categorias, ficha, Biblioteca, Ajustes e planejamento de rotas.
- `AtlasBottomSheet` contém quatro posições, rolagem interna, fling, ajuste ao teclado, áreas seguras e ações de acessibilidade.
- `PlaceDetailPanel` apresenta os campos reais disponíveis, salvar, compartilhar, copiar, discar, site e atalhos.
- `RoutePanel` liga origem/destino/paradas, inversão, modos realmente disponíveis, alternativas, instruções e início explícito.
- `NavigationOverlay` liga instruções, chegada estimada, distância, GPS, voz, visão geral e encerramento.
- Estilos vetoriais claro/escuro locais presentes, com 57 camadas cada e fonte OpenFreeMap; documentação em `docs/MAP_STYLE.md`.
- Callback de gesto interrompe acompanhamento de câmera; retorno à localização reativa. Insets laterais são usados em paisagem.
- GPS de exploração fica ativo somente com mapa visível e Activity em primeiro plano; navegação é responsabilidade do serviço.
- Recálculo transferido do ViewModel para `NavigationService`: intervalo mínimo de 25 s, cancelamento, preservação de paradas e resposta protegida por sessão/rota original.
- Estado `routeError` separado de GPS/TTS; busca não mantém resultados de uma consulta anterior enquanto outra é digitada.
- Links recebidos abrem o mapa mesmo a partir da Biblioteca/Ajustes; durante navegação, aguardam encerramento sem substituir a rota silenciosamente.
- Mensagens usam canal com buffer para não desaparecer antes de a UI começar a observar.
- Encerrar navegação retorna ao modo de exploração; botões de limpar filtros/resultados estão conectados.
- Testes de interfaces e recálculo acrescentados como código de teste, sem execução.
- README e plano de testes adicionados; nenhum código anterior foi reiniciado.

### Verificações limitadas efetivamente executadas
- Na retomada, apenas arquivos das ligações pendentes foram consultados; não foi repetida auditoria completa.
- Verificação textual direcionada resolveu 39 callbacks de `AtlasApp`/`MapScreen` no ViewModel, sem referências ausentes nesse conjunto.
- Verificada a presença dos campos de estado do recálculo e remoção da implementação duplicada do ViewModel.
- O agente de mapas fez parse JSON/IDs de camadas dos dois estilos existentes, sem os recriar.
- Esses resultados não comprovam compatibilidade de tipos, renderização, navegação ou compilação.

### Pendências de entrega
- Nenhuma compilação, nenhum teste Kotlin/Android executado e nenhum APK gerado — explicitamente suspensos pelo usuário.
- SDK e Gradle Wrapper ainda ausentes; procedimento reproduzível documentado em `docs/BUILD.md`.
- Comparação visual com iOS 27, execução de mapas/provedores, testes GPS/voz, TalkBack, font scale, gestos e desempenho continuam pendentes de aparelho/emulador.
- A aparência implementada aproxima superfícies translúcidas, contornos e hierarquia; não há afirmação de refração óptica idêntica à Apple nem de fidelidade pixel a pixel.
- Serviços públicos de geocodificação/POIs/rotas não constituem infraestrutura contratada de produção.
- Transporte público, trânsito ao vivo, avaliações/fotos licenciadas, mapas baixados explicitamente e navegação offline completa não implementados.
- O projeto permanece **em desenvolvimento, não validado para produção**. Os fluxos estão ligados em código; isso não equivale a teste aprovado.

## Retomada DMap — 12/10/2026 (sem compilação)

### Implementado em código
- Cores: `AtlasTheme` reescrito com paletas Claro e Escuro, `ColorScheme` completo do Material 3 e `LocalContentColor` definido na raiz. Corrige texto preto sobre fundo escuro.
- Aparência: Automático, Claro e Escuro, salvos no DataStore e lidos de forma síncrona na abertura. Barras do sistema acompanham o tema do app.
- Animações: transições de navegação estilo push, troca de painéis, mola do painel com velocidade do gesto, escala ao tocar, botão Cancelar da busca, transição entre navegação e exploração, `animateItem` na Biblioteca e mudança de tema com cores interpoladas.
- Otimização: leitura da altura do painel adiada, tolerância no padding do mapa, conjunto de ids salvos nos resultados, `profileinstaller`.
- Segundo plano: o `NavigationService` entra em modo econômico com a tela apagada ou o app fora de vista (GPS a cada 3 s sem filtro de distância, sem provedor de rede, verificações a cada 15 s, notificações a cada 5 s). Com o app visível, volta ao modo preciso.
- Notificação em tempo real: instrução e distância até a manobra, mais chegada, distância e tempo restantes, visível na tela de bloqueio.
- Mapa: botão de informações removido; atribuição em texto discreto sobre o mapa. Seção de licenças removida de Ajustes.
- Seção Desenvolvedor: DMap, versão e build reais, @vitinhjkjkk e link do Instagram.
- Marca visível alterada para DMap. Pacote, `applicationId` e esquema `atlas://` foram mantidos.
- Comentários explicativos removidos do código-fonte.
- Workflow manual opcional `.github/workflows/dmap-debug.yml`.

### Não verificado
- Nada foi compilado nem executado. Contraste, animações, consumo de energia e notificações em segundo plano dependem de teste no aparelho.

## Bússola e orientação do mapa — 12/10/2026 (sem compilação)

### Implementado em código
- Três modos persistidos na sessão (ViewModel + SavedStateHandle): **Norte fixo**, **Livre** (rotação com dois dedos, sem retorno automático) e **Bússola** (mapa segue a direção do aparelho).
- Botão `CompassButton` com agulha que gira com o mapa e letra N; alterna Norte → Bússola → Norte; em Livre um toque restaura o norte com animação. Girar o mapa com dois dedos em Norte passa a Livre.
- `CompassSensor`: vetor de rotação (fallback acelerômetro + magnetômetro), declinação magnética pela localização, compensação da rotação da tela, mistura entre direção do topo (aparelho deitado) e da câmera traseira (aparelho em pé), suavização circular, zona morta de 0,4° e emissão limitada. O sensor só fica ativo no modo Bússola, com o mapa visível e o app em primeiro plano.
- Aparelhos sem sensores compatíveis: mensagem e permanência no Norte fixo. Sensor pouco calibrado: aviso para calibrar em forma de 8.
- `MapController`: seguidor de direção por quadro (Choreographer), pausado durante gestos e animações e parado em repouso; rotação por gesto desativada no modo Bússola; cone de direção do aparelho na bolinha de localização.
- Navegação: seta de rumo GPS (somente acima de 1,5 m/s) distinta do cone da bússola; zoom adaptado à velocidade; botão para alternar entre mapa girando pelo GPS e norte fixo.
- `HeadingMath` e `CameraPolicy` são funções puras, com testes em `HeadingMathTest`.

### Não verificado
- Nada foi compilado nem executado, incluindo `HeadingMathTest`. Cálculos foram conferidos à mão.
- Direção real, calibração, suavidade, consumo de bateria e aparência do cone dependem de teste no Galaxy A54.
- Assinaturas da API do MapLibre 11.8 (`CancelableCallback`, `addImage`, `setFilter`) não foram checadas pelo compilador.

## Mapas offline — peça 2, 12/10/2026
- Adicionados `core/OfflineTiles.kt`, `map/OfflineMaps.kt` e `ui/screens/OfflineMapsScreen.kt`; rota `offline` em `AtlasApp`, entrada em Ajustes e `AtlasViewModel.downloadOffline`.
- `OFFLINE_STYLE_URL` acrescentada ao `app/build.gradle.kts` e ao `local.properties.example`.
- Texto de privacidade e nota de rodapé de Ajustes atualizados; detalhes e limitações em `docs/OFFLINE.md`.
- Pendente: termos do OpenFreeMap para download em lote; compilação, testes e verificação em aparelho continuam suspensos. Nenhum workflow foi alterado.
