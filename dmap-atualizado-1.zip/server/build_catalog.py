#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from prepare_region import atomic_json, sha256


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    regions = {}
    for file in sorted(args.directory.glob('*.json')):
        item = json.loads(file.read_text())
        if item.get('provider') != 'protomaps' or item.get('kind') not in ('city', 'state'):
            continue
        archive = args.directory / f"{item['id']}.{item['version']}.zip"
        if not archive.is_file() or archive.stat().st_size != item['bytes'] or sha256(archive) != item['sha256']:
            raise SystemExit(f'Invalid archive for {file.name}')
        if item['id'] in regions:
            raise SystemExit('Keep one metadata version per region in the catalog input directory')
        regions[item['id']] = item
    atomic_json(args.output, {'schema': 1, 'regions': list(regions.values())})


if __name__ == '__main__':
    main()
