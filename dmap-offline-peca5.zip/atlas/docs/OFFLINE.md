# Mapas offline

## Como funciona

Sem internet o app troca sozinho para o OpenStreetMap e usa as regiões baixadas; com internet usa o mapa da Apple (`docs/MAP_SOURCES.md`). Só o OpenStreetMap pode ser baixado.

A tela Ajustes → Mapas offline baixa regiões do mapa para o aparelho usando o `OfflineManager` do MapLibre Native. O usuário escolhe um raio (10, 25 ou 50 km) e a área é centralizada no centro do mapa no momento. Os blocos vetoriais (zoom 5 a 14, o máximo do esquema OpenMapTiles), as fontes de texto e os sprites são guardados no banco do MapLibre e usados automaticamente pelo mapa quando não há rede. Acima do zoom 14 o mapa continua ampliando os dados do zoom 14.

- Código: `map/OfflineMaps.kt` (estado, download, pausa, retomada, exclusão), `core/OfflineTiles.kt` (área e estimativa de blocos), `ui/screens/OfflineMapsScreen.kt` (tela).
- Limites: 8 regiões, um download por vez, raio máximo de 50 km. Uma região de 25 km tem cerca de 750 blocos; uma de 50 km, cerca de 2.800.
- Metadados de cada região (nome, raio, centro, data) ficam no próprio banco do MapLibre.

## Estilo usado no download

O `OfflineManager` baixa recursos pela rede e precisa de um estilo em URL `http(s)`; um estilo local em `assets` não é suportado para esse fim. Por isso o download usa `OFFLINE_STYLE_URL` (padrão: estilo Liberty do OpenFreeMap), que referencia a mesma fonte vetorial (`https://tiles.openfreemap.org/planet`) e as mesmas fontes Noto Sans dos estilos `atlas-light.json` e `atlas-dark.json`. Os blocos e as fontes baixados são reaproveitados porque os endereços são idênticos. O raster Natural Earth do estilo Liberty só existe até o zoom 6 e custa poucos blocos.

Para usar um servidor próprio, defina `OFFLINE_STYLE_URL` em `local.properties` ou como variável de ambiente, apontando para um estilo com a mesma fonte e as mesmas fontes de texto.

## Termos do provedor

Os termos de uso do OpenFreeMap proíbem coleta automática de dados sem permissão. O download de regiões é uma busca em lote de blocos, mesmo limitada a áreas pequenas e disparada pelo usuário. Antes de publicar o aplicativo, obtenha autorização do OpenFreeMap (info@openfreemap.org) ou aponte `OFFLINE_STYLE_URL` e as fontes dos estilos para um servidor de blocos próprio, como um arquivo PMTiles hospedado por você.

## O que não funciona offline

Pesquisa de lugares, detalhes de lugares e cálculo de novas rotas continuam exigindo internet. Lugares salvos continuam disponíveis. Não há rotas nem pesquisa offline.

## Verificação

Nada disso foi compilado nem executado: o usuário suspendeu a compilação. `OfflineTilesTest` foi escrito e não executado. Os nomes e as assinaturas da API do MapLibre foram conferidos no código-fonte do repositório maplibre-native, não em tempo de compilação.
