package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.Formulas
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class FormulasTest {

    private val base = BigNum.of(15.0)
    private val growth = 1.15

    private fun closeTo(expected: BigNum, actual: BigNum, rel: Double = 1e-9) {
        val ratio = (actual / expected).toDouble()
        assertTrue("razão $ratio fora da tolerância", Math.abs(ratio - 1.0) <= rel)
    }

    @Test
    fun bulkCostEqualsSumOfUnitCosts() {
        for (owned in listOf(0L, 1L, 7L, 50L, 333L)) {
            for (n in listOf(1L, 2L, 10L, 100L)) {
                var sum = BigNum.ZERO
                for (i in 0 until n) sum += Formulas.unitCost(base, growth, owned + i)
                closeTo(sum, Formulas.bulkCost(base, growth, owned, n))
            }
        }
    }

    @Test
    fun maxAffordableIsExactlyTheBoundary() {
        val rnd = Random(42)
        repeat(300) {
            val owned = rnd.nextLong(0, 400)
            val budget = BigNum.of(10.0).pow(rnd.nextDouble(1.0, 40.0))
            val n = Formulas.maxAffordable(base, growth, owned, budget)
            if (n > 0) assertTrue("n=$n deveria caber", Formulas.bulkCost(base, growth, owned, n) <= budget)
            assertTrue("n+1 não deveria caber", Formulas.bulkCost(base, growth, owned, n + 1) > budget)
        }
    }

    @Test
    fun maxAffordableRespectsLimitAndZero() {
        val rich = BigNum.of(1e50)
        assertEquals(5L, Formulas.maxAffordable(base, growth, 0, rich, limit = 5))
        assertEquals(0L, Formulas.maxAffordable(base, growth, 0, BigNum.of(1.0)))
        assertEquals(0L, Formulas.maxAffordable(base, growth, 0, rich, limit = 0))
        assertEquals(1L, Formulas.maxAffordable(base, growth, 0, BigNum.of(15.0)))
    }

    @Test
    fun milestoneDoublesEvery25() {
        assertEquals(BigNum.ONE, Formulas.milestoneMultiplier(0))
        assertEquals(BigNum.ONE, Formulas.milestoneMultiplier(24))
        assertEquals(BigNum.of(2.0), Formulas.milestoneMultiplier(25))
        assertEquals(BigNum.of(4.0), Formulas.milestoneMultiplier(50))
        assertEquals(BigNum.of(16.0), Formulas.milestoneMultiplier(100))
    }

    @Test
    fun costStrictlyIncreasesWithOwned() {
        var prev = BigNum.ZERO
        for (owned in 0L..500L) {
            val c = Formulas.unitCost(base, growth, owned)
            assertTrue(c > prev)
            prev = c
        }
    }
}
