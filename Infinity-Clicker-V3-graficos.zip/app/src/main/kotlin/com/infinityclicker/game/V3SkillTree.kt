package com.infinityclicker.game

import java.util.Locale

/**
 * Árvore V3 com cinco rotas e exatamente cem nós. Os primeiros nove preservam IDs e efeitos
 * da V2; os demais usam [SkillEffect], que é calculado pelo motor econômico em tempo real.
 */
object V3SkillTree {

    private data class Spec(
        val id: String,
        val name: String,
        val description: String,
        val effect: SkillEffect,
        val perLevel: Double,
        val maxLevel: Int = 5
    )

    val nodes: List<SkillNodeDef> = buildList {
        // Poder — 3 legados + 17 novos.
        add(SkillNodeDef(SkillTree.POWER_CORE, SkillPath.POWER, "Pulso Prismático", "+25% de energia por clique por nível.", 10, 1,
            effectText = { "×${"%.2f".format(Locale.US, 1.0 + it * 0.25)} por clique" }))
        add(SkillNodeDef(SkillTree.POWER_CRIT, SkillPath.POWER, "Foco Crítico", "+2% de chance de crítico por nível.", 8, 2, listOf(SkillTree.POWER_CORE),
            effectText = { "+${it * 2}% chance crítica" }))
        add(SkillNodeDef(SkillTree.POWER_COMBO, SkillPath.POWER, "Ressonância", "+10 de limite de combo por nível.", 6, 3, listOf(SkillTree.POWER_CORE),
            effectText = { "+${it * 10} combo máximo" }))
        addBranching(
            path = SkillPath.POWER,
            roots = listOf(SkillTree.POWER_CRIT, SkillTree.POWER_COMBO),
            specs = listOf(
                Spec("power_impact_vector", "Vetor de Impacto", "+8% de força de clique por nível.", SkillEffect.CLICK_MULTIPLIER, .08),
                Spec("power_luminous_strike", "Golpe Luminoso", "+1 energia base por clique por nível.", SkillEffect.CLICK_FLAT, 1.0),
                Spec("power_redline_combo", "Combo no Limite", "+0,5% por passo de combo.", SkillEffect.COMBO_STEP, .005, 6),
                Spec("power_critical_prism", "Prisma Crítico", "+0,2× de dano crítico por nível.", SkillEffect.CRIT_POWER, .20),
                Spec("power_siege_touch", "Toque de Cerco", "+8% de dano contra chefes por nível.", SkillEffect.BOSS_DAMAGE, .08),
                Spec("power_cascade", "Cascata Cinética", "+0,02% da produção/s por clique.", SkillEffect.CLICK_FROM_PRODUCTION, .0002, 6),
                Spec("power_piercing_pulse", "Pulso Perfurante", "+0,8% de chance crítica por nível.", SkillEffect.CRIT_CHANCE, .008),
                Spec("power_afterimage", "Pós-imagem", "+5% de força de clique por nível.", SkillEffect.CLICK_MULTIPLIER, .05, 7),
                Spec("power_deep_combo", "Ritmo Profundo", "+4 de limite de combo por nível.", SkillEffect.COMBO_CAP, 4.0, 6),
                Spec("power_void_force", "Força do Vazio", "+10% de força de clique por nível.", SkillEffect.CLICK_MULTIPLIER, .10),
                Spec("power_resonant_cut", "Corte Ressonante", "+0,4% por passo de combo.", SkillEffect.COMBO_STEP, .004, 6),
                Spec("power_anvil", "Bigorna Estelar", "+2 energia base por clique por nível.", SkillEffect.CLICK_FLAT, 2.0),
                Spec("power_warped_crit", "Crítico Distorcido", "+0,18× de dano crítico por nível.", SkillEffect.CRIT_POWER, .18),
                Spec("power_execution", "Execução Astral", "+7% de dano contra chefes por nível.", SkillEffect.BOSS_DAMAGE, .07),
                Spec("power_starlight_siphon", "Sifão de Luz", "+0,02% da produção/s por clique.", SkillEffect.CLICK_FROM_PRODUCTION, .0002, 6),
                Spec("power_finality", "Finalidade", "+12% de força de clique por nível.", SkillEffect.CLICK_MULTIPLIER, .12, 4),
                Spec("power_infinite_hand", "Mão Infinita", "+18% de força de clique por nível.", SkillEffect.CLICK_MULTIPLIER, .18, 3)
            )
        )

        // Automação — 3 legados + 17 novos.
        add(SkillNodeDef(SkillTree.AUTO_CORE, SkillPath.AUTOMATION, "Matriz Autônoma", "+30% de produção por nível.", 10, 1,
            effectText = { "×${"%.2f".format(Locale.US, 1.0 + it * 0.30)} produção" }))
        add(SkillNodeDef(SkillTree.AUTO_MILESTONE, SkillPath.AUTOMATION, "Engrenagem Fractal", "Reduz o intervalo de marco dos geradores.", 5, 2, listOf(SkillTree.AUTO_CORE),
            effectText = { "marco a cada ${maxOf(10L, Formulas.MILESTONE_STEP - it.toLong() * 2L)}" }))
        add(SkillNodeDef(SkillTree.AUTO_OFFLINE, SkillPath.AUTOMATION, "Âncora Temporal", "+2 h e +5% eficiência offline por nível.", 6, 3, listOf(SkillTree.AUTO_CORE),
            effectText = { "+${it * 2} h / +${it * 5}% offline" }))
        addBranching(
            path = SkillPath.AUTOMATION,
            roots = listOf(SkillTree.AUTO_MILESTONE, SkillTree.AUTO_OFFLINE),
            specs = listOf(
                Spec("auto_warm_core", "Núcleo Aquecido", "+10% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .10),
                Spec("auto_night_shift", "Turno Noturno", "+1 h de ganhos offline por nível.", SkillEffect.OFFLINE_HOURS, 1.0),
                Spec("auto_geometric_gear", "Engrenagem Geométrica", "Reduz 1 o marco de gerador por nível.", SkillEffect.MILESTONE_REDUCTION, 1.0, 5),
                Spec("auto_supply_chain", "Cadeia de Suprimento", "-1% no custo de geradores por nível.", SkillEffect.GENERATOR_DISCOUNT, .01, 8),
                Spec("auto_condenser", "Condensador de Vácuo", "+2% de eficiência offline por nível.", SkillEffect.OFFLINE_EFFICIENCY, .02, 8),
                Spec("auto_vector_farm", "Fazenda Vetorial", "+12% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .12),
                Spec("auto_bulk_bay", "Baia de Lote", "-1% no custo de melhorias por nível.", SkillEffect.UPGRADE_DISCOUNT, .01, 8),
                Spec("auto_patience", "Paciência Mecânica", "+1 h de ganhos offline por nível.", SkillEffect.OFFLINE_HOURS, 1.0, 6),
                Spec("auto_repeat", "Repetidor Fractal", "+8% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .08, 7),
                Spec("auto_milestone_drive", "Impulso de Marco", "Reduz 1 o marco de gerador por nível.", SkillEffect.MILESTONE_REDUCTION, 1.0, 5),
                Spec("auto_cold_start", "Partida Fria", "+3% de eficiência offline por nível.", SkillEffect.OFFLINE_EFFICIENCY, .03, 6),
                Spec("auto_forge", "Forja Autônoma", "+14% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .14),
                Spec("auto_market", "Mercado Quântico", "-1,5% no custo de geradores por nível.", SkillEffect.GENERATOR_DISCOUNT, .015, 6),
                Spec("auto_blueprint", "Projeto Recursivo", "-1,5% no custo de melhorias por nível.", SkillEffect.UPGRADE_DISCOUNT, .015, 6),
                Spec("auto_long_watch", "Vigília Longa", "+2 h de ganhos offline por nível.", SkillEffect.OFFLINE_HOURS, 2.0, 4),
                Spec("auto_assembly", "Linha Infinita", "+16% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .16, 4),
                Spec("auto_self_replicate", "Auto-replicação", "+20% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .20, 3)
            )
        )

        // Cósmico — os três nós de Transcendência foram mantidos com os mesmos IDs.
        add(SkillNodeDef(SkillTree.TRANS_CORE, SkillPath.COSMIC, "Memória Eterna", "+10% de bônus permanente por ponto de prestígio.", 8, 2,
            effectText = { "+${it * 10}% por ponto de prestígio" }))
        add(SkillNodeDef(SkillTree.TRANS_PRESTIGE, SkillPath.COSMIC, "Horizonte", "+25% de pontos recebidos no renascimento por nível.", 6, 3, listOf(SkillTree.TRANS_CORE),
            effectText = { "+${it * 25}% pontos de prestígio" }))
        add(SkillNodeDef(SkillTree.TRANS_DIMENSION, SkillPath.COSMIC, "Passagem Quântica", "Reduz o requisito de dimensão em 10% por nível.", 5, 4, listOf(SkillTree.TRANS_CORE),
            effectText = { "-${it * 10}% requisito de dimensão" }))
        addBranching(
            path = SkillPath.COSMIC,
            roots = listOf(SkillTree.TRANS_PRESTIGE, SkillTree.TRANS_DIMENSION),
            specs = listOf(
                Spec("cosmic_legacy", "Legado de Luz", "+5% de pontos de prestígio por nível.", SkillEffect.PRESTIGE_GAIN, .05),
                Spec("cosmic_anchor", "Âncora Eterna", "+1% de bônus permanente por ponto de prestígio.", SkillEffect.PRESTIGE_PERMANENT, .01),
                Spec("cosmic_gate", "Portão Celeste", "-1,5% no requisito de dimensão por nível.", SkillEffect.DIMENSION_REDUCTION, .015, 7),
                Spec("cosmic_trophy", "Troféu Astral", "+8% de fragmentos de chefe por nível.", SkillEffect.SHARD_REWARD, .08),
                Spec("cosmic_resonance", "Ressonância Alta", "+2,5% de força da ressonância por nível.", SkillEffect.RESONANCE_POWER, .025),
                Spec("cosmic_prism", "Prisma de Coleção", "+4% de bônus de cristal por nível.", SkillEffect.CRYSTAL_POWER, .04),
                Spec("cosmic_record", "Registro Imortal", "+5% de pontos de conquistas por nível.", SkillEffect.ACHIEVEMENT_REWARD, .05),
                Spec("cosmic_horizon", "Horizonte Dourado", "+6% de pontos de prestígio por nível.", SkillEffect.PRESTIGE_GAIN, .06),
                Spec("cosmic_memory", "Memória Fractal", "+1,2% de bônus permanente por ponto.", SkillEffect.PRESTIGE_PERMANENT, .012),
                Spec("cosmic_shortcut", "Atalho Nebular", "-1% no requisito de dimensão por nível.", SkillEffect.DIMENSION_REDUCTION, .01, 8),
                Spec("cosmic_harvest", "Colheita de Éter", "+10% de fragmentos de chefe por nível.", SkillEffect.SHARD_REWARD, .10),
                Spec("cosmic_chord", "Acorde Cósmico", "+3% de força da ressonância por nível.", SkillEffect.RESONANCE_POWER, .03),
                Spec("cosmic_refraction", "Refração Viva", "+5% de bônus de cristal por nível.", SkillEffect.CRYSTAL_POWER, .05),
                Spec("cosmic_myth", "Mito Registrado", "+6% de pontos de conquistas por nível.", SkillEffect.ACHIEVEMENT_REWARD, .06),
                Spec("cosmic_crown", "Coroa do Vazio", "+8% de pontos de prestígio por nível.", SkillEffect.PRESTIGE_GAIN, .08, 4),
                Spec("cosmic_constellation", "Constelação Eterna", "+1,5% de bônus permanente por ponto.", SkillEffect.PRESTIGE_PERMANENT, .015, 4),
                Spec("cosmic_transcend", "Transcendência", "+8% de bônus de cristal por nível.", SkillEffect.CRYSTAL_POWER, .08, 3)
            )
        )

        // Sorte — vinte nós novos, todos relacionados a crítico e eventos que ocorrem localmente.
        addBranching(
            path = SkillPath.LUCK,
            roots = emptyList(),
            specs = listOf(
                Spec("luck_first_light", "Primeira Luz", "+0,7% de chance crítica por nível.", SkillEffect.CRIT_CHANCE, .007),
                Spec("luck_comet", "Cometa Favorável", "+0,5% de chance de evento por nível.", SkillEffect.EVENT_CHANCE, .005),
                Spec("luck_loaded_die", "Dado Carregado", "+0,15× de dano crítico por nível.", SkillEffect.CRIT_POWER, .15),
                Spec("luck_storm", "Tempestade Dourada", "+5% de potência de eventos por nível.", SkillEffect.EVENT_POWER, .05),
                Spec("luck_lucky_prism", "Prisma Afortunado", "+3% de bônus de cristal por nível.", SkillEffect.CRYSTAL_POWER, .03),
                Spec("luck_second_sun", "Segundo Sol", "+0,8% de chance crítica por nível.", SkillEffect.CRIT_CHANCE, .008),
                Spec("luck_portal", "Portal de Sorte", "+0,6% de chance de evento por nível.", SkillEffect.EVENT_CHANCE, .006),
                Spec("luck_supernova", "Supernova Premiada", "+6% de potência de eventos por nível.", SkillEffect.EVENT_POWER, .06),
                Spec("luck_coin", "Moeda Estelar", "+4% de pontos de conquistas por nível.", SkillEffect.ACHIEVEMENT_REWARD, .04),
                Spec("luck_eclipse", "Eclipse Crítico", "+0,18× de dano crítico por nível.", SkillEffect.CRIT_POWER, .18),
                Spec("luck_signal", "Sinal Raro", "+0,7% de chance de evento por nível.", SkillEffect.EVENT_CHANCE, .007),
                Spec("luck_aurora", "Aurora Premiada", "+7% de potência de eventos por nível.", SkillEffect.EVENT_POWER, .07),
                Spec("luck_fortune", "Fortuna Nebular", "+1% de chance crítica por nível.", SkillEffect.CRIT_CHANCE, .01, 4),
                Spec("luck_lottery", "Loteria Quântica", "+5% de pontos de conquistas por nível.", SkillEffect.ACHIEVEMENT_REWARD, .05, 4),
                Spec("luck_miracle", "Milagre de Éter", "+4% de bônus de cristal por nível.", SkillEffect.CRYSTAL_POWER, .04, 4),
                Spec("luck_orbit", "Órbita Favorável", "+0,9% de chance de evento por nível.", SkillEffect.EVENT_CHANCE, .009, 4),
                Spec("luck_starluck", "Sorte Estelar", "+0,22× de dano crítico por nível.", SkillEffect.CRIT_POWER, .22, 4),
                Spec("luck_jackpot", "Jackpot Galáctico", "+8% de potência de eventos por nível.", SkillEffect.EVENT_POWER, .08, 3),
                Spec("luck_destiny", "Destino Luminoso", "+1,2% de chance crítica por nível.", SkillEffect.CRIT_CHANCE, .012, 3),
                Spec("luck_impossible", "Improvável", "+1% de chance de evento por nível.", SkillEffect.EVENT_CHANCE, .01, 3)
            )
        )

        // Temporal — vinte nós novos para habilidades, chefes e velocidade sustentável.
        addBranching(
            path = SkillPath.TEMPORAL,
            roots = emptyList(),
            specs = listOf(
                Spec("time_dilation", "Dilatação", "+6% de duração de habilidade por nível.", SkillEffect.ABILITY_DURATION, .06),
                Spec("time_shortcut", "Atalho Temporal", "-5% de recarga de habilidade por nível.", SkillEffect.ABILITY_COOLDOWN, .05),
                Spec("time_charge", "Carga Cronal", "+8% de potência de habilidade por nível.", SkillEffect.ABILITY_POWER, .08),
                Spec("time_battlefield", "Campo Estendido", "+8% de tempo de chefe por nível.", SkillEffect.BOSS_DURATION, .08),
                Spec("time_reserve", "Reserva Horária", "+2% de eficiência offline por nível.", SkillEffect.OFFLINE_EFFICIENCY, .02),
                Spec("time_loop", "Laço de Produção", "+7% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .07),
                Spec("time_echo", "Eco de Recarga", "-4% de recarga de habilidade por nível.", SkillEffect.ABILITY_COOLDOWN, .04),
                Spec("time_long_now", "Agora Longo", "+7% de duração de habilidade por nível.", SkillEffect.ABILITY_DURATION, .07),
                Spec("time_overclock", "Overclock Cronal", "+9% de potência de habilidade por nível.", SkillEffect.ABILITY_POWER, .09),
                Spec("time_patience", "Paciência do Vazio", "+10% de tempo de chefe por nível.", SkillEffect.BOSS_DURATION, .10),
                Spec("time_sleep", "Sono das Estrelas", "+1 h de ganhos offline por nível.", SkillEffect.OFFLINE_HOURS, 1.0, 6),
                Spec("time_stream", "Fluxo Constante", "+8% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .08),
                Spec("time_recall", "Retorno Instantâneo", "-6% de recarga de habilidade por nível.", SkillEffect.ABILITY_COOLDOWN, .06, 4),
                Spec("time_stasis", "Estase Favorável", "+8% de duração de habilidade por nível.", SkillEffect.ABILITY_DURATION, .08, 4),
                Spec("time_surge", "Surto de Era", "+10% de potência de habilidade por nível.", SkillEffect.ABILITY_POWER, .10, 4),
                Spec("time_mercy", "Misericórdia Cronal", "+12% de tempo de chefe por nível.", SkillEffect.BOSS_DURATION, .12, 4),
                Spec("time_archive", "Arquivo de Horas", "+3% de eficiência offline por nível.", SkillEffect.OFFLINE_EFFICIENCY, .03, 4),
                Spec("time_accelerate", "Aceleração Total", "+10% de produção por nível.", SkillEffect.PRODUCTION_MULTIPLIER, .10, 4),
                Spec("time_paradox", "Paradoxo Útil", "+12% de potência de habilidade por nível.", SkillEffect.ABILITY_POWER, .12, 3),
                Spec("time_infinite", "Hora Infinita", "+10% de duração de habilidade por nível.", SkillEffect.ABILITY_DURATION, .10, 3)
            )
        )
        check(size == 100) { "A árvore V3 precisa conter exatamente 100 nós; recebeu $size" }
    }

    private fun MutableList<SkillNodeDef>.addBranching(
        path: SkillPath,
        roots: List<String>,
        specs: List<Spec>
    ) {
        val ids = ArrayList<String>(specs.size)
        specs.forEachIndexed { index, spec ->
            val prerequisites = when {
                index < roots.size -> listOf(roots[index])
                index < 2 && roots.isEmpty() -> emptyList()
                index < 2 -> listOf(roots[index % roots.size])
                else -> listOf(ids[index - 2])
            }
            val cost = 2 + index / 2 + path.ordinal
            add(
                SkillNodeDef(
                    id = spec.id,
                    path = path,
                    name = spec.name,
                    description = spec.description,
                    maxLevel = spec.maxLevel,
                    baseCost = cost,
                    prerequisites = prerequisites,
                    effectText = { level -> formatEffect(spec.effect, spec.perLevel * level) },
                    effect = spec.effect,
                    effectPerLevel = spec.perLevel
                )
            )
            ids += spec.id
        }
    }

    private fun formatEffect(effect: SkillEffect, amount: Double): String = when (effect) {
        SkillEffect.CLICK_MULTIPLIER -> "+${percent(amount)} por clique"
        SkillEffect.CLICK_FLAT -> "+${"%.0f".format(Locale.US, amount)} base por clique"
        SkillEffect.CLICK_FROM_PRODUCTION -> "+${percent(amount)} da produção/s por clique"
        SkillEffect.CRIT_CHANCE -> "+${percent(amount)} chance crítica"
        SkillEffect.CRIT_POWER -> "+${"%.2f".format(Locale.US, amount)}× crítico"
        SkillEffect.COMBO_CAP -> "+${amount.toInt()} combo máximo"
        SkillEffect.COMBO_STEP -> "+${percent(amount)} por passo de combo"
        SkillEffect.BOSS_DAMAGE -> "+${percent(amount)} dano a chefes"
        SkillEffect.PRODUCTION_MULTIPLIER -> "+${percent(amount)} produção"
        SkillEffect.OFFLINE_HOURS -> "+${amount.toInt()} h offline"
        SkillEffect.OFFLINE_EFFICIENCY -> "+${percent(amount)} eficiência offline"
        SkillEffect.MILESTONE_REDUCTION -> "-${amount.toInt()} no marco de geradores"
        SkillEffect.GENERATOR_DISCOUNT -> "-${percent(amount)} custo de geradores"
        SkillEffect.UPGRADE_DISCOUNT -> "-${percent(amount)} custo de melhorias"
        SkillEffect.PRESTIGE_GAIN -> "+${percent(amount)} pontos de prestígio"
        SkillEffect.PRESTIGE_PERMANENT -> "+${percent(amount)} permanente por PP"
        SkillEffect.DIMENSION_REDUCTION -> "-${percent(amount)} requisito dimensional"
        SkillEffect.SHARD_REWARD -> "+${percent(amount)} fragmentos de chefe"
        SkillEffect.RESONANCE_POWER -> "+${percent(amount)} força da ressonância"
        SkillEffect.CRYSTAL_POWER -> "+${percent(amount)} bônus de cristal"
        SkillEffect.EVENT_CHANCE -> "+${percent(amount)} chance de evento"
        SkillEffect.EVENT_POWER -> "+${percent(amount)} potência de evento"
        SkillEffect.ACHIEVEMENT_REWARD -> "+${percent(amount)} PP de conquistas"
        SkillEffect.ABILITY_DURATION -> "+${percent(amount)} duração de habilidades"
        SkillEffect.ABILITY_COOLDOWN -> "-${percent(amount)} recarga de habilidades"
        SkillEffect.ABILITY_POWER -> "+${percent(amount)} potência de habilidades"
        SkillEffect.BOSS_DURATION -> "+${percent(amount)} tempo contra chefes"
    }

    private fun percent(value: Double): String = "%.1f%%".format(Locale.US, value * 100.0)
}
