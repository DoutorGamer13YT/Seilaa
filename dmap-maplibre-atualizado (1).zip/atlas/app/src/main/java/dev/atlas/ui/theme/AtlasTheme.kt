package dev.atlas.ui.theme

import android.app.Activity
import android.graphics.drawable.ColorDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import dev.atlas.core.ThemeMode

@Immutable
data class AtlasColors(
    val background: Color, val surface: Color, val glass: Color,
    val grouped: Color, val secondarySurface: Color, val text: Color,
    val secondaryText: Color, val separator: Color, val glassBorder: Color,
    val accent: Color, val onAccent: Color, val positive: Color, val onPositive: Color,
    val danger: Color, val onDanger: Color, val isDark: Boolean,
)

private val LightPalette = AtlasColors(
    background = Color(0xFFF2F2F7), surface = Color(0xFFFFFFFF),
    glass = Color(0xF5FBFBFD), grouped = Color(0xFFF2F2F7),
    secondarySurface = Color(0xFFE5E5EA), text = Color(0xFF111114),
    secondaryText = Color(0xFF5A5A62), separator = Color(0x293C3C43),
    glassBorder = Color(0xCCFFFFFF), accent = Color(0xFF0A66D8), onAccent = Color(0xFFFFFFFF),
    positive = Color(0xFF1B7A33), onPositive = Color(0xFFFFFFFF),
    danger = Color(0xFFC4001A), onDanger = Color(0xFFFFFFFF), isDark = false,
)

private val DarkPalette = AtlasColors(
    background = Color(0xFF111113), surface = Color(0xFF232326),
    glass = Color(0xF51C1C1F), grouped = Color(0xFF1C1C1E),
    secondarySurface = Color(0xFF36363A), text = Color(0xFFF5F5F7),
    secondaryText = Color(0xFFB4B4BC), separator = Color(0x4D545458),
    glassBorder = Color(0x40FFFFFF), accent = Color(0xFF69ADFF), onAccent = Color(0xFF04203F),
    positive = Color(0xFF5BDD82), onPositive = Color(0xFF04210E),
    danger = Color(0xFFFF7068), onDanger = Color(0xFF2B0300), isDark = true,
)

val LocalAtlasColors = compositionLocalOf { LightPalette }
val LocalAtlasReduceMotion = staticCompositionLocalOf { false }

object AtlasMotion {
    val Emphasized = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
    val Standard = CubicBezierEasing(0.32f, 0.72f, 0f, 1f)
    const val Short = 180
    const val Medium = 320
    const val Long = 420
}

object AtlasDimens {
    val ScreenMargin = 16.dp
    val SheetRadius = 30.dp
    val CardRadius = 20.dp
    val ControlRadius = 25.dp
    val SearchRadius = 23.dp
    val SearchHeight = 52.dp
    val ControlSize = 50.dp
    val IconSize = 23.dp
    val TouchTarget = 48.dp
    val RowMinHeight = 76.dp
    val SmallGap = 8.dp
    val MediumGap = 12.dp
    val LargeGap = 20.dp
    val FloatingElevation = 7.dp
    const val ShortAnimationMillis = 180
    const val PanelDamping = 0.94f
    const val PanelStiffness = 240f
}

private val AtlasTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 37.sp, letterSpacing = (-0.7).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 27.sp, lineHeight = 33.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 29.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 23.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 17.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 15.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp),
)

private fun schemeFor(p: AtlasColors): ColorScheme {
    val tint = if (p.isDark) Color.White else Color.Black
    val container = lerp(p.surface, tint, if (p.isDark) 0.04f else 0.02f)
    val containerHigh = lerp(p.surface, tint, if (p.isDark) 0.08f else 0.04f)
    val containerHighest = lerp(p.surface, tint, if (p.isDark) 0.12f else 0.06f)
    val containerLow = if (p.isDark) lerp(p.surface, Color.Black, 0.25f) else p.grouped
    val primaryContainer = lerp(p.surface, p.accent, if (p.isDark) 0.28f else 0.14f)
    val errorContainer = lerp(p.surface, p.danger, if (p.isDark) 0.28f else 0.14f)
    val onErrorContainer = if (p.isDark) Color(0xFFFFDAD6) else Color(0xFF5C0010)
    val outline = p.secondaryText.copy(alpha = 0.6f)
    return if (p.isDark) darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, primaryContainer = primaryContainer, onPrimaryContainer = p.text,
        inversePrimary = Color(0xFF0A66D8),
        secondary = p.accent, onSecondary = p.onAccent, secondaryContainer = primaryContainer, onSecondaryContainer = p.text,
        tertiary = p.positive, onTertiary = p.onPositive, tertiaryContainer = p.secondarySurface, onTertiaryContainer = p.text,
        background = p.background, onBackground = p.text,
        surface = p.surface, onSurface = p.text, surfaceVariant = p.secondarySurface, onSurfaceVariant = p.secondaryText,
        surfaceTint = p.accent, inverseSurface = p.text, inverseOnSurface = p.background,
        error = p.danger, onError = p.onDanger, errorContainer = errorContainer, onErrorContainer = onErrorContainer,
        outline = outline, outlineVariant = p.separator, scrim = Color.Black,
        surfaceBright = containerHighest, surfaceDim = p.background,
        surfaceContainerLowest = p.background, surfaceContainerLow = containerLow, surfaceContainer = container,
        surfaceContainerHigh = containerHigh, surfaceContainerHighest = containerHighest,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, primaryContainer = primaryContainer, onPrimaryContainer = p.text,
        inversePrimary = Color(0xFF69ADFF),
        secondary = p.accent, onSecondary = p.onAccent, secondaryContainer = primaryContainer, onSecondaryContainer = p.text,
        tertiary = p.positive, onTertiary = p.onPositive, tertiaryContainer = p.secondarySurface, onTertiaryContainer = p.text,
        background = p.background, onBackground = p.text,
        surface = p.surface, onSurface = p.text, surfaceVariant = p.secondarySurface, onSurfaceVariant = p.secondaryText,
        surfaceTint = p.accent, inverseSurface = Color(0xFF2A2A2E), inverseOnSurface = Color(0xFFF5F5F7),
        error = p.danger, onError = p.onDanger, errorContainer = errorContainer, onErrorContainer = onErrorContainer,
        outline = outline, outlineVariant = p.separator, scrim = Color.Black,
        surfaceBright = p.surface, surfaceDim = p.secondarySurface,
        surfaceContainerLowest = p.surface, surfaceContainerLow = containerLow, surfaceContainer = container,
        surfaceContainerHigh = containerHigh, surfaceContainerHighest = containerHighest,
    )
}

private fun paletteFor(mode: ThemeMode, systemDark: Boolean): AtlasColors = when (mode) {
    ThemeMode.SYSTEM -> if (systemDark) DarkPalette else LightPalette
    ThemeMode.LIGHT -> LightPalette
    ThemeMode.DARK -> DarkPalette
}

@Composable
private fun animatedPalette(target: AtlasColors, reduceMotion: Boolean): AtlasColors {
    val spec = if (reduceMotion) snap<Color>() else tween<Color>(AtlasMotion.Medium, easing = AtlasMotion.Standard)
    return AtlasColors(
        background = animateColorAsState(target.background, spec, label = "background").value,
        surface = animateColorAsState(target.surface, spec, label = "surface").value,
        glass = animateColorAsState(target.glass, spec, label = "glass").value,
        grouped = animateColorAsState(target.grouped, spec, label = "grouped").value,
        secondarySurface = animateColorAsState(target.secondarySurface, spec, label = "secondarySurface").value,
        text = animateColorAsState(target.text, spec, label = "text").value,
        secondaryText = animateColorAsState(target.secondaryText, spec, label = "secondaryText").value,
        separator = animateColorAsState(target.separator, spec, label = "separator").value,
        glassBorder = animateColorAsState(target.glassBorder, spec, label = "glassBorder").value,
        accent = animateColorAsState(target.accent, spec, label = "accent").value,
        onAccent = animateColorAsState(target.onAccent, spec, label = "onAccent").value,
        positive = animateColorAsState(target.positive, spec, label = "positive").value,
        onPositive = animateColorAsState(target.onPositive, spec, label = "onPositive").value,
        danger = animateColorAsState(target.danger, spec, label = "danger").value,
        onDanger = animateColorAsState(target.onDanger, spec, label = "onDanger").value,
        isDark = target.isDark,
    )
}

@Composable
fun AtlasTheme(mode: ThemeMode = ThemeMode.SYSTEM, reduceMotion: Boolean = false, content: @Composable () -> Unit) {
    val palette = animatedPalette(paletteFor(mode, isSystemInDarkTheme()), reduceMotion)
    val scheme = remember(palette) { schemeFor(palette) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !palette.isDark
            controller.isAppearanceLightNavigationBars = !palette.isDark
            window.setBackgroundDrawable(ColorDrawable(palette.background.toArgb()))
        }
    }
    CompositionLocalProvider(
        LocalAtlasColors provides palette,
        LocalAtlasReduceMotion provides reduceMotion,
        LocalContentColor provides palette.text,
    ) {
        MaterialTheme(colorScheme = scheme, typography = AtlasTypography, content = content)
    }
}
