package com.infinityclicker.game

import com.infinityclicker.core.BigNum
import com.infinityclicker.generators.GeneratorDefs

/** Estado de um chefe aberto. A vida é persistida para que sair do app não reinicie uma luta. */
data class ActiveBoss(
    var dimensionId: Int = -1,
    var health: BigNum = BigNum.ZERO,
    var deadlineMs: Long = 0L
)

/** Evento temporário local. Não depende de rede e sua duração continua correta após reiniciar. */
data class ActiveCosmicEvent(
    var eventId: String = "",
    var endsAtMs: Long = 0L
)

/** Desafio iniciado pelo jogador. A meta e o prazo ficam no save para não poderem ser duplicados. */
data class ActiveChallenge(
    var challengeId: String = "",
    var startedAtMs: Long = 0L,
    var deadlineMs: Long = 0L,
    var progress: Long = 0L
)

/** Um registro pequeno, imutável no save, para o histórico de renascimentos. */
data class PrestigeEntry(
    val atMs: Long,
    val points: Int,
    val lifetimeEnergy: BigNum
)

/** Todo o progresso persistente do jogador. Mutável e sem dependência de Android ou Compose. */
class GameState {
    var energy: BigNum = BigNum.ZERO
    /** Energia produzida na vida toda (cliques + geradores + offline); nunca diminui ao gastar. */
    var totalEnergy: BigNum = BigNum.ZERO
    var totalClicks: Long = 0L
    var critClicks: Long = 0L
    var maxCombo: Int = 0
    var generatorsBought: Long = 0L
    var upgradeLevelsBought: Long = 0L
    var playTimeMs: Long = 0L
    var offlineEarned: BigNum = BigNum.ZERO
    /** Separação de fontes para estatísticas e conquistas reais da versão 3. */
    var clickEnergy: BigNum = BigNum.ZERO
    var productionEnergy: BigNum = BigNum.ZERO
    var eventEnergy: BigNum = BigNum.ZERO
    var highestProduction: BigNum = BigNum.ZERO
    var highestTapMultiplier: Double = 1.0
    var bestClicksPerSecond: Int = 0
    /** Relógio de parede (ms) do último salvamento/encerramento de sessão; 0 = jogo novo. */
    var lastSessionMs: Long = 0L

    /** Energia acumulada desde o último renascimento. Não substitui [totalEnergy]. */
    var runEnergy: BigNum = BigNum.ZERO
    var prestigePoints: Int = 0
    var prestigeCount: Int = 0
    val prestigeHistory: MutableList<PrestigeEntry> = ArrayList()

    /** Árvore de habilidades: os níveis são limitados pelas definições, nunca por UI. */
    val skillLevels: MutableMap<String, Int> = HashMap()

    /** Dimensões, recursos e chefes. A dimensão 0 está sempre disponível. */
    var currentDimension: Int = 0
    val dimensionUnlocked: BooleanArray = BooleanArray(DimensionDefs.count).also { it[0] = true }
    val dimensionShards: LongArray = LongArray(DimensionDefs.count)
    /** Ressonância comprada com fragmentos da própria dimensão. */
    val dimensionResonance: IntArray = IntArray(DimensionDefs.count)
    val bossWins: IntArray = IntArray(DimensionDefs.count)
    var activeBoss: ActiveBoss? = null
    var dimensionTravelCount: Long = 0L

    /** Coleção e aparência do cristal equipável. O cristal base é sempre possuído. */
    val crystalsUnlocked: BooleanArray = BooleanArray(CrystalDefs.count).also { it[0] = true }
    var equippedCrystal: Int = 0

    /** Cenários são cosméticos, mas cada um altera de fato o Canvas de fundo. */
    val backgroundsUnlocked: BooleanArray = BooleanArray(BackgroundDefs.count).also { it[0] = true }
    var equippedBackground: Int = 0

    /** Habilidades temporárias têm recarga e término em relógio de parede, sobreviveram a reinícios. */
    val abilityLevels: MutableMap<String, Int> = HashMap()
    val abilityCooldownUntilMs: MutableMap<String, Long> = HashMap()
    val abilityActiveUntilMs: MutableMap<String, Long> = HashMap()
    val abilityUseCounts: MutableMap<String, Long> = HashMap()
    var abilitiesUsed: Long = 0L

    /** Eventos locais e desafios nunca exigem conexão. */
    var activeEvent: ActiveCosmicEvent? = null
    var eventCooldownUntilMs: Long = 0L
    var eventsTriggered: Long = 0L
    var activeChallenge: ActiveChallenge? = null
    var challengeCompletions: Long = 0L
    var challengeFastestMs: Long = Long.MAX_VALUE
    val challengeWins: LongArray = LongArray(ChallengeDefs.count)
    var challengesAbandoned: Long = 0L

    /** Conteúdo diário local — cada recompensa é marcada antes de ser salva. */
    var dailyDay: Long = -1L
    val dailyProgress: LongArray = LongArray(DailyMissionDefs.count)
    val dailyClaimed: BooleanArray = BooleanArray(DailyMissionDefs.count)
    var lastLoginDay: Long = -1L
    var loginStreak: Int = 0
    var loginClaimedDay: Long = -1L
    val achievementsClaimed: MutableSet<String> = HashSet()
    /** Registro de desbloqueio independente da coleta da recompensa, usado pela galeria/histórico. */
    val achievementsUnlockedAt: MutableMap<String, Long> = HashMap()

    /** Dados de compras para conquistas e estatísticas; 1, 10, 100 e máximo. */
    val purchaseModeUses: LongArray = LongArray(4)
    /** -1 significa que nenhum gerador foi comprado ainda. */
    var highestGeneratorTierEver: Int = -1
    var highestUpgradeLevelEver: Int = 0

    var tutorialStep: Int = 0
    var saveRevision: Long = 0L
    var lastModifiedMs: Long = 0L

    val generators: LongArray = LongArray(GeneratorDefs.count)
    val upgradeLevels: MutableMap<String, Int> = HashMap()

    fun level(id: String): Int = upgradeLevels[id] ?: 0
    fun skillLevel(id: String): Int = skillLevels[id] ?: 0
    fun abilityLevel(id: String): Int = abilityLevels[id] ?: 0

    companion object {
        fun new(): GameState = GameState()
    }
}
