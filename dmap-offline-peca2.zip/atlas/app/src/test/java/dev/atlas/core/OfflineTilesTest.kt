package dev.atlas.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineTilesTest {
    private val saoPaulo = Coordinate(-23.5505, -46.6333)

    @Test
    fun boxIsCenteredAndWiderInLongitudeAwayFromEquator() {
        val equator = OfflineTiles.box(Coordinate(0.0, 0.0), 25)
        val north = OfflineTiles.box(Coordinate(60.0, 0.0), 25)
        assertEquals(equator.north, -equator.south, 1e-9)
        assertTrue(north.east - north.west > equator.east - equator.west)
    }

    @Test
    fun boxStaysInsideWorldLimits() {
        val box = OfflineTiles.box(Coordinate(84.9, 179.9), 50)
        assertTrue(box.north <= 85.0 && box.south >= -85.0)
        assertTrue(box.east <= 180.0 && box.west >= -180.0)
    }

    @Test
    fun tileCountGrowsWithRadiusAndStaysBounded() {
        val small = OfflineTiles.tileCount(OfflineTiles.box(saoPaulo, 10))
        val medium = OfflineTiles.tileCount(OfflineTiles.box(saoPaulo, 25))
        val large = OfflineTiles.tileCount(OfflineTiles.box(saoPaulo, 50))
        assertTrue(small in 1 until medium)
        assertTrue(medium < large)
        assertTrue(large < 20_000)
    }

    @Test
    fun singleZoomCountMatchesTileGrid() {
        val box = OfflineTiles.Box(south = -1.0, west = -1.0, north = 1.0, east = 1.0)
        assertEquals(4L, OfflineTiles.tileCount(box, 1, 1))
    }

    @Test(expected = IllegalArgumentException::class)
    fun zeroRadiusIsRejected() {
        OfflineTiles.box(saoPaulo, 0)
    }
}
