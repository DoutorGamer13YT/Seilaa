package com.infinityclicker.ui.components

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.composed
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import kotlin.math.max
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Vidro líquido de baixo custo. A versão anterior usava `shadow(14.dp)` com cor própria em cada painel:
 * em superfícies translúcidas a sombra é recortada e redesenhada fora da forma, o que custava caro na
 * GPU do Galaxy A54 e era a principal causa de travadas na rolagem de listas com muitos cartões.
 *
 * Agora cada painel desenha, uma vez por tamanho (drawWithCache), só gradientes simples:
 * corpo translúcido, halo de cor na borda de baixo (no lugar da sombra), brilho especular no topo
 * e borda com refração. Nenhum blur, nenhuma sombra de elevação.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    borderAlpha: Float = 0.38f
): Modifier = this
    .clip(shape)
    .drawWithCache {
        val outline = shape.createOutline(size, layoutDirection, this)
        val body = Brush.linearGradient(
            0f to Color.White.copy(alpha = (alpha * 0.32f + 0.05f).coerceAtMost(0.20f)),
            0.24f to tint.copy(alpha = (alpha + 0.10f).coerceAtMost(0.42f)),
            0.66f to tint.copy(alpha = (alpha * 0.46f).coerceAtMost(0.25f)),
            1f to Color(0xFF050616).copy(alpha = (alpha * 0.72f).coerceAtLeast(0.05f))
        )
        // Brilho especular: faixa clara que some em ~45% da altura, como luz sobre vidro curvo.
        val sheen = Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.13f),
            0.45f to Color.Transparent
        )
        val glow = Brush.verticalGradient(
            0.62f to Color.Transparent,
            1f to tint.copy(alpha = (alpha * 0.9f).coerceIn(0.03f, 0.22f))
        )
        val border = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = borderAlpha.coerceIn(0f, 0.9f)),
                Color.White.copy(alpha = 0.05f),
                tint.copy(alpha = (borderAlpha * 0.74f).coerceIn(0f, 0.8f))
            )
        )
        // Vazamento de luz no canto superior esquerdo: dá profundidade e uma "fonte" de luz consistente em todos os painéis.
        val leak = Brush.radialGradient(
            listOf(tint.copy(alpha = (alpha * 1.4f).coerceIn(0.05f, 0.28f)), Color.Transparent),
            Offset(size.width * 0.06f, 0f), size.maxDimension * 0.62f
        )
        val stroke = Stroke(1.2.dp.toPx())
        onDrawBehind {
            drawOutline(outline, body)
            drawOutline(outline, glow)
            drawOutline(outline, leak)
            drawOutline(outline, sheen)
            drawOutline(outline, border, style = stroke)
        }
    }

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier.glass(tint = tint, alpha = alpha).padding(14.dp),
        content = content
    )
}

/**
 * Clique com resposta física: o elemento afunda ao toque e volta com uma mola levemente elástica.
 * Deve vir ANTES de `.glass(...)` na cadeia, para o vidro inteiro escalar junto.
 */
fun Modifier.bouncyClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.48f, stiffness = 650f), label = "bounce"
    )
    this.graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

/**
 * Barra de progresso com mola, degradê, brilho no topo e ponto luminoso na ponta.
 * Mesmos parâmetros do LinearProgressIndicator (progress em lambda), então troca direta.
 */
@Composable
fun GlowBar(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    trackColor: Color = Color.White.copy(alpha = 0.12f)
) {
    val p by animateFloatAsState(progress().coerceIn(0f, 1f), spring(dampingRatio = 0.85f, stiffness = 220f), label = "glowBar")
    Canvas(modifier.height(6.dp)) {
        val radius = CornerRadius(size.height / 2f)
        drawRoundRect(trackColor, cornerRadius = radius)
        val w = size.width * p
        if (w > 0.5f) {
            val fillW = max(w, size.height)
            drawRoundRect(
                Brush.horizontalGradient(listOf(color.copy(alpha = 0.55f), color, Color.White.copy(alpha = 0.85f).compositeOver(color)), 0f, fillW),
                size = Size(fillW, size.height), cornerRadius = radius
            )
            drawRoundRect(Color.White.copy(alpha = 0.22f), topLeft = Offset(size.height * 0.4f, size.height * 0.12f),
                size = Size((fillW - size.height * 0.8f).coerceAtLeast(0f), size.height * 0.30f), cornerRadius = CornerRadius(size.height * 0.15f))
            drawCircle(color.copy(alpha = 0.30f), size.height * 1.4f, Offset(fillW - size.height / 2f, size.height / 2f))
        }
    }
}
