package dev.atlas.core

import java.io.ByteArrayOutputStream
import java.net.URI
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.Locale

sealed interface DeepLinkTarget {
    data class Search(val query: String) : DeepLinkTarget
    data class Pin(val coordinate: Coordinate, val label: String?, val navigate: Boolean = false) : DeepLinkTarget
}

object DeepLinks {
    private const val MAX_URI_LENGTH = 2_048
    private const val MAX_QUERY_LENGTH = 200
    private const val MAX_NAME_LENGTH = 120
    private const val NUMERIC = "[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?"
    private val numeric = Regex("^$NUMERIC$")
    private val coordinatePair = Regex("^\\s*($NUMERIC)\\s*,\\s*($NUMERIC)\\s*$")
    private val coordinateWithLabel = Regex("^\\s*($NUMERIC)\\s*,\\s*($NUMERIC)\\s*(?:\\((.*)\\))?$", RegexOption.DOT_MATCHES_ALL)
    private val nonFiniteCoordinate = Regex("(?i)^[+-]?(?:NaN|Infinity)\\s*,|,\\s*[+-]?(?:NaN|Infinity)(?:\\s|\\(|$)")

    fun parse(raw: String): DeepLinkTarget? {
        if (raw.isBlank() || raw.length > MAX_URI_LENGTH || raw.any(::forbiddenCharacter) ||
            !StandardCharsets.UTF_8.newEncoder().canEncode(raw)) return null
        return runCatching {
            val uri = URI(raw)
            if (uri.rawFragment != null) return null
            when (uri.scheme?.lowercase(Locale.ROOT)) {
                "atlas" -> atlas(uri)
                "geo" -> geo(uri)
                else -> null
            }
        }.getOrNull()
    }

    private fun atlas(uri: URI): DeepLinkTarget? {
        if (uri.isOpaque || uri.rawUserInfo != null || uri.port != -1 ||
            (uri.rawPath != "" && uri.rawPath != "/")) return null
        val host = uri.host?.lowercase(Locale.ROOT) ?: return null
        val parameters = parameters(uri.rawQuery ?: return null) ?: return null
        return when (host) {
            "search" -> {
                if (parameters.keys != setOf("q")) return null
                val query = text(parameters["q"], MAX_QUERY_LENGTH) ?: return null
                DeepLinkTarget.Search(query)
            }
            "place", "navigate" -> {
                if (parameters.keys.any { it !in setOf("lat", "lon", "name") }) return null
                val coordinate = coordinate(parameters["lat"], parameters["lon"]) ?: return null
                val label = parameters["name"]?.let {
                    if (it.length > MAX_NAME_LENGTH) return null
                    if (it.isBlank()) null else text(it, MAX_NAME_LENGTH) ?: return null
                }
                DeepLinkTarget.Pin(coordinate, label, host == "navigate")
            }
            else -> null
        }
    }

    private fun geo(uri: URI): DeepLinkTarget? {
        if (!uri.isOpaque || uri.rawAuthority != null) return null
        val pieces = uri.rawSchemeSpecificPart.split('?', limit = 2)
        val base = coordinatePair.matchEntire(decode(pieces[0], plusAsSpace = false) ?: return null) ?: return null
        val baseCoordinate = coordinate(base.groupValues[1], base.groupValues[2]) ?: return null
        if (pieces.size == 1) return DeepLinkTarget.Pin(baseCoordinate, null)
        val parameters = parameters(pieces[1]) ?: return null
        if (parameters.keys != setOf("q")) return null
        val query = text(parameters["q"], MAX_QUERY_LENGTH) ?: return null
        val explicitCoordinate = coordinateWithLabel.matchEntire(query)
        if (explicitCoordinate != null) {
            val coordinate = coordinate(explicitCoordinate.groupValues[1], explicitCoordinate.groupValues[2]) ?: return null
            val label = explicitCoordinate.groupValues[3].let {
                if (it.length > MAX_NAME_LENGTH) return null
                if (it.isBlank()) null else text(it, MAX_NAME_LENGTH) ?: return null
            }
            return DeepLinkTarget.Pin(coordinate, label)
        }
        if (nonFiniteCoordinate.containsMatchIn(query)) return null
        return DeepLinkTarget.Search(query)
    }

    private fun coordinate(latitude: String?, longitude: String?): Coordinate? {
        if (latitude == null || longitude == null || latitude.length > 32 || longitude.length > 32) return null
        val latitudeText = latitude.trim()
        val longitudeText = longitude.trim()
        if (!numeric.matches(latitudeText) || !numeric.matches(longitudeText)) return null
        val lat = latitudeText.toDoubleOrNull() ?: return null
        val lon = longitudeText.toDoubleOrNull() ?: return null
        if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return Coordinate(lat, lon)
    }

    private fun text(value: String?, maxLength: Int): String? {
        if (value == null || value.length > maxLength || value.any(::forbiddenCharacter)) return null
        return value.trim().takeIf { it.isNotEmpty() }
    }

    private fun parameters(raw: String): Map<String, String>? {
        val parts = raw.split('&')
        if (parts.size > 8) return null
        val result = linkedMapOf<String, String>()
        for (part in parts) {
            val fields = part.split('=', limit = 2)
            if (fields.size != 2) return null
            val key = decode(fields[0]) ?: return null
            val value = decode(fields[1]) ?: return null
            if (key.isEmpty() || key.any(::forbiddenCharacter) || value.any(::forbiddenCharacter) || result.put(key, value) != null) return null
        }
        return result
    }

    private fun decode(raw: String, plusAsSpace: Boolean = true): String? {
        return runCatching {
            val output = StringBuilder()
            var index = 0
            while (index < raw.length) {
                when (raw[index]) {
                    '+' -> { output.append(if (plusAsSpace) ' ' else '+'); index++ }
                    '%' -> {
                        val bytes = ByteArrayOutputStream()
                        while (index < raw.length && raw[index] == '%') {
                            if (index + 2 >= raw.length) return null
                            val high = raw[index + 1].digitToIntOrNull(16) ?: return null
                            val low = raw[index + 2].digitToIntOrNull(16) ?: return null
                            bytes.write(high * 16 + low)
                            index += 3
                        }
                        val decoder = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                        output.append(decoder.decode(ByteBuffer.wrap(bytes.toByteArray())))
                    }
                    else -> output.append(raw[index++])
                }
            }
            output.toString().takeUnless { it.any(::forbiddenCharacter) }
        }.getOrNull()
    }

    private fun forbiddenCharacter(char: Char): Boolean = Character.isISOControl(char) ||
        char in '\u202A'..'\u202E' || char in '\u2066'..'\u2069' || char == '\uFFFD'
}
