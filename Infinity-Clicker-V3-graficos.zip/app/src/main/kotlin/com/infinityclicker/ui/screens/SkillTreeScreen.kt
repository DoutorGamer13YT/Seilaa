package com.infinityclicker.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastAny
import androidx.compose.ui.util.fastForEach
import com.infinityclicker.game.SkillPath
import com.infinityclicker.game.SkillTree
import com.infinityclicker.ui.SkillNodeUi
import com.infinityclicker.ui.components.bouncyClick
import com.infinityclicker.ui.components.drawPadlock
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------------------------
// Geometria da árvore (em dp). Cada rota é uma coluna; nós da mesma profundidade ficam lado a lado.
// ---------------------------------------------------------------------------------------------
private const val COL_W = 240f
private const val LANE = 64f
private const val ROW_H = 140f
private const val NODE = 72f
private const val TOP = 92f
private const val MIN_SCALE = 0.30f
private const val MAX_SCALE = 1.9f

private val pathColors = listOf(Neon.Cyan, Neon.Green, Neon.Pink, Neon.Gold, Neon.Violet)

/** Posição de cada nó, calculada uma única vez a partir das dependências (não depende do estado do jogo). */
private object TreeLayout {
    val centers: Map<String, Offset>
    val widthDp: Float = SkillPath.entries.size * COL_W
    val heightDp: Float

    init {
        val defs = SkillTree.all
        val depth = HashMap<String, Int>()
        defs.forEach { d -> depth[d.id] = (d.prerequisites.maxOfOrNull { depth[it] ?: 0 } ?: -1) + 1 }
        val map = HashMap<String, Offset>()
        defs.groupBy { it.path to (depth[it.id] ?: 0) }.forEach { (key, list) ->
            list.forEachIndexed { i, d ->
                val x = key.first.ordinal * COL_W + COL_W / 2f + (i - (list.size - 1) / 2f) * 2f * LANE
                val y = TOP + key.second * ROW_H + NODE / 2f
                map[d.id] = Offset(x, y)
            }
        }
        centers = map
        heightDp = TOP + (depth.values.maxOrNull() ?: 0) * ROW_H + NODE + 80f
    }

    fun columnCenter(path: Int) = path * COL_W + COL_W / 2f
}

/**
 * Câmera da árvore: posição e zoom ficam em estados lidos SÓ na camada gráfica (graphicsLayer),
 * então arrastar ou dar pinça não recompõe nada — a GPU só move a camada já desenhada.
 * Fica fora da tela para a posição sobreviver à troca de abas.
 */
@Stable
class SkillViewport {
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
    var selectedId by mutableStateOf<String?>(null)
    var viewW = 0f
    var viewH = 0f
    var placed = false

    fun clamp(d: Float) {
        val m = 48f * d
        val cw = TreeLayout.widthDp * d * scale
        val ch = TreeLayout.heightDp * d * scale
        tx = if (cw + 2 * m <= viewW) (viewW - cw) / 2f else tx.coerceIn(viewW - cw - m, m)
        ty = if (ch + 2 * m <= viewH) (viewH - ch) / 2f else ty.coerceIn(viewH - ch - m, m)
    }

    /** Pan e zoom ao mesmo tempo, em qualquer direção, ancorados no centro dos dedos. */
    fun transform(centroid: Offset, pan: Offset, zoom: Float, d: Float) {
        val ns = (scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
        val k = ns / scale
        tx = centroid.x - (centroid.x - tx) * k + pan.x
        ty = centroid.y - (centroid.y - ty) * k + pan.y
        scale = ns
        clamp(d)
    }

    fun focusPath(path: Int, scaleTo: Float, d: Float) {
        scale = scaleTo
        tx = viewW / 2f - TreeLayout.columnCenter(path) * d * scaleTo
        ty = 4f * d
        clamp(d)
    }
}

@Composable
fun SkillTreeScreen(
    nodes: List<SkillNodeUi>,
    prestigePoints: Int,
    viewport: SkillViewport,
    onBuy: (String) -> Unit
) {
    val d = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    val byId = remember(nodes) { nodes.associateBy { it.def.id } }
    val owned = remember(nodes) { nodes.count { it.level > 0 } }
    val fling = remember { arrayOfNulls<Job>(1) }
    val buyNow by rememberUpdatedState(onBuy)

    fun startFling(v: Offset) {
        fling[0]?.cancel()
        fling[0] = scope.launch {
            var vx = v.x
            var vy = v.y
            var last = androidx.compose.runtime.withFrameNanos { it }
            while (hypot(vx, vy) > 40f) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = now
                val ox = viewport.tx
                val oy = viewport.ty
                viewport.tx += vx * dt
                viewport.ty += vy * dt
                viewport.clamp(d)
                // Bateu na borda: zera a velocidade naquele eixo em vez de "grudar" arrastando.
                if (viewport.tx == ox) vx = 0f
                if (viewport.ty == oy) vy = 0f
                val decay = exp(-3.4f * dt)
                vx *= decay
                vy *= decay
            }
        }
    }

    fun flyTo(path: Int) {
        fling[0]?.cancel()
        fling[0] = scope.launch {
            val s0 = viewport.scale
            val x0 = viewport.tx
            val y0 = viewport.ty
            val s1 = 1f
            val x1 = viewport.viewW / 2f - TreeLayout.columnCenter(path) * d * s1
            val y1 = 4f * d
            Animatable(0f).animateTo(1f, tween(420, easing = FastOutSlowInEasing)) {
                val p = value
                viewport.scale = s0 + (s1 - s0) * p
                viewport.tx = x0 + (x1 - x0) * p
                viewport.ty = y0 + (y1 - y0) * p
                viewport.clamp(d)
            }
        }
    }

    fun tapAt(pos: Offset) {
        val cx = (pos.x - viewport.tx) / viewport.scale / d
        val cy = (pos.y - viewport.ty) / viewport.scale / d
        var best: String? = null
        var bestDist = NODE / 2f + 10f
        for (n in nodes) {
            val c = TreeLayout.centers[n.def.id] ?: continue
            val dist = hypot(cx - c.x, cy - c.y)
            if (dist <= bestDist) { bestDist = dist; best = n.def.id }
        }
        viewport.selectedId = best
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 68.dp, top = 8.dp, bottom = 8.dp)) {
            Text("Árvore de Habilidades", color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                "$prestigePoints PP disponíveis · $owned/${nodes.size} nós · arraste e use pinça",
                color = Neon.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SkillPath.entries.forEachIndexed { i, path ->
                val color = pathColors[i % pathColors.size]
                Box(
                    Modifier.weight(1f).height(32.dp).bouncyClick(onClick = { flyTo(i) })
                        .glass(CircleShape, tint = color, alpha = 0.18f, borderAlpha = 0.45f),
                    contentAlignment = Alignment.Center
                ) { Text(path.label, color = Neon.TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
            }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().clipToBounds()
                .onSizeChanged {
                    viewport.viewW = it.width.toFloat()
                    viewport.viewH = it.height.toFloat()
                    if (!viewport.placed && it.width > 0) {
                        viewport.placed = true
                        viewport.focusPath(0, 0.9f, d)
                    } else viewport.clamp(d)
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fling[0]?.cancel()
                        val tracker = VelocityTracker()
                        tracker.addPosition(down.uptimeMillis, down.position)
                        val slop = viewConfiguration.touchSlop
                        var zoomAcc = 1f
                        var panAcc = Offset.Zero
                        var past = false
                        var multi = false
                        var canceled: Boolean
                        do {
                            val event = awaitPointerEvent()
                            canceled = event.changes.fastAny { it.isConsumed }
                            if (!canceled) {
                                if (event.changes.size > 1) multi = true
                                val zoomChange = event.calculateZoom()
                                val panChange = event.calculatePan()
                                if (!past) {
                                    zoomAcc *= zoomChange
                                    panAcc += panChange
                                    val spread = event.calculateCentroidSize(useCurrent = false)
                                    if (abs(1f - zoomAcc) * spread > slop || panAcc.getDistance() > slop) past = true
                                }
                                if (past) {
                                    val centroid = event.calculateCentroid(useCurrent = false)
                                    if (zoomChange != 1f || panChange != Offset.Zero) viewport.transform(centroid, panChange, zoomChange, d)
                                    event.changes.fastForEach { if (it.positionChanged()) it.consume() }
                                }
                                event.changes.firstOrNull()?.let { tracker.addPosition(it.uptimeMillis, it.position) }
                            }
                        } while (!canceled && event.changes.fastAny { it.pressed })
                        if (past) {
                            if (!multi) {
                                val v = tracker.calculateVelocity()
                                startFling(Offset(v.x, v.y))
                            }
                        } else if (!canceled) tapAt(down.position)
                    }
                }
        ) {
            Box(
                Modifier.wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(TreeLayout.widthDp.dp, TreeLayout.heightDp.dp)
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        translationX = viewport.tx
                        translationY = viewport.ty
                        scaleX = viewport.scale
                        scaleY = viewport.scale
                    }
            ) {
                TreeEdges(nodes, byId)
                SkillPath.entries.forEachIndexed { i, path ->
                    val color = pathColors[i % pathColors.size]
                    val inPath = nodes.filter { it.def.path == path }
                    PathHeader(path.label, color, inPath.count { it.level > 0 }, inPath.size, Modifier.offset((TreeLayout.columnCenter(i) - 100f).dp, 12.dp))
                }
                val selected = viewport.selectedId
                nodes.forEach { node ->
                    val c = TreeLayout.centers[node.def.id] ?: return@forEach
                    val color = pathColors[node.def.path.ordinal % pathColors.size]
                    SkillBubble(node, color, node.def.id == selected, Modifier.offset((c.x - NODE / 2f).dp, (c.y - NODE / 2f).dp))
                    Text(
                        node.def.name,
                        color = if (node.requirementsMet || node.level > 0) Neon.TextPrimary else Neon.TextSecondary,
                        fontSize = 12.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 14.sp,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.offset((c.x - 55f).dp, (c.y + NODE / 2f + 4f).dp).width(110.dp)
                    )
                }
            }

            val sel = viewport.selectedId?.let { byId[it] }
            AnimatedVisibility(
                visible = sel != null,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(tween(160)) + slideInVertically(tween(220)) { it / 2 },
                exit = fadeOut(tween(110)) + slideOutVertically(tween(160)) { it / 2 }
            ) {
                // Mantém o último nó enquanto a animação de saída roda.
                val shown = remember { arrayOfNulls<SkillNodeUi>(1) }
                if (sel != null) shown[0] = sel
                shown[0]?.let { n ->
                    NodeDetail(n, pathColors[n.def.path.ordinal % pathColors.size], { buyNow(n.def.id) }, { viewport.selectedId = null })
                }
            }
        }
    }
}

@Composable
private fun TreeEdges(nodes: List<SkillNodeUi>, byId: Map<String, SkillNodeUi>) {
    Canvas(Modifier.fillMaxSize()) {
        val d = density
        for (n in nodes) {
            val to = TreeLayout.centers[n.def.id] ?: continue
            val color = pathColors[n.def.path.ordinal % pathColors.size]
            for (pre in n.def.prerequisites) {
                val from = TreeLayout.centers[pre] ?: continue
                val lit = (byId[pre]?.level ?: 0) > 0
                val a = Offset(from.x * d, from.y * d)
                val b = Offset(to.x * d, to.y * d)
                if (lit) drawLine(color.copy(alpha = 0.18f), a, b, 9.dp.toPx())
                drawLine(color.copy(alpha = if (lit) 0.90f else 0.22f), a, b, 3.dp.toPx())
            }
        }
    }
}

@Composable
private fun PathHeader(label: String, color: Color, owned: Int, total: Int, modifier: Modifier) {
    Column(
        modifier.width(200.dp).background(color.copy(alpha = 0.16f), RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("$owned de $total desbloqueadas", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Nó da árvore: só desenho simples (disco, anel de progresso) — sem vidro, sem animação por nó. */
@Composable
private fun SkillBubble(node: SkillNodeUi, pathColor: Color, selected: Boolean, modifier: Modifier) {
    val maxed = node.level >= node.def.maxLevel
    val owned = node.level > 0
    val accent = when {
        maxed -> Neon.Gold
        owned -> pathColor
        node.requirementsMet -> pathColor.copy(alpha = 0.85f)
        else -> Neon.TextSecondary.copy(alpha = 0.55f)
    }
    val fraction = node.level.toFloat() / node.def.maxLevel.coerceAtLeast(1)
    Box(modifier.size(NODE.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 6.dp.toPx()
            val inset = stroke / 2f
            val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
            drawCircle(Color(0xFF0A0E22).copy(alpha = 0.94f))
            if (owned) drawCircle(accent.copy(alpha = 0.16f))
            if (node.canBuy) drawCircle(accent.copy(alpha = 0.30f), radius = size.minDimension / 2f, style = Stroke(3.dp.toPx()))
            drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            if (fraction > 0f) drawArc(
                accent, -90f, 360f * fraction, false, Offset(inset, inset), arcSize,
                style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
            if (selected) drawCircle(Color.White.copy(alpha = 0.95f), radius = size.minDimension / 2f + 5.dp.toPx(), style = Stroke(2.dp.toPx()))
        }
        if (node.requirementsMet || owned) {
            Text("${node.level}", color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        } else {
            Canvas(Modifier.size(24.dp)) { drawPadlock(Neon.TextSecondary) }
        }
    }
}

@Composable
private fun NodeDetail(node: SkillNodeUi, pathColor: Color, onBuy: () -> Unit, onClose: () -> Unit) {
    val maxed = node.level >= node.def.maxLevel
    val owned = node.level > 0
    val accent = if (maxed) Neon.Gold else pathColor
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().padding(12.dp)
            .background(Color(0xFF0A0E22).copy(alpha = 0.90f), shape)
            .glass(shape, tint = accent, alpha = 0.22f, borderAlpha = 0.55f)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(node.def.name, color = Neon.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Nível ${node.level}/${node.def.maxLevel}", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Box(Modifier.size(36.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                com.infinityclicker.ui.components.GlyphIcon("✕", Neon.TextSecondary, 18.dp)
            }
        }
        Text(node.def.description, color = Neon.TextSecondary, fontSize = 13.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp))
        Text(
            if (owned) "Atual: ${node.def.effectText(node.level)}" else "Efeito: ${node.def.effectText(1)}",
            color = Neon.TextPrimary.copy(alpha = 0.9f), fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp)
        )
        if (owned && !maxed) Text("Próximo: ${node.def.effectText(node.level + 1)}", color = accent, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        val pill = RoundedCornerShape(50)
        when {
            maxed -> Text("Nível máximo", color = Neon.Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
            node.canBuy -> Box(
                Modifier.padding(top = 12.dp).fillMaxWidth().background(accent, pill).clickable(onClick = onBuy).padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text("Evoluir · ${node.def.costAt(node.level)} PP", color = Neon.Bg, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            node.requirementsMet -> Text("Precisa de ${node.def.costAt(node.level)} PP", color = Neon.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
            else -> Text("Desbloqueie a habilidade anterior", color = Neon.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
