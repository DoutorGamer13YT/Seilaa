# Cartografia e integração do mapa

## Implementação

`AtlasMap` usa MapLibre Native Android 11.8.0 em um `AndroidView` do Compose. Os estilos locais `app/src/main/assets/styles/atlas-light.json` e `atlas-dark.json` contêm 57 camadas cada, escritas para Atlas, no formato MapLibre Style Specification v8. O mapa é vetorial e interativo; os arquivos JSON definem a apresentação, não uma imagem estática nem um conjunto de tiles incluído no aplicativo.

As duas paletas mantêm a mesma hierarquia: fundo discreto, parques verdes, água azul, edifícios, ruas locais claras, rodovias em tom quente, passagens subterrâneas e pontes, ferrovias, limites e nomes. O tema escuro possui cores próprias. Rótulos usam Noto Sans Regular/Bold e preferem `name:pt`, com fallback para o nome original. Prédios em zoom alto usam alturas fornecidas pelo conjunto de dados; não são modelos detalhados da Apple.

Marcadores de resultados, destaque do lugar selecionado, rota azul com contorno, paradas, posição e círculo de precisão são camadas GeoJSON incrementais. Atualizações de posição e seleção não recarregam o estilo. O limite atual é de 250 marcadores de resultados simultâneos, além do selecionado; ainda não há agrupamento de marcadores.

## Fontes, créditos e licenças

| Recurso | Fonte e condições |
| --- | --- |
| TileJSON vetorial | `https://tiles.openfreemap.org/planet`, serviço público OpenFreeMap, esquema OpenMapTiles |
| Glyphs | `https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf`, Noto Sans |
| Dados geográficos | [OpenStreetMap](https://www.openstreetmap.org/copyright), ODbL |
| Esquema cartográfico | [OpenMapTiles](https://openmaptiles.org/), créditos e [licenças](https://github.com/openmaptiles/openmaptiles/blob/master/LICENSE.md) |
| Serviço de tiles | [OpenFreeMap](https://openfreemap.org/), [guia de uso](https://openfreemap.org/quick_start/) |
| Fontes | [Noto Sans, SIL Open Font License 1.1](https://openfontlicense.org/) |
| Motor | [MapLibre Native](https://github.com/maplibre/maplibre-native), BSD 2-Clause |

O estilo público [Liberty no repositório OpenFreeMap](https://github.com/hyperknot/openfreemap-styles/blob/main/styles/liberty/style.json) foi inspecionado para confirmar os endpoints, o esquema dos dados e os nomes das fontes. Seus 111 layers não foram importados para Atlas. As regras, cores e organização das 57 camadas Atlas foram escritas separadamente. As [licenças do repositório de estilos](https://github.com/hyperknot/openfreemap-styles/blob/main/LICENSE.md) documentam também a origem das fontes públicas.

Os estilos incluem links de atribuição para OpenFreeMap, OpenMapTiles e colaboradores do OpenStreetMap. O controle de atribuição nativo permanece habilitado e é deslocado para fora da região ocupada pelo painel; os créditos também devem permanecer na tela de informações do aplicativo. Não são usados tiles, fontes SF, sprites ou recursos privados da Apple. A referência visual não representa afiliação com a Apple.

Não há chave necessária para a configuração OpenFreeMap atual. A disponibilidade do serviço público e seus termos devem ser acompanhados antes de publicar o aplicativo. Um serviço compatível com o esquema OpenMapTiles pode substituir `sources.openmaptiles.url` nos dois arquivos. Ao trocar de serviço, atualizar atribuição, endpoints de fontes, termos, limites e configuração de credenciais. Nenhuma integração MapTiler é ativada por estes estilos.

## Contrato com a interface

```kotlin
AtlasMap(
    modifier = modifier,
    dark = dark,
    places = places,
    selectedPlace = selectedPlace,
    route = route,
    location = location,
    cameraRequest = cameraRequest,
    bottomPaddingDp = bottomPaddingDp,
    reduceMotion = reduceMotion,
    onPlaceClick = onPlaceClick,
    onMapLongPress = onMapLongPress,
    onCenterChanged = onCenterChanged,
    onMapError = onMapError,
    onUserGesture = onUserGesture, // opcional
    leftPaddingDp = leftPaddingDp, // opcional, 0 por padrão
)
```

- `CameraRequest` aplica um movimento por `id` novo. Aceita alvo, pontos para enquadrar, zoom, orientação e inclinação. A animação dura 700 ms; `reduceMotion` aplica a mudança sem animação.
- `onUserGesture` é chamado quando o SDK informa movimento de câmera causado por gesto do usuário. A interface pode suspender o acompanhamento GPS nesse evento. Animações programáticas não acionam esse callback.
- `onCenterChanged` é emitido ao terminar movimento, quando o centro mudou ao menos 5 metros desde o último evento. O callback não executa pesquisa de rede; essa decisão é da interface/repositório.
- `leftPaddingDp` e `bottomPaddingDp` são convertidos para pixels e aplicados ao SDK e ao controle de atribuição. O espaço é limitado para manter uma área mínima utilizável. Em paisagem, o painel lateral pode passar sua largura em `leftPaddingDp` e usar `bottomPaddingDp = 0f`.
- `onMapError` recebe uma mensagem de falha e `null` quando o mapa termina de carregar. Depois de falha, um novo `CameraRequest.id` também permite tentar carregar novamente. Recomposições com o mesmo pedido não geram repetição contínua.
- Long press produz uma coordenada validada; tocar um marcador devolve o `Place` correspondente. Resultados textuais na interface continuam sendo a alternativa acessível ao mapa gráfico.

O ciclo `onCreate/onStart/onResume/onPause/onStop/onDestroy` acompanha o lifecycle da composição/atividade e protege chamadas duplicadas. Sinais de pouca memória são encaminhados ao MapView. Latitude, longitude, zoom, orientação e inclinação são preservados com `rememberSaveable`. O mapa não solicita localização por conta própria.

## Rede, privacidade e offline

Os pedidos de tiles e glyphs usam HTTPS. Consultas cartográficas revelam ao provedor os tiles/região visualizados e o endereço IP da conexão. O módulo de mapa não registra coordenadas em logs, não adiciona analytics e não coleta GPS. O provedor de pesquisa e o de rotas são documentados separadamente.

Estilo local, preferências e lugares persistidos podem continuar disponíveis sem internet; tiles só aparecem se já estiverem no cache do SDK. Esse cache é oportunista: não há download gerenciado de regiões, garantia de mapas offline ou navegação offline neste módulo.

## Verificação registrada

- Leitura dos estilos e das licenças oficiais via conector GitHub: realizada.
- Conferência das APIs utilizadas contra o código-fonte oficial MapLibre `android-v11.8.0` para MapView, MapLibreMap, UiSettings, GeoJsonSource e CameraUpdateFactory: realizada por inspeção estática.
- Validação Python dos dois JSON: aprovada para parse, versão 8, IDs únicos, 57 camadas por tema, source/source-layer esperados, endpoints HTTPS, fontes Noto e paletas distintas. A primeira execução continha uma expectativa incorreta de 10 camadas de texto; a lista real tem 9. A verificação foi corrigida para comparar os nomes das camadas e executada novamente com sucesso.
- Fetch direto de `https://tiles.openfreemap.org/styles/liberty`: indisponível no ambiente; o conteúdo equivalente no repositório oficial foi inspecionado. Renderização de tiles e glyphs no aparelho: não verificada.
- Validação integral pelo parser nativo, compilação, emulador, capturas de tela, contraste em hardware e comparação visual com Apple Maps: não realizadas. A instrução mais recente do usuário impede compilar o aplicativo nesta etapa.

Não há evidência de execução do APK ou de equivalência visual exata. A próxima validação, quando autorizada, deve cobrir carregamento real em ambos os temas, gestos, troca de tema durante carga, giro de tela, enquadramento com painel lateral/inferior, falha de rede e recuperação, atribuição e TalkBack.
