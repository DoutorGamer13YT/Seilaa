# Atlas para Android

Aplicativo nativo em Kotlin e Jetpack Compose, com mapa vetorial MapLibre e interface própria inspirada na linguagem visual do Apple Maps/iOS 27. Não é um produto Apple e não utiliza tiles, fontes ou ícones proprietários da Apple.

**Estado atual:** código em desenvolvimento, com os fluxos principais conectados. O aplicativo ainda não foi compilado nem executado em dispositivo. Não há APK disponível. A compilação foi suspensa por instrução do usuário; nenhum teste Kotlin/Android é apresentado como aprovado.

## Fluxos implementados no código

- Mapa vetorial interativo, estilos claros/escuros, posição e precisão, marcadores selecionáveis, inclinação, orientação e enquadramento de rotas.
- Pesquisa Photon com debounce/cancelamento, resultados reais e histórico; descoberta por 20 categorias via Overpass.
- Ficha com dados disponíveis do provedor, favoritos, compartilhar, copiar, telefone, site, Casa e Trabalho.
- Biblioteca Room com listas múltiplas, reordenação, atalhos e persistência; preferências em DataStore.
- Planejamento de rotas com origem, destino, até seis paradas, inversão, alternativas e manobras fornecidas pelo serviço.
- Navegação com serviço de localização, notificação, voz TTS, GPS temporariamente indisponível e recálculo.
- Painel com quatro posições, tema do sistema/claro/escuro, unidades, movimento reduzido, feedback háptico e links `geo:`/`atlas://` validados.

Essa lista descreve a implementação presente, não uma certificação de funcionamento no aparelho. Validação do SDK, gestos, mapas, GPS e acessibilidade requer compilação e execução futuras.

## Provedores

| Função | Fonte | Configuração |
| --- | --- | --- |
| Cartografia | OpenFreeMap / OpenMapTiles / OpenStreetMap | Estilos em `app/src/main/assets/styles/` |
| Endereços | Photon | `PHOTON_BASE_URL` |
| Categorias e detalhes | Overpass / OpenStreetMap | `OVERPASS_URL` |
| Rotas de carro | OSRM | `OSRM_BASE_URL` |
| Rotas com outros modos | OpenRouteService, opcional | `ORS_BASE_URL`, `ORS_API_KEY` |

Por padrão, somente carro é oferecido para rotas. Caminhada/bicicleta dependem da configuração real do OpenRouteService. Transporte público, trânsito ao vivo, avaliações, imagens comerciais e navegação offline não são anunciados como recursos disponíveis.

Os servidores públicos são adequados para experimentação limitada conforme suas políticas, sem garantia operacional de produção. Para distribuição ampla, configure instâncias próprias ou serviços contratados. Consulte [provedores e privacidade](docs/PROVIDERS.md) e [fontes cartográficas](docs/MAP_STYLE.md). Chaves inseridas no APK não são segredos.

## Estrutura

`core` contém modelos e cálculos; `network`, provedores e conectividade; `data`, Room/DataStore; `location`, GPS e serviço de navegação; `map`, integração MapLibre; `ui`, ViewModel, telas, componentes e tokens. A aplicação usa um contêiner explícito de dependências, sem adicionar framework de injeção desnecessário.

## Retomada e ferramentas

O código dos seis agentes foi preservado em `/workspace/checkpoints/atlas-before-skills-20261011T211423Z.tar.gz`, com inventário SHA-256 correspondente. As skills solicitadas estão em `.agents/skills/`; sua origem e integridade estão documentadas em [SKILLS_INSTALLATION.md](docs/SKILLS_INSTALLATION.md).

O SDK Android e o Gradle Wrapper ainda precisam ser preparados. O procedimento real, as versões e os comandos futuros estão em [BUILD.md](docs/BUILD.md). Essa documentação não dispara build automaticamente.

## Documentação de estado

- [Progresso e pendências](DEVELOPMENT_STATUS.md)
- [Design e limites da referência visual](docs/DESIGN.md)
- [Persistência e testes previstos](docs/PERSISTENCE.md)
- [Localização e navegação](docs/LOCATION.md)
- [Plano de validação](docs/TESTING.md)

Favoritos, listas, atalhos e configurações continuam locais sem internet. Cache do mapa é oportunista; não existe download explícito de regiões nem garantia de rotas offline. Não há rastreamento iniciado após boot ou reinício oculto da navegação.
