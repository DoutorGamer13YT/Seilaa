package dev.atlas.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.ThemeMode

@Immutable
data class AtlasColors(
    val background: Color, val surface: Color, val glass: Color,
    val grouped: Color, val secondarySurface: Color, val text: Color,
    val secondaryText: Color, val separator: Color, val glassBorder: Color,
    val accent: Color, val positive: Color, val danger: Color, val isDark: Boolean,
)

private val LightPalette = AtlasColors(
    background = Color(0xFFF2F2F7), surface = Color(0xFFFCFCFD),
    glass = Color(0xF2FCFCFD), grouped = Color(0xFFF2F2F7),
    secondarySurface = Color(0xFFE9E9EE), text = Color(0xFF19191C),
    secondaryText = Color(0xFF636369), separator = Color(0x243C3C43),
    glassBorder = Color(0xCCFFFFFF), accent = Color(0xFF007AFF),
    positive = Color(0xFF248A3D), danger = Color(0xFFD70015), isDark = false,
)
private val DarkPalette = AtlasColors(
    background = Color(0xFF111113), surface = Color(0xFF252528),
    glass = Color(0xF229292D), grouped = Color(0xFF1C1C1E),
    secondarySurface = Color(0xFF38383C), text = Color(0xFFF5F5F7),
    secondaryText = Color(0xFFB0B0B8), separator = Color(0x40545458),
    glassBorder = Color(0x407D7D84), accent = Color(0xFF64A8FF),
    positive = Color(0xFF57D97D), danger = Color(0xFFFF6961), isDark = true,
)
val LocalAtlasColors = staticCompositionLocalOf { LightPalette }
val LocalAtlasReduceMotion = staticCompositionLocalOf { false }

object AtlasDimens {
    val ScreenMargin = 16.dp
    val SheetRadius = 30.dp
    val CardRadius = 20.dp
    val ControlRadius = 25.dp
    val SearchRadius = 23.dp
    val SearchHeight = 52.dp
    val ControlSize = 50.dp
    val IconSize = 23.dp
    val TouchTarget = 48.dp
    val RowMinHeight = 76.dp
    val SmallGap = 8.dp
    val MediumGap = 12.dp
    val LargeGap = 20.dp
    val FloatingElevation = 7.dp
    const val ShortAnimationMillis = 180
    const val PanelDamping = 0.88f
    const val PanelStiffness = 420f
}

private val AtlasTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 37.sp, letterSpacing = (-0.7).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 27.sp, lineHeight = 33.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 29.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 23.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 17.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 15.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp),
)

@Composable
fun AtlasTheme(mode: ThemeMode = ThemeMode.SYSTEM, reduceMotion: Boolean = false, content: @Composable () -> Unit) {
    val dark = when (mode) { ThemeMode.SYSTEM -> isSystemInDarkTheme(); ThemeMode.DARK -> true; ThemeMode.LIGHT -> false }
    val palette = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) darkColorScheme(
        primary = palette.accent, onPrimary = Color(0xFF041C38), background = palette.background,
        surface = palette.surface, onSurface = palette.text, onBackground = palette.text,
        surfaceVariant = palette.secondarySurface, onSurfaceVariant = palette.secondaryText,
        outline = palette.separator, error = palette.danger,
    ) else lightColorScheme(
        primary = palette.accent, onPrimary = Color.White, background = palette.background,
        surface = palette.surface, onSurface = palette.text, onBackground = palette.text,
        surfaceVariant = palette.secondarySurface, onSurfaceVariant = palette.secondaryText,
        outline = palette.separator, error = palette.danger,
    )
    CompositionLocalProvider(LocalAtlasColors provides palette, LocalAtlasReduceMotion provides reduceMotion) {
        MaterialTheme(colorScheme = scheme, typography = AtlasTypography, content = content)
    }
}
