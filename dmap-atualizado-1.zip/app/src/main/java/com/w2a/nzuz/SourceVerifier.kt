package com.w2a.nzuz

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URI
import java.net.HttpURLConnection

object SourceVerifier {
    suspend fun verify(url: String) = withContext(Dispatchers.IO) {
        val style = fetch(url)
        require(style.optInt("version") == 8) { "A URL deve retornar um estilo MapLibre versão 8." }
        val sources = style.optJSONObject("sources") ?: error("Estilo sem fontes.")
        require(style.optJSONArray("layers")?.length()?.let { it > 0 } == true) { "Estilo sem camadas." }
        require(sources.length() in 1..8) { "Use de 1 a 8 fontes neste perfil offline." }
        var tiled = false
        sources.keys().forEach { id ->
            val source = sources.getJSONObject(id)
            val type = source.optString("type")
            require(type == "vector" || type == "raster" || type == "raster-dem") { "Fonte $id não é uma pirâmide de tiles suportada." }
            val tileJson = if (source.has("url")) {
                val address = source.getString("url")
                validateAddress(address)
                fetch(address)
            } else source
            val tiles = tileJson.optJSONArray("tiles") ?: error("Fonte $id sem tiles.")
            require(tiles.length() in 1..4) { "Fonte $id sem endpoint válido." }
            for (i in 0 until tiles.length()) validateAddress(tiles.getString(i))
            tiled = true
        }
        require(tiled) { "Nenhuma fonte de tiles encontrada." }
        if (style.has("glyphs")) validateAddress(style.getString("glyphs"))
        if (style.has("sprite")) {
            require(style.get("sprite") is String) { "Use um estilo com uma única URL de sprites." }
            validateAddress(style.getString("sprite"))
        }
        val layers = style.getJSONArray("layers")
        for (i in 0 until layers.length()) {
            val layout = layers.getJSONObject(i).optJSONObject("layout")
            if (layout?.has("text-field") == true) require(style.has("glyphs")) { "O estilo tem textos, mas não fornece fontes offline." }
        }
    }

    private fun validateAddress(url: String) {
        val clean = url.replace(Regex("\\{[^}]+}"), "0")
        val uri = URI(clean)
        val host = uri.host.orEmpty().lowercase()
        require(uri.scheme == "https" && host.isNotBlank() && uri.userInfo == null) { "Todos os recursos precisam ter URLs HTTPS absolutas." }
        require(host != "apple.com" && !host.endsWith(".apple.com") && host != "openstreetmap.org" && !host.endsWith(".openstreetmap.org")) {
            "O estilo referencia um servidor não permitido para download offline."
        }
    }

    private fun fetch(url: String): JSONObject {
        validateAddress(url)
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 15_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("User-Agent", "Dmap/2.0 (Android; offline source validation)")
            require(connection.responseCode == 200) { "A fonte respondeu HTTP ${connection.responseCode}. Use a URL HTTPS final, sem redirecionamento." }
            val bytes = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (output.size() <= 2_097_152) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            require(bytes.size <= 2_097_152) { "Estilo ou TileJSON excede 2 MB." }
            return JSONObject(String(bytes, Charsets.UTF_8))
        } finally { connection.disconnect() }
    }
}
