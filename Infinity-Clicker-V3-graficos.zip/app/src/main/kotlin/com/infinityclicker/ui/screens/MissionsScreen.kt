package com.infinityclicker.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.layout.width
import com.infinityclicker.ui.components.GlassChip
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.LocalMotionEnabled
import com.infinityclicker.ui.components.enterAnimation
import com.infinityclicker.ui.components.phaseOf
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.infinityclicker.ui.components.GlowBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.game.AchievementCategory
import com.infinityclicker.game.Rarity
import com.infinityclicker.ui.AchievementUi
import com.infinityclicker.ui.ChallengeUi
import com.infinityclicker.ui.DailyMissionUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.color

@Composable
fun MissionsScreen(
    ui: UiState,
    onClaimDaily: (Int) -> Unit,
    onClaimLogin: () -> Unit,
    onClaimAchievement: (String) -> Unit,
    onStartChallenge: (String) -> Unit,
    onAbandonChallenge: () -> Unit
) {
    val sci = ui.settings.scientificNotation
    val f: (com.infinityclicker.core.BigNum) -> String = androidx.compose.runtime.remember(sci) { { n: com.infinityclicker.core.BigNum -> NumberFormatter.format(n, sci) } }
    var categoryFilter by rememberSaveable { mutableIntStateOf(0) }
    var rarityFilter by rememberSaveable { mutableIntStateOf(0) }
    val categoryOptions = remember { listOf("Todas") + AchievementCategory.entries.map { it.label } }
    val rarityOptions = remember { listOf("Todas") + Rarity.entries.map { it.label } }
    // Ordem: resgatáveis no topo, depois as em andamento/bloqueadas, e as já resgatadas no final.
    // sortedBy é estável, então dentro de cada grupo a ordem original é mantida.
    val filteredAchievements = remember(ui.achievements, categoryFilter, rarityFilter) {
        ui.achievements.filter { row ->
            (categoryFilter == 0 || row.def.category == AchievementCategory.entries[categoryFilter - 1]) &&
                (rarityFilter == 0 || row.def.rarity == Rarity.entries[rarityFilter - 1])
        }.sortedBy { row -> if (row.canClaim) 0 else if (row.claimed) 2 else 1 }
    }
    val claimableCount = remember(ui.achievements) { ui.achievements.count { it.canClaim } }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Column(Modifier.padding(end = 52.dp).enterAnimation(0)) {
                Text("Missões", color = Neon.TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Objetivos locais são resetados por dia e cada recompensa é registrada uma única vez.", color = Neon.TextSecondary, fontSize = 13.sp)
            }
        }
        if (!ui.timeSynced) item {
            GlassCard(Modifier.fillMaxWidth().enterAnimation(1), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
                Text("Hora automática desligada", color = Neon.Pink, fontWeight = FontWeight.Bold)
                Text(
                    "O jogo usa a hora do celular e só confia nela com \"Data e hora automáticas\" e \"Fuso horário automático\" ligados " +
                        "(Ajustes do Android › Data e hora). Enquanto estiverem desligados, missões diárias, login e ganho offline ficam pausados.",
                    color = Neon.TextSecondary, fontSize = 12.sp
                )
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().enterAnimation(1), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
                Text("Galeria de conquistas", color = Neon.Violet, fontWeight = FontWeight.Bold)
                Text("${ui.stats.achievementsClaimed}/${ui.achievements.size} resgatadas · ${ui.stats.achievementsUnlocked} desbloqueadas", color = Neon.TextSecondary, fontSize = 12.sp)
                GlowBar(
                    progress = { ui.stats.completionFraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                    color = Neon.Violet, trackColor = Color.White.copy(alpha = .12f)
                )
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().enterAnimation(2), tint = Neon.Gold, alpha = ui.settings.panelOpacity) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Sequência de login", color = Neon.Gold, fontWeight = FontWeight.Bold)
                        Text("Dia ${ui.loginStreak.coerceAtLeast(1)} · recompensa diária", color = Neon.TextSecondary, fontSize = 12.sp)
                    }
                    BuyButton(
                        if (ui.loginReward.isZero) "Coletada" else "+${f(ui.loginReward)}", null, !ui.loginReward.isZero,
                        Neon.Gold, onClaimLogin, Modifier.width(104.dp), height = 38.dp, compact = true
                    )
                }
            }
        }
        item { Text("Diárias", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp)) }
        itemsIndexed(ui.dailyMissions, key = { _, row -> row.def.id }, contentType = { _, _ -> "daily" }) { index, row ->
            DailyCard(row, f, ui.settings.panelOpacity, androidx.compose.runtime.remember(index) { Modifier.enterAnimation(index) }) { onClaimDaily(index) }
        }
        item { Text("Desafios cósmicos", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
        itemsIndexed(ui.challenges, key = { _, row -> row.def.id }, contentType = { _, _ -> "challenge" }) { index, row ->
            ChallengeCard(row, ui.settings.panelOpacity, androidx.compose.runtime.remember(index) { Modifier.enterAnimation(index) }, onStartChallenge, onAbandonChallenge)
        }
        item {
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Conquistas", color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (claimableCount > 0) Text(
                    "$claimableCount para resgatar", color = Neon.Bg, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.background(Neon.Green, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
        }
        item {
            FilterStrip(categoryOptions, categoryFilter) { categoryFilter = it }
            FilterStrip(rarityOptions, rarityFilter, tintByIndex = true) { rarityFilter = it }
        }
        itemsIndexed(filteredAchievements, key = { _, row -> row.def.id }, contentType = { _, _ -> "achievement" }) { index, row ->
            AchievementCard(row, ui.settings.panelOpacity, Modifier.animateItem().then(androidx.compose.runtime.remember(index) { Modifier.enterAnimation(index) })) { onClaimAchievement(row.def.id) }
        }
    }
}

@Composable
private fun DailyCard(row: DailyMissionUi, f: (com.infinityclicker.core.BigNum) -> String, alpha: Float, modifier: Modifier, onClaim: () -> Unit) {
    val fraction = (row.progress.toFloat() / row.def.target).coerceIn(0f, 1f)
    GlassCard(modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(row.def.title, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text("${row.progress}/${row.def.target}", color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text("+${f(row.def.reward)}", color = Neon.Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        GlowBar(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
            color = Neon.Cyan, trackColor = Color.White.copy(alpha = 0.12f)
        )
        BuyButton(
            if (row.claimed) "Recompensa coletada" else if (row.canClaim) "Coletar recompensa" else "Progresso insuficiente",
            null, row.canClaim, Neon.Cyan, onClaim, Modifier.fillMaxWidth().padding(top = 8.dp), progress = fraction, height = 42.dp
        )
    }
}

@Composable
private fun ChallengeCard(row: ChallengeUi, alpha: Float, modifier: Modifier, onStart: (String) -> Unit, onAbandon: () -> Unit) {
    val fraction = (row.progress.toFloat() / row.def.target.toFloat()).coerceIn(0f, 1f)
    GlassCard(modifier.fillMaxWidth(), tint = if (row.active) Neon.Pink else Neon.Gold, alpha = alpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(row.def.name, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text(row.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
            }
            Text("${row.wins}×", color = Neon.Gold, fontWeight = FontWeight.Bold)
        }
        if (row.active) {
            Text("${row.progress}/${row.def.target} · ${NumberFormatter.duration(row.remainingMs)}", color = Neon.Pink, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            GlowBar(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), color = Neon.Pink, trackColor = Color.White.copy(alpha = .12f))
        }
        BuyButton(
            if (row.active) "Abandonar desafio" else if (row.available) "Iniciar desafio" else "Indisponível",
            null, row.active || row.available, if (row.active) Neon.Pink else Neon.Gold,
            if (row.active) onAbandon else { { onStart(row.def.id) } },
            Modifier.fillMaxWidth().padding(top = 8.dp), height = 42.dp
        )
    }
}

@Composable
private fun FilterStrip(options: List<String>, selected: Int, tintByIndex: Boolean = false, onSelect: (Int) -> Unit) {
    LazyRow(Modifier.padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(options) { index, label ->
            val tint = if (tintByIndex && index > 0) Rarity.entries[index - 1].color() else Neon.Cyan
            GlassChip(
                label, selected = index == selected, tint = tint, onClick = { onSelect(index) }, idleTint = tint,
                fontSize = 11.sp, fontWeight = FontWeight.Normal, horizontalPadding = 12.dp, verticalPadding = 7.dp
            )
        }
    }
}

@Composable
private fun AchievementCard(row: AchievementUi, alpha: Float, modifier: Modifier, onClaim: () -> Unit) {
    val secretLocked = row.def.secret && !row.unlocked
    val tint = when {
        row.claimed -> Neon.Green
        secretLocked -> Neon.TextSecondary
        else -> row.def.rarity.color()
    }
    // Resgatável: cartão mais brilhante. Já resgatada: apagada, pois já foi.
    val cardAlpha = if (row.canClaim) (alpha + 0.10f).coerceAtMost(0.34f) else if (row.claimed) alpha * 0.6f else alpha
    GlassCard(modifier.fillMaxWidth(), tint = tint, alpha = cardAlpha) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            AchievementEmblem(tint = tint, active = row.canClaim, secret = secretLocked, claimed = row.claimed)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(if (secretLocked) "Conquista secreta" else row.def.title, color = Neon.TextPrimary, fontWeight = FontWeight.Bold)
                Text(if (secretLocked) "????" else row.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
                if (!secretLocked) {
                    Text(row.def.rarity.label + " · " + row.progress.label, color = tint, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    GlowBar(progress = { row.progress.fraction }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = tint, trackColor = Color.White.copy(alpha = .12f))
                }
            }
            BuyButton(
                if (row.claimed) "Obtida" else if (row.canClaim) "+${row.def.reward} PP" else "Bloqueada",
                null, row.canClaim, tint, onClaim, Modifier.padding(start = 8.dp).width(98.dp), height = 38.dp, compact = true
            )
        }
    }
}

/**
 * Medalha vetorial para tornar cada conquista reconhecível sem carregar imagens adicionais.
 * Só as resgatáveis animam (órbita e pulso pelo relógio do jogo, que respeita o limite de FPS); as demais ficam
 * paradas e não custam quadro nenhum. Ao resgatar, uma onda de anel e faíscas se abre uma vez.
 */
@Composable
private fun AchievementEmblem(tint: Color, active: Boolean, secret: Boolean, claimed: Boolean) {
    val ticker = LocalFrameTicker.current
    val motion = LocalMotionEnabled.current
    val burst = remember { Animatable(0f) }
    val wasClaimed = remember { claimed }
    LaunchedEffect(claimed) {
        if (claimed && !wasClaimed && motion) {
            burst.snapTo(0f)
            burst.animateTo(1f, tween(760, easing = FastOutSlowInEasing))
        }
    }
    val glowBrush = remember(tint) { Brush.radialGradient(listOf(tint.copy(alpha = 0.33f), Color.Transparent), Offset.Zero, 1000f) }
    Canvas(Modifier.size(44.dp)) {
        val c = center
        val r = size.minDimension * 0.5f
        val animate = active && motion
        val nanos = if (animate) ticker.value else 0L
        val rotation = if (animate) phaseOf(nanos, 5_800L) * (180f / PI.toFloat()) else 0f
        val pulse = if (animate) 0.96f + 0.12f * sin(phaseOf(nanos, 1_250L)) else 0.84f
        withTransform({ translate(c.x, c.y); scale(r / 1000f, r / 1000f, Offset.Zero) }) { drawCircle(glowBrush, 1000f, Offset.Zero, alpha = pulse) }
        if (active) rotate(rotation, c) {
            drawArc(
                tint.copy(alpha = 0.72f), 12f, 92f, false,
                Offset(c.x - r * .86f, c.y - r * .86f), androidx.compose.ui.geometry.Size(r * 1.72f, r * 1.72f),
                style = Stroke(width = 1.7f)
            )
            drawArc(
                Color.White.copy(alpha = 0.52f), 192f, 54f, false,
                Offset(c.x - r * .72f, c.y - r * .72f), androidx.compose.ui.geometry.Size(r * 1.44f, r * 1.44f),
                style = Stroke(width = 1.2f)
            )
        }
        drawCircle(Color(0xFF0A0D1D).copy(alpha = 0.78f), r * .57f, c)
        drawCircle(Color.White.copy(alpha = 0.44f), r * .57f, c, style = Stroke(width = 1.2f))
        if (secret) {
            drawCircle(tint.copy(alpha = 0.78f), r * .13f, c)
            drawLine(tint.copy(alpha = 0.78f), Offset(c.x, c.y - r * .33f), Offset(c.x, c.y + r * .33f), 2.1f)
        } else {
            drawCircle(tint.copy(alpha = 0.95f), r * .18f, c)
            drawLine(Color.White.copy(alpha = 0.82f), Offset(c.x - r * .30f, c.y), Offset(c.x + r * .30f, c.y), 1.35f)
            drawLine(Color.White.copy(alpha = 0.82f), Offset(c.x, c.y - r * .30f), Offset(c.x, c.y + r * .30f), 1.35f)
        }
        val b = burst.value
        if (b > 0f && b < 1f) {
            val e = 1f - (1f - b) * (1f - b)
            val fade = 1f - b
            drawCircle(tint.copy(alpha = 0.55f * fade), r * (0.6f + 0.75f * e), c, style = Stroke(width = 3f * fade + 1f))
            drawCircle(Color.White.copy(alpha = 0.35f * fade), r * (0.45f + 0.55f * e), c, style = Stroke(width = 1.4f))
            for (i in 0 until 8) {
                val a = i * (PI.toFloat() / 4f)
                val d0 = r * (0.70f + 0.30f * e)
                val d1 = r * (0.80f + 0.60f * e)
                drawLine(
                    tint.copy(alpha = 0.85f * fade),
                    Offset(c.x + cos(a) * d0, c.y + sin(a) * d0), Offset(c.x + cos(a) * d1, c.y + sin(a) * d1),
                    2f, StrokeCap.Round
                )
            }
        }
    }
}
