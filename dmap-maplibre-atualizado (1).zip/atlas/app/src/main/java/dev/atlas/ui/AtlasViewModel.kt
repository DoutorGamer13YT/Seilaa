package dev.atlas.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import dev.atlas.AtlasApplication
import dev.atlas.core.*
import dev.atlas.location.CompassSensor
import dev.atlas.location.LocationTracker
import dev.atlas.location.NavigationSession
import dev.atlas.map.CameraRequest
import dev.atlas.network.ConnectivityObserver
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

enum class PanelContent { EXPLORE, SEARCH, PLACE, ROUTE }
enum class SearchTarget { PLACE, ORIGIN, DESTINATION, STOP }
data class MapScreenState(
    val panel: PanelContent = PanelContent.EXPLORE,
    val query: String = "", val results: List<Place> = emptyList(),
    val searching: Boolean = false, val searched: Boolean = false,
    val error: String? = null, val selectedPlace: Place? = null,
    val loadingDetails: Boolean = false, val detailError: String? = null,
    val category: PlaceCategory? = null, val areaMoved: Boolean = false,
    val center: Coordinate = Coordinate(-23.5505, -46.6333),
    val origin: Place? = null, val destination: Place? = null,
    val stops: List<Place> = emptyList(), val routes: List<Route> = emptyList(),
    val routeIndex: Int = 0, val mode: TransportMode = TransportMode.CAR,
    val routing: Boolean = false, val routeError: String? = null,
    val searchTarget: SearchTarget = SearchTarget.PLACE,
    val camera: CameraRequest? = null,
) { val route: Route? get() = routes.getOrNull(routeIndex) }

class AtlasViewModel(private val app: AtlasApplication, private val saved: SavedStateHandle) : ViewModel() {
    private val mutable = MutableStateFlow(MapScreenState(center = restoredCenter()))
    val state = mutable.asStateFlow()
    private val local = app.local
    val favorites = local.favorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val lists = local.lists.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val history = local.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val shortcuts = local.shortcuts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings = local.settings.stateIn(viewModelScope, SharingStarted.Eagerly, local.settingsSnapshot())
    val online = ConnectivityObserver(app, viewModelScope).online
    val location = LocationTracker(app)
    val compass = CompassSensor(app)
    private val mutableOrientation = MutableStateFlow(restoredOrientation())
    val orientation = mutableOrientation.asStateFlow()
    private val mutableNavigationNorthUp = MutableStateFlow(false)
    val navigationNorthUp = mutableNavigationNorthUp.asStateFlow()
    private var compassWarned = false
    val navigation = NavigationSession.state
    private val mutableMapOpenRequests = MutableStateFlow(0L)
    val mapOpenRequests = mutableMapOpenRequests.asStateFlow()
    val supportedModes = app.routing.supportedModes
    private val mutableMessages = Channel<String>(Channel.BUFFERED)
    val messages = mutableMessages.receiveAsFlow()
    private var searchJob: Job? = null
    private var detailsJob: Job? = null
    private var routeJob: Job? = null
    private var cameraId = 0L
    private var lastNearby = 0L
    private var searchVersion = 0L
    private var routeVersion = 0L
    private var lifecycleStarted = false
    private var mapVisible = true
    private var lastSearchCenter: Coordinate? = null
    private var userMovedMap = false
    private var awaitingCenter = false
    private var pendingLink: DeepLinkTarget? = null
    private var wasNavigating = false
    var followNavigation = true
        private set

    init {
        viewModelScope.launch { local.errors.collect { mutableMessages.send(it.message) } }
        viewModelScope.launch {
            location.state.collect { fixState ->
                fixState.fix?.let { compass.setLocation(it.coordinate) }
                if (awaitingCenter && !fixState.isStale && fixState.fix != null) {
                    awaitingCenter = false
                    focus(fixState.fix.coordinate, 15.5)
                }
            }
        }
        viewModelScope.launch {
            compass.state.collect { compassState ->
                if (!compassState.unreliable) compassWarned = false
                else if (!compassWarned && orientation.value == MapOrientation.COMPASS) {
                    compassWarned = true
                    mutableMessages.send("Calibre a bússola movendo o aparelho em forma de 8.")
                }
            }
        }
        viewModelScope.launch {
            navigation.collect { nav ->
                updateLocationSubscription()
                if (wasNavigating && !nav.active) finishNavigationUi()
                wasNavigating = nav.active
                if (nav.active && nav.fix != null && !nav.gpsLost && followNavigation) followNavigationCamera(nav.fix)

                if (!nav.active && lifecycleStarted) openPendingLink()
            }
        }
    }

    private fun restoredOrientation(): MapOrientation =
        MapOrientation.entries.firstOrNull { it.name == saved.get<String>("orientation") } ?: MapOrientation.NORTH

    private fun followNavigationCamera(fix: LocationFix) {
        val northUp = mutableNavigationNorthUp.value
        val course = if (northUp) 0.0 else CameraPolicy.courseOrNull(fix.bearing, fix.speedMetersPerSecond)?.toDouble()
        mutable.update { it.copy(camera = CameraRequest(++cameraId, fix.coordinate, bearing = course,
            tilt = if (northUp) 0.0 else 45.0, zoom = CameraPolicy.navigationZoom(fix.speedMetersPerSecond), following = true)) }
    }

    fun setOrientation(mode: MapOrientation) {
        if (mutableOrientation.value == mode) return
        mutableOrientation.value = mode
        saved["orientation"] = mode.name
        compassWarned = false
        updateCompassSubscription()
    }

    fun userRotatedMap() {
        if (orientation.value != MapOrientation.FREE) setOrientation(MapOrientation.FREE)
    }

    fun toggleNavigationNorthUp() {
        mutableNavigationNorthUp.update { !it }
        followNavigation = true
        navigation.value.fix?.let { if (navigation.value.active) followNavigationCamera(it) }
    }

    private fun updateCompassSubscription() {
        if (orientation.value == MapOrientation.COMPASS && lifecycleStarted && mapVisible && !navigation.value.active) compass.start()
        else compass.stop()
    }

    private fun restoredCenter(): Coordinate = runCatching {
        Coordinate(saved.get<Double>("latitude") ?: -23.5505, saved.get<Double>("longitude") ?: -46.6333)
    }.getOrDefault(Coordinate(-23.5505, -46.6333))

    fun setForeground(started: Boolean) {
        NavigationSession.setAppVisible(started)
        lifecycleStarted = started
        updateLocationSubscription()
        if (started && !navigation.value.active) openPendingLink()
    }
    fun setMapVisible(visible: Boolean) { mapVisible = visible; updateLocationSubscription() }
    private fun updateLocationSubscription() {
        updateCompassSubscription()
        if (lifecycleStarted && mapVisible && !navigation.value.active) location.start() else location.stop()
    }
    fun refreshLocation() { location.refresh(); updateLocationSubscription() }
    fun centerLocation() {
        val nav = navigation.value
        val fix = if (nav.active && !nav.gpsLost) nav.fix else location.state.value.let { if (!it.isStale) it.fix else null }
        if (fix != null) { followNavigation = true; focus(fix.coordinate, if (nav.active) 17.0 else 15.5) }
        else { awaitingCenter = true; refreshLocation(); message(location.state.value.error ?: "Buscando sua localização…") }
    }
    fun mapMoved(center: Coordinate) {
        val moved = userMovedMap && lastSearchCenter?.let { center.distanceTo(it) > 180 } == true
        mutable.update { it.copy(center = center, areaMoved = it.category != null && moved) }
        saved["latitude"] = center.latitude; saved["longitude"] = center.longitude
    }
    fun mapGesture() { followNavigation = false; awaitingCenter = false; userMovedMap = true }
    fun focus(coordinate: Coordinate, zoom: Double = 16.0) {
        mutable.update { it.copy(camera = CameraRequest(++cameraId, target = coordinate, zoom = zoom)) }
    }
    fun orient(tilted: Boolean = false, resetNorth: Boolean = false) {
        mutable.update { it.copy(camera = CameraRequest(++cameraId, bearing = if (resetNorth) 0.0 else null, tilt = if (tilted) 50.0 else 0.0)) }
    }
    fun showOverview() {
        followNavigation = false
        val route = navigation.value.route ?: state.value.route ?: return
        mutable.update { it.copy(camera = CameraRequest(++cameraId, points = route.geometry, bearing = 0.0, tilt = 0.0)) }
    }
    fun openSearch(target: SearchTarget = SearchTarget.PLACE) {
        cancelSearchWork()
        mutable.update { it.copy(panel = PanelContent.SEARCH, searchTarget = target, query = "", results = emptyList(), searching = false, searched = false, error = null, category = null) }
    }
    fun setQuery(query: String) {
        cancelSearchWork()
        mutable.update { it.copy(query = query.take(200), results = emptyList(), searching = false, error = null, searched = false, category = null, areaMoved = false) }
        if (query.trim().length >= 2) searchJob = viewModelScope.launch { delay(650); executeSearch(false) }
        else mutable.update { it.copy(results = emptyList()) }
    }
    fun submitSearch() {
        cancelSearchWork()
        if (state.value.query.trim().length < 2) { message("Digite pelo menos duas letras."); return }
        searchJob = viewModelScope.launch { executeSearch(true) }
    }
    private suspend fun executeSearch(record: Boolean) {
        val query = state.value.query.trim()
        val version = searchVersion
        mutable.update { it.copy(searching = true, searched = false, error = null) }
        try {
            val result = app.places.search(query, state.value.center)
            if (version == searchVersion) mutable.update { it.copy(results = result, searching = false, searched = true) }
            if (record) performStorage { local.recordSearch(query) }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { if (version == searchVersion) mutable.update { it.copy(searching = false, searched = true, error = friendlyError(e)) } }
    }
    private fun cancelSearchWork() { searchVersion++; searchJob?.cancel() }
    fun closePanel() {
        cancelSearchWork(); detailsJob?.cancel()
        val panel = if (state.value.panel == PanelContent.SEARCH && state.value.searchTarget != SearchTarget.PLACE) PanelContent.ROUTE else PanelContent.EXPLORE
        mutable.update { it.copy(panel = panel, query = "", searching = false, loadingDetails = false, error = null, selectedPlace = if (panel == PanelContent.ROUTE) it.destination else null) }
        if (panel == PanelContent.EXPLORE) { routeJob?.cancel(); routeVersion++; mutable.update { it.copy(routes = emptyList(), routing = false) } }
    }
    fun clearResults() { cancelSearchWork(); mutable.update { it.copy(results = emptyList(), category = null, query = "", searched = false, searching = false, areaMoved = false, error = null) } }
    fun searchCategory(category: PlaceCategory) {
        val now = System.currentTimeMillis()
        if (now - lastNearby < 1_200) return
        lastNearby = now
        cancelSearchWork()
        val center = state.value.center
        lastSearchCenter = center
        userMovedMap = false
        val version = searchVersion
        mutable.update { it.copy(panel = PanelContent.SEARCH, searchTarget = SearchTarget.PLACE, category = category, query = category.label, results = emptyList(), searching = true, searched = false, areaMoved = false, error = null, selectedPlace = null) }
        searchJob = viewModelScope.launch {
            try {
                val places = app.places.nearby(category, center)
                if (version == searchVersion) mutable.update { it.copy(results = places, searching = false, searched = true,
                    camera = if (places.isEmpty()) it.camera else CameraRequest(++cameraId, points = places.map(Place::coordinate))) }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (version == searchVersion) mutable.update { it.copy(searching = false, searched = true, error = friendlyError(e)) } }
        }
    }
    fun retrySearch() { state.value.category?.let(::searchCategory) ?: submitSearch() }
    fun selectPlace(place: Place) {
        cancelSearchWork()
        val selectedQuery = state.value.query
        if (selectedQuery.isNotBlank() && state.value.category == null) storage { local.recordSearch(selectedQuery) }
        when (state.value.searchTarget) {
            SearchTarget.ORIGIN -> { mutable.update { it.copy(origin = place, panel = PanelContent.ROUTE, searching = false, searchTarget = SearchTarget.PLACE) }; calculateRoute() }
            SearchTarget.DESTINATION -> { mutable.update { it.copy(destination = place, panel = PanelContent.ROUTE, searching = false, searchTarget = SearchTarget.PLACE) }; calculateRoute() }
            SearchTarget.STOP -> { mutable.update { it.copy(stops = (it.stops + place).take(6), panel = PanelContent.ROUTE, searching = false, searchTarget = SearchTarget.PLACE) }; calculateRoute() }
            SearchTarget.PLACE -> showPlace(place)
        }
    }
    fun showPlace(place: Place) {
        cancelSearchWork(); detailsJob?.cancel()
        mutable.update { it.copy(panel = PanelContent.PLACE, selectedPlace = place, loadingDetails = true, detailError = null, searching = false, searchTarget = SearchTarget.PLACE, camera = CameraRequest(++cameraId, target = place.coordinate, zoom = 16.0)) }
        detailsJob = viewModelScope.launch {
            try {
                val detailed = app.places.details(place)
                mutable.update { if (it.selectedPlace?.id == place.id) it.copy(selectedPlace = detailed, loadingDetails = false) else it }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { mutable.update { if (it.selectedPlace?.id == place.id) it.copy(loadingDetails = false, detailError = friendlyError(e)) else it } }
        }
    }
    fun pin(coordinate: Coordinate, label: String? = null) = showPlace(Place("pin:${coordinate.latitude},${coordinate.longitude}", label ?: "Local marcado", coordinate, coordinateLabel(coordinate), "Ponto no mapa", source = "Marcado por você"))
    fun planRoute(place: Place) {
        val fix = currentFix()
        mutable.update { it.copy(panel = PanelContent.ROUTE, destination = place, origin = fix?.let(::locationPlace), stops = emptyList(), routes = emptyList(), routeError = null) }
        calculateRoute()
    }
    fun useLocationOrigin() {
        val fix = currentFix()
        if (fix == null) { message("Aguarde sua localização ou escolha uma origem."); return }
        mutable.update { it.copy(origin = locationPlace(fix)) }; calculateRoute()
    }
    private fun locationPlace(fix: LocationFix) = Place("current-location", "Minha localização", fix.coordinate, source = "Localização do Android")
    private fun currentFix(): LocationFix? = navigation.value.let { nav ->
        if (nav.active) nav.fix.takeUnless { nav.gpsLost }
        else location.state.value.let { if (!it.isStale) it.fix else null }
    }
    fun swapRoute() { mutable.update { it.copy(origin = it.destination, destination = it.origin, stops = it.stops.reversed()) }; calculateRoute() }
    fun removeStop(index: Int) { mutable.update { it.copy(stops = it.stops.filterIndexed { i, _ -> i != index }) }; calculateRoute() }
    fun selectMode(mode: TransportMode) { if (mode in supportedModes) { mutable.update { it.copy(mode = mode) }; calculateRoute() } }
    fun selectRoute(index: Int) {
        val route = state.value.routes.getOrNull(index) ?: return
        mutable.update { it.copy(routeIndex = index, camera = CameraRequest(++cameraId, points = route.geometry)) }
    }
    fun calculateRoute() {
        routeJob?.cancel(); val version = ++routeVersion
        val current = state.value
        val origin = current.origin; val destination = current.destination
        mutable.update { it.copy(routes = emptyList(), routeIndex = 0, routeError = null, routing = false) }
        if (origin == null || destination == null) return
        val points = listOf(origin.coordinate) + current.stops.map(Place::coordinate) + destination.coordinate
        mutable.update { it.copy(routing = true) }
        routeJob = viewModelScope.launch {
            try {
                val routes = app.routing.routes(points, current.mode)
                if (version == routeVersion) mutable.update { it.copy(routes = routes, routing = false, routeIndex = 0,
                    routeError = if (routes.isEmpty()) "Nenhuma rota disponível para este trajeto." else null,
                    camera = routes.firstOrNull()?.let { route -> CameraRequest(++cameraId, points = route.geometry) } ?: it.camera) }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (version == routeVersion) mutable.update { it.copy(routing = false, routeError = friendlyError(e)) } }
        }
    }
    fun startNavigation() {
        val route = state.value.route ?: return
        val fix = location.state.value
        if (!fix.permissionGranted || !fix.providerEnabled || fix.isStale || fix.fix == null) {
            message("Ative a localização e aguarde um sinal atual para começar."); return
        }
        val origin = route.geometry.firstOrNull() ?: return
        if (fix.fix.coordinate.distanceTo(origin) > 250) {
            mutable.update { it.copy(origin = locationPlace(fix.fix)) }
            calculateRoute(); message("Origem ajustada à sua localização. Confira a nova rota antes de iniciar."); return
        }
        followNavigation = true
        NavigationSession.start(app, route, settings.value.voice)
    }
    fun stopNavigation() { NavigationSession.stop(app); updateLocationSubscription() }
    private fun finishNavigationUi() {
        mutableNavigationNorthUp.value = false
        if (orientation.value == MapOrientation.FREE) setOrientation(MapOrientation.NORTH)
        routeJob?.cancel(); routeVersion++
        mutable.update { it.copy(panel = PanelContent.EXPLORE, routes = emptyList(), routing = false,
            selectedPlace = null, camera = CameraRequest(++cameraId, bearing = 0.0, tilt = 0.0, zoom = 14.5)) }
    }
    fun handleLink(target: DeepLinkTarget) {
        if (navigation.value.active) {
            pendingLink = target
            message("Link recebido. Ele abrirá quando você encerrar a navegação.")
            return
        }
        mutableMapOpenRequests.update { it + 1 }
        when (target) {
            is DeepLinkTarget.Search -> { openSearch(); setQuery(target.query); submitSearch() }
            is DeepLinkTarget.Pin -> { pin(target.coordinate, target.label); if (target.navigate) state.value.selectedPlace?.let(::planRoute) }
        }
    }
    private fun openPendingLink() {
        val target = pendingLink ?: return
        pendingLink = null
        handleLink(target)
    }
    fun toggleFavorite(place: Place) = storage { if (favorites.value.any { it.place.id == place.id }) local.removePlace(place.id) else local.savePlace(place) }
    fun createList(name: String) = storage { local.createList(name) }
    fun renameList(id: Long, name: String) = storage { local.renameList(id, name) }
    fun deleteList(id: Long) = storage { local.deleteList(id) }
    fun moveList(id: Long, delta: Int) = storage { local.moveList(id, delta) }
    fun setLists(place: Place, ids: Set<Long>) = storage { local.setPlaceLists(place, ids) }
    fun shortcut(kind: String, place: Place?) = storage { local.setShortcut(kind, place) }
    fun removeHistory(query: String) = storage { local.removeHistory(query) }
    fun clearHistory() = storage { local.clearHistory() }
    fun updateSettings(settings: AppSettings) = storage {
        local.updateSettings(settings)
        if (navigation.value.active) NavigationSession.setMuted(!settings.voice)
    }
    fun message(message: String) { mutableMessages.trySend(message) }
    private fun storage(block: suspend () -> Unit) { viewModelScope.launch { performStorage(block) } }
    private suspend fun performStorage(block: suspend () -> Unit) {
        try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { mutableMessages.send(friendlyError(e)) }
    }
    override fun onCleared() { location.stop(); compass.stop() }
}

fun friendlyError(error: Exception): String = (error as? AppException)?.message ?: "Não foi possível concluir. Tente novamente."
