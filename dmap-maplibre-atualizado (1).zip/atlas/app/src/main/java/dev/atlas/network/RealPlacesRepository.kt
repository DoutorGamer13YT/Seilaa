package dev.atlas.network

import dev.atlas.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.Locale

class RealPlacesRepository(
    client: OkHttpClient,
    photonBaseUrl: String,
    overpassUrl: String,
) : PlacesRepository {
    private val http = ProviderHttp(client)
    private val photon = validatedBaseUrl(photonBaseUrl)
    private val overpass = validatedBaseUrl(overpassUrl).toString().trimEnd('/')
    private val searchPacer = RequestPacer(800)
    private val overpassPacer = RequestPacer(2_000)
    private val searches = ProviderCache<List<Place>>(40, 10 * 60 * 1000)
    private val nearbyPlaces = ProviderCache<List<Place>>(20, 5 * 60 * 1000)
    private val detailsCache = ProviderCache<Place>(80, 60 * 60 * 1000)

    override suspend fun search(query: String, center: Coordinate?): List<Place> {
        val clean = query.trim()
        if (clean.length < 2) return emptyList()
        if (clean.length > 200) throw AppException(ErrorKind.INVALID_INPUT, "Use uma pesquisa com até 200 caracteres.")
        val key = "${clean.lowercase(Locale.ROOT)}|${center?.latitude}|${center?.longitude}"
        searches.get(key)?.let { return it }
        return withCachedFallback(searches, key) {
            searchPacer.awaitTurn()
            val url = photon.newBuilder().addPathSegment("api").addPathSegment("")
                .addQueryParameter("q", clean).addQueryParameter("limit", "12")
                .apply {
                    center?.let { addQueryParameter("lat", it.latitude.toString()); addQueryParameter("lon", it.longitude.toString()) }
                }.build()
            val body = http.execute(Request.Builder().url(url).build())
            parseResponse { ProviderParsers.photon(body) }
        }
    }

    override suspend fun nearby(category: PlaceCategory, center: Coordinate): List<Place> {
        val key = "${category.name}|${center.latitude}|${center.longitude}"
        nearbyPlaces.get(key)?.let { return it }
        return withCachedFallback(nearbyPlaces, key) {
            overpassPacer.awaitTurn()
            val query = ProviderParsers.nearbyQuery(category, center)
            val body = http.execute(Request.Builder().url(overpass)
                .post(FormBody.Builder().add("data", query).build()).build())
            parseResponse { ProviderParsers.overpass(body) }
                .sortedBy { it.coordinate.distanceTo(center) }.take(60)
        }
    }

    override suspend fun details(place: Place): Place {
        val match = OSM_ID.matchEntire(place.id) ?: return place
        if (match.groupValues[2].toLongOrNull() == null) return place
        detailsCache.get(place.id)?.let { return it }
        return try {
            overpassPacer.awaitTurn()
            val query = "[out:json][timeout:20];${match.groupValues[1]}(${match.groupValues[2]});out center tags;"
            val body = http.execute(Request.Builder().url(overpass)
                .post(FormBody.Builder().add("data", query).build()).build())
            val found = parseResponse { ProviderParsers.overpass(body) }.firstOrNull { it.id == place.id }
            val result = if (found == null) place else place.copy(
                name = found.name.takeUnless { it == "Local sem nome" } ?: place.name,
                address = found.address.ifBlank { place.address },
                category = found.category.takeUnless { it == "Lugar" } ?: place.category,
                phone = found.phone ?: place.phone,
                website = found.website ?: place.website,
                openingHours = found.openingHours ?: place.openingHours,
                source = "OpenStreetMap · Overpass",
            )
            detailsCache.put(place.id, result)
            result
        } catch (error: AppException) {
            val cached = detailsCache.get(place.id, allowStale = true)
            if (cached != null && error.kind in CACHEABLE_ERRORS) cached.copy(source = "${cached.source} · cache temporário")
            else throw error
        }
    }

    private suspend fun withCachedFallback(
        cache: ProviderCache<List<Place>>, key: String, block: suspend () -> List<Place>,
    ): List<Place> = try {
        block().also { cache.put(key, it) }
    } catch (error: AppException) {
        val cached = cache.get(key, allowStale = true)
        if (cached != null && error.kind in CACHEABLE_ERRORS) cached.map { it.copy(source = "${it.source} · cache temporário") }
        else throw error
    }

    private companion object {
        val OSM_ID = Regex("(node|way|relation):([1-9][0-9]{0,18})")
        val CACHEABLE_ERRORS = setOf(ErrorKind.NETWORK, ErrorKind.RATE_LIMIT, ErrorKind.PROVIDER)
    }
}

internal suspend fun <T> parseResponse(block: () -> T): T = withContext(Dispatchers.Default) {
    try { block() }
    catch (e: JSONException) { throw AppException(ErrorKind.PROVIDER, "O serviço enviou dados que não puderam ser lidos.", e) }
    catch (e: IllegalArgumentException) { throw AppException(ErrorKind.PROVIDER, "O serviço enviou coordenadas ou dados inválidos.", e) }
}

internal object ProviderParsers {
    fun photon(body: String): List<Place> {
        val features = JSONObject(body).getJSONArray("features")
        return features.objects().mapNotNull { feature ->
            val properties = feature.optJSONObject("properties") ?: return@mapNotNull null
            val geometry = feature.optJSONObject("geometry") ?: return@mapNotNull null
            if (geometry.optString("type") != "Point") return@mapNotNull null
            val coordinate = coordinate(geometry.optJSONArray("coordinates")) ?: return@mapNotNull null
            val type = when (properties.optString("osm_type").uppercase(Locale.ROOT)) {
                "N", "NODE" -> "node"; "W", "WAY" -> "way"; "R", "RELATION" -> "relation"; else -> return@mapNotNull null
            }
            val id = osmId(properties, "osm_id") ?: return@mapNotNull null
            val street = listOfNotNull(properties.text("street"), properties.text("housenumber")).joinToString(", ")
            val address = listOf(street, properties.text("district"), properties.text("city"), properties.text("state"), properties.text("postcode"), properties.text("country"))
                .filterNotNull().filter(String::isNotBlank).distinct().joinToString(", ")
            Place(
                id = "$type:$id",
                name = properties.text("name") ?: street.ifBlank { properties.text("city") ?: properties.text("country") ?: "Endereço" },
                coordinate = coordinate, address = address,
                category = PlaceCategory.labelFor(properties.optString("osm_key"), properties.optString("osm_value")),
                source = "OpenStreetMap · Photon",
            )
        }.distinctBy { it.id }.take(12)
    }

    fun nearbyQuery(category: PlaceCategory, center: Coordinate): String {
        val selector = if (category.osmValue == "*") "[\"${category.osmKey}\"]"
        else "[\"${category.osmKey}\"=\"${category.osmValue}\"]"
        return "[out:json][timeout:20];nwr$selector(around:3000,${center.latitude},${center.longitude});out center tags 60;"
    }

    fun overpass(body: String): List<Place> {
        val document = JSONObject(body)
        if (document.text("remark") != null) throw AppException(ErrorKind.PROVIDER, "A consulta não foi concluída pelo serviço de lugares. Tente uma área menor ou aguarde.")
        return document.getJSONArray("elements").objects().mapNotNull { element ->
            val type = element.optString("type").takeIf { it in setOf("node", "way", "relation") } ?: return@mapNotNull null
            val id = osmId(element, "id") ?: return@mapNotNull null
            val coords = element.optJSONObject("center") ?: element
            val latitude = coords.optDouble("lat", Double.NaN)
            val longitude = coords.optDouble("lon", Double.NaN)
            val point = checkedCoordinate(latitude, longitude) ?: return@mapNotNull null
            val tags = element.optJSONObject("tags") ?: JSONObject()
            val key = listOf("amenity", "shop", "tourism", "leisure", "aeroway", "public_transport").firstOrNull(tags::has)
            val street = listOfNotNull(tags.text("addr:street"), tags.text("addr:housenumber")).joinToString(", ")
            val address = tags.text("addr:full") ?: listOf(street, tags.text("addr:suburb"), tags.text("addr:city"), tags.text("addr:postcode"))
                .filterNotNull().filter(String::isNotBlank).distinct().joinToString(", ")
            Place("$type:$id", tags.text("name") ?: tags.text("brand") ?: "Local sem nome", point,
                address = address,
                category = if (key == null) "Lugar" else PlaceCategory.labelFor(key, tags.optString(key)),
                phone = (tags.text("contact:phone") ?: tags.text("phone"))?.take(80),
                website = safeWebsite(tags.text("contact:website") ?: tags.text("website")),
                openingHours = tags.text("opening_hours"),
                source = "OpenStreetMap · Overpass")
        }.distinctBy { it.id }
    }

    fun coordinate(array: JSONArray?): Coordinate? = if (array == null || array.length() < 2) null
    else checkedCoordinate(array.optDouble(1, Double.NaN), array.optDouble(0, Double.NaN))

    private fun checkedCoordinate(latitude: Double, longitude: Double): Coordinate? =
        if (latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0)
            Coordinate(latitude, longitude) else null

    private fun osmId(json: JSONObject, field: String): Long? {
        val raw = json.opt(field)?.toString() ?: return null
        if (!Regex("[1-9][0-9]{0,18}").matches(raw)) return null
        return raw.toLongOrNull()
    }

    private fun safeWebsite(raw: String?): String? {
        if (raw.isNullOrBlank() || raw.length > 2048) return null
        val uri = runCatching { java.net.URI(raw.trim()) }.getOrNull() ?: return null
        return raw.trim().takeIf { uri.scheme?.lowercase(Locale.ROOT) in setOf("https", "http") && !uri.host.isNullOrBlank() && uri.userInfo == null }
    }
}

internal fun JSONObject.text(key: String): String? = optString(key, "").trim().takeIf { it.isNotEmpty() && it != "null" }?.take(2048)
internal fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
