package com.infinityclicker.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.remember
import com.infinityclicker.ui.BossUi
import com.infinityclicker.ui.CosmicEventUi
import com.infinityclicker.ui.components.Motion
import com.infinityclicker.ui.components.bumpOnChange
import com.infinityclicker.ui.components.enterAnimation
import com.infinityclicker.ui.components.pulseOverlay

import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import com.infinityclicker.ui.components.glass
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.infinityclicker.ui.components.GlowBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.CrystalArea
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.GlyphIcon
import com.infinityclicker.ui.components.LocalMotionEnabled
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor

@Composable
fun HomeScreen(
    ui: UiState,
    onTap: () -> TapResult?,
    onUseAbility: (String) -> Unit,
    onNavigate: (Int) -> Unit
) {
    val sci = ui.settings.scientificNotation
    fun f(n: com.infinityclicker.core.BigNum) = NumberFormatter.format(n, sci)
    val crystal = ui.crystals.firstOrNull { it.equipped }?.def
    val dimension = ui.dimensions.firstOrNull { it.current }?.def
    // Só a camada do número pulsa; não há animação de layout nem alteração do ritmo do jogo.
    val motionEnabled = LocalMotionEnabled.current
    val numberMotion = rememberInfiniteTransition(label = "energyReadout")
    val numberScale by numberMotion.animateFloat(
        initialValue = 1f,
        targetValue = if (motionEnabled) 1.012f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1_850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "energyBreath"
    )

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val accent = dimension?.tintColor ?: Neon.Cyan
        // Estilo do número de energia e textos formatados: criados só quando algo muda (antes, a cada publicação do estado).
        val energyStyle = remember(accent) {
            TextStyle(
                brush = Brush.verticalGradient(listOf(Color.White, Color.White, accent.copy(alpha = 0.85f))),
                fontSize = 42.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, fontFeatureSettings = "tnum",
                shadow = Shadow(accent.copy(alpha = 0.55f), Offset(0f, 0f), 22f)
            )
        }
        val critText = remember(ui.critChance, ui.critMultiplier) { "${"%.0f".format(ui.critChance * 100)}% · ×${"%.1f".format(ui.critMultiplier)}" }
        val comboText = remember(ui.combo, ui.maxCombo, ui.comboMultiplier) { "${ui.combo}/${ui.maxCombo} · ×${"%.2f".format(ui.comboMultiplier)}" }
        // Cabeçalho: a energia é a estrela da tela, centralizada e com degradê; o resto vira etiquetas de vidro.
        Column(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Tag(dimension?.name ?: "Primordial", accent)
                Tag(crystal?.name ?: "Éter Azul", crystal?.tintColor ?: Neon.Cyan)
            }
            Text("ENERGIA", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 10.dp))
            Text(
                f(ui.energy),
                style = energyStyle,
                maxLines = 1,
                modifier = Modifier.bumpOnChange(ui.stats.totalClicks, peak = 1.06f).graphicsLayer { scaleX = numberScale; scaleY = numberScale }
            )
            Text(
                "+${f(ui.production)} / s", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 2.dp).glass(RoundedCornerShape(50), tint = accent, alpha = 0.18f, borderAlpha = 0.45f)
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }

        val renderQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver, ui.settings.deviceQuality)
        val fleet = androidx.compose.runtime.remember(ui.generators) { com.infinityclicker.ui.components.fleetSizeFor(ui.generators.sumOf { it.owned }) }
        CrystalArea(
            tier = (ui.stats.totalEnergy.exponent / 3L).toInt(),
            crystalStyle = crystal?.id ?: 0,
            baseColor = crystal?.tintColor ?: Neon.Cyan,
            comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f,
            effectsIntensity = ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.5f else renderQuality.particleScale,
            particleLimit = (150f * ui.settings.effectsIntensity * if (ui.settings.batterySaver) 0.3f else renderQuality.particleScale).toInt(),
            quality = renderQuality,
            hapticsEnabled = ui.settings.hapticsEnabled,
            motionEnabled = motionEnabled,
            formatGain = { r -> f(r.gain) },
            onTap = onTap,
            fleetSize = fleet,
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        // Um único filho do Column principal (chefe + evento + habilidades): assim o espaçamento entre blocos não ganha
        // vãos fantasmas quando chefe e evento estão fechados; cada cartão carrega o próprio respiro de baixo.
        Column(Modifier.fillMaxWidth()) {
        // Chefe e evento entram expandindo a altura (o cristal cede espaço com suavidade) e saem do mesmo jeito.
        // O último valor fica guardado só para o cartão não esvaziar durante a animação de saída.
        val bossNow = ui.activeBoss
        val bossHold = remember { arrayOfNulls<BossUi>(1) }
        if (bossNow != null) bossHold[0] = bossNow
        AnimatedVisibility(
            visible = bossNow != null,
            enter = if (motionEnabled) expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(tween(260)) else EnterTransition.None,
            exit = if (motionEnabled) shrinkVertically(tween(260, easing = Motion.Emphasized)) + fadeOut(tween(160)) else ExitTransition.None
        ) {
            (bossNow ?: bossHold[0])?.let { boss ->
                val fraction = (boss.active.health / boss.maxHealth).toDouble().toFloat().coerceIn(0f, 1f)
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlyphIcon("⚠", Neon.Pink, 16.dp)
                            Text(
                                ui.dimensions.firstOrNull { it.def.id == boss.active.dimensionId }?.def?.bossName ?: "Chefe",
                                color = Neon.Pink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 7.dp)
                            )
                        }
                        Text("${NumberFormatter.duration(boss.remainingMs)}", color = Neon.Gold, fontSize = 12.sp)
                    }
                    GlowBar(
                        progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(7.dp),
                        color = Neon.Pink, trackColor = Color.White.copy(alpha = 0.12f)
                    )
                    Text("Vida: ${f(boss.active.health)} · cada toque causa dano real", color = Neon.TextSecondary, fontSize = 12.sp)
                }
            }
        }

        val eventNow = ui.activeEvent
        val eventHold = remember { arrayOfNulls<CosmicEventUi>(1) }
        if (eventNow != null) eventHold[0] = eventNow
        AnimatedVisibility(
            visible = eventNow != null,
            enter = if (motionEnabled) expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(tween(260)) else EnterTransition.None,
            exit = if (motionEnabled) shrinkVertically(tween(260, easing = Motion.Emphasized)) + fadeOut(tween(160)) else ExitTransition.None
        ) {
            (eventNow ?: eventHold[0])?.let { event ->
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), tint = Color(event.def.tintArgb), alpha = ui.settings.panelOpacity) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlyphIcon("✦", Color(event.def.tintArgb), 16.dp)
                            Text(event.def.name, color = Color(event.def.tintArgb), fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 7.dp))
                        }
                        Text(NumberFormatter.duration(event.remainingMs), color = Neon.Gold, fontSize = 12.sp)
                    }
                    Text(event.def.description, color = Neon.TextSecondary, fontSize = 12.sp)
                }
            }
        }

        AbilityStrip(ui.abilities, sci, onUseAbility, Modifier.enterAnimation(1))
        }

        val comboFraction = if (ui.maxCombo > 0) ui.combo.toFloat() / ui.maxCombo else 0f
        Column(
            Modifier.fillMaxWidth().enterAnimation(2).glass(RoundedCornerShape(26.dp), tint = Neon.Violet, alpha = ui.settings.panelOpacity + 0.04f, borderAlpha = 0.45f)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Metric("CLIQUE", "+${f(ui.clickGain)}", Neon.TextPrimary)
                Metric("CRÍTICO", critText, Neon.Gold, Alignment.CenterHorizontally)
                Metric("COMBO", comboText, Neon.Green, Alignment.End, Modifier.bumpOnChange(ui.combo, peak = 1.10f))
            }
            GlowBar(progress = { comboFraction }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), color = Neon.Cyan)
        }
        AnimatedContent(
            targetState = ui.tutorialStep.coerceIn(0, 4),
            transitionSpec = {
                if (!motionEnabled) {
                    EnterTransition.None togetherWith ExitTransition.None
                } else {
                (fadeIn(tween(190)) + slideInVertically(tween(230, easing = Motion.Emphasized)) { it / 3 }) togetherWith
                    (fadeOut(tween(150)) + slideOutVertically(tween(190, easing = Motion.Emphasized)) { -it / 3 })
                }
            },
            modifier = Modifier.fillMaxWidth().enterAnimation(3),
            label = "tutorialGuide"
        ) { step ->
            GuidedTutorialCard(step, onNavigate)
        }
        // Depois do guia, o cartão troca a explicação fixa por uma ação útil no estado atual da partida.
        if (ui.tutorialStep >= 4) NextObjectiveCard(ui, onNavigate)
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp, maxLines = 1,
        modifier = Modifier.glass(RoundedCornerShape(50), tint = color, alpha = 0.14f, borderAlpha = 0.40f).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
private fun Metric(label: String, value: String, color: Color, align: Alignment.Horizontal = Alignment.Start, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = align) {
        Text(label, color = Neon.TextSecondary, fontSize = 9.sp, letterSpacing = 1.5.sp)
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun AbilityStrip(abilities: List<AbilityUi>, scientific: Boolean, onUse: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        abilities.forEach { ability ->
            val text = when {
                ability.activeRemainingMs > 0L -> "Ativa ${NumberFormatter.duration(ability.activeRemainingMs)}"
                ability.cooldownRemainingMs > 0L -> "Recarga ${NumberFormatter.duration(ability.cooldownRemainingMs)}"
                else -> "Usar"
            }
            val active = ability.activeRemainingMs > 0L
            val tint = when { active -> Neon.Green; ability.canUse -> Neon.Cyan; else -> Color.White }
            Column(
                Modifier.bouncyClick(enabled = ability.canUse) { onUse(ability.def.id) }
                    .glass(RoundedCornerShape(20.dp), tint = tint, alpha = if (ability.canUse || active) 0.30f else 0.07f, borderAlpha = if (ability.canUse || active) 0.62f else 0.22f)
                    .then(if (active) Modifier.pulseOverlay(Neon.Green, 20.dp, 900L, 1.4f) else if (ability.canUse) Modifier.pulseOverlay(Neon.Cyan, 20.dp, 2_400L, 0.7f) else Modifier)
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(ability.def.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (ability.canUse || active) Neon.TextPrimary else Neon.TextSecondary, maxLines = 1)
                Text(text, fontSize = 10.sp, color = if (active) Neon.Green else if (ability.canUse) Neon.Cyan else Neon.TextSecondary, maxLines = 1)
            }
        }
    }
}

private data class TutorialLesson(
    val number: Int,
    val tint: Color,
    val title: String,
    val body: String,
    val action: String? = null,
    val destination: Int? = null
)

private fun lessonFor(step: Int): TutorialLesson = when (step) {
    0 -> TutorialLesson(
        1, Neon.Cyan, "Toque no cristal",
        "Cada toque gera energia. Toque em sequência para aumentar o combo; ele zera depois de 1 segundo sem tocar."
    )
    1 -> TutorialLesson(
        2, Neon.Violet, "Ligue a produção automática",
        "Na Loja, compre um Fragmento Estelar. Geradores continuam produzindo energia por segundo, mesmo sem tocar.",
        "Abrir Loja", 1
    )
    2 -> TutorialLesson(
        3, Neon.Green, "Use uma habilidade",
        "As habilidades ficam acima do painel de combo. Toque em uma que esteja disponível para ganhar bônus reais de clique ou produção."
    )
    3 -> TutorialLesson(
        4, Neon.Pink, "Explore dimensões e chefes",
        "Quando tiver energia total suficiente, desbloqueie uma dimensão. Chefes rendem fragmentos, que fortalecem a ressonância.",
        "Ver Dimensões", 2
    )
    else -> TutorialLesson(
        5, Neon.Gold, "Guia concluído",
        "Você já sabe o básico: toque, produção, habilidades, dimensões e renascimento. Abaixo há sempre uma sugestão do melhor próximo passo.",
        "Abrir Resumo", 5
    )
}

@Composable
private fun GuidedTutorialCard(step: Int, onNavigate: (Int) -> Unit) {
    val lesson = lessonFor(step)
    val action = lesson.action
    val destination = lesson.destination
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), tint = lesson.tint, alpha = 0.13f, borderAlpha = 0.45f)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("GUIA INICIAL · ${lesson.number}/5", color = lesson.tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("PASSO ATUAL", color = Neon.TextSecondary, fontSize = 10.sp, letterSpacing = 1.sp)
        }
        GlowBar(
            progress = { lesson.number / 5f },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(5.dp),
            color = lesson.tint,
            trackColor = Color.White.copy(alpha = 0.10f)
        )
        Text(lesson.title, color = Neon.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Text(lesson.body, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 3.dp))
        if (action != null && destination != null) {
            Button(
                onClick = { onNavigate(destination) },
                colors = ButtonDefaults.buttonColors(containerColor = lesson.tint, contentColor = Neon.Bg),
                modifier = Modifier.align(Alignment.End).padding(top = 10.dp)
            ) {
                Text(action, fontWeight = FontWeight.Bold)
            }
        } else {
            Text("Faça isso agora para avançar.", color = lesson.tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private data class NextObjective(
    val tint: Color,
    val title: String,
    val body: String,
    val action: String? = null,
    val destination: Int? = null,
    /** Preço do próximo passo quando ainda falta energia; permite mostrar progresso real, não só uma dica genérica. */
    val targetCost: BigNum? = null
)

private data class PendingPurchase(val type: String, val name: String, val cost: BigNum, val tint: Color)

/** Prioridade curta e contextual para a tela inicial, sem criar uma nova mecânica ou alterar recompensas. */
private fun nextObjectiveFor(ui: UiState): NextObjective {
    if (ui.prestige.available) return NextObjective(
        Neon.Gold, "Renascimento disponível",
        "Você já acumulou energia suficiente nesta corrida. Renascer concede pontos permanentes para a Árvore.",
        "Abrir Resumo", 5
    )
    ui.dimensions.firstOrNull { it.canUnlock }?.let { dimension ->
        return NextObjective(
            Neon.Pink, "Nova dimensão liberável",
            "${dimension.def.name} já pode ser desbloqueada. Novas dimensões abrem chefes e multiplicadores.",
            "Ver Dimensões", 2
        )
    }
    val readyGenerator = ui.generators.firstOrNull { it.isBest && it.unlocked && it.plan.count > 0L && it.plan.affordable }
        ?: ui.generators.firstOrNull { it.unlocked && it.plan.count > 0L && it.plan.affordable }
    readyGenerator?.let { generator ->
        return NextObjective(
            Neon.Violet, "Aumente a produção",
            "${generator.def.name} está ao seu alcance. Produção automática continua rendendo enquanto você toca.",
            "Abrir Loja", 1
        )
    }
    ui.upgrades.firstOrNull { it.unlocked && !it.maxed && it.plan.affordable }?.let { upgrade ->
        return NextObjective(
            Neon.Cyan, "Melhoria pronta",
            "${upgrade.def.name} pode fortalecer sua próxima fase de progresso.",
            "Ver melhorias", 1
        )
    }
    ui.abilities.firstOrNull { it.canUse }?.let { ability ->
        return NextObjective(
            Neon.Green, "Habilidade disponível",
            "Use ${ability.def.name} acima do painel de combo para acelerar esta corrida."
        )
    }
    // Quando nada pode ser comprado agora, o objetivo deixa de ser vago: mostra o investimento mais próximo e uma barra real até ele.
    val nextGenerator = ui.generators
        .asSequence()
        .filter { it.unlocked && it.plan.count > 0L && !it.plan.affordable }
        .map { PendingPurchase("Gerador", it.def.name, it.plan.cost, Neon.Violet) }
        .minByOrNull { it.cost }
    val nextUpgrade = ui.upgrades
        .asSequence()
        .filter { it.unlocked && !it.maxed && it.plan.count > 0L && !it.plan.affordable }
        .map { PendingPurchase("Melhoria", it.def.name, it.plan.cost, Neon.Cyan) }
        .minByOrNull { it.cost }
    val nextPurchase = listOfNotNull(nextGenerator, nextUpgrade).minByOrNull { it.cost }
    if (nextPurchase != null) return NextObjective(
        nextPurchase.tint, "Próximo investimento",
        "${nextPurchase.type}: ${nextPurchase.name}",
        "Abrir Loja", 1, nextPurchase.cost
    )
    return NextObjective(
        Neon.Cyan, "Faça a energia crescer",
        "Toque no cristal, mantenha o combo e guarde energia para o próximo gerador ou melhoria."
    )
}

@Composable
private fun NextObjectiveCard(ui: UiState, onNavigate: (Int) -> Unit) {
    val goal = nextObjectiveFor(ui)
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), tint = goal.tint, alpha = 0.11f, borderAlpha = 0.40f)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text("PRÓXIMO OBJETIVO", color = goal.tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text(goal.title, color = Neon.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
        Text(goal.body, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 3.dp))
        goal.targetCost?.let { cost ->
            val progress = if (cost.isZero) 1f else (ui.energy / cost).toDouble().toFloat().coerceIn(0f, 1f)
            val remaining = cost - ui.energy
            val f: (BigNum) -> String = { n -> NumberFormatter.format(n, ui.settings.scientificNotation) }
            val eta = if (remaining.isZero || ui.production.isZero) null else {
                val milliseconds = ((remaining / ui.production).toDouble() * 1_000.0).coerceIn(0.0, 9.0e15).toLong()
                NumberFormatter.duration(milliseconds)
            }
            Text(
                "Faltam ${f(remaining)}" + (eta?.let { " · cerca de $it" } ?: ""),
                color = goal.tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 9.dp)
            )
            GlowBar(
                progress = { progress }, color = goal.tint,
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(6.dp),
                trackColor = Color.White.copy(alpha = 0.12f)
            )
            Text(
                "${f(ui.energy)} / ${f(cost)} · ${(progress * 100f).toInt()}%",
                color = goal.tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 5.dp)
            )
        }
        if (goal.action != null && goal.destination != null) {
            Button(
                onClick = { onNavigate(goal.destination) },
                colors = ButtonDefaults.buttonColors(containerColor = goal.tint, contentColor = Neon.Bg),
                modifier = Modifier.align(Alignment.End).padding(top = 10.dp)
            ) {
                Text(goal.action, fontWeight = FontWeight.Bold)
            }
        }
    }
}
