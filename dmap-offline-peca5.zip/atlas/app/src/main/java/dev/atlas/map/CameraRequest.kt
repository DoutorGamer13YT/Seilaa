package dev.atlas.map

import dev.atlas.core.Coordinate

data class CameraRequest(
    val id: Long,
    val target: Coordinate? = null,
    val points: List<Coordinate> = emptyList(),
    val bearing: Double? = null,
    val tilt: Double? = null,
    val zoom: Double? = null,
)

data class CameraSnapshot(
    val latitude: Double,
    val longitude: Double,
    val zoom: Double,
    val bearing: Double,
    val tilt: Double,
)
