package dev.atlas.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HeadingMathTest {
    private fun matrix(x: Triple<Float, Float, Float>, y: Triple<Float, Float, Float>, z: Triple<Float, Float, Float>) = floatArrayOf(
        x.first, y.first, z.first,
        x.second, y.second, z.second,
        x.third, y.third, z.third,
    )

    private val flatTopNorth = matrix(Triple(1f, 0f, 0f), Triple(0f, 1f, 0f), Triple(0f, 0f, 1f))
    private val flatTopEast = matrix(Triple(0f, -1f, 0f), Triple(1f, 0f, 0f), Triple(0f, 0f, 1f))
    private val uprightFacingEast = matrix(Triple(0f, -1f, 0f), Triple(0f, 0f, 1f), Triple(-1f, 0f, 0f))

    @Test fun flatPhoneReportsDirectionOfScreenTop() {
        assertEquals(0f, HeadingMath.headingDegrees(flatTopNorth, 0)!!, 0.01f)
        assertEquals(90f, HeadingMath.headingDegrees(flatTopEast, 0)!!, 0.01f)
    }

    @Test fun uprightPhoneReportsDirectionOfBackCamera() {
        assertEquals(90f, HeadingMath.headingDegrees(uprightFacingEast, 0)!!, 0.01f)
    }

    @Test fun landscapeRotationsUseTheMatchingScreenAxis() {
        assertEquals(270f, HeadingMath.headingDegrees(flatTopNorth, 1)!!, 0.01f)
        assertEquals(180f, HeadingMath.headingDegrees(flatTopNorth, 2)!!, 0.01f)
        assertEquals(90f, HeadingMath.headingDegrees(flatTopNorth, 3)!!, 0.01f)
    }

    @Test fun invalidMatricesAreRejected() {
        assertNull(HeadingMath.headingDegrees(FloatArray(4), 0))
        assertNull(HeadingMath.headingDegrees(FloatArray(9) { Float.NaN }, 0))
        assertNotNull(HeadingMath.headingDegrees(flatTopNorth, 0))
    }

    @Test fun shortestDeltaCrossesNorthTheShortWay() {
        assertEquals(20f, HeadingMath.shortestDelta(350f, 10f), 0.001f)
        assertEquals(-20f, HeadingMath.shortestDelta(10f, 350f), 0.001f)
        assertEquals(179f, HeadingMath.shortestDelta(0f, 179f), 0.001f)
    }

    @Test fun normalizeKeepsAnglesInsideZeroTo360() {
        assertEquals(350f, HeadingMath.normalize(-10f), 0.001f)
        assertEquals(10f, HeadingMath.normalize(370f), 0.001f)
        assertEquals(0f, HeadingMath.normalize(360f), 0.001f)
    }

    @Test fun smoothingIgnoresJitterAndConvergesWithoutSpinning() {
        assertEquals(100f, HeadingMath.smooth(null, 100f), 0.001f)
        assertEquals(100f, HeadingMath.smooth(100f, 100.3f), 0.001f)
        var value = 350f
        repeat(60) { value = HeadingMath.smooth(value, 10f) }
        assertEquals(10f, value, 1f)
        assertTrue(HeadingMath.smooth(350f, 10f) > 350f || HeadingMath.smooth(350f, 10f) < 10f)
    }

    @Test fun navigationZoomShrinksWithSpeed() {
        assertEquals(17.6, CameraPolicy.navigationZoom(null), 0.0)
        assertTrue(CameraPolicy.navigationZoom(8f) > CameraPolicy.navigationZoom(18f))
        assertTrue(CameraPolicy.navigationZoom(18f) > CameraPolicy.navigationZoom(35f))
        assertEquals(17.6, CameraPolicy.navigationZoom(Float.NaN), 0.0)
    }

    @Test fun gpsCourseIsIgnoredWhenStationary() {
        assertNull(CameraPolicy.courseOrNull(90f, 0.4f))
        assertNull(CameraPolicy.courseOrNull(90f, null))
        assertNull(CameraPolicy.courseOrNull(Float.NaN, 10f))
        assertEquals(90f, CameraPolicy.courseOrNull(90f, 5f)!!, 0.001f)
        assertEquals(350f, CameraPolicy.courseOrNull(-10f, 5f)!!, 0.001f)
    }
}
