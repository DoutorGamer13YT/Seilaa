package dev.atlas.core

enum class PlaceCategory(val label: String, val osmKey: String, val osmValue: String) {
    RESTAURANTS("Restaurantes", "amenity", "restaurant"),
    CAFES("Cafés", "amenity", "cafe"),
    MARKETS("Mercados", "shop", "supermarket"),
    PHARMACIES("Farmácias", "amenity", "pharmacy"),
    HOSPITALS("Hospitais", "amenity", "hospital"),
    FUEL("Postos de combustível", "amenity", "fuel"),
    PARKING("Estacionamentos", "amenity", "parking"),
    HOTELS("Hotéis", "tourism", "hotel"),
    BANKS("Bancos", "amenity", "bank"),
    ATMS("Caixas eletrônicos", "amenity", "atm"),
    SHOPS("Lojas", "shop", "*"),
    PARKS("Parques", "leisure", "park"),
    ATTRACTIONS("Atrações turísticas", "tourism", "attraction"),
    GYMS("Academias", "leisure", "fitness_centre"),
    CAR_REPAIR("Oficinas", "shop", "car_repair"),
    TRANSIT("Transporte público", "public_transport", "platform"),
    AIRPORTS("Aeroportos", "aeroway", "aerodrome"),
    SCHOOLS("Escolas", "amenity", "school"),
    UNIVERSITIES("Universidades", "amenity", "university"),
    PUBLIC_SERVICES("Serviços públicos", "amenity", "townhall");

    companion object {
        fun labelFor(key: String, value: String): String = entries
            .firstOrNull { it.osmKey == key && it.osmValue == value }?.label
            ?: if (key == "shop") "Loja" else value.replace('_', ' ').ifBlank { "Lugar" }
    }
}
