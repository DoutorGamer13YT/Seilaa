package dev.atlas.location

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.SystemClock
import android.view.Display
import dev.atlas.core.Coordinate
import dev.atlas.core.HeadingMath
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

data class CompassState(
    val heading: Float? = null,
    val available: Boolean = false,
    val unreliable: Boolean = false,
)

class CompassSensor(context: Context) : SensorEventListener {
    private val appContext = context.applicationContext
    private val sensors = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val displays = appContext.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
    private val rotationVector = sensors?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelerometer = sensors?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometer = sensors?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    val available: Boolean = rotationVector != null || (accelerometer != null && magnetometer != null)
    private val mutable = MutableStateFlow(CompassState(available = available))
    val state: StateFlow<CompassState> = mutable.asStateFlow()
    private val rotation = FloatArray(9)
    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetic = false
    private var running = false
    private var smoothed: Float? = null
    private var emitted: Float? = null
    private var lastEmitMillis = 0L
    private var declination = 0f
    private var declinationAt: Coordinate? = null

    fun start() {
        if (running || !available) return
        val manager = sensors ?: return
        running = true
        smoothed = null
        emitted = null
        hasGravity = false
        hasMagnetic = false
        val registered = if (rotationVector != null) {
            manager.registerListener(this, rotationVector, SensorManager.SENSOR_DELAY_UI)
        } else {
            val accel = manager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
            val mag = manager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
            accel && mag
        }
        if (!registered) {
            running = false
            manager.unregisterListener(this)
            mutable.value = CompassState(available = false)
        }
    }

    fun stop() {
        if (!running) return
        running = false
        sensors?.unregisterListener(this)
        smoothed = null
        emitted = null
        mutable.value = mutable.value.copy(heading = null, unreliable = false)
    }

    fun setLocation(coordinate: Coordinate) {
        val previous = declinationAt
        if (previous != null && previous.distanceTo(coordinate) < 50_000.0) return
        declinationAt = coordinate
        declination = runCatching {
            GeomagneticField(coordinate.latitude.toFloat(), coordinate.longitude.toFloat(), 0f, System.currentTimeMillis()).declination
        }.getOrDefault(0f)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!running) return
        val ready = when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> runCatching {
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
            }.isSuccess
            Sensor.TYPE_ACCELEROMETER -> {
                lowPass(gravity, event.values, hasGravity)
                hasGravity = true
                hasMagnetic && SensorManager.getRotationMatrix(rotation, null, gravity, magnetic)
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                lowPass(magnetic, event.values, hasMagnetic)
                hasMagnetic = true
                hasGravity && SensorManager.getRotationMatrix(rotation, null, gravity, magnetic)
            }
            else -> false
        }
        if (!ready) return
        val raw = HeadingMath.headingDegrees(rotation, displayRotation()) ?: return
        val next = HeadingMath.smooth(smoothed, raw + declination)
        smoothed = next
        val now = SystemClock.elapsedRealtime()
        val last = emitted
        if (last == null || (abs(HeadingMath.shortestDelta(last, next)) >= 1f && now - lastEmitMillis >= 33L)) {
            emitted = next
            lastEmitMillis = now
            mutable.value = mutable.value.copy(heading = next)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (!running) return
        val unreliable = accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW
        if (mutable.value.unreliable != unreliable) mutable.value = mutable.value.copy(unreliable = unreliable)
    }

    private fun displayRotation(): Int =
        displays?.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: 0

    private fun lowPass(target: FloatArray, input: FloatArray, initialized: Boolean) {
        for (i in 0..2) target[i] = if (initialized) target[i] + 0.2f * (input[i] - target[i]) else input[i]
    }
}
