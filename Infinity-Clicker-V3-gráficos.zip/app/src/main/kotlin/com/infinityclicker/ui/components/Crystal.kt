package com.infinityclicker.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import kotlin.math.abs
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.TapResult
import com.infinityclicker.ui.theme.Neon
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.min
import kotlin.math.sin

/**
 * Cristal 3D em Canvas: facetas em perspectiva, bordas especulares, núcleo volumétrico e órbitas.
 * Os cinco estilos alteram a geometria real (quantidade de faces/anel/núcleo), sem bitmap externo.
 */
@Composable
fun CrystalArea(
    tier: Int,
    crystalStyle: Int,
    baseColor: Color,
    comboFraction: Float,
    effectsIntensity: Float,
    particleLimit: Int,
    quality: GraphicsQuality,
    hapticsEnabled: Boolean,
    motionEnabled: Boolean,
    formatGain: (TapResult) -> String,
    onTap: () -> TapResult?,
    fleetSize: Int = 0,
    modifier: Modifier = Modifier
) {
    val field = remember(particleLimit) { ParticleField(particleLimit.coerceIn(24, 260)) }
    // O detector de toque só reinicia quando as chaves mudam: lambdas lidos por estado não ficam velhos.
    val currentOnTap by rememberUpdatedState(onTap)
    val currentFormatGain by rememberUpdatedState(formatGain)
    // Corpo-mola do cristal (balança ao toque) e simulação das naves: estado mutável, lido só no desenho.
    val body = remember { CrystalBody() }
    val sim = remember { FleetSim() }
    val textMeasurer = rememberTextMeasurer(cacheSize = 32)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val press = remember { Animatable(1f) }
    val ticker = LocalFrameTicker.current
    val detail = quality.detail
    // Frota decorativa (só visual): cresce com os geradores comprados; a quantidade visível respeita a qualidade gráfica.
    val fleetCap = when (detail) { 0 -> 6; 1 -> 12; 2 -> 20; else -> 28 }
    val fleetAnim = animateFloatAsState(
        if (motionEnabled) fleetSize.coerceIn(0, fleetCap).toFloat() else 0f, tween(700), label = "fleet"
    )
    // Brushes/efeitos criados uma vez por cor: criar um Brush por quadro gera um shader nativo novo a cada desenho.
    val gfx = remember(baseColor) { CrystalGfx(baseColor) }
    val bigStyle = remember { TextStyle(color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
    val smallStyle = remember { TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }

    LaunchedEffect(field, motionEnabled) { if (!motionEnabled) { field.clear(); body.reset(); sim.reset() } }

    Box(
        modifier = modifier.pointerInput(field, effectsIntensity, baseColor, crystalStyle, motionEnabled, hapticsEnabled) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    for (change in event.changes) {
                        if (!change.changedToDown()) continue
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = min(size.width, size.height) * 0.31f
                        if (hypot(change.position.x - center.x, change.position.y - center.y) > radius * 1.45f) continue
                        change.consume()
                        val result = currentOnTap()
                        if (result != null && hapticsEnabled) {
                            Haptics.play(context, if (result.crit) HapticKind.HEAVY else HapticKind.CLICK)
                        }
                        scope.launch {
                            press.snapTo(0.84f)
                            press.animateTo(1f, spring(dampingRatio = 0.34f, stiffness = Spring.StiffnessMedium))
                        }
                        if (result != null && motionEnabled) {
                            // Chute físico: o cristal é empurrado para longe do dedo e ganha torque conforme o lado tocado.
                            val dx = center.x - change.position.x
                            val dy = center.y - change.position.y
                            val dl = hypot(dx, dy).coerceAtLeast(1f)
                            body.kick(dx / dl, dy / dl, if (result.crit) 430f else 250f,
                                (change.position.x - center.x) / radius * if (result.crit) 5f else 3f)
                        }
                        if (result != null) {
                            val color = if (result.crit) Neon.Gold else baseColor
                            if (motionEnabled) {
                                field.burst(change.position, color, (12 * effectsIntensity).toInt().coerceAtLeast(3), result.crit)
                                field.floatText(change.position - Offset(0f, radius * 0.34f), (if (result.crit) "CRÍTICO! +" else "+") + currentFormatGain(result), color, result.crit)
                                if (!result.bossDamage.isZero) field.floatText(change.position + Offset(0f, radius * 0.20f), "−${currentFormatGain(result.copy(gain = result.bossDamage))}", Neon.Pink, false)
                            }
                        }
                    }
                }
            }
        }
    ) {
        // graphicsLayer isola a camada: sem ela, cada quadro invalidava (e regravava) a tela inteira.
        Canvas(Modifier.fillMaxSize().graphicsLayer { }) {
            // O relógio é lido só no desenho: a cena anima no ritmo do limite de FPS sem recompor nada.
            val nanos = ticker.value
            val spin = if (motionEnabled) phaseOf(nanos, 13_000L) else 0f
            val bob = if (motionEnabled) phaseOf(nanos, 4_100L) else 0f
            val pulse = if (motionEnabled) 0.91f + 0.09f * cos(phaseOf(nanos, 4_400L)) else 1f
            if (motionEnabled) {
                field.setBounds(size.width, size.height)
                field.stepTo(nanos)
                body.stepTo(nanos)
            }
            val center = Offset(size.width / 2f + body.ox, size.height / 2f + sin(bob) * size.height * 0.016f + body.oy)
            val radius = min(size.width, size.height) * 0.29f * press.value
            val flash = ((1f - press.value) / 0.16f).coerceIn(0f, 1f)
            if (flash > 0f) unitDisc(gfx.flash, center.x, center.y, radius * 1.9f, flash)
            if (flash > 0f) drawTapRefraction(center, radius, baseColor, flash, detail)
            val fleet = fleetAnim.value
            val orbitR = min(size.width, size.height) * 0.29f
            if (motionEnabled && detail >= 1) drawEnergyPulse(center, radius, nanos, baseColor)
            if (fleet > 0.01f && motionEnabled) sim.step(nanos, center, orbitR, fleet, field, body)
            if (fleet > 0.01f && motionEnabled) with(sim) { drawShips(baseColor, false) }
            drawCrystalScene(gfx, center, radius, spin + body.angle, pulse, comboFraction, baseColor, crystalStyle, tier, detail, if (motionEnabled) nanos else 0L)
            if (fleet > 0.01f && motionEnabled) with(sim) { drawShips(baseColor, true) }
            field.draw(this)
            field.forEachText { x, y, text, color, alpha, big, pop ->
                // Estilo fixo (cache de layout do TextMeasurer acerta); cor, alfa e "pop" elástico vão no desenho.
                val layout = textMeasurer.measure(text, if (big) bigStyle else smallStyle)
                withTransform({ scale(pop, pop, Offset(x, y)) }) {
                    drawText(layout, color = color, topLeft = Offset(x - layout.size.width / 2f, y - layout.size.height / 2f), alpha = alpha)
                }
            }
        }
    }
}

private const val U = 1000f
private const val FACET_STEPS = 256
/** Dois anéis de energia que nascem no cristal e se expandem, em laço contínuo (fase periódica: sem emenda). */
private fun DrawScope.drawEnergyPulse(center: Offset, r: Float, nanos: Long, base: Color) {
    val t = nanos / 1_000_000_000.0
    for (k in 0 until 2) {
        val p = ((t / 3.6) + k * 0.5) % 1.0
        val ease = (1.0 - (1.0 - p) * (1.0 - p)).toFloat()
        val a = ((1.0 - p) * (1.0 - p)).toFloat()
        drawCircle(base.copy(alpha = 0.20f * a), r * (1.25f + ease * 1.9f), center, style = Stroke(width = 1f + 2.4f * a))
    }
}

/** Refração curta no exato toque: anéis e raios existem só durante o retorno da mola do cristal. */
private fun DrawScope.drawTapRefraction(center: Offset, r: Float, base: Color, flash: Float, detail: Int) {
    val progress = 1f - flash
    val radius = r * (1.08f + progress * 1.18f)
    val alpha = flash * flash
    drawCircle(base.copy(alpha = 0.32f * alpha), radius, center, style = Stroke(width = 4.5f * alpha + 1f))
    drawCircle(Color.White.copy(alpha = 0.42f * alpha), radius * 0.78f, center, style = Stroke(width = 1.2f + alpha))
    if (detail >= 1) {
        val ray = r * (0.82f + progress * 0.42f)
        repeat(4) { index ->
            val a = index * (PI.toFloat() / 2f) + progress * 0.36f
            val inner = Offset(center.x + cos(a) * r * 0.24f, center.y + sin(a) * r * 0.24f)
            val outer = Offset(center.x + cos(a) * ray, center.y + sin(a) * ray)
            drawLine(Color.White.copy(alpha = 0.28f * alpha), inner, outer, 1.4f + alpha)
        }
    }
}

/** Brushes em "espaço unitário" (centro 0,0, raio 1000): são movidos/escalados por transformação, nunca recriados. */
private class CrystalGfx(base: Color) {
    val halo = Brush.radialGradient(listOf(base, Color.Transparent), Offset.Zero, U)
    val bloom = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.05f), base.copy(alpha = 0.10f), Color.Transparent), Offset.Zero, U)
    val flash = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.40f), base.copy(alpha = 0.22f), Color.Transparent), Offset.Zero, U)
    val pool = Brush.radialGradient(listOf(base.copy(alpha = 0.34f), base.copy(alpha = 0.10f), Color.Transparent), Offset.Zero, U)
    val spec = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.72f), base.copy(alpha = 0.35f), Color.Transparent), Offset.Zero, U)
    val streak = Brush.horizontalGradient(listOf(Color.Transparent, base.copy(alpha = 0.85f), Color.White, base.copy(alpha = 0.85f), Color.Transparent), -U, U)
    val core = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), base.copy(alpha = 0.52f), Color.Transparent), Offset.Zero, U)

    // Cor das facetas por luz (0..1), tabelada uma vez por cor-base. O `lerp` de cor do Compose converte para Oklab a cada
    // chamada (objetos de conversão + pow/cbrt) e rodava 14× por quadro (2 + uma por lado). A tabela tem 256 amostras
    // calculadas com o mesmo `lerp`; o erro máximo é menos de meio nível de 8 bits (medido em simulação: 0,45).
    private val facetRamp = FloatArray(FACET_STEPS * 4).also { ramp ->
        val dark = lerp(base, Color(0xFF030411), 0.78f)
        val bright = lerp(base, Color.White, 0.64f)
        for (k in 0 until FACET_STEPS) {
            val c = lerp(dark, bright, k / (FACET_STEPS - 1).toFloat())
            ramp[k * 4] = c.red; ramp[k * 4 + 1] = c.green; ramp[k * 4 + 2] = c.blue; ramp[k * 4 + 3] = c.alpha
        }
    }

    /** Cor de preenchimento de uma faceta para a luz [light] (0..1), sem alocar nem converter espaço de cor. */
    fun facet(light: Float): Color {
        val i = (light.coerceIn(0f, 1f) * (FACET_STEPS - 1) + 0.5f).toInt() * 4
        return Color(facetRamp[i], facetRamp[i + 1], facetRamp[i + 2], facetRamp[i + 3])
    }

    private var tickEffect: PathEffect? = null
    private var tickRadius = -1f

    /** Anel tracejado (marcas de relógio) para o raio dado; só recria se o raio mudou mais de 2 px. */
    fun ticks(radius: Float, count: Int): PathEffect {
        val cached = tickEffect
        if (cached != null && abs(radius - tickRadius) < 2f) return cached
        val gap = (2f * PI.toFloat() * radius / count - 2.5f).coerceAtLeast(3f)
        return PathEffect.dashPathEffect(floatArrayOf(2.5f, gap)).also { tickEffect = it; tickRadius = radius }
    }
}

private inline fun DrawScope.unitDisc(brush: Brush, cx: Float, cy: Float, radius: Float, alpha: Float) {
    withTransform({ translate(cx, cy); scale(radius / U, radius / U, Offset.Zero) }) { drawCircle(brush, U, Offset.Zero, alpha) }
}

/**
 * Reaproveita objetos Path entre quadros: o cristal montava ~40 Paths nativos por quadro (≈5 mil/s a 120 fps),
 * gerando coleta de lixo e alocação nativa. O desenho roda numa só thread, e cada Path só vive dentro do quadro.
 */
private class PathPool {
    private val items = ArrayList<Path>()
    private var used = 0
    fun reset() { used = 0 }
    fun next(): Path {
        val p = if (used < items.size) items[used] else Path().also { items += it }
        used++
        p.rewind()
        return p
    }
}

private val pathPool = PathPool()

/** Scratch reutilizado entre quadros para o cálculo das facetas (evita ~50 alocações por desenho). */
private class FacetScratch {
    val ringX = FloatArray(24)
    val ringY = FloatArray(24)
    val z = FloatArray(24)
    val light = FloatArray(24)
    val order = IntArray(24)
}
private val facetScratch = FacetScratch()

/**
 * Planos internos fixos, alinhados à lapidação externa. Diferente de riscos aleatórios, eles fazem o cristal parecer
 * um prisma cortado e polido: cada face aponta para a mesma fonte de luz e a leitura continua limpa em movimento.
 */
private fun DrawScope.drawCutPlanes(
    center: Offset, r: Float, top: Offset, bottom: Offset, halfWidth: Float, waistY: Float, base: Color, detail: Int
) {
    val crown = Offset(center.x, center.y - r * 0.54f)
    val left = Offset(center.x - halfWidth * 0.56f, waistY - r * 0.02f)
    val right = Offset(center.x + halfWidth * 0.56f, waistY - r * 0.02f)
    val heart = Offset(center.x, center.y + r * 0.05f)
    val lower = Offset(center.x, center.y + r * 0.56f)
    val lowerLeft = Offset(center.x - halfWidth * 0.34f, center.y + r * 0.32f)
    val lowerRight = Offset(center.x + halfWidth * 0.34f, center.y + r * 0.32f)

    val leftPlane = pathPool.next().apply {
        moveTo(crown.x, crown.y); lineTo(left.x, left.y); lineTo(heart.x, heart.y); close()
    }
    val rightPlane = pathPool.next().apply {
        moveTo(crown.x, crown.y); lineTo(heart.x, heart.y); lineTo(right.x, right.y); close()
    }
    val core = pathPool.next().apply {
        moveTo(crown.x, crown.y); lineTo(right.x, right.y); lineTo(lower.x, lower.y); lineTo(left.x, left.y); close()
    }
    val lowerPlane = pathPool.next().apply {
        moveTo(heart.x, heart.y); lineTo(lowerRight.x, lowerRight.y); lineTo(lower.x, lower.y); lineTo(lowerLeft.x, lowerLeft.y); close()
    }

    drawPath(leftPlane, Color.White.copy(alpha = 0.075f))
    drawPath(rightPlane, base.copy(alpha = 0.105f))
    drawPath(core, base.copy(alpha = 0.085f))
    drawPath(lowerPlane, Color.White.copy(alpha = 0.070f))
    drawPath(core, Color.White.copy(alpha = 0.16f), style = Stroke(1.0f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawLine(Color.White.copy(alpha = 0.24f), crown, heart, 1.0f, StrokeCap.Round)
    if (detail >= 3) {
        drawLine(base.copy(alpha = 0.33f), heart, lower, 1.25f, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.18f), left, lowerLeft, 0.85f, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.15f), right, lowerRight, 0.85f, StrokeCap.Round)
    }
    // Mantém os extremos vinculados à silhueta para a forma continuar equilibrada em todos os estilos.
    if (detail >= 3) drawLine(Color.White.copy(alpha = 0.12f), top, bottom, 0.7f, StrokeCap.Round)
}

/** Brilhos em cruz que piscam sobre as facetas (refração de luz), cada um no próprio ritmo. */
private fun DrawScope.drawGlints(center: Offset, r: Float, nanos: Long, base: Color, count: Int) {
    if (nanos == 0L) return
    val t = nanos / 1_000_000_000.0
    for (i in 0 until count) {
        val period = 2.4 + (i % 4) * 0.7
        val ph = ((t / period) + i * 0.37) % 1.0
        val tw = if (ph < 0.22) sin(ph / 0.22 * PI).toFloat() else 0f
        if (tw <= 0.02f) continue
        val seed = i * 2.399963f
        val dist = r * (0.15f + 0.62f * (((i * 53) % 100) / 100f))
        val x = center.x + cos(seed) * dist
        val y = center.y + sin(seed) * dist * 0.92f
        val len = r * (0.10f + 0.06f * (i % 3)) * tw
        val c = Color.White.copy(alpha = 0.85f * tw)
        val soft = c.copy(alpha = c.alpha * 0.5f)
        drawCircle(base.copy(alpha = 0.30f * tw), len * 0.9f, Offset(x, y))
        drawLine(c, Offset(x - len, y), Offset(x + len, y), 1.6f, StrokeCap.Round)
        drawLine(c, Offset(x, y - len), Offset(x, y + len), 1.6f, StrokeCap.Round)
        drawLine(soft, Offset(x - len * 0.5f, y - len * 0.5f), Offset(x + len * 0.5f, y + len * 0.5f), 1.1f, StrokeCap.Round)
        drawLine(soft, Offset(x - len * 0.5f, y + len * 0.5f), Offset(x + len * 0.5f, y - len * 0.5f), 1.1f, StrokeCap.Round)
    }
}

private fun DrawScope.drawCrystalScene(
    gfx: CrystalGfx, center: Offset, r: Float, spin: Float, pulse: Float, combo: Float, base: Color, style: Int, tier: Int, detail: Int, nanos: Long
) {
    pathPool.reset()
    val twoPi = 2f * PI.toFloat()
    val halo = r * (2.15f + combo * 0.6f)
    // 1) Raios de luz girando devagar atrás do cristal (um único Path, uma única chamada de desenho).
    if (detail >= 1) {
        val rays = if (detail >= 2) 14 else 8
        val path = pathPool.next()
        for (i in 0 until rays) {
            val a = spin * 0.55f + i * twoPi / rays
            val len = r * (2.35f + (i % 3) * 0.32f) * (0.92f + 0.08f * pulse)
            val w = 0.045f + (i % 2) * 0.02f
            path.moveTo(center.x, center.y)
            path.lineTo(center.x + cos(a - w) * len, center.y + sin(a - w) * len * 0.92f)
            path.lineTo(center.x + cos(a + w) * len, center.y + sin(a + w) * len * 0.92f)
            path.close()
        }
        drawPath(path, base.copy(alpha = 0.055f + combo * 0.07f))
    }
    // 2) Halo e bloom.
    unitDisc(gfx.halo, center.x, center.y, halo, (0.26f + combo * 0.26f) * pulse)
    if (detail >= 2) unitDisc(gfx.bloom, center.x, center.y, halo * 1.3f, pulse)
    // Anel de marcas girando e arco de combo: o combo ganha um medidor circular que acende em volta do cristal.
    if (detail >= 1) {
        val tickR = r * 1.66f
        if (detail >= 2) rotate(spin * 57.3f * 0.8f, center) {
            drawCircle(base.copy(alpha = 0.30f), tickR, center, style = Stroke(width = 4f, pathEffect = gfx.ticks(tickR, 72)))
        }
        val arcR = r * 1.56f
        val arcTop = Offset(center.x - arcR, center.y - arcR)
        val arcSize = Size(arcR * 2f, arcR * 2f)
        drawArc(Color.White.copy(alpha = 0.07f), 0f, 360f, false, arcTop, arcSize, style = Stroke(3.5f))
        if (combo > 0.01f) {
            drawArc(base.copy(alpha = 0.22f), -90f, 360f * combo, false, arcTop, arcSize, style = Stroke(9f, cap = StrokeCap.Round))
            drawArc(Color.White.copy(alpha = 0.85f), -90f, 360f * combo, false, arcTop, arcSize, style = Stroke(3f, cap = StrokeCap.Round))
        }
    }
    // 3) Pedestal de vidro com anéis de energia que se expandem.
    if (detail >= 1) drawPedestal(gfx, center, r, base, nanos, detail)
    // 4) Anel orbital: metade de trás antes do cristal, metade da frente depois.
    if (detail >= 1) drawOrbitRing(center, r, spin, base, back = true, style = style)
    if (style >= 2 && detail >= 1) drawOrbits(center, r, spin, base, style)
    drawFacetedCrystal(gfx, center, r, spin, base, style, tier, detail, nanos)
    if (detail >= 2) drawGlints(center, r, nanos, base, if (detail >= 3) 8 else 5)
    // Faixa de luz horizontal (estilo lente anamórfica): cresce e brilha conforme o combo sobe.
    if (detail >= 2) {
        val fl = r * (2.5f + combo * 1.3f)
        val fa = (0.10f + combo * 0.24f) * pulse
        withTransform({ translate(center.x, center.y); scale(fl / U, 1f, Offset.Zero) }) {
            drawRect(gfx.streak, Offset(-U, -1.1f), Size(2f * U, 2.2f), alpha = fa)
            drawRect(gfx.streak, Offset(-U, -4f), Size(2f * U, 8f), alpha = fa * 0.30f)
        }
    }
    if (detail >= 1) drawOrbitRing(center, r, spin, base, back = false, style = style)
    // 5) Fagulhas subindo do pedestal.
    if (detail >= 2) drawMotes(center, r, base, nanos, if (detail >= 3) 18 else 11)
    if (detail >= 3) { // Ultra: faíscas orbitando o cristal
        repeat(8) { i ->
            val a = spin * (1.6f + i * 0.11f) + i * (twoPi / 8f)
            val rr = r * (1.35f + 0.12f * (i % 3))
            drawCircle(Color.White.copy(alpha = 0.55f), 2.2f + (i % 3), Offset(center.x + cos(a) * rr, center.y + sin(a) * rr * 0.45f))
        }
    }
}

private fun DrawScope.drawPedestal(gfx: CrystalGfx, center: Offset, r: Float, base: Color, nanos: Long, detail: Int) {
    val cy = center.y + r * 1.34f
    val w = r * 1.95f
    val h = r * 0.46f
    // Poça de luz projetada pelo cristal.
    withTransform({ translate(center.x, cy); scale(w / U, w / U, Offset.Zero) }) {
        drawOval(gfx.pool, Offset(-U, -U * 0.236f), Size(U * 2f, U * 0.472f))
    }
    // Disco de vidro.
    drawOval(Color.White.copy(alpha = 0.055f), topLeft = Offset(center.x - w * 0.62f, cy - h * 0.62f), size = Size(w * 1.24f, h * 1.24f))
    drawOval(Color.White.copy(alpha = 0.34f),
        topLeft = Offset(center.x - w * 0.62f, cy - h * 0.62f), size = Size(w * 1.24f, h * 1.24f), style = Stroke(1.6f))
    drawOval(base.copy(alpha = 0.40f), topLeft = Offset(center.x - w * 0.46f, cy - h * 0.46f), size = Size(w * 0.92f, h * 0.92f), style = Stroke(1.1f))
    // Sombra de contato: três elipses concêntricas de alfa baixo imitam a penumbra suave sob o cristal flutuando.
    for (k in 0 until 3) {
        val sk = 1f - k * 0.24f
        drawOval(Color.Black.copy(alpha = 0.15f), topLeft = Offset(center.x - w * 0.30f * sk, cy - h * 0.27f * sk), size = Size(w * 0.60f * sk, h * 0.54f * sk))
    }
    // Reflexo no vidro polido: a ponta do cristal toca primeiro o chão e abre para baixo; recortado pelo disco.
    if (detail >= 2) {
        val disc = pathPool.next().apply { addOval(Rect(center.x - w * 0.62f, cy - h * 0.62f, center.x + w * 0.62f, cy + h * 0.62f)) }
        val refl = pathPool.next().apply {
            moveTo(center.x, cy - h * 0.58f); lineTo(center.x - w * 0.21f, cy + h * 0.66f); lineTo(center.x + w * 0.21f, cy + h * 0.66f); close()
        }
        clipPath(disc) {
            drawPath(refl, base.copy(alpha = 0.17f))
            drawPath(refl, Color.White.copy(alpha = 0.10f), style = Stroke(1.2f))
        }
    }
    if (nanos > 0L) repeat(if (detail >= 2) 2 else 1) { k ->
        val p = ((nanos / 1_000_000L + k * 1_450L) % 2_900L) / 2_900f
        val sw = w * (0.55f + p * 0.75f)
        val sh = h * (0.55f + p * 0.75f)
        drawOval(base.copy(alpha = (1f - p) * 0.38f), topLeft = Offset(center.x - sw, cy - sh), size = Size(sw * 2f, sh * 2f), style = Stroke(1.5f))
    }
}

/** Anel inclinado com pontos luminosos; `back` desenha o arco de trás (acima do centro) ou o da frente. */
private fun DrawScope.drawOrbitRing(center: Offset, r: Float, spin: Float, base: Color, back: Boolean, style: Int) {
    val a = r * 1.95f
    val b = r * 0.46f
    val tilt = -13f
    rotate(tilt, center) {
        drawArc(
            if (back) base.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.50f),
            startAngle = if (back) 180f else 0f, sweepAngle = 180f, useCenter = false,
            topLeft = Offset(center.x - a, center.y - b), size = Size(a * 2f, b * 2f), style = Stroke(if (back) 1.2f else 2.0f)
        )
        val dots = if (style == 4) 4 else 3
        for (i in 0 until dots) {
            val th = spin * 2.1f + i * (2f * PI.toFloat() / dots)
            val sy = sin(th)
            if ((sy < 0f) != back) continue
            val pos = Offset(center.x + cos(th) * a, center.y + sy * b)
            // Rastro de cometa: três pontos que ficam para trás, cada vez menores e mais apagados.
            for (k in 1..3) {
                val t2 = th - k * 0.17f
                val s2 = sin(t2)
                if ((s2 < 0f) != back) continue
                val f = 1f - k * 0.25f
                drawCircle(base.copy(alpha = 0.30f * f), 6f * f + 1f, Offset(center.x + cos(t2) * a, center.y + s2 * b))
            }
            drawCircle(base.copy(alpha = 0.28f), 9f, pos)
            drawCircle(Color.White.copy(alpha = 0.95f), 3.2f, pos)
        }
    }
}

private fun DrawScope.drawMotes(center: Offset, r: Float, base: Color, nanos: Long, count: Int) {
    val ms = nanos / 1_000_000L
    for (i in 0 until count) {
        val cycle = 5_200L + (i % 5) * 700L
        val p = ((ms + i * 977L) % cycle) / cycle.toFloat()
        val x = center.x + sin(i * 2.4f + p * 3.1f) * r * (0.55f + (i % 4) * 0.28f)
        val y = center.y + r * 1.30f - p * r * 2.9f
        val fade = sin(p * PI.toFloat())
        val c = if (i % 3 == 0) Color.White else base
        val size = 1.4f + (i % 3) * 0.9f
        drawCircle(c.copy(alpha = fade * 0.18f), size * 3.2f, Offset(x, y))
        drawCircle(c.copy(alpha = fade * 0.85f), size, Offset(x, y))
    }
}

private fun DrawScope.drawOrbits(center: Offset, r: Float, spin: Float, color: Color, style: Int) {
    repeat(if (style == 4) 3 else 1) { i ->
        val scale = 1f + i * 0.18f
        val tilt = 0.34f + i * 0.08f
        val rect = Rect(center.x - r * 1.18f * scale, center.y - r * tilt, center.x + r * 1.18f * scale, center.y + r * tilt)
        drawArc(color.copy(alpha = 0.30f - i * 0.06f), startAngle = (spin * 57.3f + i * 70f), sweepAngle = 210f,
            useCenter = false, topLeft = rect.topLeft, size = rect.size, style = Stroke(width = 1.6f))
    }
}

private fun DrawScope.drawFacetedCrystal(gfx: CrystalGfx, center: Offset, r: Float, spin: Float, base: Color, style: Int, tier: Int, detail: Int, nanos: Long) {
    val sides = when (style) { 0 -> 6; 1 -> 8; 2 -> 10; 3 -> 4; else -> 12 }
    val elongation = when (style) { 1 -> 1.25f; 3 -> 0.88f; 4 -> 1.08f; else -> 1f }
    val ringRadius = r * when (style) { 3 -> 0.92f; 4 -> 0.72f; else -> 0.82f }
    val top = Offset(center.x, center.y - r * 1.08f * elongation)
    val bottom = Offset(center.x, center.y + r * 1.18f * elongation)
    val ringY = center.y - r * 0.04f
    val squash = if (style == 3) 0.38f else 0.29f

    // Sem alocação por quadro: anéis, profundidades e luz vivem num scratch reutilizado.
    // As faces de cada lado compartilham a mesma profundidade z, então ordenar os lados por z
    // e desenhar topo+base consecutivos reproduz exatamente a ordem do painter's algorithm anterior.
    val sc = facetScratch
    val stepA = 2f * PI.toFloat() / sides
    for (i in 0 until sides) {
        val a = spin + i * stepA
        sc.ringX[i] = center.x + cos(a) * ringRadius
        sc.ringY[i] = ringY + sin(a) * ringRadius * squash
        val angle = spin + (i + 0.5f) * stepA
        sc.z[i] = sin(angle)
        sc.light[i] = 0.42f + 0.58f * cos(angle - 5.25f)
        sc.order[i] = i
    }
    // Ordenação própria (selection sort): n <= 12 e IntArray não tem sort com comparador.
    for (a in 0 until sides - 1) {
        var m = a
        for (b in a + 1 until sides) if (sc.z[sc.order[b]] < sc.z[sc.order[m]]) m = b
        if (m != a) { val tmp = sc.order[a]; sc.order[a] = sc.order[m]; sc.order[m] = tmp }
    }
    for (oi in 0 until sides) {
        val i = sc.order[oi]
        val j = (i + 1) % sides
        val p1x = sc.ringX[i]; val p1y = sc.ringY[i]
        val p2x = sc.ringX[j]; val p2y = sc.ringY[j]
        val z = sc.z[i]
        val fill = gfx.facet(sc.light[i])
        val topPath = pathPool.next().apply { moveTo(top.x, top.y); lineTo(p1x, p1y); lineTo(p2x, p2y); close() }
        val bottomPath = pathPool.next().apply { moveTo(bottom.x, bottom.y); lineTo(p2x, p2y); lineTo(p1x, p1y); close() }
        drawPath(topPath, fill.copy(alpha = if (z > 0f) 0.91f else 0.91f * 0.45f))
        drawPath(bottomPath, fill.copy(alpha = if (z > 0f) 0.82f else 0.82f * 0.45f))
        if (detail >= 1) {
            val strokeAlpha = if (z > 0f) 0.52f else 0.15f
            drawPath(topPath, Color.White.copy(alpha = strokeAlpha), style = Stroke(width = 1.45f))
            drawPath(bottomPath, Color.White.copy(alpha = strokeAlpha * 0.72f), style = Stroke(width = 1.45f))
        }
    }
    // Chanfro: triângulo menor e mais claro dentro de cada face da frente dá relevo de lapidação.
    if (detail >= 2) for (i in 0 until sides) {
        val p1 = Offset(sc.ringX[i], sc.ringY[i]); val p2 = Offset(sc.ringX[(i + 1) % sides], sc.ringY[(i + 1) % sides])
        val z = sin(spin + (i + 0.5f) * (2f * PI.toFloat() / sides))
        if (z <= 0.05f) continue
        val light = (0.42f + 0.58f * cos(spin + (i + 0.5f) * (2f * PI.toFloat() / sides) - 5.25f)).coerceIn(0f, 1f)
        val gx = (top.x + p1.x + p2.x) / 3f; val gy = (top.y + p1.y + p2.y) / 3f
        fun lerpPt(a: Offset) = Offset(gx + (a.x - gx) * 0.55f, gy + (a.y - gy) * 0.55f)
        val a = lerpPt(top); val b = lerpPt(p1); val c = lerpPt(p2)
        drawPath(pathPool.next().apply { moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); close() }, Color.White.copy(alpha = 0.10f + 0.20f * light * z))
    }
    // Uma única silhueta é usada pelas camadas internas: evita recriar paths e mantém cada plano dentro do cristal.
    val silhouette = pathPool.next().apply {
        moveTo(top.x, top.y); lineTo(center.x + ringRadius, ringY); lineTo(bottom.x, bottom.y); lineTo(center.x - ringRadius, ringY); close()
    }
    // Transmissão de luz: a cor do cristal se acumula na parte de baixo, como luz atravessando um sólido translúcido.
    // Recortado pela silhueta para não vazar para fora do vidro.
    if (detail >= 1) {
        clipPath(silhouette) { unitDisc(gfx.pool, center.x, center.y + r * 0.46f, r * 0.80f, 0.62f) }
        // Luz-chave do alto à esquerda: a aresta voltada para ela fica mais clara (reflexo de Fresnel na borda).
        drawLine(Color.White.copy(alpha = 0.55f), top, Offset(center.x - ringRadius, ringY), 2.4f, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.22f), Offset(center.x - ringRadius, ringY), bottom, 1.8f, StrokeCap.Round)
        // Aresta oposta na sombra: um fio escuro separa o cristal do fundo e aumenta o contraste.
        drawLine(Color.Black.copy(alpha = 0.28f), top, Offset(center.x + ringRadius, ringY), 1.6f, StrokeCap.Round)
    }
    // Lapidação interna simétrica: substitui as inclusões aleatórias por planos que acompanham a geometria da gema.
    if (detail >= 2) clipPath(silhouette) { drawCutPlanes(center, r, top, bottom, ringRadius, ringY, base, detail) }
    // Núcleo interno e reflexo especular: duas camadas dão volume sem blur caro.
    unitDisc(gfx.spec, center.x - r * 0.22f, center.y - r * 0.30f, r * 0.52f, 1f)
    if (detail >= 1) drawPath(pathPool.next().apply {
        moveTo(top.x, top.y + r * 0.12f); lineTo(center.x - r * 0.16f, center.y - r * 0.12f); lineTo(center.x - r * 0.03f, center.y - r * 0.47f); close()
    }, Color.White.copy(alpha = 0.46f))
    // Faixa de brilho que varre o cristal de tempos em tempos, recortada pela silhueta.
    if (detail >= 2 && nanos > 0L) {
        val cycle = 5_500L
        val p = ((nanos / 1_000_000L) % cycle) / cycle.toFloat()
        if (p < 0.38f) {
            val q = p / 0.38f
            val x = center.x - r * 1.2f + q * r * 2.4f
            clipPath(silhouette) {
                val band = pathPool.next().apply {
                    moveTo(x - r * 0.10f, top.y); lineTo(x + r * 0.10f, top.y)
                    lineTo(x + r * 0.10f - r * 0.5f, bottom.y); lineTo(x - r * 0.10f - r * 0.5f, bottom.y); close()
                }
                drawPath(band, Color.White.copy(alpha = 0.34f * sin(q * PI.toFloat())))
            }
        }
    }
    if (style == 4 || tier >= 5) {
        unitDisc(gfx.core, center.x, center.y, r * 0.52f, 1f)
    }
    // Uma borda única e precisa parece lapidação real; a faixa colorida larga dá presença sem o aspecto de contorno desenhado à mão.
    if (detail >= 2) {
        drawPath(silhouette, base.copy(alpha = 0.28f), style = Stroke(4.0f, join = StrokeJoin.Round))
        drawPath(silhouette, Color.White.copy(alpha = 0.58f), style = Stroke(1.25f, join = StrokeJoin.Round))
    }
}
