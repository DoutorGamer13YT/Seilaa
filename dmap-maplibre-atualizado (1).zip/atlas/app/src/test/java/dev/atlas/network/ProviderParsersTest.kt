package dev.atlas.network

import dev.atlas.core.*
import org.junit.Assert.*
import org.junit.Test

class ProviderParsersTest {
    @Test fun photonPreservesOsmIdentityAndCoordinatesInsteadOfMatchingNames() {
        val places = ProviderParsers.photon("""{"features":[
            {"geometry":{"type":"Point","coordinates":[-46.6559,-23.5614]},"properties":{"osm_type":"W","osm_id":123,"name":"Museu","street":"Avenida Paulista","housenumber":"1578","city":"São Paulo","osm_key":"tourism","osm_value":"museum"}},
            {"geometry":{"type":"Point","coordinates":[-43.18,-22.90]},"properties":{"osm_type":"N","osm_id":123,"name":"Museu","osm_key":"tourism","osm_value":"museum"}}
        ]}""")
        assertEquals(2, places.size)
        assertEquals("way:123", places[0].id)
        assertEquals("node:123", places[1].id)
        assertEquals(Coordinate(-23.5614, -46.6559), places[0].coordinate)
        assertEquals("Avenida Paulista, 1578, São Paulo", places[0].address)
        assertNull(places[0].phone)
        assertNull(places[0].openingHours)
    }

    @Test fun photonRejectsInvalidCoordinatesAndDeduplicatesOnlyOsmIdentity() {
        val feature = """{"geometry":{"type":"Point","coordinates":[10,20]},"properties":{"osm_type":"N","osm_id":10,"name":"A"}}"""
        val invalid = """{"geometry":{"type":"Point","coordinates":[10,91]},"properties":{"osm_type":"N","osm_id":11,"name":"B"}}"""
        assertEquals(1, ProviderParsers.photon("""{"features":[$feature,$feature,$invalid]}""").size)
    }

    @Test fun overpassReadsCenterContactAndDoesNotTrustWebsiteSchemes() {
        val places = ProviderParsers.overpass("""{"elements":[
          {"type":"way","id":42,"center":{"lat":-23.55,"lon":-46.63},"tags":{"name":"Café","amenity":"cafe","contact:phone":"+55 11 1234","website":"javascript:alert(1)","opening_hours":"Mo-Fr 09:00-17:00"}},
          {"type":"node","id":43,"lat":-23.56,"lon":-46.64,"tags":{"name":"Hospital","amenity":"hospital","website":"https://example.org/"}}
        ]}""")
        assertEquals("way:42", places[0].id)
        assertEquals("Cafés", places[0].category)
        assertEquals("+55 11 1234", places[0].phone)
        assertEquals("Mo-Fr 09:00-17:00", places[0].openingHours)
        assertNull(places[0].website)
        assertEquals("https://example.org/", places[1].website)
    }

    @Test fun overpassResourceErrorIsNotAnEmptySuccessfulSearch() {
        val error = assertThrows(AppException::class.java) { ProviderParsers.overpass("""{"elements":[],"remark":"runtime error: timeout"}""") }
        assertEquals(ErrorKind.PROVIDER, error.kind)
    }

    @Test fun categoriesGenerateBoundedWhitelistedQueries() {
        assertEquals(20, PlaceCategory.entries.size)
        PlaceCategory.entries.forEach { category ->
            val query = ProviderParsers.nearbyQuery(category, Coordinate(12.5, -30.25))
            assertTrue(query.contains("around:3000,12.5,-30.25"))
            assertTrue(query.endsWith("out center tags 60;"))
            assertFalse(query.contains("[\"shop\"=\"*\"]"))
        }
    }

    @Test fun osrmPreservesRealRouteTotalsAndManeuvers() {
        val routes = RoutingParsers.osrm(OSRM, listOf(Coordinate(52.5, 13.4), Coordinate(52.6, 13.5)))
        assertEquals(1234.5, routes.single().distanceMeters, 0.0)
        assertEquals(300.0, routes.single().durationSeconds, 0.0)
        assertEquals(Coordinate(52.5, 13.4), routes.single().geometry[0])
        assertEquals("Vire à direita em Rua B", routes.single().steps[1].instruction)
        assertEquals("Você chegou ao destino", routes.single().steps.last().instruction)
        assertEquals(3, routes.single().steps.size)
        assertEquals(TransportMode.CAR, routes.single().mode)
        assertEquals(2, routes.single().waypoints.size)
    }

    @Test fun osrmNoRouteAndBadGeometryFailExplicitly() {
        assertEquals(ErrorKind.NO_ROUTE, assertThrows(AppException::class.java) {
            RoutingParsers.osrm("""{"code":"NoRoute","message":"impossible"}""", emptyList())
        }.kind)
        assertEquals(ErrorKind.PROVIDER, assertThrows(AppException::class.java) {
            RoutingParsers.osrm(OSRM.replace("[13.4,52.5]", "[13.4,999]"), emptyList())
        }.kind)
    }

    @Test fun instructionsUseActualRoundaboutExitAndUTurn() {
        assertEquals("Na rotatória, pegue a 3ª saída em Avenida", RoutingParsers.osrmInstruction("roundabout", "right", "Avenida", 3))
        assertEquals("Faça o retorno", RoutingParsers.osrmInstruction("turn", "uturn", "", 0))
        assertEquals("Entre na rotatória", RoutingParsers.osrmInstruction("roundabout", "", "", 0))
    }

    @Test fun orsKeepsProviderInstructionAndUsesWaypointIndex() {
        val routes = RoutingParsers.ors("""{"features":[{"geometry":{"type":"LineString","coordinates":[[13.4,52.5],[13.5,52.6]]},"properties":{"summary":{"distance":500,"duration":600},"segments":[{"steps":[{"instruction":"Vire à esquerda na Rua A","name":"Rua A","distance":500,"duration":600,"type":0,"way_points":[0,1]},{"instruction":"Chegou ao destino","name":"-","distance":0,"duration":0,"type":10,"way_points":[1,1]}]}]}}]}""", emptyList(), TransportMode.WALK)
        assertEquals("Vire à esquerda na Rua A", routes.single().steps.first().instruction)
        assertEquals(Coordinate(52.6, 13.5), routes.single().steps.last().coordinate)
        assertEquals("arrive", routes.single().steps.last().maneuver)
        assertEquals(TransportMode.WALK, routes.single().mode)
    }

    @Test fun orsNoRouteHasSpecificFailure() {
        assertEquals(ErrorKind.NO_ROUTE, assertThrows(AppException::class.java) {
            RoutingParsers.ors("""{"error":{"code":2009,"message":"Route could not be found"}}""", emptyList(), TransportMode.BIKE)
        }.kind)
    }

    companion object {
        val OSRM = """{"code":"Ok","routes":[{"distance":1234.5,"duration":300,"geometry":{"type":"LineString","coordinates":[[13.4,52.5],[13.45,52.55],[13.5,52.6]]},"legs":[{"summary":"Rua A, Rua B","steps":[{"distance":200,"duration":40,"name":"Rua A","maneuver":{"type":"depart","modifier":"straight","location":[13.4,52.5]}},{"distance":1034.5,"duration":260,"name":"Rua B","maneuver":{"type":"turn","modifier":"right","location":[13.45,52.55]}},{"distance":0,"duration":0,"name":"Rua B","maneuver":{"type":"arrive","location":[13.5,52.6]}}]}]}]}"""
    }
}
