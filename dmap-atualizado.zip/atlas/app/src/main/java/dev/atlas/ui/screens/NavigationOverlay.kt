package dev.atlas.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.*
import dev.atlas.location.NavigationState
import dev.atlas.ui.theme.LocalAtlasColors

@Composable
fun NavigationOverlay(state: NavigationState, units: Units, recalculating: Boolean,
    onStop: () -> Unit, onMute: () -> Unit, onOverview: () -> Unit, onRecenter: () -> Unit,
) {
    val colors = LocalAtlasColors.current
    val progress = state.progress
    val route = state.route
    var confirmEnd by remember { mutableStateOf(false) }
    BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
        val compact = maxHeight < 440.dp
        Surface(Modifier.align(Alignment.TopStart).widthIn(max = if (compact) 300.dp else 580.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp), color = colors.glass, border = BorderStroke(.8.dp, colors.glassBorder), shadowElevation = 8.dp,
        ) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Icon(if (progress?.arrived == true) Icons.Rounded.Flag else maneuverIcon(route?.steps?.getOrNull(progress?.stepIndex ?: 0)?.maneuver ?: "straight"), null, Modifier.size(46.dp), colors.accent)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(when { progress?.arrived == true -> "Você chegou"; state.gpsLost -> "Aguardando GPS"; recalculating -> "Recalculando…"; progress?.offRoute == true -> "Fora da rota"; progress != null -> formatDistance(progress.distanceToManeuverMeters, units); else -> "Preparando navegação" }, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(if (state.gpsLost) state.error ?: "Aguarde um sinal mais preciso." else progress?.instruction ?: "Obtendo sua posição atual…", style = MaterialTheme.typography.bodyLarge, maxLines = 3)
                    if (!state.gpsLost) state.routeError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = colors.danger) }
                }
            }
        }
        Column(Modifier.align(Alignment.CenterEnd), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            dev.atlas.ui.components.CircularMapButton(if (state.muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, if (state.muted) "Ativar instruções por voz" else "Silenciar instruções", onMute)
            dev.atlas.ui.components.CircularMapButton(Icons.Rounded.Route, "Visão geral da rota", onOverview)
            dev.atlas.ui.components.CircularMapButton(Icons.Rounded.MyLocation, "Acompanhar minha localização", onRecenter)
        }
        Surface(Modifier.align(Alignment.BottomStart).widthIn(max = if (compact) 370.dp else 580.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp), color = colors.glass, border = BorderStroke(.8.dp, colors.glassBorder), shadowElevation = 8.dp,
        ) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    NavMetric(if (state.gpsLost) "—" else progress?.let { formatArrival(it.remainingDurationSeconds) } ?: "—", "chegada estimada", Modifier.weight(1f))
                    NavMetric(if (state.gpsLost) "—" else progress?.let { formatDuration(it.remainingDurationSeconds) } ?: "—", "restantes", Modifier.weight(1f))
                    NavMetric(if (state.gpsLost) "—" else progress?.let { formatDistance(it.remainingDistanceMeters, units) } ?: "—", "restantes", Modifier.weight(1f))
                }
                Button(onClick = { if (progress?.arrived == true) onStop() else confirmEnd = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(24.dp), colors = ButtonDefaults.buttonColors(containerColor = colors.danger, contentColor = colors.onDanger)) {
                    Text(if (progress?.arrived == true) "Concluir" else "Encerrar navegação", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
    if (confirmEnd) AlertDialog(onDismissRequest = { confirmEnd = false }, title = { Text("Encerrar navegação?") }, text = { Text("As instruções e o acompanhamento da sua posição serão encerrados.") }, confirmButton = { TextButton(onClick = { confirmEnd = false; onStop() }) { Text("Encerrar") } }, dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Continuar") } })
}
@Composable private fun NavMetric(value: String, label: String, modifier: Modifier) {
    Column(modifier.padding(end = 6.dp)) {
        Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
