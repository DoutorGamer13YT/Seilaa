package dev.atlas

import android.app.Application
import dev.atlas.data.LocalRepository
import dev.atlas.network.RealPlacesRepository
import dev.atlas.network.RealRoutingRepository
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AtlasApplication : Application() {
    val local by lazy { LocalRepository(this) }
    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS).callTimeout(35, TimeUnit.SECONDS).build()
    }
    val places by lazy { RealPlacesRepository(http, BuildConfig.PHOTON_BASE_URL, BuildConfig.OVERPASS_URL) }
    val routing by lazy { RealRoutingRepository(http, BuildConfig.OSRM_BASE_URL, BuildConfig.ORS_BASE_URL, BuildConfig.ORS_API_KEY) }
}
