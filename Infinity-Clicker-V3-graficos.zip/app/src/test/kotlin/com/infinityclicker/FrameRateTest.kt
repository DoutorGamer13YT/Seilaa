package com.infinityclicker

import com.infinityclicker.ui.components.frameDivisor
import org.junit.Assert.assertEquals
import org.junit.Test

class FrameRateTest {
    @Test fun display120() {
        assertEquals(1L, frameDivisor(120f, 120))
        assertEquals(1L, frameDivisor(120f, 90)) // 90 não divide 120: fica a 120, sem quadros irregulares
        assertEquals(2L, frameDivisor(120f, 60))
        assertEquals(4L, frameDivisor(120f, 30))
    }

    @Test fun display60() {
        assertEquals(1L, frameDivisor(60f, 120))
        assertEquals(1L, frameDivisor(60f, 90))
        assertEquals(1L, frameDivisor(60f, 60))
        assertEquals(2L, frameDivisor(60f, 30))
    }

    @Test fun display90() {
        assertEquals(1L, frameDivisor(90f, 90))
        assertEquals(3L, frameDivisor(90f, 30))
    }
}
