package com.infinityclicker.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

internal const val MAX_FLEET = 28
/** Voo do projétil: curto, para o tiro acertar quase junto do disparo (antes eram 0,20 s, o que parecia atraso). */
private const val SHOT_DUR = 0.11f
private const val IMPACT_DUR = 0.24f
/** A nave começa a mirar o cristal um pouco ANTES de atirar, então o nariz já está apontado quando o tiro sai. */
private const val AIM_LEAD = 0.34f
private const val TWO_PI_F = (2.0 * PI).toFloat()

/** Quantas naves aparecem para [totalOwned] geradores: cresce rápido no começo e devagar depois (logarítmico). */
fun fleetSizeFor(totalOwned: Long): Int =
    if (totalOwned <= 0L) 0 else max(1, (ln(1.0 + totalOwned.toDouble()) * 3.0).toInt()).coerceAtMost(MAX_FLEET)

private class ShipSeed(
    val lane: Float, val speed: Float, val dir: Float, val phase: Float,
    val fireEvery: Float, val fireOff: Float, val design: Int
)

/** Parâmetros fixos de cada nave (órbita, velocidade, ritmo de tiro, modelo): a mesma nave sempre se comporta igual. */
private val shipSeeds: List<ShipSeed> = run {
    val rnd = Random(2718)
    List(MAX_FLEET) { i ->
        ShipSeed(
            lane = (i % 4) * 0.30f + rnd.nextFloat() * 0.12f,
            speed = 0.55f + rnd.nextFloat() * 0.65f,
            dir = if (i % 2 == 0) 1f else -1f,
            phase = rnd.nextFloat() * 2f * PI.toFloat(),
            fireEvery = 0.9f + rnd.nextFloat() * 1.6f,
            fireOff = rnd.nextFloat() * 3f,
            design = i % 3
        )
    }
}

/**
 * Três modelos de nave desenhados em "espaço unitário" (nariz em +x, asas em ±y): são montados uma vez
 * e só movidos/girados/escalados por transformação, então não há alocação por quadro.
 */
private object ShipShapes {
    private fun poly(vararg v: Float): Path = Path().apply {
        moveTo(v[0], v[1])
        var k = 2
        while (k < v.size) { lineTo(v[k], v[k + 1]); k += 2 }
        close()
    }

    /** Polígono espelhado em y (para asas e cascos simétricos). */
    private fun mirrored(vararg v: Float): Path {
        val m = FloatArray(v.size) { if (it % 2 == 1) -v[it] else v[it] }
        return Path().apply {
            addPath(poly(*v))
            addPath(poly(*m))
        }
    }

    val hull = arrayOf(
        // Caça: nariz afilado, fuselagem fina.
        poly(1.0f, 0f, 0.35f, 0.16f, -0.35f, 0.22f, -0.70f, 0.12f, -0.70f, -0.12f, -0.35f, -0.22f, 0.35f, -0.16f),
        // Interceptador: agulha longa.
        poly(1.15f, 0f, 0.20f, 0.12f, -0.60f, 0.15f, -0.60f, -0.15f, 0.20f, -0.12f),
        // Canhoneira: casco largo.
        poly(0.85f, 0f, 0.30f, 0.25f, -0.50f, 0.30f, -0.70f, 0.15f, -0.70f, -0.15f, -0.50f, -0.30f, 0.30f, -0.25f)
    )
    val wings = arrayOf(
        mirrored(0.25f, 0.14f, -0.55f, 0.95f, -0.80f, 0.95f, -0.55f, 0.20f),
        mirrored(0.30f, 0.10f, -0.75f, 0.80f, -0.75f, 0.15f),
        mirrored(0.10f, 0.25f, -0.20f, 0.80f, -0.65f, 0.80f, -0.50f, 0.25f)
    )
    /** Metade de cima do casco, mais clara: simula a luz vindo de cima. */
    val light = arrayOf(
        poly(1.0f, 0f, 0.35f, 0.16f, -0.35f, 0.22f, -0.70f, 0.12f, -0.70f, 0f),
        poly(1.15f, 0f, 0.20f, 0.12f, -0.60f, 0.15f, -0.60f, 0f),
        poly(0.85f, 0f, 0.30f, 0.25f, -0.50f, 0.30f, -0.70f, 0.15f, -0.70f, 0f)
    )
    val noseX = floatArrayOf(1.0f, 1.15f, 0.85f)
    val engineX = floatArrayOf(-0.70f, -0.60f, -0.70f)
    val engineHalf = floatArrayOf(0.10f, 0.07f, 0.09f)
    val engineY = arrayOf(floatArrayOf(0f), floatArrayOf(-0.10f, 0.10f), floatArrayOf(-0.17f, 0.17f))
    val canopy = arrayOf(floatArrayOf(0.28f, 0.30f, 0.15f), floatArrayOf(0.40f, 0.36f, 0.10f), floatArrayOf(0.30f, 0.28f, 0.16f))
    val tipX = floatArrayOf(-0.68f, -0.75f, -0.60f)
    val tipY = floatArrayOf(0.95f, 0.80f, 0.80f)
    /** Canhões nas asas: x0, y0, x1 (y simétrico). O interceptador não tem. */
    val guns = arrayOf(floatArrayOf(-0.25f, 0.70f, 0.35f), floatArrayOf(), floatArrayOf(0.50f, 0.80f, 1.0f))
}

/**
 * Simulação das naves: cada uma é uma partícula presa à sua órbita por uma mola amortecida (com
 * velocidade antecipada, então não "arrasta" atrás da órbita), tem inércia, vira o nariz com suavidade,
 * inclina nas curvas, leva coice ao atirar e entra no campo por um "warp" vindo de fora.
 * Tiros são projéteis reais (saem do nariz, viajam e acertam o ponto da borda do cristal visado no disparo);
 * o impacto solta faíscas na física de partículas e empurra levemente o cristal.
 */
internal class FleetSim {
    private val px = FloatArray(MAX_FLEET)
    private val py = FloatArray(MAX_FLEET)
    private val vx = FloatArray(MAX_FLEET)
    private val vy = FloatArray(MAX_FLEET)
    private val heading = FloatArray(MAX_FLEET)
    private val bank = FloatArray(MAX_FLEET)
    private val grows = FloatArray(MAX_FLEET)
    private val depths = FloatArray(MAX_FLEET)
    private val isFront = BooleanArray(MAX_FLEET)
    private val alive = BooleanArray(MAX_FLEET)
    private val lastCycle = FloatArray(MAX_FLEET)
    private val muzzle = FloatArray(MAX_FLEET)
    private val impact = FloatArray(MAX_FLEET)
    private val shotActive = BooleanArray(MAX_FLEET)
    private val boltP = FloatArray(MAX_FLEET)
    private val bsx = FloatArray(MAX_FLEET)
    private val bsy = FloatArray(MAX_FLEET)
    private val bex = FloatArray(MAX_FLEET)
    private val bey = FloatArray(MAX_FLEET)

    private var active = 0
    private var shipScale = 1f
    private var radius = 1f
    private var lastNanos = -1L

    private val flame = Path()

    // Cores derivadas da cor-base. O `lerp` de cor do Compose converte para Oklab (cria objetos de conversão e faz
    // pow/cbrt) e antes rodava 3× por nave por quadro (+1 por passada). Agora só é refeito quando a cor-base muda;
    // o resultado é exatamente o mesmo, só calculado uma vez.
    private var shadeBase = Color.Unspecified
    private var hullColor = Color.Unspecified
    private var wingColor = Color.Unspecified
    private var edgeColor = Color.Unspecified
    private var boltColor = Color.Unspecified

    private fun updateShades(base: Color) {
        if (base == shadeBase) return
        shadeBase = base
        hullColor = lerp(Color(0xFF283049), base, 0.20f)
        wingColor = lerp(Color(0xFF1A2036), base, 0.34f)
        edgeColor = lerp(base, Color.White, 0.55f)
        boltColor = lerp(base, Color.White, 0.35f)
    }

    fun reset() {
        for (i in 0 until MAX_FLEET) { alive[i] = false; shotActive[i] = false; muzzle[i] = 0f; impact[i] = 0f }
        lastNanos = -1L
        active = 0
    }

    private fun angDiff(to: Float, from: Float): Float {
        var d = (to - from) % TWO_PI_F
        if (d > PI.toFloat()) d -= TWO_PI_F
        if (d < -PI.toFloat()) d += TWO_PI_F
        return d
    }

    fun step(nanos: Long, center: Offset, r: Float, fleet: Float, field: ParticleField, body: CrystalBody) {
        val dt = if (lastNanos >= 0L && nanos > lastNanos) ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f) else 0f
        lastNanos = nanos
        val t = nanos / 1_000_000_000.0
        active = ceil(fleet.toDouble()).toInt().coerceIn(0, MAX_FLEET)
        radius = r
        shipScale = r * 0.155f / (1f + active * 0.012f)

        for (i in 0 until active) {
            val seed = shipSeeds[i]
            val w = seed.dir * seed.speed * 0.39
            val a = (seed.phase + w * t) % (2.0 * PI)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val ro = r * (1.95f + seed.lane)
            val tx = center.x + ca * ro
            val ty = center.y + sa * ro * 0.5f
            val wf = w.toFloat()
            val tvx = -sa * ro * wf
            val tvy = ca * ro * 0.5f * wf
            isFront[i] = sa >= 0f
            depths[i] = 0.82f + 0.22f * sa
            grows[i] = (fleet - i).coerceIn(0f, 1f)
            val cycle = ((t + seed.fireOff) % seed.fireEvery).toFloat()

            if (!alive[i]) {
                // Entrada em "warp": nasce longe, na direção radial, e é puxada para a órbita pela mola.
                val ox = tx - center.x
                val oy = ty - center.y
                val ol = hypot(ox, oy).coerceAtLeast(1f)
                px[i] = tx + ox / ol * r * 2.4f
                py[i] = ty + oy / ol * r * 1.2f
                vx[i] = -ox / ol * r * 3f
                vy[i] = -oy / ol * r * 1.5f
                heading[i] = atan2(-oy, -ox)
                bank[i] = 0f
                lastCycle[i] = cycle
                shotActive[i] = false
                muzzle[i] = 0f
                impact[i] = 0f
                alive[i] = true
            }

            // Mola amortecida com antecipação da velocidade do alvo (ζ ≈ 0.7).
            var rem = dt
            while (rem > 0f) {
                val h = min(rem, 0.016f)
                vx[i] += (70f * (tx - px[i]) + 11.5f * (tvx - vx[i])) * h
                vy[i] += (70f * (ty - py[i]) + 11.5f * (tvy - vy[i])) * h
                px[i] += vx[i] * h
                py[i] += vy[i] * h
                rem -= h
            }

            // Mira: durante o tiro o nariz aponta para o cristal; no cruzeiro, para onde está indo.
            var dx = center.x - px[i]
            var dy = center.y - py[i]
            val len = hypot(dx, dy).coerceAtLeast(1f)
            dx /= len; dy /= len
            val aiming = (cycle > seed.fireEvery - AIM_LEAD || cycle < SHOT_DUR + 0.10f) && grows[i] > 0.6f
            val speed = hypot(vx[i], vy[i])
            val desired = if (aiming) atan2(dy, dx) else if (speed > 8f) atan2(vy[i], vx[i]) else heading[i]
            val turnK = if (aiming) 18f else 6f
            val diff = angDiff(desired, heading[i])
            val blend = 1f - exp(-turnK * dt)
            heading[i] += diff * blend
            // Inclinação lateral proporcional à velocidade angular de giro.
            val rate = if (dt > 0f) diff * blend / dt else 0f
            bank[i] += ((rate / 6f).coerceIn(-1f, 1f) - bank[i]) * (1f - exp(-8f * dt))

            // Disparo: ao virar o ciclo, sai um projétil do nariz em direção ao ponto visado da borda do cristal.
            if (grows[i] > 0.6f) {
                if (cycle < lastCycle[i]) {
                    val design = seed.design
                    val noseLen = ShipShapes.noseX[design] * shipScale * depths[i]
                    // O tiro sai do nariz de verdade (na direção em que a nave aponta) e vai ao ponto da borda do cristal.
                    val nx = px[i] + cos(heading[i]) * noseLen
                    val ny = py[i] + sin(heading[i]) * noseLen
                    var ax = center.x - nx
                    var ay = center.y - ny
                    val al = hypot(ax, ay).coerceAtLeast(1f)
                    ax /= al; ay /= al
                    bsx[i] = nx
                    bsy[i] = ny
                    bex[i] = center.x - ax * r * 0.80f
                    bey[i] = center.y - ay * r * 0.80f
                    shotActive[i] = true
                    boltP[i] = 0f
                    muzzle[i] = 1f
                    // Coice: a nave é empurrada para trás e depois a mola a traz de volta.
                    vx[i] -= dx * r * 0.8f
                    vy[i] -= dy * r * 0.8f
                }
                if (shotActive[i]) {
                    if (cycle >= SHOT_DUR) {
                        shotActive[i] = false
                        impact[i] = 1f
                        field.sparks(Offset(bex[i], bey[i]), -dx, -dy, Color.White, 5)
                        body.kick(dx, dy, 9f, 0f)
                    } else {
                        boltP[i] = (cycle / SHOT_DUR).coerceIn(0f, 1f)
                    }
                }
            }
            lastCycle[i] = cycle
            if (muzzle[i] > 0f) muzzle[i] = max(0f, muzzle[i] - dt * 9f)
            if (impact[i] > 0f) impact[i] = max(0f, impact[i] - dt / IMPACT_DUR)
        }
        for (i in active until MAX_FLEET) alive[i] = false
    }

    /**
     * [front] = false desenha as naves de trás antes do cristal; true, as da frente. Tiros e impactos de TODAS as naves
     * saem na passada da frente, por cima do cristal: antes, o tiro de uma nave de trás sumia atrás do cristal e
     * parecia que ela atirava no vazio (ou atrasado).
     */
    fun DrawScope.drawShips(base: Color, front: Boolean) {
        val t = lastNanos / 1_000_000_000.0
        updateShades(base)
        val bolt = boltColor
        for (i in 0 until active) {
            if (!alive[i]) continue
            val grow = grows[i]
            val depth = depths[i]
            val s = shipScale * depth * grow
            if (s < 1.2f) continue
            val alpha = (0.6f + 0.4f * depth.coerceAtMost(1f)) * grow
            val x = px[i]
            val y = py[i]

            if (isFront[i] == front) {
                val speed = hypot(vx[i], vy[i])
                val thrust = (speed / (radius * 1.3f)).coerceIn(0.25f, 1.4f)
                val design = shipSeeds[i].design

                // Rastro de movimento (espaço de tela), atrás da nave.
                drawLine(
                    base.copy(alpha = 0.20f * alpha * thrust.coerceAtMost(1f)),
                    Offset(x, y), Offset(x - vx[i] * 0.07f, y - vy[i] * 0.07f), s * 0.35f, StrokeCap.Round
                )

                val headingDeg = heading[i] * (180f / PI.toFloat())
                val squash = 1f - 0.22f * abs(bank[i])
                withTransform({
                    translate(x, y)
                    rotate(headingDeg, Offset.Zero)
                    scale(s, s * squash, Offset.Zero)
                }) {
                    drawShipBody(design, base, alpha, thrust, t, i, muzzle[i])
                }
            }
            if (!front) continue

            // Projétil de plasma: halo largo, miolo colorido, núcleo branco, cabeça com clarão em cruz e cauda longa.
            if (shotActive[i]) {
                val p = boltP[i]
                val hx = bsx[i] + (bex[i] - bsx[i]) * p
                val hy = bsy[i] + (bey[i] - bsy[i]) * p
                val q = (p - 0.55f).coerceAtLeast(0f)
                val tx = bsx[i] + (bex[i] - bsx[i]) * q
                val ty = bsy[i] + (bey[i] - bsy[i]) * q
                val bw = s * 0.22f
                drawLine(base.copy(alpha = 0.26f * alpha), Offset(tx, ty), Offset(hx, hy), bw * 3.6f, StrokeCap.Round)
                drawLine(bolt.copy(alpha = 0.70f * alpha), Offset(tx, ty), Offset(hx, hy), bw * 1.8f, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.98f * alpha), Offset(tx, ty), Offset(hx, hy), bw, StrokeCap.Round)
                drawCircle(base.copy(alpha = 0.50f * alpha), bw * 2.8f, Offset(hx, hy))
                drawCircle(Color.White.copy(alpha = alpha), bw * 1.2f, Offset(hx, hy))
                val fl = bw * 4.2f
                drawLine(Color.White.copy(alpha = 0.55f * alpha), Offset(hx - fl, hy), Offset(hx + fl, hy), bw * 0.35f, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = 0.55f * alpha), Offset(hx, hy - fl), Offset(hx, hy + fl), bw * 0.35f, StrokeCap.Round)
            }
            // Impacto no cristal: clarão, anel de choque que se expande e brilho no ponto atingido.
            if (impact[i] > 0f) {
                val k = impact[i]
                val q = 1f - k
                val c = Offset(bex[i], bey[i])
                drawCircle(bolt.copy(alpha = k * 0.35f * alpha), radius * (0.02f + q * 0.07f), c)
                drawCircle(bolt.copy(alpha = k * 0.85f * alpha), radius * (0.03f + q * 0.10f), c, style = Stroke(width = (2.2f * k + 0.5f)))
                drawCircle(Color.White.copy(alpha = k * alpha), radius * 0.028f * k + 1f, c)
            }
        }
    }

    /** Desenha a nave no espaço unitário (já girado/escalado pelo chamador). */
    private fun DrawScope.drawShipBody(design: Int, base: Color, alpha: Float, thrust: Float, t: Double, i: Int, muzzleAmt: Float) {
        updateShades(base)
        val hull = hullColor.copy(alpha = alpha)
        val wing = wingColor.copy(alpha = alpha)
        val edge = edgeColor
        val flick = (0.82f + 0.18f * sin((t * 41.0 + i * 1.7).toFloat()))
        val len = (0.35f + 0.60f * thrust) * flick

        // 1) Chamas dos motores (atrás de tudo).
        val ex = ShipShapes.engineX[design]
        val hw = ShipShapes.engineHalf[design]
        for (ey in ShipShapes.engineY[design]) {
            drawCircle(base.copy(alpha = 0.26f * alpha), hw * 3.4f, Offset(ex - 0.03f, ey))
            flame.rewind()
            flame.moveTo(ex, ey - hw); flame.lineTo(ex - len, ey); flame.lineTo(ex, ey + hw); flame.close()
            drawPath(flame, base.copy(alpha = 0.60f * alpha))
            flame.rewind()
            flame.moveTo(ex, ey - hw * 0.5f); flame.lineTo(ex - len * 0.55f, ey); flame.lineTo(ex, ey + hw * 0.5f); flame.close()
            drawPath(flame, Color.White.copy(alpha = 0.92f * alpha))
        }

        // 2) Asas, casco, luz de cima e contorno brilhante.
        drawPath(ShipShapes.wings[design], wing)
        drawPath(ShipShapes.wings[design], edge.copy(alpha = 0.55f * alpha), style = Stroke(width = 0.045f))
        drawPath(ShipShapes.hull[design], hull)
        drawPath(ShipShapes.light[design], Color.White.copy(alpha = 0.13f * alpha))
        drawPath(ShipShapes.hull[design], edge.copy(alpha = 0.70f * alpha), style = Stroke(width = 0.04f))

        // 3) Cabine (vidro com reflexo).
        val c = ShipShapes.canopy[design]
        drawOval(base.copy(alpha = 0.85f * alpha), Offset(c[0] - c[1] / 2f, -c[2] / 2f), Size(c[1], c[2]))
        drawOval(Color.White.copy(alpha = 0.60f * alpha), Offset(c[0] - c[1] * 0.12f, -c[2] * 0.40f), Size(c[1] * 0.45f, c[2] * 0.40f))

        // 4) Canhões.
        val g = ShipShapes.guns[design]
        if (g.size == 3) {
            drawLine(edge.copy(alpha = 0.85f * alpha), Offset(g[0], g[1]), Offset(g[2], g[1]), 0.07f, StrokeCap.Round)
            drawLine(edge.copy(alpha = 0.85f * alpha), Offset(g[0], -g[1]), Offset(g[2], -g[1]), 0.07f, StrokeCap.Round)
        }

        // 5) Luzes de navegação piscando (vermelha / verde).
        val blink = ((t * 1.6 + i * 0.37) % 1.0) < 0.18
        if (blink) {
            val tx = ShipShapes.tipX[design]
            val ty = ShipShapes.tipY[design]
            drawCircle(Color(0xFFFF4D5A).copy(alpha = 0.35f * alpha), 0.17f, Offset(tx, ty))
            drawCircle(Color(0xFFFF8088).copy(alpha = alpha), 0.065f, Offset(tx, ty))
            drawCircle(Color(0xFF4DFFA0).copy(alpha = 0.35f * alpha), 0.17f, Offset(tx, -ty))
            drawCircle(Color(0xFF9CFFCB).copy(alpha = alpha), 0.065f, Offset(tx, -ty))
        }

        // 6) Clarão de boca de cano ao disparar.
        if (muzzleAmt > 0f) {
            val nx = ShipShapes.noseX[design] + 0.1f
            drawCircle(base.copy(alpha = 0.55f * muzzleAmt * alpha), 0.38f * muzzleAmt, Offset(nx, 0f))
            drawCircle(Color.White.copy(alpha = 0.95f * muzzleAmt * alpha), 0.15f * muzzleAmt + 0.04f, Offset(nx, 0f))
        }
    }
}
