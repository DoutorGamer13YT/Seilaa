package com.w2a.nzuz

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun RegionsPanel(vm: MapViewModel, regions: List<RegionItem>, onNew: () -> Unit, onOpen: (RegionItem) -> Unit, onDelete: (RegionItem) -> Unit) {
    var used by remember { mutableLongStateOf(0) }
    var free by remember { mutableLongStateOf(0) }
    LaunchedEffect(regions) { used = vm.repo.diskBytes(); free = vm.repo.freeBytes() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Mapas offline", style = MaterialTheme.typography.headlineMedium)
        Text("Dados de mapas: ${formatBytes(used)} • Livre: ${formatBytes(free)}", style = MaterialTheme.typography.bodySmall)
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Baixar nova região") }
        if (regions.isEmpty()) Text("Nenhuma região salva. Escolha uma área com internet antes de viajar.")
        regions.forEach { r -> key(r.id) {
            ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(r.name, style = MaterialTheme.typography.titleLarge)
                    Text(r.message, style = MaterialTheme.typography.bodyMedium)
                    Text("${formatBytes(r.bytes)} • ${r.count} recursos salvos", style = MaterialTheme.typography.bodySmall)
                    if (!r.complete) {
                        val fraction = r.fraction
                        if (fraction != null) {
                            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                            Text("${(fraction * 100).toInt()}% • ${r.count}/${r.required} recursos", style = MaterialTheme.typography.labelMedium)
                        } else Text("Total ainda em descoberta; sem percentual disponível.", style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.retryOnline(); vm.action { vm.repo.resume(r.id) } }) { Text("Retomar") }
                            TextButton(onClick = { vm.action { vm.repo.pause(r.id) } }) { Text("Pausar") }
                        }
                    } else Button(onClick = { onOpen(r) }) { Text("Abrir offline") }
                    TextButton(onClick = { onDelete(r) }) { Text(if (r.complete) "Excluir mapa" else "Cancelar e excluir") }
                    Text(r.credit, style = MaterialTheme.typography.labelSmall)
                }
            }
        } }
        Text("Os tiles compartilhados são reutilizados entre regiões. A soma dos tamanhos pode ser maior que o espaço físico usado.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { vm.action { vm.repo.clearCache(); used = vm.repo.diskBytes(); free = vm.repo.freeBytes(); vm.notice.value = "Cache temporário limpo; regiões preservadas." } }, modifier = Modifier.fillMaxWidth()) {
            Text("Limpar cache temporário e compactar")
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SettingsPanel(vm: MapViewModel, settings: AppSettings, count: Int, onNew: () -> Unit, onRegions: () -> Unit) {
    var catalogUrl by rememberSaveable(settings.catalogUrl) { mutableStateOf(settings.catalogUrl) }
    var serviceUrl by rememberSaveable(settings.serviceUrl) { mutableStateOf(settings.serviceUrl) }
    var token by remember(settings.serviceToken) { mutableStateOf(settings.serviceToken) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    var legal by remember { mutableStateOf(false) }
    var style by rememberSaveable(settings.styleUrl) { mutableStateOf(settings.styleUrl) }
    var credit by rememberSaveable(settings.attribution) { mutableStateOf(settings.attribution) }
    var authorized by rememberSaveable(settings.authorized) { mutableStateOf(settings.authorized) }
    var saving by remember { mutableStateOf(false) }
    var sourceMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Configurações", style = MaterialTheme.typography.headlineMedium)
        SettingsCard("Mapas offline") {
            SwitchRow("Usar mapa offline", "Abre somente regiões completas salvas no aparelho", settings.offline) { vm.setMode(it) }
            SwitchRow("Troca automática", "Usa offline sem conexão; volta ao Apple Maps após a rede estabilizar", settings.automatic) { vm.prefs.update(settings.copy(automatic = it)) }
            TextButton(onClick = onNew) { Text("Baixar nova região") }
            TextButton(onClick = onRegions) { Text("Regiões baixadas e armazenamento ($count)") }
            Text("Pesquisa de lugares e cálculo de rotas precisam de internet. O GPS funciona sem internet, dependendo do sinal.", style = MaterialTheme.typography.bodySmall)
        }
        SettingsCard("Preferências de download") {
            SwitchRow("Somente rede sem cobrança", "Wi-Fi ou outra rede que o Android considera não tarifada", settings.wifiOnly) {
                vm.prefs.update(settings.copy(wifiOnly = it))
                vm.notice.value = "A preferência vale para novos downloads. Pause e retome os existentes para aplicá-la."
            }
            Text("Downloads podem ser adiados pelo Android para poupar bateria. Dados parciais são mantidos; use Retomar após uma interrupção.", style = MaterialTheme.typography.bodySmall)
        }
        SettingsCard("Protomaps • distribuição regional") {
            OutlinedTextField(catalogUrl, { catalogUrl = it.trim() }, label = { Text("URL HTTPS do catálogo") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(serviceUrl, { serviceUrl = it.trim() }, label = { Text("Serviço de recortes (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(token, { token = it }, label = { Text("Token do serviço próprio") }, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.action {
                if (catalogUrl.isNotBlank()) SecureHttp.url(catalogUrl)
                if (serviceUrl.isNotBlank()) SecureHttp.url(serviceUrl)
                vm.prefs.update(vm.settings.value.copy(catalogUrl = catalogUrl, serviceUrl = serviceUrl.trimEnd('/'), serviceToken = token))
                if (catalogUrl.isNotBlank()) vm.packages.refreshCatalog()
                vm.notice.value = "Configuração salva."
            } }) { Text("Salvar e atualizar catálogo") }
            Text("Requer distribuição própria configurada. Nenhum servidor de mapas regionais vem habilitado. Os pacotes incluem PMTiles, estilos, fontes e ícones.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { advanced = !advanced }) { Text("Fontes anteriores • avançado") }
        }
        if (advanced) SettingsCard("Fonte dos mapas offline anterior") {
            Text("Use um estilo MapLibre de um servidor próprio ou de um provedor que permita baixar regiões. A autorização deve incluir tiles, fontes e ícones.", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(style, { style = it.trim(); authorized = false; sourceMessage = null }, label = { Text("URL HTTPS do estilo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(credit, { credit = it; authorized = false }, label = { Text("Fonte, atribuição e licença") }, modifier = Modifier.fillMaxWidth())
            SwitchRow("Tenho autorização para baixar", "Confirme os termos do provedor. A licença dos dados não substitui as regras do servidor.", authorized) { authorized = it }
            Button(onClick = {
                val invalid = validateSource(style, credit, authorized)
                if (invalid != null) { sourceMessage = invalid; return@Button }
                val validatedStyle = style
                val validatedCredit = credit
                val validatedAuthorization = authorized
                saving = true; sourceMessage = null
                scope.launch {
                    try {
                        SourceVerifier.verify(validatedStyle)
                        vm.prefs.update(vm.settings.value.copy(styleUrl = validatedStyle, attribution = validatedCredit, authorized = validatedAuthorization))
                        sourceMessage = "Fonte validada e salva. Agora escolha Baixar nova região."
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { sourceMessage = e.message ?: "Não foi possível validar a fonte." } finally { saving = false }
                }
            }, enabled = !saving, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "Validando recursos…" else "Validar e salvar fonte") }
            sourceMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Text("Nenhum mapa da Apple é baixado. Regiões existentes mantêm a fonte original ao alterar esta opção.", style = MaterialTheme.typography.bodySmall)
        }
        SettingsCard("Aparência") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "Sistema", "light" to "Claro", "dark" to "Escuro").forEach { (value, label) ->
                    FilterChip(selected = settings.theme == value, onClick = { vm.prefs.update(settings.copy(theme = value)) }, label = { Text(label) })
                }
            }
            Text("O tema muda a interface e os mapas Protomaps locais. O Apple Maps controla a própria aparência.", style = MaterialTheme.typography.bodySmall)
        }
        SettingsCard("Sobre o Dmap") {
            Text("Dmap 2.1 • @vitinhjkjkk")
            TextButton(onClick = { legal = true }) { Text("Licenças e atribuições") }
            Text("Online: site Apple Maps. Offline: MapLibre Native. Este aplicativo é independente e não é afiliado à Apple.", style = MaterialTheme.typography.bodySmall)
            Text("Sua localização não é enviada pelo modo offline. O modo online e os downloads conectam-se aos respectivos provedores. Dados locais são apagados ao desinstalar ou limpar os dados do app.", style = MaterialTheme.typography.bodySmall)
        }
    }
    if (legal) AlertDialog(onDismissRequest = { legal = false }, title = { Text("Licenças e atribuições") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
            Text("Dados Protomaps: © OpenStreetMap contributors • ODbL 1.0. openstreetmap.org/copyright\nNatural Earth: domínio público.\nDesign Protomaps: CC0; código: BSD-3-Clause.\nFontes Noto: SIL OFL. Ícones: MIT.\nMapLibre Native: BSD-2-Clause.\nAndroidX e Kotlin: Apache-2.0.\nApple Maps online: termos e atribuições do próprio site.")
            val context = androidx.compose.ui.platform.LocalContext.current
            val notices = remember { runCatching { context.assets.open("licenses.txt").bufferedReader().use { it.readText() } }.getOrDefault("") }
            Text(notices, style = MaterialTheme.typography.bodySmall)
        } }, confirmButton = { TextButton(onClick = { legal = false }) { Text("Fechar") } })

}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, description: String, value: Boolean, onValue: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium); Text(description, style = MaterialTheme.typography.bodySmall) }
        Switch(value, onValue)
    }
}
