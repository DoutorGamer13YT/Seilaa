package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.AchievementDefs
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.generators.GeneratorDefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone
import kotlin.random.Random

/** Correções e recursos da versão 3.7: conquista resgatável, dia local, melhor compra e tempo até comprar. */
class V37Test {

    private fun engine(setup: (GameState) -> Unit = {}): GameEngine {
        val s = GameState.new()
        setup(s)
        return GameEngine(s, Random(7)).also { it.recompute(1_700_000_000_000L) }
    }

    @Test
    fun unlockedAchievementStaysClaimableAfterRequirementDrops() {
        val e = engine { it.generators[0] = 30L }
        e.recordAchievementUnlocks(1L)
        assertTrue("owned_25" in e.state.achievementsUnlockedAt)
        e.state.generators[0] = 0L // prestígio zera geradores
        assertTrue(e.canClaimAchievement("owned_25"))
        assertNotNull(e.claimAchievement("owned_25", 2L))
        assertFalse(e.canClaimAchievement("owned_25")) // não resgata duas vezes
    }

    @Test
    fun neverReachedAchievementIsNotClaimable() {
        val e = engine()
        assertFalse(e.canClaimAchievement("owned_25"))
        assertNull(e.claimAchievement("owned_25", 1L))
        assertFalse(e.canClaimAchievement("id_que_nao_existe"))
        assertTrue(AchievementDefs.all.isNotEmpty())
    }

    @Test
    fun dailyResetFollowsDeviceTimezone() {
        val old = TimeZone.getDefault()
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("America/Sao_Paulo"))
            val e = engine()
            // 2026-11-01 23:30 em São Paulo = 02:30 UTC do dia 2: ainda é o mesmo dia local.
            val night = 1_793_586_600_000L
            e.refreshDaily(night)
            val day = e.state.dailyDay
            e.refreshDaily(night + 20 * 60_000L) // 23:50 local
            assertEquals(day, e.state.dailyDay)
            e.refreshDaily(night + 40 * 60_000L) // 00:10 local do dia seguinte
            assertEquals(day + 1, e.state.dailyDay)
        } finally {
            TimeZone.setDefault(old)
        }
    }

    @Test
    fun bestGeneratorIsUnlockedAndHasPositiveGain() {
        val e = engine { it.energy = BigNum.of(1.0e6) }
        val best = e.bestGeneratorId()
        assertNotNull(best)
        assertTrue(e.isGeneratorUnlocked(best!!))
        assertFalse(e.productionGainOfOne(GeneratorDefs.byId(best)).isZero)
    }

    @Test
    fun bestGeneratorBeatsEveryOtherOnPayback() {
        val e = engine { s -> s.generators[0] = 40L; s.generators[1] = 12L; s.generators[2] = 3L }
        val best = e.bestGeneratorId()!!
        fun score(id: Int): Double {
            val def = GeneratorDefs.byId(id)
            val cost = e.planGenerator(def, com.infinityclicker.game.BuyMode.X1).cost
            return (cost / e.productionGainOfOne(def)).log10()
        }
        for (def in GeneratorDefs.all) {
            if (!e.isGeneratorUnlocked(def.id)) continue
            assertTrue("gerador ${def.id} melhor que o escolhido $best", score(best) <= score(def.id) + 1e-9)
        }
    }

    @Test
    fun secondsUntilAffordableCoversAllCases() {
        val e = engine { it.energy = BigNum.of(50.0) }
        assertEquals(0.0, e.secondsUntilAffordable(BigNum.of(10.0))!!, 0.0)
        assertNull(e.secondsUntilAffordable(BigNum.of(1000.0))) // sem produção
        val p = engine { it.generators[0] = 10L; it.energy = BigNum.of(0.0) }
        val secs = p.secondsUntilAffordable(p.production * 100.0)!!
        assertEquals(100.0, secs, 0.5)
    }
}

/** Proteções contra relógio alterado (3.8). */
class V38ClockTest {
    private val t0 = 1_800_000_000_000L
    private val hour = 3_600_000L

    private fun engine(): GameEngine {
        val s = GameState.new()
        s.generators[0] = 10L
        return GameEngine(s, Random(3)).also { it.recompute(t0) }
    }

    @Test
    fun clockRollbackDoesNotGrantOfflineTwice() {
        val e = engine()
        e.state.lastSessionMs = t0
        assertNull(e.applyOffline(t0 - 8 * hour)) // relógio voltou 8 h: nada
        assertEquals(t0, e.state.lastSessionMs)   // marca preservada
        e.touchSession(t0 - 8 * hour)             // salvamento com relógio voltado
        assertEquals(t0, e.state.lastSessionMs)
        assertNull(e.applyOffline(t0))            // hora real de volta: sem ganho
    }

    @Test
    fun farFutureStampIsDroppedSoOfflineDoesNotFreeze() {
        val e = engine()
        e.state.lastSessionMs = t0 + 10 * 24 * hour
        e.touchSession(t0)
        assertEquals(t0, e.state.lastSessionMs)
        assertNotNull(e.applyOffline(t0 + 2 * hour))
    }

    @Test
    fun rollbackDoesNotResetDailyOrLogin() {
        val e = engine()
        val day = 86_400_000L
        assertNotNull(e.claimLogin(t0))
        val claimedDay = e.state.loginClaimedDay
        assertNull(e.claimLogin(t0 - day))        // dia anterior: sem segundo resgate
        assertTrue(e.loginRewardPreview(t0 - day).isZero)
        e.refreshDaily(t0)
        val dd = e.state.dailyDay
        e.state.dailyClaimed[0] = true
        e.refreshDaily(t0 - 2 * day)
        assertEquals(dd, e.state.dailyDay)
        assertTrue(e.state.dailyClaimed[0])
        assertEquals(claimedDay, e.state.loginClaimedDay)
    }
}

class V39ClockTrustTest {
    private val t0 = 1_800_000_000_000L

    @Test
    fun untrustedClockDoesNotAdvanceDailyDay() {
        val s = GameState.new()
        val e = GameEngine(s, Random(5))
        e.refreshDaily(t0)
        val day = s.dailyDay
        e.clockTrusted = false
        e.refreshDaily(t0 + 30L * 86_400_000L) // hora manual mudada para o futuro
        assertEquals(day, s.dailyDay)
        e.clockTrusted = true
        e.refreshDaily(t0 + 86_400_000L)
        assertEquals(day + 1, s.dailyDay)
    }
}

class V310AuroraTest {
    private val t0 = 1_800_000_000_000L

    private fun engine(): GameEngine {
        val s = GameState.new()
        s.generators[0] = 20L
        return GameEngine(s, Random(11)).also { it.recompute(t0) }
    }

    @Test
    fun chanceIsOneThousandthOfAPercentAndRareIsNeverInTheCommonDraw() {
        assertEquals(0.0, engine().auroraChance, 0.0) // desligada por padrão nos testes
        val live = engine().also { it.enableAurora() }
        assertEquals(0.00001, live.auroraChance, 0.0) // 0,001% no jogo real
        assertTrue(com.infinityclicker.game.CosmicEventDefs.all.none { it.rare })
        assertTrue(com.infinityclicker.game.CosmicEventDefs.byId.containsKey(com.infinityclicker.game.CosmicEventDefs.AURORA_ID))
    }

    @Test
    fun noAuroraWhenChanceIsZero() {
        val e = engine()
        e.auroraChance = 0.0
        repeat(2000) { e.tap(it * 10L, t0 + it) ; e.advance(1000L, t0 + it) }
        assertNull(e.state.activeEvent)
        assertFalse(e.consumeAuroraTrigger())
    }

    @Test
    fun auroraBoostsEverythingThenEnds() {
        val e = engine()
        val prodBefore = e.production
        val clickBefore = e.clickBase
        val critBefore = e.critChance
        e.auroraChance = 1.0
        e.tap(0L, t0)
        assertEquals(com.infinityclicker.game.CosmicEventDefs.AURORA_ID, e.state.activeEvent?.eventId)
        assertTrue(e.consumeAuroraTrigger())
        assertFalse(e.consumeAuroraTrigger()) // só avisa uma vez
        assertEquals(7.0, (e.production / prodBefore).toDouble(), 0.01)
        assertEquals(5.0, (e.clickBase / clickBefore).toDouble(), 0.01)
        assertTrue(e.critChance > critBefore)
        val endsAt = e.state.activeEvent!!.endsAtMs
        e.tap(10L, t0 + 1000L) // sorteio não reinicia uma Aurora em andamento
        assertEquals(endsAt, e.state.activeEvent!!.endsAtMs)
        e.auroraChance = 0.0
        e.refreshTimedEffects(endsAt + 1L)
        assertNull(e.state.activeEvent)
        assertEquals(prodBefore.toDouble(), e.production.toDouble(), prodBefore.toDouble() * 0.001)
    }

    @Test
    fun auroraSurvivesSaveAndLoad() {
        val e = engine()
        e.startAurora(t0)
        val back = com.infinityclicker.data.StateSerializer.deserialize(com.infinityclicker.data.StateSerializer.serialize(e.state))
        assertNotNull(back)
        assertEquals(com.infinityclicker.game.CosmicEventDefs.AURORA_ID, back!!.activeEvent?.eventId)
    }
}
