package com.infinityclicker.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.SpaceBackground
import com.infinityclicker.ui.components.rememberFrameTicker
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.screens.DeveloperScreen
import com.infinityclicker.ui.screens.DimensionsScreen
import com.infinityclicker.ui.screens.HomeScreen
import com.infinityclicker.ui.screens.MissionsScreen
import com.infinityclicker.ui.screens.ProfileScreen
import com.infinityclicker.ui.screens.ShopScreen
import com.infinityclicker.ui.theme.InfinityTheme
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val tabs = listOf("Início", "Loja", "Dimensões", "Missões", "Perfil", "Dev")
private val tabIcons = listOf("✦", "◈", "◎", "✧", "◉", "✪")

@Composable
fun GameApp(vm: GameViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val background = ui.backgrounds.firstOrNull { it.equipped }?.def
    val currentTint = background?.tintColor ?: ui.dimensions.firstOrNull { it.current }?.def?.tintColor ?: Neon.Cyan
    val effectiveQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.exportSaveText()
            if (text != null) {
                scope.launch {
                    val success = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
                                ?: error("Fluxo de saída indisponível")
                        }.isSuccess
                    }
                    vm.reportExportResult(success)
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (text == null) vm.reportImportReadFailure() else vm.importSaveText(text)
            }
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }
    LaunchedEffect(tab) { vm.setActiveTab(tab) }
    val effectiveFps = if (ui.settings.batterySaver) 30 else ui.settings.frameRateCap
    val frameTicker = rememberFrameTicker(effectiveFps)
    LaunchedEffect(effectiveFps) {
        // Pede à tela o modo de exibição mais próximo do limite escolhido. Só preferiremos modos
        // com a mesma resolução; o limite real das animações é aplicado pelo FrameTicker.
        (context as? Activity)?.window?.let { window ->
            val display = window.decorView.display ?: @Suppress("DEPRECATION") window.windowManager.defaultDisplay
            val attrs = window.attributes
            val current = display?.mode
            val candidates = display?.supportedModes?.filter {
                current == null || (it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight)
            }.orEmpty()
            val best = candidates.filter { it.refreshRate >= effectiveFps - 1f }.minByOrNull { it.refreshRate }
                ?: candidates.maxByOrNull { it.refreshRate }
            attrs.preferredDisplayModeId = best?.modeId ?: 0
            attrs.preferredRefreshRate = best?.refreshRate ?: effectiveFps.toFloat()
            window.attributes = attrs
        }
    }
    LaunchedEffect(ui.notice) {
        ui.notice?.let {
            snackbar.showSnackbar(it)
            vm.dismissNotice()
        }
    }

    InfinityTheme {
      CompositionLocalProvider(LocalFrameTicker provides frameTicker) {
        Box(Modifier.fillMaxSize()) {
            SpaceBackground(
                tint = currentTint,
                style = background?.style,
                quality = effectiveQuality,
                motionEnabled = !ui.settings.batterySaver
            )
            if (ui.loaded) {
                Box(Modifier.fillMaxSize().statusBarsPadding().padding(bottom = 88.dp)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            (fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) + slideInHorizontally(spring(stiffness = Spring.StiffnessLow)) { it / 8 }) togetherWith
                                (fadeOut(spring(stiffness = Spring.StiffnessMediumLow)) + slideOutHorizontally(spring(stiffness = Spring.StiffnessLow)) { -it / 10 })
                        }, label = "tabTransition"
                    ) { screen ->
                        when (screen) {
                            0 -> HomeScreen(ui, vm::tap, vm::useAbility)
                            1 -> ShopScreen(ui, vm::setBuyMode, vm::buyGenerator, vm::buyUpgrade)
                            2 -> DimensionsScreen(ui, vm::unlockDimension, vm::travelDimension, vm::buyResonance, vm::startBoss, vm::equipCrystal)
                            3 -> MissionsScreen(ui, vm::claimDaily, vm::claimLogin, vm::claimAchievement, vm::startChallenge, vm::abandonChallenge)
                            5 -> DeveloperScreen(ui)
                            else -> ProfileScreen(
                                ui = ui,
                                onScientific = vm::setScientific,
                                onQuality = vm::setGraphicsQuality,
                                onFrameRate = vm::setFrameRate,
                                onBatterySaver = vm::setBatterySaver,
                                onEffects = vm::setEffectsIntensity,
                                onPanelOpacity = vm::setPanelOpacity,
                                onHaptics = vm::setHaptics,
                                onUpgradeAbility = vm::upgradeAbility,
                                onBuySkill = vm::buySkill,
                                onEquipBackground = vm::equipBackground,
                                onExportSave = { exportLauncher.launch("InfinityClicker-V3.ic-save") },
                                onImportSave = { importLauncher.launch(arrayOf("text/plain", "application/octet-stream")) },
                                onPrestige = vm::prestige,
                                onReset = vm::hardReset
                            )
                        }
                    }
                }
            }
            SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp))
            BottomBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
        }

        ui.offlineReport?.let { r ->
            val sci = ui.settings.scientificNotation
            AlertDialog(
                onDismissRequest = vm::dismissOfflineReport,
                title = { Text("Bem-vindo de volta!") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Tempo ausente: ${NumberFormatter.duration(r.elapsedMs)}")
                        Text("Tempo creditado: ${NumberFormatter.duration(r.creditedMs)}" + if (r.elapsedMs > r.capMs) " (limite de ${NumberFormatter.duration(r.capMs)})" else "")
                        Text("Eficiência offline: ${"%.0f".format(r.efficiency * 100)}%")
                        Text("Multiplicador global: ×${NumberFormatter.format(r.globalMultiplier, sci)}")
                        Text("Produção: ${NumberFormatter.format(r.productionPerSecond, sci)}/s")
                        Text("Energia recebida: ${NumberFormatter.format(r.gain, sci)}", fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = { TextButton(onClick = vm::dismissOfflineReport) { Text("Coletar") } }
            )
        }
      }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth()
            .glass(RoundedCornerShape(30.dp), tint = Neon.Violet, alpha = 0.17f, borderAlpha = 0.52f).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        tabs.forEachIndexed { index, label ->
            val active = index == selected
            Column(
                Modifier.weight(1f).glass(
                    RoundedCornerShape(23.dp), tint = if (active) Neon.Cyan else Color0,
                    alpha = if (active) 0.34f else 0f, borderAlpha = if (active) 0.58f else 0f
                ).clickable { onSelect(index) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(tabIcons[index], fontSize = 18.sp, color = if (active) Neon.Cyan else Neon.TextSecondary)
                Text(label, fontSize = 10.sp, color = if (active) Neon.TextPrimary else Neon.TextSecondary)
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.White
