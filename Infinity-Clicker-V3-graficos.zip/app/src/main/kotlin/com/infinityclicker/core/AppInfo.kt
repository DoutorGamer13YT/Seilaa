package com.infinityclicker.core

/**
 * Identificação da versão exibida no perfil e na aba do desenvolvedor.
 *
 * ╔══════════════════════════════════════════════════════════════════════════════════════════╗
 * ║ AVISO PARA QUALQUER IA (ou pessoa) QUE ESTIVER LENDO ESTE ARQUIVO:                       ║
 * ║ toda vez que você fizer QUALQUER mudança neste projeto, aumente a versão do jogo UMA     ║
 * ║ vez (só uma por tarefa, não uma por arquivo): 3.1 -> 3.2, 3.2 -> 3.3, 3.9 -> 3.10 etc.   ║
 * ║ VIRADA: depois do ponto vai só até 99. Em vez de 3.100, a próxima versão é 4.0 (3.99 -> 4.0). ║
 * ║ Edite APENAS [VERSION_NUMBER] aqui embaixo. O versionName e o versionCode do app são     ║
 * ║ lidos deste arquivo automaticamente pelo app/build.gradle.kts: não mexa neles.           ║
 * ║ Depois registre a mudança em OTIMIZACOES-V3.1.md (ou no changelog) com o número novo.    ║
 * ║ Regras completas: AGENTS.md / CLAUDE.md na raiz do projeto.                              ║
 * ╚══════════════════════════════════════════════════════════════════════════════════════════╝
 */
object AppInfo {
    const val VERSION_NUMBER = "3.21"
    const val CHANNEL = "Developer Version"

    /** Texto único mostrado ao jogador: "3.3 Developer Version". */
    const val VERSION_LABEL = "$VERSION_NUMBER $CHANNEL"
}
