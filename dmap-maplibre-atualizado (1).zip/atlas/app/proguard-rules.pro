# MapLibre ships consumer rules for JNI. Room ships generated implementation rules.
# Keep source line information useful without including personal data in logs.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
