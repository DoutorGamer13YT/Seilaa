package com.w2a.nzuz

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class Connectivity(context: Context) {
    private val manager = context.getSystemService(ConnectivityManager::class.java)
    private val mutable = MutableStateFlow(available())
    val usable = mutable.asStateFlow()
    private fun available(): Boolean {
        val c = manager.getNetworkCapabilities(manager.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { mutable.value = available() }
        override fun onLost(network: Network) { mutable.value = available() }
        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) { mutable.value = available() }
    }
    init { manager.registerDefaultNetworkCallback(callback) }
    fun close() { manager.unregisterNetworkCallback(callback) }
}

class GpsTracker(private val context: Context) : LocationListener {
    private val manager = context.getSystemService(LocationManager::class.java)
    private val point = MutableStateFlow<Location?>(null)
    val location = point.asStateFlow()
    private val message = MutableStateFlow("Ative a localização para mostrar sua posição")
    val status = message.asStateFlow()
    private var started = false
    fun permitted(): Boolean = fine() || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun fine() = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    @Suppress("MissingPermission")
    fun start() {
        if (started || !permitted()) return
        try {
            var count = 0
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (provider == LocationManager.GPS_PROVIDER && !fine()) continue
                if (!manager.isProviderEnabled(provider)) continue
                manager.requestLocationUpdates(provider, 2_000L, 3f, this, Looper.getMainLooper())
                manager.getLastKnownLocation(provider)?.takeIf { android.os.SystemClock.elapsedRealtimeNanos() - it.elapsedRealtimeNanos < 120_000_000_000L }?.let { onLocationChanged(it) }
                count++
            }
            started = count > 0
            message.value = if (started) "Aguardando sinal GPS; tente um local aberto" else "Localização desativada no Android"
        } catch (_: SecurityException) { message.value = "Permissão de localização não concedida" }
    }
    fun stop() {
        manager.removeUpdates(this)
        started = false
    }
    override fun onLocationChanged(location: Location) {
        val old = point.value
        if (old == null || location.elapsedRealtimeNanos - old.elapsedRealtimeNanos > 10_000_000_000L || location.accuracy <= old.accuracy) point.value = location
        message.value = "Precisão ±${location.accuracy.toInt()} m"
    }
    override fun onProviderDisabled(provider: String) { message.value = "Provedor $provider desativado" }
    override fun onProviderEnabled(provider: String) { stop(); start() }
    @Deprecated("Android callback")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
}
