package com.vitinhjkjkk.dmap.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DmapDark = darkColorScheme(
    primary = Color(0xFFA8C7FF),
    onPrimary = Color(0xFF102F57),
    secondary = Color(0xFFB6C8E5),
    background = Color(0xFF101216),
    surface = Color(0xFF1B1F25),
    surfaceVariant = Color(0xFF292E36),
    onSurface = Color(0xFFF0F1F4),
    onSurfaceVariant = Color(0xFFBEC4CE),
)
private val DmapLight = lightColorScheme(
    primary = Color(0xFF315F9E),
    secondary = Color(0xFF4C627E),
    background = Color(0xFFF4F6F8),
    surface = Color.White,
    surfaceVariant = Color(0xFFE6EAF0),
)

@Composable
fun DmapTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DmapDark else DmapLight, content = content)
}
