# Fontes de mapa: Apple online, OpenStreetMap offline

## Regra

`MapSourcePolicy.choose(online, appleAvailable)` decide a fonte. Com internet validada e token configurado, o mapa é o da Apple (`map/AppleMap.kt`). Sem internet, ou se o mapa da Apple falhar, o mapa é o OpenStreetMap (`map/AtlasMap.kt`, MapLibre, estilos `atlas-light.json` e `atlas-dark.json`). A troca é automática, em `ui/screens/MapScreen.kt`, a partir de `ConnectivityObserver.online`. Ao voltar a internet, o app volta para a Apple. Se a Apple falhar com internet (token inválido, bloqueio, tempo esgotado de 15 s), o app fica no OpenStreetMap até a próxima queda de rede.

A câmera (centro, zoom, rotação) é repassada de um mapa para o outro, então a troca não pula a posição.

## Modo visualização (sem token)

Sem `APPLE_MAPKIT_TOKEN`, com internet, o app mostra o site público `https://maps.apple.com` em um `WebView` (`map/AppleWebMap.kt`), só para visualizar. Limites: sem marcadores, rota, bolinha de localização nem bússola do DMap por cima; arrastar o mapa não atualiza o centro usado em "Pesquisar nesta área"; selecionar lugar ou pedir câmera recarrega a página em `?ll=…&z=…`; navegação limitada a domínios da Apple; falha de carregamento cai no OpenStreetMap. Não verificado: se o site da Apple Maps carrega em `WebView` Android e se aceita `ll` e `z`.

## Como o mapa da Apple é exibido com token

Não existe tile público em `maps.apple.com`. O mapa da Apple só é exibido pelo MapKit JS, que exige conta Apple Developer e um token JWT. O app carrega `assets/apple/mapkit.html` em um `WebView` (somente `https`, sem navegação externa) e conversa com ele por `AtlasBridge`. Marcadores, rota, bolinha de localização, precisão, toque em lugar e pressão longa são redesenhados no MapKit JS.

Configuração em `local.properties` ou variável de ambiente:
- `APPLE_MAPKIT_TOKEN`: token JWT do MapKit JS. Vazio = Apple desativada, só OpenStreetMap.
- `APPLE_MAPKIT_ORIGIN`: origem usada como base do `WebView` (padrão `https://localhost`). Deve coincidir com a claim `origin` do token, se houver.

O token fica no APK e é recuperável: restrinja pela origem no token.

## Offline

Só o OpenStreetMap pode ser baixado (`docs/OFFLINE.md`). A tela de mapas offline avisa que o mapa da Apple não é baixado. Os termos do MapKit JS não permitem guardar tiles da Apple.

## Diferenças no modo Apple

- Sem inclinação 3D: o MapKit JS não expõe inclinação; o botão 3D só afeta o OpenStreetMap.
- Estilo e cartografia são os da Apple; o tema claro/escuro segue o do app.
- Pesquisa, detalhes e rotas continuam usando os provedores atuais (`docs/PROVIDERS.md`), não os da Apple.

## Não verificado

Nada foi compilado nem executado. Não testado em aparelho: carregamento do MapKit JS, eventos `scroll-start`, `zoom-start`, `rotation-start`, `rotation-end`, `region-change-end`, `configuration-change`, construtor `mapkit.Padding` com objeto, `setRegionAnimated` e `setRotationAnimated`, e a pressão longa por toque. Sintaxe do JavaScript conferida com `node --check`. `MapSourceTest` escrito e não executado.
