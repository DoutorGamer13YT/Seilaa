plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// AVISO PARA IAs: NÃO edite a versão aqui. Ela é lida de core/AppInfo.kt (VERSION_NUMBER).
// A cada mudança no projeto, aumente VERSION_NUMBER uma vez (3.2 -> 3.3). Veja AGENTS.md.
val appInfoSource = file("src/main/kotlin/com/infinityclicker/core/AppInfo.kt").readText()
val appVersionNumber = Regex("""VERSION_NUMBER\s*=\s*"([0-9.]+)"""").find(appInfoSource)!!.groupValues[1]
val appChannel = Regex("""CHANNEL\s*=\s*"([^"]+)"""").find(appInfoSource)!!.groupValues[1]
// A parte depois do ponto vai só até 99: em vez de 3.100 a versão é 4.0 (3.99 -> 39900, 4.0 -> 40000 continua crescendo).
// 3.3 -> 30300, 3.10 -> 31000, 3.3.1 -> 30301: sempre crescente a cada versão.
val appVersionCode = appVersionNumber.split(".").map { it.toInt() }.let { p ->
    p[0] * 10000 + p.getOrElse(1) { 0 } * 100 + p.getOrElse(2) { 0 }
}

android {
    namespace = "com.infinityclicker"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.infinityclicker"
        minSdk = 29          // Android 10
        targetSdk = 36       // Android 16
        versionCode = appVersionCode
        versionName = "$appVersionNumber $appChannel"
    }

    buildTypes {
        release {
            // R8 + remoção de recursos: menos classes para carregar e código Compose já otimizado.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Assinado com a chave de debug para instalar direto (sem keystore própria). Este é o APK
            // que deve ser usado para jogar: o debug roda o Compose bem mais lento.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    sourceSets {
        getByName("main").java.srcDirs("src/main/kotlin")
        getByName("test").java.srcDirs("src/test/kotlin")
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    // Aplica o perfil de base (src/main/baseline-prof.txt) na instalação: pré-compila o caminho quente do Compose.
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")

    testImplementation("junit:junit:4.13.2")
}
