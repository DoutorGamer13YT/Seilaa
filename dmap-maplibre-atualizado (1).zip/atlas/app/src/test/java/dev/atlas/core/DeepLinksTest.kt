package dev.atlas.core

import org.junit.Assert.*
import org.junit.Test

class DeepLinksTest {
    @Test fun atlasPlaceParsesAnExplicitCoordinateAndUtf8Name() {
        assertEquals(DeepLinkTarget.Pin(Coordinate(-23.55052, -46.633308), "Praça da Sé"),
            DeepLinks.parse("atlas://place?lat=-23.55052&lon=-46.633308&name=Pra%C3%A7a+da+S%C3%A9"))
    }

    @Test fun atlasNavigateSetsIntentWithoutStartingNavigationItself() {
        assertEquals(DeepLinkTarget.Pin(Coordinate(12.0, 34.0), null, navigate = true),
            DeepLinks.parse("atlas://navigate?lat=12&lon=34"))
        assertEquals(DeepLinkTarget.Pin(Coordinate(12.0, 34.0), "Destino", navigate = true),
            DeepLinks.parse("atlas://navigate?lat=12&lon=34&name=Destino"))
    }

    @Test fun searchPreservesLiteralTextAndDoesNotAssignCoordinates() {
        assertEquals(DeepLinkTarget.Search("Rua A, 123"), DeepLinks.parse("atlas://search?q=Rua+A%2C+123"))
        assertEquals(DeepLinkTarget.Search("Café & Cia"), DeepLinks.parse("atlas://search?q=Caf%C3%A9%20%26%20Cia"))
        assertEquals(DeepLinkTarget.Search("Praça"), DeepLinks.parse("atlas://search?q=Praça"))
    }

    @Test fun geoBasePinAndCoordinatesInQueryAreSupported() {
        assertEquals(DeepLinkTarget.Pin(Coordinate(-23.5, -46.6), null), DeepLinks.parse("geo:-23.5,-46.6"))
        assertEquals(DeepLinkTarget.Pin(Coordinate(-23.5, -46.6), "Parque"),
            DeepLinks.parse("geo:0,0?q=-23.5,-46.6(Parque)"))
        assertEquals(DeepLinkTarget.Pin(Coordinate(10.0, 20.0), null), DeepLinks.parse("geo:1e+1,2e+1"))
    }

    @Test fun geoTextQueryIsIndependentFromBaseCoordinate() {
        assertEquals(DeepLinkTarget.Search("Restaurantes"), DeepLinks.parse("geo:-23.5,-46.6?q=Restaurantes"))
        assertEquals(DeepLinkTarget.Search("Rua A, 123"), DeepLinks.parse("geo:0,0?q=Rua+A%2C+123"))
    }

    @Test fun coordinatesMustBeFiniteAndWithinBounds() {
        listOf(
            "atlas://place?lat=NaN&lon=0", "atlas://place?lat=Infinity&lon=0",
            "atlas://place?lat=91&lon=0", "atlas://place?lat=0&lon=-181",
            "atlas://place?lat=1e309&lon=0", "atlas://place?lat=0x1p0&lon=0",
            "atlas://place?lat=1f&lon=0", "geo:91,0", "geo:0,0?q=91,0(label)",
            "geo:0,0?q=NaN,0", "geo:0,0?q=0,Infinity",
        ).forEach { assertNull(it, DeepLinks.parse(it)) }
        assertNotNull(DeepLinks.parse("atlas://place?lat=-90&lon=180"))
    }

    @Test fun missingOrDuplicateParametersAreRejected() {
        listOf(
            "atlas://place?lat=0", "atlas://place?lon=0", "atlas://search", "atlas://search?q=",
            "atlas://search?q=%20%20", "atlas://search?q", "atlas://place?lat=0&lon=0&lat=1",
            "atlas://search?q=a&%71=b", "geo:0,0?q=a&q=b", "geo:0,0?q=a&z=1",
            "atlas://place?lat=0&lon=0&redirect=https%3A%2F%2Fexample.org",
        ).forEach { assertNull(it, DeepLinks.parse(it)) }
    }

    @Test fun queryAndNameLengthLimitsApplyAfterDecoding() {
        assertNotNull(DeepLinks.parse("atlas://search?q=${"a".repeat(200)}"))
        assertNull(DeepLinks.parse("atlas://search?q=${"a".repeat(201)}"))
        assertNotNull(DeepLinks.parse("atlas://place?lat=0&lon=0&name=${"a".repeat(120)}"))
        assertNull(DeepLinks.parse("atlas://place?lat=0&lon=0&name=${"a".repeat(121)}"))
        assertNull(DeepLinks.parse("atlas://place?lat=0&lon=0&name=${"%20".repeat(121)}"))
        assertNull(DeepLinks.parse("geo:0,0?q=0,0(${"a".repeat(121)})"))
        assertNull(DeepLinks.parse("atlas://search?q=${"a".repeat(3_000)}"))
    }

    @Test fun malformedEncodingAndControlCharactersAreRejected() {
        listOf(
            "atlas://search?q=%", "atlas://search?q=%GG", "atlas://search?q=%C0%AF",
            "atlas://search?q=%ED%A0%80", "atlas://search?q=%00", "atlas://search?q=%0D%0A",
            "atlas://search?q=%E2%80%AEexample", "atlas://search?q=a\nb", "atlas://search?q=a\u007fb",
            "atlas://search?q=\uD800", "atlas://search?q=\uDC00",
        ).forEach { assertNull(it, DeepLinks.parse(it)) }
    }

    @Test fun externalSchemesAuthoritiesPathsAndFragmentsCannotMasqueradeAsSupportedLinks() {
        listOf(
            "https://atlas/place?lat=0&lon=0", "javascript:alert(1)", "file:///etc/passwd",
            "intent://place?lat=0&lon=0", "atlas://evil.example/place?lat=0&lon=0",
            "atlas://user@place?lat=0&lon=0", "atlas://place:443?lat=0&lon=0",
            "atlas://place/evil?lat=0&lon=0", "atlas://place?lat=0&lon=0#spoof",
            "atlas:place?lat=0&lon=0", "geo://0,0", "geo:0,0,100", "geo:0,0;u=50",
        ).forEach { assertNull(it, DeepLinks.parse(it)) }
    }

    @Test fun percentEncodedQueryIsDecodedOnce() {
        assertEquals(DeepLinkTarget.Search("%0A"), DeepLinks.parse("atlas://search?q=%250A"))
        assertEquals(DeepLinkTarget.Search("A+B"), DeepLinks.parse("atlas://search?q=A%2BB"))
    }

    @Test fun validUnicodeSurrogatePairsArePreserved() {
        assertEquals(DeepLinkTarget.Search("Café ☕"), DeepLinks.parse("atlas://search?q=Caf%C3%A9+%E2%98%95"))
        assertEquals(DeepLinkTarget.Search("Parque 🌳"), DeepLinks.parse("atlas://search?q=Parque+%F0%9F%8C%B3"))
    }
}
