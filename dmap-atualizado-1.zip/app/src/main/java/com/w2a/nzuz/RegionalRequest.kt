package com.w2a.nzuz

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

suspend fun requestRegion(vm: MapViewModel, name: String, bounds: LatLngBounds, zoom: Int) = withContext(Dispatchers.IO) {
    val settings = vm.settings.value
    require(settings.serviceUrl.isNotBlank() && settings.serviceToken.isNotBlank()) { "Configure o serviço próprio de recortes e seu token em Configurações" }
    SecureHttp.url(settings.serviceUrl)
    require(bounds.longitudeEast - bounds.longitudeWest <= 15 && bounds.latitudeNorth - bounds.latitudeSouth <= 15) { "Reduza a área para no máximo 15° por lado" }
    val id = UUID.randomUUID().toString()
    val json = JSONObject().put("requestId", id).put("name", name.take(120)).put("maxZoom", zoom)
        .put("bounds", JSONArray(listOf(bounds.longitudeWest, bounds.latitudeSouth, bounds.longitudeEast, bounds.latitudeNorth)))
        .put("service", settings.serviceUrl.trimEnd('/')).put("status", "Agendado")
    val dir = File(vm.packages.root, "requests").apply { mkdirs() }
    PackageStore.atomic(File(dir, "$id.json"), json.toString())
    scheduleRequest(vm.getApplication(), id)
    vm.notice.value = "Recorte solicitado. O servidor preparará um pacote real; o tamanho será confirmado antes do download."
}
fun scheduleRequest(context: Context, id: String) {
    WorkManager.getInstance(context).enqueueUniqueWork("prepare-$id", ExistingWorkPolicy.KEEP,
        OneTimeWorkRequestBuilder<PrepareRegionWorker>().setInputData(workDataOf("requestId" to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS).build())
}
class PrepareRegionWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as DmapsApp
        val id = inputData.getString("requestId") ?: return@withContext Result.failure()
        if (!Regex("[a-f0-9-]{36}").matches(id)) return@withContext Result.failure()
        val file = File(app.packages.root, "requests/$id.json")
        var request: JSONObject? = null
        try {
            val j = JSONObject(android.util.AtomicFile(file).openRead().bufferedReader().use { it.readText() }); request = j
            val s = app.prefs.state.value
            val base = j.getString("service")
            require(s.serviceUrl.trimEnd('/') == base && s.serviceToken.isNotBlank()) { "Restaure a configuração do serviço para retomar" }
            val response = SecureHttp.json("$base/requests", s.serviceToken, JSONObject(j.toString()).apply { remove("service"); remove("status"); remove("package") })
            when (response.getString("status")) {
                "ready" -> {
                    val pack = MapPackage(response.getJSONObject("package"))
                    j.put("package", pack.json).put("status", "Pronto; confirme o tamanho para baixar")
                    PackageStore.atomic(file, j.toString()); Result.success()
                }
                "failed" -> { j.put("status", response.optString("error", "Falha ao preparar recorte")); PackageStore.atomic(file, j.toString()); Result.failure() }
                else -> {
                    j.put("status", "Preparando no servidor; sem percentual disponível")
                    PackageStore.atomic(file, j.toString())
                    if (runAttemptCount < 100) Result.retry() else Result.failure()
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
            request?.let { it.put("status", "Preparação interrompida: ${e.message}"); PackageStore.atomic(file, it.toString()) }
            if (runAttemptCount < 10) Result.retry() else Result.failure()
        }
    }
}
