package com.infinityclicker.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import com.infinityclicker.R
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.pow
import kotlin.random.Random

/** Efeitos do jogo. Todos são sintetizados no próprio app: não há arquivos de áudio nem internet. */
enum class Sfx { TAP, CRIT, BUY, ERROR, ABILITY, CLAIM, UNLOCK, BOSS_START, BOSS_DOWN, PRESTIGE, NAV, OFFLINE, COUNT_TICK }

/**
 * Sons sintetizados + trilha ambiente em loop, tocados por um SoundPool (vários sons ao mesmo tempo,
 * baixa latência — importante para toques rápidos). Os WAVs são gerados uma vez no cache do app,
 * em segundo plano, então a abertura do app não espera a síntese.
 */
object SoundFx {
    @Volatile private var sfxEnabled = true
    @Volatile private var musicEnabled = true
    @Volatile private var foreground = false

    private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<Sfx, Int>()
    private val loaded: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    private var musicId = 0
    private var player: MediaPlayer? = null
    private var musicStream = 0
    private var lastTapMs = 0L

    // --- Estado do "diretor" de áudio (lido por duas threads: marcado @Volatile) ---
    @Volatile private var moodIntensity = 0f   // 0..1 vindo do jogo (combo, habilidades)
    @Volatile private var bossActive = false
    @Volatile private var activity = 0f        // sobe a cada toque e decai sozinho: reatividade imediata
    @Volatile private var duck = 0f            // 0..1: quanto a música abaixa para um efeito grande passar
    private val main = Handler(Looper.getMainLooper())
    private var directorRunning = false
    private var musicLevel = 0f                // volume atual do MediaPlayer (suavizado)
    private var lastDirectorMs = 0L
    private var synth: LayerSynth? = null

    /** Idempotente: pode ser chamado a cada onStart. */
    @Synchronized
    fun init(context: Context) {
        if (pool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        sp.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) {
                loaded += id
                if (id == musicId) syncMusic()
            }
        }
        pool = sp
        val dir = File(context.applicationContext.cacheDir, "sfx").apply { mkdirs() }
        Thread({
            runCatching {
                for (sfx in Sfx.entries) {
                    val file = File(dir, "${sfx.name.lowercase()}.wav")
                    writeWav(file, Synth.render(sfx))
                    ids[sfx] = sp.load(file.absolutePath, 1)
                }
            }
            // Música de fundo: faixa real em res/raw (longa demais para o SoundPool), em loop num MediaPlayer.
            runCatching {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
                val mp = MediaPlayer.create(context.applicationContext, R.raw.bg_music, attrs, 0)
                if (mp != null) {
                    mp.isLooping = true
                    mp.setVolume(0f, 0f) // o diretor faz o fade de entrada
                    synchronized(this) { player = mp }
                    syncMusic()
                }
            }
            // Camadas geradas em tempo real (ar, pulso, grave, cintilações): reagem ao jogo.
            runCatching {
                val ls = LayerSynth()
                synchronized(this) { synth = ls }
                ls.start()
                syncMusic()
            }
        }, "sfx-synth").apply { isDaemon = true; start() }
    }

    /** Humor do jogo: [intensity] 0..1 (combo/habilidades) e [boss]. Chamado pela UI quando algo muda. */
    fun setMood(intensity: Float, boss: Boolean) {
        moodIntensity = intensity.coerceIn(0f, 1f)
        bossActive = boss
    }

    fun configure(sfx: Boolean, music: Boolean) {
        sfxEnabled = sfx
        musicEnabled = music
        syncMusic()
    }

    fun setForeground(value: Boolean) {
        foreground = value
        syncMusic()
    }

    /**
     * [pan] -1 (esquerda) .. 1 (direita). Pequenas variações aleatórias de tom e volume evitam o efeito
     * "metralhadora" de sons idênticos; efeitos grandes abaixam a música (ducking) e toques/críticos
     * esquentam as camadas dinâmicas.
     */
    fun play(sfx: Sfx, rate: Float = 1f, volume: Float = 1f, pan: Float = 0f) {
        if (!sfxEnabled) return
        val sp = pool ?: return
        val id = ids[sfx] ?: return
        if (id !in loaded) return
        if (sfx == Sfx.TAP) { // evita "metralhadora" em autoclickers
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastTapMs < 28L) return
            lastTapMs = now
        }
        when (sfx) {
            Sfx.TAP -> activity = min(1f, activity + 0.09f)
            Sfx.CRIT -> { activity = min(1f, activity + 0.30f); synth?.sparkle(3) }
            Sfx.BOSS_START -> duck = 0.55f
            Sfx.BOSS_DOWN, Sfx.PRESTIGE -> { duck = 0.6f; synth?.sparkle(6) }
            Sfx.OFFLINE -> { duck = 0.45f; synth?.sparkle(5) }
            Sfx.CLAIM, Sfx.UNLOCK, Sfx.ABILITY -> { duck = max(duck, 0.25f); synth?.sparkle(2) }
            else -> Unit
        }
        val jitter = if (sfx == Sfx.NAV || sfx == Sfx.COUNT_TICK) 1f else 1f + (rnd.nextFloat() - 0.5f) * 0.05f
        val v = (volume * (0.94f + rnd.nextFloat() * 0.06f)).coerceIn(0f, 1f)
        val p = pan.coerceIn(-1f, 1f)
        // Pan de potência constante simplificado: o lado oposto ao do toque cai até ~35%.
        val l = v * (if (p > 0f) 1f - 0.65f * p else 1f)
        val r = v * (if (p < 0f) 1f + 0.65f * p else 1f)
        sp.play(id, l, r, 1, 0, (rate * jitter).coerceIn(0.5f, 2f))
    }

    private val rnd = Random(System.nanoTime())

    /**
     * Escada pentatônica (Mi menor): o toque sobe pelas notas com o combo e volta a descer,
     * então tocar rápido vira uma melodia em vez de um bipe repetido. Devolve a taxa de reprodução.
     */
    fun tapRate(combo: Int): Float {
        val steps = intArrayOf(0, 3, 5, 7, 10, 12, 10, 7, 5, 3)
        val st = steps[(combo.coerceAtLeast(0) / 2) % steps.size]
        return 2f.pow(st / 12f).coerceIn(0.5f, 2f)
    }

    @Synchronized
    private fun syncMusic() {
        val want = musicEnabled && foreground
        synth?.setActive(want)
        player?.let { mp ->
            runCatching {
                if (want && !mp.isPlaying) { musicLevel = 0f; mp.setVolume(0f, 0f); mp.start() }
            }
        }
        if ((want || musicLevel > 0.001f) && !directorRunning) {
            directorRunning = true
            lastDirectorMs = android.os.SystemClock.elapsedRealtime()
            main.post(directorTick)
        }
    }

    /**
     * Diretor: a cada ~33 ms suaviza o volume da música (fade de entrada/saída em vez de corte seco),
     * aplica o ducking dos efeitos grandes e leva a intensidade para as camadas sintetizadas.
     */
    private val directorTick = object : Runnable {
        override fun run() {
            val now = android.os.SystemClock.elapsedRealtime()
            val dt = ((now - lastDirectorMs) / 1000f).coerceIn(0.001f, 0.2f)
            lastDirectorMs = now
            activity = max(0f, activity - 0.35f * dt)
            duck = max(0f, duck - 0.9f * dt)
            val want = musicEnabled && foreground
            val intensity = max(moodIntensity, activity).coerceIn(0f, 1f)
            // Música base: respira um pouco mais alta com a intensidade e some ao ser ducada.
            val target = if (want) MUSIC_VOLUME * (0.80f + 0.35f * intensity) * (1f - 0.7f * duck) else 0f
            val k = if (target > musicLevel) 1.6f else 2.8f // entra em ~0,6 s, sai em ~0,35 s
            musicLevel += (target - musicLevel) * (1f - exp(-k * dt * 3f))
            player?.let { mp ->
                runCatching {
                    mp.setVolume(musicLevel, musicLevel)
                    if (!want && musicLevel < 0.004f && mp.isPlaying) mp.pause()
                }
            }
            synth?.setMood(intensity, bossActive, duck)
            if (want || musicLevel > 0.004f) {
                main.postDelayed(this, 33L)
            } else {
                synchronized(this@SoundFx) { directorRunning = false }
            }
        }
    }

    private const val MUSIC_VOLUME = 0.35f
    private const val SR = 22050

    private fun writeWav(file: File, pcm: ShortArray) {
        val data = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        pcm.forEach { data.putShort(it) }
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size * 2).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size * 2)
        file.outputStream().use { it.write(header.array()); it.write(data.array()) }
    }

    /** Osciladores simples somados com envelopes: o bastante para um som "cristalino" de jogo. */
    private object Synth {
        private const val TAU = (2.0 * PI).toFloat()

        private fun build(durMs: Int, gain: Float = 0.9f, gen: (t: Float, p: Float) -> Float): ShortArray {
            val n = SR * durMs / 1000
            val raw = FloatArray(n) { i -> gen(i / SR.toFloat(), i / n.toFloat()) }
            val peak = max(0.0001f, raw.maxOf { abs(it) })
            return ShortArray(n) { i ->
                // Fade curto nas pontas elimina estalos.
                val edge = min(1f, min(i, n - 1 - i) / 90f)
                (raw[i] / peak * gain * edge * Short.MAX_VALUE).toInt().toShort()
            }
        }

        private fun sine(f: Float, t: Float) = sin(TAU * f * t)
        private fun chirp(f0: Float, f1: Float, t: Float, total: Float) = sin(TAU * (f0 * t + (f1 - f0) * t * t / (2f * total)))
        private fun decay(p: Float, k: Float) = exp(-p * k)

        /** Sequência de notas: cada nota tem frequência e duração (s); sino com 2º harmônico. */
        private fun notes(freqs: List<Float>, noteSec: Float, lastSec: Float = noteSec, tail: Float = 9f, durMs: Int): ShortArray =
            build(durMs) { t, _ ->
                val idx = floor(t / noteSec).toInt().coerceAtMost(freqs.lastIndex)
                val start = idx * noteSec
                val local = (t - start) / (if (idx == freqs.lastIndex) lastSec else noteSec)
                val f = freqs[idx]
                (sine(f, t) + 0.35f * sine(f * 2f, t) + 0.12f * sine(f * 3f, t)) * decay(local, tail / 3f) * min(1f, (t - start) * 400f)
            }

        fun render(sfx: Sfx): ShortArray = when (sfx) {
            Sfx.TAP -> build(120, 0.8f) { t, p ->
                (0.8f * chirp(640f, 940f, t, 0.12f) + 0.25f * chirp(1280f, 1880f, t, 0.12f)) * decay(p, 7f) * min(1f, t * 700f)
            }
            Sfx.CRIT -> build(360, 0.9f) { t, p ->
                val env = decay(p, 3.6f) * min(1f, t * 600f)
                val second = if (t > 0.05f) 0.8f * sine(1760f, t) else 0f
                (sine(1318f, t) + second + 0.35f * sine(2637f, t)) * env
            }
            Sfx.BUY -> notes(listOf(523f, 659f, 784f), 0.085f, 0.2f, 9f, 330)
            Sfx.ERROR -> build(170, 0.55f) { t, p ->
                val f = 190f - 50f * p
                (sine(f, t) + 0.4f * sine(f * 3f, t)) * (if (p < 0.5f) 1f else 0.8f) * decay(p, 3f)
            }
            Sfx.ABILITY -> build(520, 0.85f) { t, p ->
                val vib = 1f + 0.03f * sin(TAU * 18f * t)
                val env = sin(PI.toFloat() * p) * (1f - 0.35f * p)
                (chirp(240f, 1500f, t, 0.52f) * vib + 0.3f * chirp(480f, 3000f, t, 0.52f)) * env
            }
            Sfx.CLAIM -> notes(listOf(659f, 784f, 988f, 1318f), 0.075f, 0.28f, 9f, 560)
            Sfx.UNLOCK -> build(420, 0.85f) { t, p ->
                (chirp(380f, 820f, t, 0.42f) + 0.6f * chirp(570f, 1230f, t, 0.42f) + 0.2f * sine(1640f, t)) * decay(p, 3.2f) * min(1f, t * 500f)
            }
            Sfx.BOSS_START -> build(780, 0.95f) { t, p ->
                val f = 150f - 80f * p
                val pulse = 0.75f + 0.25f * sin(TAU * 7f * t)
                (sine(f, t) + 0.5f * sine(f * 2f, t) + 0.3f * sine(f * 3f, t) + 0.18f * chirp(900f, 180f, t, 0.78f)) * pulse * decay(p, 1.8f) * min(1f, t * 300f)
            }
            Sfx.BOSS_DOWN -> notes(listOf(523f, 659f, 784f, 1047f, 1319f), 0.11f, 0.5f, 9f, 940)
            Sfx.PRESTIGE -> build(1500, 0.95f) { t, p ->
                val sweep = chirp(180f, 2600f, t, 1.5f)
                val sh = 0.35f * sine(1760f, t) * sin(TAU * 6f * t) + 0.3f * sine(2217f, t) * sin(TAU * 4.5f * t)
                (sweep * 0.8f + sh) * (if (p < 0.6f) p / 0.6f else decay((p - 0.6f) / 0.4f, 4f))
            }
            Sfx.NAV -> build(40, 0.5f) { t, p -> sine(1100f, t) * decay(p, 9f) }
            Sfx.OFFLINE -> notes(listOf(392f, 523f, 659f, 784f, 1047f), 0.12f, 0.60f, 9f, 1250)
            Sfx.COUNT_TICK -> build(30, 0.45f) { t, p -> sine(2100f, t) * decay(p, 8f) }
        }

        /**
         * Pad ambiente de 8 s. Todas as frequências têm número inteiro de ciclos por segundo e as
         * modulações têm períodos que dividem 8 s, então o fim encaixa no começo sem emenda audível.
         */
        fun ambientLoop(): ShortArray = build(8000, 0.8f) { t, _ ->
            val swell = 0.65f + 0.35f * sin(TAU * 0.125f * t)
            val pad = sine(110f, t) + 0.8f * sine(111f, t) + 0.55f * sine(165f, t) + 0.5f * sine(220f, t) +
                0.32f * sine(330f, t) * (0.5f + 0.5f * sin(TAU * 0.25f * t)) + 0.2f * sine(440f, t) * (0.5f + 0.5f * sin(TAU * 0.5f * t + 1f))
            pad * swell
        }
    }
}


private const val LS_SR = 22050
private const val LS_VOICES = 8
private const val LS_TAU = (2.0 * PI).toFloat()
/** Mi menor pentatônica em semitons a partir de Mi5 (659,26 Hz): qualquer combinação soa consonante. */
private val LS_SCALE = intArrayOf(-12, -9, -7, -5, -2, 0, 3, 5, 7, 10, 12, 15)
private val LS_HAT_ACCENT = floatArrayOf(1f, 0.35f, 0.7f, 0.35f, 1f, 0.35f, 0.7f, 0.5f)

/**
 * Camadas de música geradas em tempo real e mixadas num único AudioTrack em streaming (todas sincronizadas
 * no mesmo relógio de amostras, ao contrário de vários players soltos). A faixa real continua sendo a base;
 * estas camadas são não-tonais ou pentatônicas e entram conforme a intensidade do jogo:
 *  - AR: ruído filtrado que abre (fica mais brilhante) com a intensidade;
 *  - PULSO: chiado rítmico e, em intensidade alta ou chefe, um bumbo suave;
 *  - GRAVE: drone em Mi que só aparece no chefe (com trêmolo e batimento de 2 notas desafinadas);
 *  - CINTILAÇÕES: notas de sino aleatórias na escala, com eco ping-pong; mais densas com a intensidade,
 *    mais graves no chefe, e disparadas em sequência ascendente por eventos (crítico, resgate, chefe...).
 */
private class LayerSynth {
    @Volatile private var active = false
    @Volatile private var intensity = 0f
    @Volatile private var boss = false
    @Volatile private var duckAmt = 0f
    @Volatile private var pendingSparkles = 0
    private var track: AudioTrack? = null

    private val vf = FloatArray(LS_VOICES)
    private val vp = FloatArray(LS_VOICES)
    private val vA = FloatArray(LS_VOICES)
    private val vK = FloatArray(LS_VOICES)
    private val vPan = FloatArray(LS_VOICES)
    private val vOn = BooleanArray(LS_VOICES)
    private var nextVoice = 0
    private var ns = 0x2F6E2B1

    fun setActive(v: Boolean) { active = v }
    fun setMood(i: Float, b: Boolean, d: Float) { intensity = i; boss = b; duckAmt = d }
    fun sparkle(n: Int) { pendingSparkles = min(12, pendingSparkles + n) }

    fun start() {
        val minBuf = AudioTrack.getMinBufferSize(LS_SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(LS_SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, 8192 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        Thread({ runCatching { loop(t) }; runCatching { t.release() } }, "layer-synth").apply { isDaemon = true; start() }
    }

    private fun noise(): Float {
        ns = ns xor (ns shl 13)
        ns = ns xor (ns ushr 17)
        ns = ns xor (ns shl 5)
        return ns * 4.656613e-10f
    }

    private fun spawnVoice(freq: Float, amp: Float, pan: Float, decayPerSec: Float) {
        val v = nextVoice
        nextVoice = (nextVoice + 1) % LS_VOICES
        vf[v] = freq; vp[v] = 0f; vA[v] = amp; vPan[v] = pan
        vK[v] = exp(-decayPerSec / LS_SR)
        vOn[v] = true
    }

    private fun noteFreq(index: Int, octaveShift: Float): Float =
        659.26f * 2f.pow(LS_SCALE[index.coerceIn(0, LS_SCALE.lastIndex)] / 12f) * octaveShift

    private fun loop(t: AudioTrack) {
        val frames = 512
        val buf = ShortArray(frames * 2)
        var playing = false
        var master = 0f
        var gAir = 0f; var gPulse = 0f; var gKick = 0f; var gSub = 0f
        var airFc = 900f
        var lowL = 0f; var bandL = 0f; var lowR = 0f; var bandR = 0f
        var hpLp = 0f
        val stepLen = (LS_SR * 60f / 129.2f / 2f).toInt()
        var stepPos = 0; var stepCount = 0
        var hatEnv = 0f
        var kickT = 99f; var kickPh = 0f
        var p1 = 0f; var p2 = 0f; var p3 = 0f; var p1b = 0f
        var lfo = 0f
        val delayLen = 7500
        val dL = FloatArray(delayLen); val dR = FloatArray(delayLen)
        var di = 0
        var nextPluck = (LS_SR * 1.2f).toInt()
        var sparkleCd = 0
        var sparkleIdx = 0

        while (true) {
            val wantOn = active
            if (!wantOn && master < 0.0008f) {
                if (playing) { runCatching { t.pause(); t.flush() }; playing = false }
                for (v in 0 until LS_VOICES) vOn[v] = false
                pendingSparkles = 0
                java.util.Arrays.fill(dL, 0f); java.util.Arrays.fill(dR, 0f)
                try { Thread.sleep(80) } catch (e: InterruptedException) { return }
                master = 0f
                continue
            }
            if (!playing) { t.play(); playing = true }

            // ---- parâmetros do bloco (≈23 ms): tudo é suavizado para não haver degraus audíveis
            val inten = intensity
            val bs = boss
            val dk = duckAmt
            master += ((if (wantOn) 1f else 0f) - master) * 0.10f
            gAir += ((0.30f + 0.70f * inten) - gAir) * 0.06f
            gPulse += ((if (bs) 0.85f else ((inten - 0.30f) / 0.70f).coerceIn(0f, 1f)) - gPulse) * 0.06f
            gKick += ((if (bs) 0.9f else ((inten - 0.55f) / 0.45f).coerceIn(0f, 1f) * 0.7f) - gKick) * 0.05f
            gSub += ((if (bs) 1f else 0.20f * inten) - gSub) * 0.04f
            airFc += ((900f + 2400f * inten) - airFc) * 0.05f
            val f = 2f * sin(PI.toFloat() * airFc / LS_SR)
            val q = 0.55f
            val bus = master * (1f - 0.5f * dk)

            // Cintilações aleatórias (densidade sobe com a intensidade) e em sequência quando há evento.
            nextPluck -= frames
            if (nextPluck <= 0) {
                val shift = if (bs) 0.5f else 1f
                spawnVoice(noteFreq(rngIndex(), shift), 0.20f + 0.10f * inten, (noise()).coerceIn(-0.8f, 0.8f), 2.8f)
                val interval = (3.0f - 2.5f * inten) * (0.6f + 0.8f * (0.5f + 0.5f * noise()))
                nextPluck = (interval * LS_SR).toInt()
            }
            sparkleCd -= frames
            if (pendingSparkles > 0 && sparkleCd <= 0) {
                pendingSparkles--
                spawnVoice(noteFreq(4 + sparkleIdx, 1f), 0.26f, ((sparkleIdx % 4) - 1.5f) / 2f, 3.4f)
                sparkleIdx = if (pendingSparkles == 0) 0 else sparkleIdx + 1
                sparkleCd = (LS_SR * 0.07f).toInt()
            }

            for (n in 0 until frames) {
                // AR
                val nl = noise(); val nr = noise()
                val hL = nl - lowL - q * bandL; bandL += f * hL; lowL += f * bandL
                val hR = nr - lowR - q * bandR; bandR += f * hR; lowR += f * bandR
                val swell = 0.65f + 0.35f * sin(lfo)
                lfo += LS_TAU * 0.11f / LS_SR
                if (lfo > LS_TAU) lfo -= LS_TAU
                var l = bandL * 0.35f * gAir * swell
                var r = bandR * 0.35f * gAir * swell

                // PULSO
                if (stepPos == 0) {
                    hatEnv = LS_HAT_ACCENT[stepCount % 8]
                    if (stepCount % 4 == 0) { kickT = 0f; kickPh = 0f }
                }
                stepPos++
                if (stepPos >= stepLen) { stepPos = 0; stepCount++ }
                val hn = noise()
                hpLp += 0.25f * (hn - hpLp)
                val hat = (hn - hpLp) * hatEnv * 0.45f * gPulse
                hatEnv *= 0.9962f
                var kick = 0f
                if (kickT < 0.3f) {
                    kickPh += LS_TAU * (55f + 70f * exp(-kickT * 30f)) / LS_SR
                    kick = sin(kickPh) * exp(-kickT * 14f) * 0.6f * gKick
                    kickT += 1f / LS_SR
                }
                l += hat + kick; r += hat + kick

                // GRAVE (chefe): Mi2 + quinta + oitava, batimento com nota desafinada e trêmolo de 4 Hz
                p1 += LS_TAU * 82.41f / LS_SR; if (p1 > LS_TAU) p1 -= LS_TAU
                p2 += LS_TAU * 123.47f / LS_SR; if (p2 > LS_TAU) p2 -= LS_TAU
                p3 += LS_TAU * 164.81f / LS_SR; if (p3 > LS_TAU) p3 -= LS_TAU
                p1b += LS_TAU * 83.3f / LS_SR; if (p1b > LS_TAU) p1b -= LS_TAU
                val trem = if (bs) 0.75f + 0.25f * sin(lfo * 36f) else 1f
                val sub = (0.5f * sin(p1) + 0.28f * sin(p2) + 0.2f * sin(p3) + (if (bs) 0.3f * sin(p1b) else 0f)) * gSub * trem * 0.55f
                l += sub; r += sub

                // CINTILAÇÕES + eco ping-pong
                var pl = 0f; var pr = 0f
                for (v in 0 until LS_VOICES) {
                    if (!vOn[v]) continue
                    val e = vA[v]
                    val s = (sin(vp[v]) + 0.30f * sin(vp[v] * 2f) * e) * e
                    vp[v] += LS_TAU * vf[v] / LS_SR
                    if (vp[v] > LS_TAU) vp[v] -= LS_TAU
                    vA[v] = e * vK[v]
                    if (vA[v] < 0.0008f) vOn[v] = false
                    pl += s * (0.5f - 0.5f * vPan[v])
                    pr += s * (0.5f + 0.5f * vPan[v])
                }
                val wl = dL[di]; val wr = dR[di]
                dL[di] = pl + wr * 0.42f
                dR[di] = pr + wl * 0.42f
                di++; if (di >= delayLen) di = 0
                l += pl + wl * 0.55f
                r += pr + wr * 0.55f

                l *= bus; r *= bus
                // Saturação suave: nunca estoura, mesmo com tudo ligado.
                l = l / (1f + abs(l)); r = r / (1f + abs(r))
                buf[2 * n] = (l * 0.55f * Short.MAX_VALUE).toInt().toShort()
                buf[2 * n + 1] = (r * 0.55f * Short.MAX_VALUE).toInt().toShort()
            }
            val written = t.write(buf, 0, buf.size)
            if (written < 0) return
        }
    }

    private fun rngIndex(): Int = ((noise() * 0.5f + 0.5f) * LS_SCALE.size).toInt().coerceIn(0, LS_SCALE.lastIndex)
}
