package dev.atlas.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.atlas.core.Place
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.LocalAtlasColors
import java.util.Locale

@Composable
fun PlaceRow(
    place: Place, distance: String? = null, saved: Boolean = false,
    onClick: () -> Unit, onTrailingClick: (() -> Unit)? = null,
) {
    val colors = LocalAtlasColors.current
    val interaction = remember { MutableInteractionSource() }
    Surface(onClick = onClick, interactionSource = interaction, color = colors.surface, shape = RoundedCornerShape(AtlasDimens.CardRadius), modifier = Modifier.pressScale(interaction, 0.975f)) {
        Row(Modifier.fillMaxWidth().heightIn(min = AtlasDimens.RowMinHeight).padding(start = 14.dp, end = 4.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).background(colors.accent.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(placeCategoryIcon(place.category), null, tint = colors.accent, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(place.name, style = MaterialTheme.typography.titleMedium, color = colors.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(listOfNotNull(place.category.takeIf { it.isNotBlank() }, distance).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = colors.secondaryText, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (place.address.isNotBlank()) Text(place.address, style = MaterialTheme.typography.bodySmall, color = colors.secondaryText, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (onTrailingClick != null) IconButton(onClick = onTrailingClick) {
                Icon(if (saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                    if (saved) "Remover ${place.name} dos favoritos" else "Salvar ${place.name}",
                    tint = colors.accent, modifier = Modifier.size(22.dp))
            } else {
                Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                    Icon(if (saved) Icons.Rounded.Bookmark else Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        if (saved) "Lugar salvo" else null, tint = if (saved) colors.accent else colors.secondaryText, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
fun EmptyState(
    title: String, message: String, icon: ImageVector = Icons.Rounded.Search,
    actionLabel: String? = null, onAction: (() -> Unit)? = null, modifier: Modifier = Modifier,
) {
    val colors = LocalAtlasColors.current
    Column(modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, null, modifier = Modifier.size(36.dp), tint = colors.secondaryText)
        Text(title, style = MaterialTheme.typography.titleLarge, color = colors.text, textAlign = TextAlign.Center)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = colors.secondaryText, textAlign = TextAlign.Center)
        if (onAction != null && !actionLabel.isNullOrBlank()) TextButton(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
fun LoadingState(message: String = "Carregando…", modifier: Modifier = Modifier) {
    val colors = LocalAtlasColors.current
    Row(modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = colors.accent)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = colors.secondaryText)
    }
}

fun placeCategoryIcon(category: String): ImageVector {
    val label = category.lowercase(Locale.ROOT)
    return when {
        label.contains("café") || label.contains("cafe") || label.contains("coffee") -> Icons.Rounded.LocalCafe
        label.contains("restaur") || label.contains("food") -> Icons.Rounded.Restaurant
        label.contains("hospital") || label.contains("farm") || label.contains("pharmacy") -> Icons.Rounded.LocalHospital
        label.contains("hotel") || label.contains("lodging") -> Icons.Rounded.Hotel
        label.contains("parque") || label.contains("park") && !label.contains("parking") -> Icons.Rounded.Park
        label.contains("posto") || label.contains("fuel") -> Icons.Rounded.LocalGasStation
        label.contains("estacion") || label.contains("parking") -> Icons.Rounded.LocalParking
        label.contains("mercado") || label.contains("supermarket") || label.contains("loja") -> Icons.Rounded.ShoppingBag
        label.contains("banco") || label.contains("bank") || label.contains("atm") -> Icons.Rounded.AccountBalance
        label.contains("escola") || label.contains("univers") || label.contains("school") -> Icons.Rounded.School
        label.contains("aeroport") || label.contains("airport") -> Icons.Rounded.Flight
        label.contains("transporte") || label.contains("bus") || label.contains("station") -> Icons.Rounded.DirectionsTransit
        label.contains("academ") || label.contains("fitness") -> Icons.Rounded.FitnessCenter
        else -> Icons.Rounded.Place
    }
}
