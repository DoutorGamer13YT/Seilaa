package com.infinityclicker.generators

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.Rarity
import kotlin.math.pow

data class GeneratorDef(
    val id: Int,
    val name: String,
    val description: String,
    val rarity: Rarity,
    val baseCost: BigNum,
    /** Crescimento geométrico do preço a cada unidade comprada. */
    val growth: Double,
    /** Energia por segundo de UMA unidade, sem multiplicadores. */
    val baseProduction: BigNum
)

/**
 * Os 110 geradores cósmicos: 10 clássicos + 100 novos (de Asteroides a Multiversos).
 *  Tiers 0–9:   custo base 20 × 12,4^i; produção 0,3 × 8^i por segundo (retorno piora ~1,5× por tier).
 *  Tiers 10–109: custo × 14 e produção × 13,2 por tier, ou seja, o retorno só piora ~6% por tier.
 *                Assim cada tier novo continua alcançável, só leva mais tempo (o jogo é bem mais longo).
 *  Crescimento do preço por unidade: 1,165 + 0,006·i (limitado a 1,38).
 * Marcos: a cada 25 unidades possuídas a produção do gerador dobra (ver Formulas.milestoneMultiplier).
 */
object GeneratorDefs {

    private val classic = listOf(
        Triple("Fragmento Estelar", "Cacos de estrela que pulsam energia pura.", Rarity.COMUM),
        Triple("Núcleo Energético", "Um reator compacto de energia cósmica.", Rarity.COMUM),
        Triple("Estrela", "Uma estrela inteira trabalhando para você.", Rarity.INCOMUM),
        Triple("Nebulosa", "Nuvens de gás ionizado que se condensam em energia.", Rarity.INCOMUM),
        Triple("Sistema Solar", "Planetas e luas orbitando um motor de energia.", Rarity.RARO),
        Triple("Galáxia", "Centenas de bilhões de estrelas em sintonia.", Rarity.EPICO),
        Triple("Aglomerado Galáctico", "Galáxias unidas pela gravidade e pelo lucro.", Rarity.LENDARIO),
        Triple("Universo", "Um universo completo dedicado a produzir energia.", Rarity.MITICO),
        Triple("Multiverso", "Infinitos universos somando suas forças.", Rarity.COSMICO),
        Triple("Dimensão Infinita", "O limite do possível — e além dele.", Rarity.TRANSCENDENTAL)
    )

    /** 10 tipos de máquina × 10 corpos celestes (do menor ao maior) = 100 geradores novos, todos com nome único. */
    private val machines = listOf("Forja", "Reator", "Coletor", "Fábrica", "Motor", "Prisma", "Torre", "Anel", "Cúpula", "Colmeia")
    private val bodies = listOf("Asteroides", "Cometas", "Luas", "Estrelas", "Pulsares", "Quasares", "Nebulosas", "Galáxias", "Buracos Negros", "Multiversos")

    private val extra: List<Triple<String, String, Rarity>> = List(100) { k ->
        val machine = machines[k % machines.size]
        val body = bodies[k / machines.size]
        Triple(
            "$machine de $body",
            "$machine que transforma ${body.lowercase()} em energia cósmica pura.",
            Rarity.entries[minOf(Rarity.entries.size - 1, k / 13)]
        )
    }

    private val data = classic + extra

    private const val CLASSIC = 10

    private fun baseCostOf(i: Int): Double =
        if (i < CLASSIC) 20.0 * 12.4.pow(i) else 20.0 * 12.4.pow(CLASSIC - 1) * 14.0.pow(i - (CLASSIC - 1))

    private fun baseProductionOf(i: Int): Double =
        if (i < CLASSIC) 0.3 * 8.0.pow(i) else 0.3 * 8.0.pow(CLASSIC - 1) * 13.2.pow(i - (CLASSIC - 1))

    val all: List<GeneratorDef> = data.mapIndexed { i, (name, desc, rarity) ->
        GeneratorDef(
            id = i,
            name = name,
            description = desc,
            rarity = rarity,
            baseCost = BigNum.of(baseCostOf(i)),
            growth = (1.165 + 0.006 * i).coerceAtMost(1.38),
            baseProduction = BigNum.of(baseProductionOf(i))
        )
    }

    val count: Int get() = all.size

    fun byId(id: Int): GeneratorDef = all[id]
}
