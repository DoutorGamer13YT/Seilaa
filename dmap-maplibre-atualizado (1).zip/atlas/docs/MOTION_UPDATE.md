# Dmap — MapLibre e movimento

Alterações aplicadas sobre os fontes fornecidos em `dmap-atualizado.zip`. Não foi criado outro aplicativo nem outro motor de mapa.

## Implementado

- MapLibre Native **11.8.0** permanece como único renderizador. Os provedores, estilos vetoriais, pesquisa, rotas, dados locais e dependências existentes foram preservados.
- A instância do mapa fica fora das telas transitórias do NavHost; Ajustes/Biblioteca suspendem seu ciclo de renderização e permitem reutilizá-la ao voltar. A tentativa de recarregar um estilo também reutiliza o MapView.
- Câmera usa `easeCamera` para deslocamentos locais, orientação, inclinação e GPS; viagens longas com grande mudança de escala usam `animateCamera`. A duração depende de distância, escala e orientação, em vez de aplicar 700 ms a tudo.
- Gestos nativos conservam foco do zoom e inércia de movimento/escala/rotação. A inclinação permanece habilitada. A rotação manual também pode sair do modo bússola; o botão de inclinação preserva a orientação atual.
- Toque e exploração manual interrompem os movimentos automáticos. As solicitações de acompanhamento GPS são diferenciadas das ações explícitas, e callbacks antigos de animação não controlam movimentos novos.
- O seguidor de bússola usa tempo decorrido entre frames, para manter a mesma resposta em telas com taxas distintas. Não foi imposto um limite artificial de 60 FPS ou renderização contínua em repouso.
- Enquadramento usa padding animado da câmera e limites calculados para a área útil, considerando painel, controles superiores e layout lateral. Mudanças são agrupadas; o arraste do painel suspende ajustes automáticos e comunica seu destino ao soltar.
- O painel passou a ocupar a área até o fundo da janela com uma superfície opaca única. Os insets da navegação/IME ficam dentro dessa superfície, com cantos superiores preservados. O topo do painel tem movimento próprio enquanto o teclado altera a área interna disponível.
- Mola do painel preserva posição/velocidade nas interrupções, projeta o destino a partir da velocidade de liberação e oferece resistência progressiva nos limites. Rolagem interna pode continuar quando o painel atinge a expansão máxima.
- Entrada/saída do painel usa deslocamento, preservando a opacidade de seu fundo. Conteúdo de saída conserva o estado do cartão durante a troca de telas do painel.
- Busca, resultados, ações dos lugares, rotas e controles receberam curvas e transições específicas. A preferência Reduzir movimento e a desativação de animações do sistema são respeitadas.
- Estilos são lidos fora da thread principal e reutilizados. Serialização da geometria de rotas ocorre em background. Cache nativo entre níveis de zoom e prefetch progressivo permanecem ativos; callbacks e tarefas são encerrados com o mapa.
- O arquivo recebido já não continha a lista extensa de licenças. Os créditos foram organizados em um diálogo discreto em **Sobre o Dmap**, também acessível pela atribuição no mapa. Nome, desenvolvedor **@vitinhjkjkk**, temas claro/escuro e seleção automática do sistema foram mantidos. Não foi adicionado AMOLED.

## Arquivos Kotlin modificados

- `app/src/main/java/dev/atlas/map/AtlasMap.kt`
- `app/src/main/java/dev/atlas/map/CameraRequest.kt`
- `app/src/main/java/dev/atlas/ui/AtlasApp.kt`
- `app/src/main/java/dev/atlas/ui/AtlasViewModel.kt`
- `app/src/main/java/dev/atlas/ui/components/AtlasBottomSheet.kt`
- `app/src/main/java/dev/atlas/ui/components/MapControls.kt`
- `app/src/main/java/dev/atlas/ui/components/Motion.kt`
- `app/src/main/java/dev/atlas/ui/screens/MapScreen.kt`
- `app/src/main/java/dev/atlas/ui/screens/ExplorePanel.kt`
- `app/src/main/java/dev/atlas/ui/screens/PlaceDetailPanel.kt`
- `app/src/main/java/dev/atlas/ui/screens/RoutePanel.kt`
- `app/src/main/java/dev/atlas/ui/screens/SettingsScreen.kt`
- `app/src/main/java/dev/atlas/ui/theme/AtlasTheme.kt`

## Verificações executadas

- Compatibilidade pontual das APIs Compose adicionadas com o BOM `2024.12.01` (incluindo `animateItem`, disponível desde Foundation 1.7.0).
- `python scripts/validate_static.py --json`: aprovado, 9 arquivos XML/JSON analisados, nenhum erro. Resultado em `MOTION_STATIC_REPORT.json`.
- Comparação binária com o ZIP original: arquivos Gradle e workflows permanecem idênticos. Nenhum APK foi gerado.
- Verificação textual dos arquivos modificados para marcadores de conflito e espaços finais.

**Não executados:** Gradle, compilação Kotlin/APK, testes unitários/instrumentados, aplicativo em emulador/aparelho, medição de FPS ou inspeção visual de animações. A validação estática não comprova compilação nem a qualidade visual em execução. O aviso sobre Gradle Wrapper ausente/incompleto já pertence ao projeto recebido.

## Validação visual pendente no aparelho

- Arraste lento/rápido e reversão de direção do painel durante a mola; lista interna no topo e em movimento.
- Abrir/fechar teclado e selecionar um resultado durante a transição, nos dois temas, com navegação por gestos e três botões.
- Interromper centralização por pan/pinch/rotação; retornar ao norte; alternar 2D/3D mantendo o ângulo livre.
- Enquadrar rotas curtas/longas e destinos em retrato/paisagem; explorar manualmente sem recentralização automática.
- Abrir/fechar Ajustes e Biblioteca, trocar tema, recarregar estilo após erro de rede e retornar do background.
- GPS/bússola em aparelhos 60/120 Hz, incluindo passagem de 359° para 0° e Reduzir movimento.

## APIs da versão instalada consultadas

- [MapLibreMap 11.8.0 — câmera, padding, enquadramento, cache e prefetch](https://github.com/maplibre/maplibre-native/blob/android-v11.8.0/platform/android/MapLibreAndroid/src/main/java/org/maplibre/android/maps/MapLibreMap.java)
- [UiSettings 11.8.0 — gestos e inércia](https://github.com/maplibre/maplibre-native/blob/android-v11.8.0/platform/android/MapLibreAndroid/src/main/java/org/maplibre/android/maps/UiSettings.java)
- [MapRenderer 11.8.0 — agendamento de renderização](https://github.com/maplibre/maplibre-native/blob/android-v11.8.0/platform/android/MapLibreAndroid/src/main/java/org/maplibre/android/maps/renderer/MapRenderer.java)
