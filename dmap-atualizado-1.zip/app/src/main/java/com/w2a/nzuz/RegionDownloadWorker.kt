package com.w2a.nzuz

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import kotlinx.coroutines.*
import org.maplibre.android.offline.*
import kotlin.coroutines.resume

class RegionDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val app = context.applicationContext as DmapsApp
    private val repo = app.offline
    private val regionId = inputData.getLong("regionId", -1)
    private var lastUpdate = 0L
    private var latest: OfflineRegionStatus? = null

    override suspend fun doWork(): Result = coroutineScope {
        if (regionId < 0) return@coroutineScope Result.failure()
        if (app.prefs.state.value.offline) return@coroutineScope Result.retry()
        var acquired = false
        try {
            setForeground(notification(null))
            val region = repo.begin(regionId)
            acquired = true
            withContext(Dispatchers.Main.immediate) { repo.message(regionId, "Baixando recursos reais…") }
            val outcome = withContext(Dispatchers.Main.immediate) {
                withTimeoutOrNull(20 * 60 * 1000L) {
                    suspendCancellableCoroutine<Result> { c ->
                        region.setObserver(object : OfflineRegion.OfflineRegionObserver {
                            override fun onStatusChanged(status: OfflineRegionStatus) {
                                latest = status
                                val now = android.os.SystemClock.elapsedRealtime()
                                if (now - lastUpdate > 1000 || status.isComplete) {
                                    lastUpdate = now
                                    repo.update(regionId, status)
                                    if (status.completedResourceSize > 2L * 1024 * 1024 * 1024 || repo.freeBytes() < RegionMath.RESERVE) {
                                        repo.message(regionId, "Pausado: limite de 2 GB ou pouco espaço. Libere armazenamento.")
                                        if (c.isActive) c.resume(Result.failure())
                                        return
                                    }
                                    launch {
                                        setProgress(workDataOf("bytes" to status.completedResourceSize,
                                            "completed" to status.completedResourceCount, "required" to status.requiredResourceCount))
                                        setForeground(notification(status))
                                    }
                                }
                                if (status.isComplete && c.isActive) c.resume(Result.success())
                            }
                            override fun onError(error: OfflineRegionError) {
                                val permanent = error.reason == OfflineRegionError.REASON_NOT_FOUND ||
                                    error.message.contains("401") || error.message.contains("403")
                                repo.message(regionId, if (permanent) "A fonte recusou ou não encontrou recursos. Revise a configuração." else "Falha de rede/servidor; nova tentativa agendada")
                                if (c.isActive) c.resume(if (permanent || runAttemptCount >= 5) Result.failure() else Result.retry())
                            }
                            override fun mapboxTileCountLimitExceeded(limit: Long) {
                                repo.message(regionId, "Limite de tiles atingido; exclua regiões ou reduza a área.")
                                if (c.isActive) c.resume(Result.failure())
                            }
                        })
                        region.setDownloadState(OfflineRegion.STATE_ACTIVE)
                    }
                } ?: run {
                    repo.message(regionId, "Download parcial salvo; continuação agendada")
                    Result.retry()
                }
            }
            outcome
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            withContext(Dispatchers.Main.immediate) { repo.message(regionId, "Não foi possível continuar. Toque em Retomar.") }
            if (runAttemptCount < 5) Result.retry() else Result.failure()
        } finally {
            if (acquired) withContext(NonCancellable + Dispatchers.Main.immediate) { repo.finish(regionId) }
        }
    }

    private fun notification(status: OfflineRegionStatus?): ForegroundInfo {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("offline", "Mapas offline", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(applicationContext, 0, Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val precise = status?.isRequiredResourceCountPrecise == true && status.requiredResourceCount > 0
        val progress = if (precise) ((status!!.completedResourceCount * 100) / status.requiredResourceCount).toInt().coerceIn(0, 100) else 0
        val notification = NotificationCompat.Builder(applicationContext, "offline")
            .setSmallIcon(R.drawable.ic_dmaps).setContentTitle("Dmap • Mapas offline")
            .setContentText(status?.let { "${it.completedResourceCount} recursos • ${formatBytes(it.completedResourceSize)}" } ?: "Preparando download")
            .setProgress(100, progress, !precise).setOnlyAlertOnce(true).setOngoing(true).setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Interromper", WorkManager.getInstance(applicationContext).createCancelPendingIntent(id))
            .build()
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo((regionId % 1_000_000).toInt() + 100, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo((regionId % 1_000_000).toInt() + 100, notification)
    }
}

fun formatBytes(bytes: Long): String = when {
    bytes >= 1_073_741_824 -> String.format(java.util.Locale.getDefault(), "%.2f GB", bytes / 1_073_741_824.0)
    bytes >= 1_048_576 -> String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / 1_048_576.0)
    else -> "${bytes / 1024} KB"
}
