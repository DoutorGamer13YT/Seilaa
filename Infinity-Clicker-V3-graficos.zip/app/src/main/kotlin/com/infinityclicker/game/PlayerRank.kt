package com.infinityclicker.game

import com.infinityclicker.core.BigNum

/** Patente do jogador, derivada só da energia total produzida (nunca diminui). */
data class PlayerRank(
    val index: Int,
    val name: String,
    /** Expoente (log10 da energia total) em que a patente começa. */
    val startsAtLog10: Int
)

data class RankProgress(
    val rank: PlayerRank,
    val next: PlayerRank?,
    /** 0..1 até a próxima patente; 1 quando já está na última. */
    val fraction: Float
)

object PlayerRanks {
    val all = listOf(
        PlayerRank(0, "Faísca", 0),
        PlayerRank(1, "Viajante Estelar", 3),
        PlayerRank(2, "Engenheiro de Éter", 6),
        PlayerRank(3, "Arquiteto de Nebulosas", 10),
        PlayerRank(4, "Tecelão de Galáxias", 16),
        PlayerRank(5, "Senhor Dimensional", 24),
        PlayerRank(6, "Guardião do Infinito", 36),
        PlayerRank(7, "Entidade Transcendental", 50)
    )

    fun forEnergy(totalEnergy: BigNum): RankProgress {
        // log10 só existe para valores positivos; abaixo de 1 de energia ainda é a primeira patente.
        val log = if (totalEnergy < BigNum.ONE) 0.0 else totalEnergy.log10()
        var index = 0
        for (rank in all) if (log >= rank.startsAtLog10) index = rank.index
        val rank = all[index]
        val next = all.getOrNull(index + 1) ?: return RankProgress(rank, null, 1f)
        val span = (next.startsAtLog10 - rank.startsAtLog10).toDouble()
        val fraction = ((log - rank.startsAtLog10) / span).coerceIn(0.0, 1.0).toFloat()
        return RankProgress(rank, next, fraction)
    }
}
