package dev.atlas.ui.components

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import dev.atlas.ui.theme.AtlasMotion
import dev.atlas.ui.theme.LocalAtlasReduceMotion

fun Modifier.pressScale(interactionSource: InteractionSource, pressedScale: Float = 0.94f): Modifier = composed {
    val reduce = LocalAtlasReduceMotion.current
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduce) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

fun panelTransition(reduceMotion: Boolean): ContentTransform =
    if (reduceMotion) ContentTransform(EnterTransition.None, ExitTransition.None)
    else (fadeIn(tween(240, delayMillis = 70, easing = AtlasMotion.Standard)) +
        slideInVertically(tween(AtlasMotion.Medium, easing = AtlasMotion.Emphasized)) { it / 16 }) togetherWith
        fadeOut(tween(110))
