package dev.atlas.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.atlas.core.AppSettings
import dev.atlas.core.ThemeMode
import dev.atlas.core.Units

internal val Context.atlasSettings: DataStore<Preferences> by preferencesDataStore(name = "atlas_settings")

internal object SettingsStorage {
    val theme = stringPreferencesKey("theme")
    val units = stringPreferencesKey("units")
    val voice = booleanPreferencesKey("voice")
    val reduceMotion = booleanPreferencesKey("reduce_motion")
    val haptics = booleanPreferencesKey("haptics")

    fun decode(preferences: Preferences): AppSettings = AppSettings(
        theme = ThemeMode.entries.firstOrNull { it.name == preferences[theme] } ?: ThemeMode.SYSTEM,
        units = Units.entries.firstOrNull { it.name == preferences[units] } ?: Units.METRIC,
        voice = preferences[voice] ?: true,
        reduceMotion = preferences[reduceMotion] ?: false,
        haptics = preferences[haptics] ?: true,
    )

    suspend fun write(store: DataStore<Preferences>, settings: AppSettings) {
        store.edit { preferences ->
            preferences[theme] = settings.theme.name
            preferences[units] = settings.units.name
            preferences[voice] = settings.voice
            preferences[reduceMotion] = settings.reduceMotion
            preferences[haptics] = settings.haptics
        }
    }
}
