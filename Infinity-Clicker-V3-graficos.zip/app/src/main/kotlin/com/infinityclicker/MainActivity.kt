package com.infinityclicker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.ui.GameApp
import com.infinityclicker.ui.GameViewModel

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GameApp(vm) }
    }

    override fun onStart() {
        super.onStart()
        SoundFx.init(applicationContext)
        SoundFx.setForeground(true)
        vm.onForeground()
    }

    override fun onStop() {
        SoundFx.setForeground(false)
        vm.onBackground()
        super.onStop()
    }
}
