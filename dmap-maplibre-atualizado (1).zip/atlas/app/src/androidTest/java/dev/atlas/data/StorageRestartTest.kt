package dev.atlas.data

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.atlas.core.AppSettings
import dev.atlas.core.Coordinate
import dev.atlas.core.Place
import dev.atlas.core.ThemeMode
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StorageRestartTest {
    @Test fun favoritesRelationsHistoryShortcutsAndSettingsSurviveReopening() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val name = "restart-${UUID.randomUUID()}.db"
        val file = File(context.cacheDir, "$name.preferences_pb")
        val place = Place("test/1", "Lugar de teste", Coordinate(12.0, 15.0))
        var database = Room.databaseBuilder(context, AtlasDatabase::class.java, name).build()
        var job = SupervisorJob()
        fun newStore() = PreferenceDataStoreFactory.create(
            scope = CoroutineScope(Dispatchers.IO + job), produceFile = { file })
        try {
            var repository = LocalRepository(database, newStore())
            repository.createList("Viagem")
            val id = repository.lists.first().single().id
            repository.setPlaceLists(place, setOf(id))
            repository.recordSearch("Museus")
            repository.setShortcut("work", place)
            repository.updateSettings(AppSettings(theme = ThemeMode.DARK))
            database.close()
            job.cancelAndJoin()

            database = Room.databaseBuilder(context, AtlasDatabase::class.java, name).build()
            job = SupervisorJob()
            repository = LocalRepository(database, newStore())
            assertEquals(place, repository.favorites.first().single().place)
            assertEquals(listOf(id), repository.favorites.first().single().listIds)
            assertEquals("Viagem", repository.lists.first().single().name)
            assertEquals("Museus", repository.history.first().single().query)
            assertEquals(place, repository.shortcuts.first().single().place)
            assertEquals(ThemeMode.DARK, repository.settings.first().theme)
        } finally {
            database.close()
            job.cancelAndJoin()
            context.deleteDatabase(name)
            file.delete()
        }
        Unit
    }
}
