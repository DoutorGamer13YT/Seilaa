package com.w2a.nzuz

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLngBounds
import java.io.File

@Composable
fun PackageDownloads(vm: MapViewModel, onNew: () -> Unit, onOpen: (MapPackage) -> Unit, onLegacy: () -> Unit) {
    val items by vm.packageItems.collectAsStateWithLifecycle()
    var used by remember { mutableLongStateOf(0) }
    var free by remember { mutableLongStateOf(0) }
    var jobs by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var deleting by remember { mutableStateOf<MapPackage?>(null) }
    LaunchedEffect(items) { used = vm.packages.diskBytes(); free = vm.packages.freeBytes() }
    LaunchedEffect(Unit) {
        while (true) {
            jobs = withContext(Dispatchers.IO) { File(vm.packages.root, "requests").listFiles()?.filter { it.extension == "json" }?.mapNotNull {
                runCatching { JSONObject(android.util.AtomicFile(it).openRead().bufferedReader().use { r -> r.readText() }) }.getOrNull()
            }.orEmpty() }
            delay(3000)
        }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Mapas offline", style = MaterialTheme.typography.headlineMedium)
        Text("Pacotes: ${formatBytes(used)} • Livre: ${formatBytes(free)}")
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Baixar nova região") }
        if (items.isEmpty()) Text("Nenhuma região Protomaps instalada. Configure um catálogo e baixe antes de viajar.")
        items.forEach { item -> key(item.pack.key) {
            val p = item.pack
            ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleLarge)
                    Text("${p.version} • ${item.state}")
                    if (item.installed) {
                        Text("Mapa e recursos: ${formatBytes(p.unpackedBytes)}")
                        Button(onClick = { onOpen(p) }) { Text("Abrir offline") }
                        TextButton(onClick = { vm.action { vm.packages.verify(p) } }) { Text("Verificar integridade") }
                    } else {
                        Text("${formatBytes(item.received)} / ${formatBytes(p.bytes)}")
                        LinearProgressIndicator(progress = { (item.received.toDouble() / p.bytes).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Row {
                            TextButton(onClick = { vm.action { vm.packages.resume(p) } }) { Text("Retomar") }
                            TextButton(onClick = { vm.action { vm.packages.pause(p) } }) { Text("Pausar") }
                        }
                    }
                    TextButton(onClick = { deleting = p }) { Text(if (item.installed) "Excluir mapa" else "Cancelar e excluir") }
                }
            }
        } }
        jobs.forEach { j ->
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Text(j.optString("name")); Text(j.optString("status"))
                if (j.has("package")) {
                    val p = remember(j.toString()) { runCatching { MapPackage(j.getJSONObject("package")) }.getOrNull() }
                    p?.let { Text("Download: ${formatBytes(it.bytes)} • instalado: ${formatBytes(it.unpackedBytes)}")
                        Button(onClick = { vm.action { vm.packages.resume(it) } }) { Text("Confirmar download") } }
                } else TextButton(onClick = { scheduleRequest(vm.getApplication(), j.getString("requestId")) }) { Text("Retomar consulta") }
            } }
        }
        Text("Pesquisa e rotas continuam disponíveis apenas online. Atualizações aparecem como uma nova versão no catálogo; exclua a anterior depois de conferir a nova.")
        TextButton(onClick = onLegacy) { Text("Mapas de fontes anteriores e cache") }
    }
    deleting?.let { p -> AlertDialog(onDismissRequest = { deleting = null }, title = { Text("Excluir ${p.name}?") }, text = { Text("Os arquivos locais e downloads parciais desta versão serão removidos.") },
        confirmButton = { TextButton(onClick = { deleting = null; vm.action { vm.packages.delete(p) } }) { Text("Excluir") } }, dismissButton = { TextButton(onClick = { deleting = null }) { Text("Manter") } }) }
}

@Composable
fun PackagePicker(vm: MapViewModel, permission: Boolean, done: () -> Unit, notifyPermission: () -> Unit) {
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val location by vm.gps.location.collectAsStateWithLifecycle()
    val handle = remember { NativeMapHandle() }
    var kind by rememberSaveable { mutableStateOf("city") }
    var query by rememberSaveable { mutableStateOf("") }
    var selected by remember { mutableStateOf<MapPackage?>(null) }
    var bounds by remember { mutableStateOf<LatLngBounds?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    var zoom by rememberSaveable { mutableFloatStateOf(14f) }
    var sending by remember { mutableStateOf(false) }
    handle.onSelection = { bounds = it }
    handle.onFailure = { vm.notice.value = it }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            NativeMapView(vm, handle, null, true, "asset://overview.json", location, permission, Modifier.fillMaxSize())
            Canvas(Modifier.fillMaxSize()) {
                val p = 24.dp.toPx()
                drawRect(Color(0xFF007AFF), Offset(p, p), Size((size.width - 2*p).coerceAtLeast(0f), (size.height - 2*p).coerceAtLeast(0f)), style = Stroke(3.dp.toPx()))
            }
        }
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp) {
            Column(Modifier.fillMaxWidth().heightIn(max = 380.dp).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Prévia de limites • Natural Earth. Ruas aparecem após baixar o pacote.", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("city" to "Cidade", "state" to "Estado", "custom" to "Personalizada").forEach { (value, label) ->
                        FilterChip(selected = kind == value, onClick = { kind = value; selected = null }, label = { Text(label) })
                    }
                }
                if (kind != "custom") {
                    OutlinedTextField(query, { query = it }, label = { Text("Buscar no catálogo") }, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { vm.action { vm.packages.refreshCatalog() } }) { Text("Atualizar catálogo") }
                    val matches = catalog.filter { it.kind == kind && it.name.contains(query, true) }
                    if (matches.isEmpty()) Text("Nenhuma região disponível neste catálogo. Configure a distribuição em Configurações.")
                    matches.take(30).forEach { p ->
                        OutlinedButton(onClick = { selected = p; handle.map?.animateCamera(CameraUpdateFactory.newLatLngBounds(p.bounds, 40), 700) }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
                    }
                    selected?.let { p ->
                        Text("${p.name} • zoom ${p.minZoom}–${p.maxZoom}\nDownload: ${formatBytes(p.bytes)} • instalado: ${formatBytes(p.unpackedBytes)}")
                        Text("Limites: ${p.box.joinToString { "%.4f".format(java.util.Locale.US, it) }}", style = MaterialTheme.typography.labelSmall)
                        Button(onClick = { notifyPermission(); vm.action { vm.packages.resume(p); done() } }, modifier = Modifier.fillMaxWidth()) { Text("Baixar região selecionada") }
                    }
                } else {
                    Text("Mova o mapa: o retângulo azul define o recorte. Máximo de 15° por lado.")
                    OutlinedTextField(name, { name = it.take(120) }, label = { Text("Nome da região") }, modifier = Modifier.fillMaxWidth())
                    Text("Detalhes: zoom ${zoom.toInt()}"); Slider(zoom, { zoom = it }, valueRange = 8f..15f, steps = 6)
                    bounds?.let { b ->
                        val estimate = runCatching { RegionMath.estimate(b, zoom.toInt()) }.getOrNull()
                        estimate?.let { Text("Estimativa ampla: ${formatBytes(it.lowBytes)}–${formatBytes(it.highBytes)} + fontes e ícones. O servidor confirmará o tamanho real antes do download.", style = MaterialTheme.typography.bodySmall) }
                    }
                    Button(onClick = {
                        val b = bounds ?: return@Button
                        sending = true
                        vm.action { try { requestRegion(vm, name, b, zoom.toInt()); done() } finally { sending = false } }
                    }, enabled = !sending && name.isNotBlank() && bounds != null, modifier = Modifier.fillMaxWidth()) { Text("Preparar região no servidor") }
                }
            }
        }
    }
}
