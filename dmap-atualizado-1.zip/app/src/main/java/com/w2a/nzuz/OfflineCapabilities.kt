package com.w2a.nzuz

import org.maplibre.android.geometry.LatLng

sealed interface LocalResult<out T> {
    data class Available<T>(val value: T) : LocalResult<T>
    data class Unavailable(val reason: String) : LocalResult<Nothing>
}
data class PlaceResult(val id: String, val name: String, val location: LatLng)
data class RouteResult(val geometry: List<LatLng>, val distanceMeters: Double, val durationSeconds: Double)
interface OfflinePlaceIndex { suspend fun search(query: String, near: LatLng): LocalResult<List<PlaceResult>> }
interface OfflineRouteEngine { suspend fun route(from: LatLng, to: LatLng): LocalResult<RouteResult> }
object InternetRequiredPlaces : OfflinePlaceIndex {
    override suspend fun search(query: String, near: LatLng) = LocalResult.Unavailable("Pesquisa de lugares requer internet nesta versão.")
}
object InternetRequiredRoutes : OfflineRouteEngine {
    override suspend fun route(from: LatLng, to: LatLng) = LocalResult.Unavailable("Cálculo de rotas requer internet nesta versão.")
}
