package com.w2a.nzuz

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre
import org.maplibre.android.geometry.LatLngBounds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DmapsScreen(viewModel()) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DmapsScreen(vm: MapViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val offline by vm.modeOffline.collectAsStateWithLifecycle()
    val internet by vm.connection.usable.collectAsStateWithLifecycle()
    val failure by vm.webFailure.collectAsStateWithLifecycle()
    val regions by vm.regions.collectAsStateWithLifecycle()
    val packageItems by vm.packageItems.collectAsStateWithLifecycle()
    val selectedPackage by vm.selectedPackage.collectAsStateWithLifecycle()
    val location by vm.gps.location.collectAsStateWithLifecycle()
    val gpsStatus by vm.gps.status.collectAsStateWithLifecycle()
    val selected by vm.selectedId.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current
    var permission by remember { mutableStateOf(vm.gps.permitted()) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selecting by rememberSaveable { mutableStateOf(false) }
    var legacy by rememberSaveable { mutableStateOf(false) }
    var showPlaces by remember { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<Long?>(null) }
    var retryKey by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permission = vm.gps.permitted()
        if (permission) vm.gps.start() else vm.notice.value = "Você pode usar os mapas sem permitir sua localização."
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val askLocation = {
        locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
    }
    fun newRegion() {
        if (!internet) { vm.notice.value = "Conecte-se à internet antes de baixar uma região."; return }
        legacy = false
        selecting = true
    }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) { permission = vm.gps.permitted(); vm.gps.start(); vm.action { vm.repo.refreshStatuses() } }
            if (event == Lifecycle.Event.ON_STOP) vm.gps.stop()
        }
        owner.lifecycle.addObserver(observer)
        if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.gps.start()
        onDispose { owner.lifecycle.removeObserver(observer); vm.gps.stop() }
    }
    LaunchedEffect(notice) { notice?.let { snack.showSnackbar(it); vm.notice.value = null } }
    LaunchedEffect(internet) { if (internet) vm.webFailure.value = null }
    LaunchedEffect(offline, selecting, tab) {
        if (offline && !selecting && tab == 0) {
            MapLibre.setConnected(false)
            vm.action { vm.regions.value.filterNot { it.complete }.forEach { vm.repo.pause(it.id) } }
        } else MapLibre.setConnected(null)
    }
    LaunchedEffect(tab) {
        if (tab > 0) while (true) { vm.action { vm.repo.refreshStatuses() }; delay(3_000) }
    }
    val dark = settings.theme == "dark" || (settings.theme == "system" && isSystemInDarkTheme())
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF5CA8FF), background = Color(0xFF17202A), surface = Color(0xFF202A36))
        else lightColorScheme(primary = Color(0xFF007AFF), background = Color(0xFFF2F4F8), surface = Color.White)
    MaterialTheme(colorScheme = scheme, shapes = Shapes(medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(28.dp))) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(title = { Text(if (selecting) "Baixar nova região" else "Dmap") },
                    navigationIcon = { if (selecting) IconButton(onClick = { selecting = false }) { Icon(Icons.Default.ArrowBack, "Voltar") } },
                    actions = { if (!selecting) Text(if (offline) "Offline" else "Online", modifier = Modifier.padding(end = 20.dp), style = MaterialTheme.typography.labelLarge) })
            },
            bottomBar = {
                if (!selecting) NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Map, null) }, label = { Text("Mapa") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Download, null) }, label = { Text("Downloads") })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Configurações") })
                }
            }
        ) { padding ->
            val route = when { selecting && legacy -> "legacySelect"; selecting -> "select"; tab == 1 && legacy -> "legacy"; tab == 1 -> "downloads"; tab == 2 -> "settings"; offline -> "offline"; !internet || failure != null -> "error"; else -> "online" }
            Box(Modifier.fillMaxSize().padding(padding)) {
            AppleMapView(vm, Modifier.fillMaxSize(), active = route == "online", retryKey = retryKey, offline = offline, requestLocation = askLocation)
            Crossfade(targetState = route, animationSpec = tween(360), label = "screen", modifier = Modifier.fillMaxSize()) { destination ->
                when (destination) {
                    "select" -> PackagePicker(vm, permission, { selecting = false; tab = 1 }, { if (Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) })
                    "legacySelect" -> RegionPicker(vm, permission, askLocation, { selecting = false; tab = 1 }, {
                        if (Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    })
                    "downloads" -> PackageDownloads(vm, { newRegion() }, { vm.selectedPackage.value = it.key; vm.setMode(true); tab = 0 }, { legacy = true })
                    "legacy" -> RegionsPanel(vm, regions, onNew = { if (settings.authorized && settings.styleUrl.isNotBlank()) { legacy = true; selecting = true } else { tab = 2; vm.notice.value = "Configure a fonte avançada autorizada." } }, onOpen = {
                        vm.selectedId.value = it.id; vm.selectedPackage.value = null; vm.setMode(true); tab = 0
                    }, onDelete = { deleteId = it.id })
                    "settings" -> SettingsPanel(vm, settings, regions.size + packageItems.count { it.installed }, onNew = { newRegion() }, onRegions = { legacy = false; tab = 1 })
                    "offline" -> {
                        val region = remember(regions, selected, location) { vm.bestRegion(location) }
                        val pack = remember(packageItems, selectedPackage, location) { vm.bestPackage(location) }
                        if (pack != null && !(legacy && region != null)) OfflineMapPanel(vm, null, location, permission, gpsStatus, askLocation,
                            onPlaces = { showPlaces = true }, onOnline = { vm.retryOnline(); retryKey++ }, pack = pack, dark = dark)
                        else if (region == null) EmptyMap(
                            "Nenhuma região disponível offline",
                            "Baixe uma região com internet antes de ficar sem conexão. Pesquisa e rotas precisam de internet.",
                            "Mapas offline", { tab = 1 }, if (internet) "Tentar online" else null,
                            { vm.retryOnline(); retryKey++ }
                        ) else OfflineMapPanel(vm, region, location, permission, gpsStatus, askLocation,
                            onPlaces = { showPlaces = true }, onOnline = { vm.retryOnline(); retryKey++ })
                    }
                    "error" -> EmptyMap("Mapa online indisponível",
                        failure ?: "A rede está sem acesso à internet. Seus mapas baixados continuam disponíveis.",
                        "Abrir offline", { vm.setMode(true) }, "Tentar novamente", { vm.retryOnline(); retryKey++ })
                    else -> Unit
                }
            }
            }
        }
        if (showPlaces) ModalBottomSheet(onDismissRequest = { showPlaces = false }) {
            Column(Modifier.fillMaxWidth().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Regiões disponíveis offline", style = MaterialTheme.typography.titleLarge)
                packageItems.filter { it.installed }.forEach { item ->
                    OutlinedButton(onClick = { vm.selectedPackage.value = item.pack.key; legacy = false; showPlaces = false }, modifier = Modifier.fillMaxWidth()) { Text(item.pack.name) }
                }
                regions.filter { it.complete }.forEach { region ->
                    OutlinedButton(onClick = { vm.selectedId.value = region.id; legacy = true; showPlaces = false }, modifier = Modifier.fillMaxWidth()) { Text(region.name) }
                }
                Text("A busca de lugares e o cálculo de rotas ainda dependem da internet.")
                Spacer(Modifier.height(20.dp))
            }
        }
        deleteId?.let { id -> AlertDialog(onDismissRequest = { deleteId = null }, title = { Text("Excluir região?") },
            text = { Text("O download será interrompido e os recursos não compartilhados serão removidos. Será necessário baixar novamente.") },
            confirmButton = { TextButton(onClick = { deleteId = null; vm.action { vm.repo.delete(id) } }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Manter") } }) }
    }
}

@Composable
fun EmptyMap(title: String, body: String, action: String, onAction: () -> Unit, other: String? = null, onOther: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Map, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(20.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp)); Text(body)
        Spacer(Modifier.height(20.dp)); Button(onClick = onAction) { Text(action) }
        other?.let { TextButton(onClick = onOther) { Text(it) } }
    }
}

@Composable
private fun OfflineMapPanel(vm: MapViewModel, region: RegionItem?, location: android.location.Location?, permission: Boolean,
    gpsStatus: String, askLocation: () -> Unit, onPlaces: () -> Unit, onOnline: () -> Unit, pack: MapPackage? = null, dark: Boolean = false) {
    val handle = remember { NativeMapHandle() }
    var follow by remember { mutableIntStateOf(0) }
    var mapError by remember(region?.id, pack?.key) { mutableStateOf<String?>(null) }
    val age by produceState(0L, location) {
        while (true) {
            value = location?.let { ((android.os.SystemClock.elapsedRealtimeNanos() - it.elapsedRealtimeNanos) / 1_000_000_000).coerceAtLeast(0) } ?: 0
            delay(10_000)
        }
    }
    handle.onGesture = { if (handle.orientation == Orientation.COMPASS) handle.orient(Orientation.FREE); follow = 0 }
    handle.onFailure = { mapError = it }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            NativeMapView(vm, handle, region, false, "", location, permission, Modifier.fillMaxSize(), pack, dark)
            Column(Modifier.align(Alignment.TopEnd).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallFloatingActionButton(onClick = { handle.orient(Orientation.NORTH); follow = 0 }) { Text("N") }
                SmallFloatingActionButton(onClick = { handle.orient(Orientation.FREE); follow = 0 }) { Icon(Icons.Default.OpenWith, "Orientação livre") }
                SmallFloatingActionButton(onClick = {
                    if (!permission) askLocation()
                    else if (location == null) vm.notice.value = gpsStatus
                    else {
                        follow = (follow + 1) % 3
                        when (follow) { 0 -> handle.orient(Orientation.FREE); 1 -> { handle.orient(Orientation.NORTH); handle.center() }; else -> handle.orient(Orientation.COMPASS) }
                    }
                }) { Icon(if (follow == 2) Icons.Default.Explore else if (follow == 1) Icons.Default.MyLocation else Icons.Default.LocationSearching,
                    if (follow == 0) "Centralizar e acompanhar" else if (follow == 1) "Orientar pela bússola" else "Orientação livre") }
            }
            mapError?.let { Surface(Modifier.align(Alignment.Center).padding(24.dp), shape = RoundedCornerShape(20.dp), tonalElevation = 6.dp) {
                Column(Modifier.padding(20.dp)) { Text(it); TextButton(onClick = onPlaces) { Text("Escolher outra região") } }
            } }
        }
        Surface(modifier = Modifier.animateContentSize(), color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp, shadowElevation = 4.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(pack?.name ?: region!!.name, style = MaterialTheme.typography.titleMedium)
                Text(if (location != null) "Precisão ±${location.accuracy.toInt()} m • ${listOf("Livre", "Seguindo", "Bússola")[follow]}" else gpsStatus,
                    style = MaterialTheme.typography.bodySmall)
                if (location != null && age > 30) Text("Última posição há ${age}s; aguardando atualização do GPS.", style = MaterialTheme.typography.bodySmall)
                if (location != null && (pack?.bounds ?: region?.definition?.bounds)?.contains(org.maplibre.android.geometry.LatLng(location.latitude, location.longitude)) != true)
                    Text("Sua posição está fora desta região baixada.", color = MaterialTheme.colorScheme.error)
                Text(pack?.attribution ?: region!!.credit, style = MaterialTheme.typography.labelSmall, maxLines = 3)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = onPlaces) { Text("Regiões") }
                    TextButton(onClick = onOnline) { Text("Pesquisa e rotas online") }
                }
            }
        }
    }
}

@Composable
private fun RegionPicker(vm: MapViewModel, permission: Boolean, askLocation: () -> Unit, done: () -> Unit, notifyPermission: () -> Unit) {
    val handle = remember { NativeMapHandle() }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val location by vm.gps.location.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var bounds by remember { mutableStateOf<LatLngBounds?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    var zoom by rememberSaveable { mutableFloatStateOf(14f) }
    var error by remember { mutableStateOf<String?>(null) }
    val estimate = remember(bounds, zoom) { bounds?.let { runCatching { RegionMath.estimate(it, zoom.toInt()) }.getOrNull() } }
    handle.onSelection = { bounds = it }
    handle.onFailure = { error = it }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            NativeMapView(vm, handle, null, true, settings.styleUrl, location, permission, Modifier.fillMaxSize())
            Canvas(Modifier.fillMaxSize()) {
                val p = 24.dp.toPx()
                drawRect(Color(0xFF007AFF), Offset(p, p), Size((size.width - p * 2).coerceAtLeast(0f), (size.height - p * 2).coerceAtLeast(0f)), style = Stroke(3.dp.toPx()))
            }
            SmallFloatingActionButton(onClick = { if (!permission) askLocation() else handle.center() }, modifier = Modifier.align(Alignment.TopEnd).padding(30.dp)) {
                Icon(Icons.Default.MyLocation, "Centralizar")
            }
        }
        Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).heightIn(max = 320.dp).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Mova e amplie o mapa. A área dentro da borda será baixada.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(name, { name = it.take(80) }, label = { Text("Nome da região") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Detalhes: zoom ${zoom.toInt()} • ${if (zoom >= 15) "Ruas e edifícios" else if (zoom >= 12) "Ruas" else "Visão geral"}")
            Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 8f..16f, steps = 7)
            estimate?.let { Text("Estimativa: ${formatBytes(it.lowBytes)}–${formatBytes(it.highBytes)} • ${it.tiles} tiles-base", style = MaterialTheme.typography.bodySmall) }
            Text("Estimativa aproximada; fontes e camadas extras podem aumentar o tamanho.", style = MaterialTheme.typography.labelSmall)
            if (estimate != null && estimate.tiles > RegionMath.MAX_TILES) Text("Reduza a área ou os detalhes.", color = MaterialTheme.colorScheme.error)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(onClick = {
                val area = bounds ?: return@Button
                notifyPermission(); vm.create(name, area, zoom.toInt(), done)
            }, enabled = !busy && error == null && name.isNotBlank() && estimate != null && estimate.tiles <= RegionMath.MAX_TILES,
                modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Salvando região…" else "Baixar região") }
        }
    }
}
