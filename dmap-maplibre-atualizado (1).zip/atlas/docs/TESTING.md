# Validação — estado real

## Execução

Nenhum teste Kotlin/JVM ou Android foi executado. Nenhum APK foi compilado ou instalado. O usuário suspendeu compilação, incluindo testes que exigem compilar o app. Não existe inspeção visual do app em execução, medição de fluidez ou comparação por capturas.

Verificações não compiladas já realizadas: integridade dos arquivos preservados, hashes das skills, parse de XML/JSON da configuração e estilos; são verificações de arquivos, não testes funcionais.

## Testes escritos

- `core`: coordenadas, progressão de navegação, desvios, chegada, imprecisão, linha internacional de data, formatação e links externos inválidos.
- `network`: parsers Photon/Overpass/OSRM/ORS, erros HTTP, cancelamento, identidade OSM, parâmetros, cache e capacidades do provedor.
- `data`: normalização e validação; instrumentação Room/DataStore, relações de listas, reabertura dos arquivos e recuperação de falhas.
- `ui/MapPanelsTest`: seleção exata de resultados, pesquisa vazia, tentar novamente, ficha sem metadados comerciais, escolha de origem, ocultação de modos não suportados e quatro estados do painel via acessibilidade.

As fixtures são restritas aos testes. Não são dados apresentados pelo aplicativo.

## Próxima execução, após autorização para compilar

Preparar o ambiente conforme [BUILD.md](BUILD.md), executar JVM e instrumentação, corrigir falhas observadas e registrar comando, data, dispositivo e resultado. Não substituir essa etapa pela mera leitura do código.

## Fluxos de dispositivo pendentes

| Cenário | Resultado registrado |
| --- | --- |
| Primeira abertura, negar/aproximada/precisa, GPS desativado | Não executado |
| Pesquisa de endereço real, resultados, cancelamento e erro lento | Não executado |
| Seleção de lugar, detalhes, favoritos e múltiplas listas | Não executado |
| Fechar/reabrir app e reiniciar dispositivo; persistência | Não executado |
| Origem/destino, paradas, alternativas e modos habilitados | Não executado |
| Navegação, voz, desvio, recálculo e resposta antiga de sessão encerrada | Não executado |
| GPS perdido, tela apagada, encerrar pela notificação | Não executado |
| Tema, unidades, redução de movimento e feedback háptico | Não executado |
| Mapa indisponível, offline e recuperação de rede | Não executado |
| Arrastar painel, flings, rolagem interna e teclado | Não executado |
| Paisagem, tela estreita/grande, fonte 200%, TalkBack | Não executado |
| Compartilhar, copiar, discador, site e deep links inválidos | Não executado |
| Memória, bateria, fluidez e liberação de MapView | Não executado |

## Links para exercitar futuramente

```text
atlas://search?q=Avenida%20Paulista
atlas://place?lat=-23.5614&lon=-46.6559&name=Local%20marcado
atlas://navigate?lat=-23.5614&lon=-46.6559
geo:-23.5614,-46.6559
geo:0,0?q=-23.5614,-46.6559(Local%20marcado)
```

O comando `navigate` abre planejamento: ele não inicia GPS ou navegação sozinho. As coordenadas são entradas explícitas para teste, não uma afirmação sobre o nome/endereço de um estabelecimento. Parâmetros fora da faixa, repetidos, fragmentos, esquemas inesperados e codificação inválida são rejeitados pelo parser.
