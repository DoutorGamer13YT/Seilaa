package dev.atlas.ui.screens

import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyItemScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.*
import dev.atlas.ui.MapScreenState
import dev.atlas.ui.components.PlaceRow
import dev.atlas.ui.components.pressScale
import dev.atlas.ui.theme.AtlasMotion
import dev.atlas.ui.theme.LocalAtlasReduceMotion

@Composable
fun ExplorePanel(favorites: List<SavedPlace>, shortcuts: List<Shortcut>, history: List<SearchHistory>,
    onSelect: (Place) -> Unit, onLibrary: () -> Unit, onSearch: (String) -> Unit,
    onCategory: (PlaceCategory) -> Unit, onRemoveHistory: (String) -> Unit,
) {
    val reduceMotion = LocalAtlasReduceMotion.current
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item(key = "library") {
            Column(Modifier.padding(horizontal = 20.dp)) {
                SectionHeading("Biblioteca", "Ver tudo", onLibrary)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ShortcutTile("Casa", Icons.Rounded.Home, Color(0xFF007AFF), Modifier.weight(1f)) {
                        shortcuts.firstOrNull { it.kind == "home" }?.let { onSelect(it.place) } ?: onLibrary()
                    }
                    ShortcutTile("Trabalho", Icons.Rounded.Work, Color(0xFFA05DE1), Modifier.weight(1f)) {
                        shortcuts.firstOrNull { it.kind == "work" }?.let { onSelect(it.place) } ?: onLibrary()
                    }
                    ShortcutTile("Salvos", Icons.Rounded.Bookmark, Color(0xFFEB625A), Modifier.weight(1f), onLibrary)
                }
            }
        }
        if (favorites.isNotEmpty()) item(key = "favorites") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 20.dp)) {
                items(favorites.take(8), key = { it.place.id }) { saved ->
                    val interaction = remember { MutableInteractionSource() }
                    Surface(onClick = { onSelect(saved.place) }, interactionSource = interaction, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface,
                        modifier = itemMotion(reduceMotion).width(178.dp).pressScale(interaction, 0.975f)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Icon(Icons.Rounded.Bookmark, null, tint = MaterialTheme.colorScheme.primary)
                            Text(saved.place.name, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text(saved.place.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
        item(key = "categories") {
            Column {
                Text("Explore por perto", Modifier.padding(horizontal = 20.dp).padding(bottom = 12.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(PlaceCategory.entries) { category ->
                        SuggestionChip(onClick = { onCategory(category) }, label = { Text(category.label) }, shape = RoundedCornerShape(22.dp), icon = { Icon(categoryIcon(category), null, Modifier.size(18.dp)) })
                    }
                }
            }
        }
        if (history.isNotEmpty()) {
            item(key = "history-title") { Text("Recentes", Modifier.padding(horizontal = 20.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            items(history.take(6), key = { "history:${it.query}" }) { recent ->
                Row(itemMotion(reduceMotion).fillMaxWidth().clickable { onSearch(recent.query) }.padding(start = 22.dp, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Schedule, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(recent.query, Modifier.weight(1f).padding(horizontal = 14.dp), maxLines = 2)
                    IconButton(onClick = { onRemoveHistory(recent.query) }) { Icon(Icons.Rounded.Close, "Remover ${recent.query} do histórico", Modifier.size(18.dp)) }
                }
            }
        } else item(key = "empty-history") {
            Text("O próximo lugar começa aqui.\nPesquise um endereço ou explore o mapa.", Modifier.padding(horizontal = 22.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ShortcutTile(label: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(58.dp).background(color.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) { Icon(icon, null, Modifier.size(28.dp), color) }
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SectionHeading(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
fun SearchResults(state: MapScreenState, favorites: List<SavedPlace>, history: List<SearchHistory>, units: Units,
    position: Coordinate?, onSelect: (Place) -> Unit, onRetry: () -> Unit, onHistory: (String) -> Unit, onDeleteHistory: (String) -> Unit,
) {
    val reduceMotion = LocalAtlasReduceMotion.current
    val savedIds = remember(favorites) { favorites.mapTo(HashSet()) { it.place.id } }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        if (state.searching) item(key = "search-progress") {
            Row(itemMotion(reduceMotion).padding(24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Text("Buscando lugares…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        state.error?.let { error -> item(key = "search-error") { Box(itemMotion(reduceMotion)) { ErrorCard(error, onRetry) } } }
        if (!state.searching && state.error == null && state.searched && state.results.isEmpty()) item(key = "no-results") {
            Box(itemMotion(reduceMotion)) { MessageCard(Icons.Rounded.SearchOff, "Nenhum lugar encontrado", "Tente incluir a cidade ou pesquisar outro endereço.") }
        }
        if (state.results.isNotEmpty()) item(key = "results-title") {
            Text(if (state.category != null) "${state.results.size} lugares · até 3 km" else "Resultados", itemMotion(reduceMotion).padding(horizontal = 22.dp, vertical = 12.dp), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(state.results, key = { "place:${it.id}" }, contentType = { "place" }) { place ->
            Box(itemMotion(reduceMotion)) {
                PlaceRow(place = place, distance = position?.let { "aprox. ${formatDistance(it.distanceTo(place.coordinate), units)}" }, saved = place.id in savedIds, onClick = { onSelect(place) })
            }
        }
        if (!state.searched && state.query.isBlank()) {
            item(key = "history-title") { Text("Recentes", itemMotion(reduceMotion).padding(22.dp), fontWeight = FontWeight.Bold, fontSize = 21.sp) }
            if (history.isEmpty()) item(key = "empty-history") { MessageCard(Icons.Rounded.Search, "Encontre seu próximo lugar", "Busque ruas, cidades, endereços e estabelecimentos.") }
            items(history, key = { "history:${it.query}" }, contentType = { "history" }) { recent ->
                Row(itemMotion(reduceMotion).fillMaxWidth().clickable { onHistory(recent.query) }.padding(start = 22.dp, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Schedule, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(recent.query, Modifier.weight(1f).padding(16.dp))
                    IconButton(onClick = { onDeleteHistory(recent.query) }) { Icon(Icons.Rounded.Close, "Remover pesquisa") }
                }
            }
        }
    }
}

private fun LazyItemScope.itemMotion(reduceMotion: Boolean): Modifier =
    if (reduceMotion) Modifier else Modifier.animateItem(
        fadeInSpec = tween(180, easing = AtlasMotion.Standard),
        placementSpec = spring(dampingRatio = 1f, stiffness = 450f),
        fadeOutSpec = tween(110),
    )

@Composable fun ErrorCard(message: String, onRetry: () -> Unit) {
    Surface(Modifier.padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.errorContainer) {
        Column(Modifier.padding(18.dp)) { Text(message, color = MaterialTheme.colorScheme.onErrorContainer); TextButton(onClick = onRetry) { Text("Tentar novamente") } }
    }
}
@Composable fun MessageCard(icon: ImageVector, title: String, description: String) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, Modifier.size(36.dp), MaterialTheme.colorScheme.onSurfaceVariant)
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
fun categoryIcon(category: PlaceCategory): ImageVector = when (category) {
    PlaceCategory.RESTAURANTS -> Icons.Rounded.Restaurant
    PlaceCategory.CAFES -> Icons.Rounded.LocalCafe
    PlaceCategory.MARKETS -> Icons.Rounded.LocalGroceryStore
    PlaceCategory.PHARMACIES, PlaceCategory.HOSPITALS -> Icons.Rounded.LocalHospital
    PlaceCategory.FUEL -> Icons.Rounded.LocalGasStation
    PlaceCategory.PARKING -> Icons.Rounded.LocalParking
    PlaceCategory.HOTELS -> Icons.Rounded.Hotel
    PlaceCategory.BANKS, PlaceCategory.ATMS -> Icons.Rounded.AccountBalance
    PlaceCategory.PARKS -> Icons.Rounded.Park
    PlaceCategory.GYMS -> Icons.Rounded.FitnessCenter
    PlaceCategory.TRANSIT -> Icons.Rounded.Train
    PlaceCategory.AIRPORTS -> Icons.Rounded.Flight
    PlaceCategory.SCHOOLS, PlaceCategory.UNIVERSITIES -> Icons.Rounded.School
    PlaceCategory.CAR_REPAIR -> Icons.Rounded.Build
    PlaceCategory.ATTRACTIONS -> Icons.Rounded.PhotoCamera
    else -> Icons.Rounded.Place
}
