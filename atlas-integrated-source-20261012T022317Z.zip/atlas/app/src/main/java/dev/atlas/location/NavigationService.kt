package dev.atlas.location

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import dev.atlas.AtlasApplication
import dev.atlas.core.AppException
import dev.atlas.core.ErrorKind
import dev.atlas.core.NavigationEngine
import dev.atlas.core.NavigationProgress
import dev.atlas.core.Route
import dev.atlas.core.TransportMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

/** A visible, explicitly started location foreground service. No background location permission. */
class NavigationService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var tracker: LocationTracker
    private var tts: TextToSpeech? = null
    private var voiceReady = false
    private var voiceError: String? = null
    private var lastAnnouncement = ""
    private var nearAnnouncement = ""
    private var lastNotificationMillis = 0L
    private var lastNotificationText = ""
    private var collecting = false
    private var trackedRoute: Route? = null
    private var sessionId = 0L
    private var destroyed = false
    private var recalculationJob: Job? = null
    private var recalculationGeneration = 0L
    private var lastRecalculationMillis: Long? = null

    override fun onCreate() {
        super.onCreate()
        tracker = LocationTracker(this)
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(
                CHANNEL, "Navegação em andamento", NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Instruções e controle da navegação ativa"; setSound(null, null) })
        }
        tts = TextToSpeech(this) { status ->
            if (destroyed) return@TextToSpeech
            if (status == TextToSpeech.SUCCESS) {
                val support = tts?.setLanguage(Locale.forLanguageTag("pt-BR")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                voiceReady = support != TextToSpeech.LANG_MISSING_DATA && support != TextToSpeech.LANG_NOT_SUPPORTED
                if (!voiceReady) voiceError = "Voz em português indisponível. As instruções continuam na tela."
            } else voiceError = "Áudio indisponível. As instruções continuam na tela."
            if (voiceError != null) NavigationSession.update {
                if (!it.active || it.muted || it.sessionId != sessionId) it else it.copy(error = voiceError)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val current = NavigationSession.state.value
        val requestedSession = intent?.getLongExtra(EXTRA_SESSION_ID, -1L) ?: -1L
        if (intent?.action == ACTION_STOP) {
            if (requestedSession == current.sessionId) NavigationSession.stop(this)
            return START_NOT_STICKY
        }
        if (!current.active || current.route == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        // An old queued start/notification cannot control a later user-initiated session.
        if (requestedSession != current.sessionId) return START_NOT_STICKY
        if (sessionId != current.sessionId) {
            cancelRecalculation()
            lastRecalculationMillis = null
            trackedRoute = null
        }
        sessionId = current.sessionId
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tracker.stop()
            NavigationSession.fail("Permita a localização para iniciar a navegação.", sessionId)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val notification = notification(NavigationSession.state.value)
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            else startForeground(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            tracker.stop()
            NavigationSession.fail("Não foi possível iniciar a localização. Abra o aplicativo e confira as permissões.", sessionId)
            stopSelf()
            return START_NOT_STICKY
        } catch (_: IllegalStateException) {
            tracker.stop()
            NavigationSession.fail("Abra o aplicativo para iniciar a navegação.", sessionId)
            stopSelf()
            return START_NOT_STICKY
        }
        lastAnnouncement = ""
        nearAnnouncement = ""
        tracker.start(navigating = true)
        if (!collecting) {
            collecting = true
            scope.launch {
                combine(tracker.state, NavigationSession.state.map { Triple(it.sessionId, it.route, it.active) }.distinctUntilChanged()) {
                    location, session -> location to session
                }.collectLatest { (location, session) ->
                        val (expectedSession, route, active) = session
                        if (route == null || !active) {
                            cancelRecalculation()
                            tracker.stop()
                            tts?.stop()
                            stopSelf()
                            return@collectLatest
                        }
                        if (expectedSession != sessionId) {
                            cancelRecalculation()
                            return@collectLatest
                        }
                        if (route != trackedRoute) {
                            cancelRecalculation()
                            trackedRoute = route
                            tracker.start(navigating = true)
                        }
                        // Arrival intentionally stops GPS. Do not turn that into a lost-signal banner.
                        if (NavigationSession.state.value.progress?.arrived == true) {
                            cancelRecalculation(clearError = true)
                            return@collectLatest
                        }
                        if (!location.permissionGranted) {
                            tracker.stop()
                            NavigationSession.fail(location.error ?: "A permissão de localização foi removida.", expectedSession)
                            stopSelf()
                            return@collectLatest
                        }
                        val fix = location.fix
                        val inaccurate = fix != null && fix.accuracyMeters > 100f
                        val usableForGuidance = fix != null && !location.isStale && location.providerEnabled && !inaccurate
                        val previous = NavigationSession.state.value.progress
                        val progress = if (usableForGuidance && fix != null) withContext(Dispatchers.Default) {
                            NavigationEngine.progress(route, fix, previous)
                        } else previous
                        NavigationSession.update { current ->
                            if (!current.active || current.sessionId != expectedSession || current.route != route) current else current.copy(
                                progress = progress, fix = fix, gpsLost = !usableForGuidance,
                                error = if (inaccurate) "Localização imprecisa. Ative a localização precisa para receber instruções."
                                    else location.error ?: voiceError?.takeUnless { current.muted },
                            )
                        }
                        val state = NavigationSession.state.value
                        if (!state.active || state.sessionId != expectedSession || state.route != route) return@collectLatest
                        if (state.gpsLost || state.progress?.offRoute != true) {
                            cancelRecalculation(clearError = !state.gpsLost)
                        } else maybeRecalculate(state)
                        updateNotification(NavigationSession.state.value)
                        if (state.gpsLost || state.progress?.offRoute == true) tts?.stop()
                        announce(state)
                        if (state.progress?.arrived == true) tracker.stop()
                    }
            }
            scope.launch {
                NavigationSession.state.map { it.muted }.distinctUntilChanged().collectLatest { muted ->
                    if (muted) tts?.stop()
                }
            }
        }
        return START_NOT_STICKY
    }

    /** Owned by the foreground service, so closing the activity does not remove recalculation. */
    private fun maybeRecalculate(state: NavigationState) {
        val progress = state.progress ?: return
        if (!state.active || state.sessionId != sessionId || state.gpsLost || !progress.offRoute ||
            progress.arrived || recalculationJob?.isActive == true) return
        val originalRoute = state.route ?: return
        val fix = state.fix ?: return
        val now = SystemClock.elapsedRealtime()
        if (lastRecalculationMillis?.let { now - it < RECALCULATION_COOLDOWN_MILLIS } == true) return
        lastRecalculationMillis = now
        val expectedSession = state.sessionId
        val generation = ++recalculationGeneration
        NavigationSession.update {
            if (it.active && it.sessionId == expectedSession && it.route === originalRoute)
                it.copy(recalculating = true, routeError = null) else it
        }
        recalculationJob = scope.launch {
            try {
                val points = withContext(Dispatchers.Default) { remainingRoutePoints(originalRoute, fix.coordinate, progress) }
                if (points.size < 2) throw AppException(ErrorKind.NO_ROUTE, "A rota não tem um destino válido para recalcular.")
                val replacement = withContext(Dispatchers.IO) {
                    (application as AtlasApplication).routing.routes(points, originalRoute.mode).firstOrNull()
                        ?: throw AppException(ErrorKind.NO_ROUTE, "Nenhuma nova rota foi encontrada para este destino.")
                }
                if (!ownsRecalculation(generation, expectedSession, originalRoute)) return@launch
                val current = NavigationSession.state.value
                if (!current.gpsLost && current.progress?.offRoute == true &&
                    !NavigationSession.updateRoute(replacement, expectedSession, originalRoute)) {
                    throw AppException(ErrorKind.PROVIDER, "O serviço enviou uma rota que não pode ser usada.")
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                if (ownsRecalculation(generation, expectedSession, originalRoute)) {
                    val reason = (failure as? AppException)?.message ?: "Verifique a conexão e tente novamente."
                    NavigationSession.update {
                        if (it.active && it.sessionId == expectedSession && it.route === originalRoute)
                            it.copy(routeError = "Não foi possível recalcular. $reason") else it
                    }
                }
            } finally {
                if (generation == recalculationGeneration) {
                    recalculationJob = null
                    NavigationSession.update {
                        if (it.sessionId == expectedSession) it.copy(recalculating = false) else it
                    }
                    val current = NavigationSession.state.value
                    if (!destroyed && current.active && current.sessionId == expectedSession) updateNotification(current)
                }
            }
        }
    }

    private fun ownsRecalculation(generation: Long, expectedSession: Long, route: Route): Boolean {
        val current = NavigationSession.state.value
        return !destroyed && generation == recalculationGeneration && current.active &&
            current.sessionId == expectedSession && current.route === route
    }

    private fun cancelRecalculation(clearError: Boolean = false) {
        recalculationGeneration++
        recalculationJob?.cancel()
        recalculationJob = null
        NavigationSession.update {
            if (it.sessionId == sessionId) it.copy(recalculating = false,
                routeError = if (clearError) null else it.routeError) else it
        }
    }

    private fun updateNotification(state: NavigationState) {
        val now = SystemClock.elapsedRealtime()
        val title = notificationText(state)
        if (title == lastNotificationText) return
        if (now - lastNotificationMillis < 3_000 && state.progress?.arrived != true &&
            state.progress?.offRoute != true && !state.gpsLost) return
        lastNotificationMillis = now
        lastNotificationText = title
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(state))
    }

    private fun notificationText(state: NavigationState): String = when {
        state.gpsLost -> "Aguardando sinal de localização"
        state.progress?.arrived == true -> "Você chegou ao destino"
        state.recalculating -> "Recalculando a rota"
        state.routeError != null -> state.routeError
        state.progress?.offRoute == true -> "Você está fora do trajeto"
        state.progress != null -> "${distance(state.progress.distanceToManeuverMeters)} · ${state.progress.instruction}"
        else -> "Preparando as instruções"
    }

    private fun notification(state: NavigationState): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val stop = PendingIntent.getService(this, state.sessionId.hashCode(),
            Intent(this, NavigationService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_SESSION_ID, state.sessionId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 1, it.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        return builder.setSmallIcon(android.R.drawable.ic_menu_directions)
            .setContentTitle("Atlas · Navegação")
            .setContentText(notificationText(state))
            .setStyle(Notification.BigTextStyle().bigText(notificationText(state)))
            .setContentIntent(open).setCategory(Notification.CATEGORY_NAVIGATION)
            .setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Encerrar", stop).build())
            .build()
    }

    private fun announce(state: NavigationState) {
        if (!voiceReady || state.muted || state.gpsLost || !state.active) return
        val progress = state.progress ?: return
        if (progress.offRoute) return
        val key = "${progress.routeKey}:${progress.stepIndex}"
        val near = progress.distanceToManeuverMeters < if (state.route?.mode == TransportMode.CAR) 100 else 40
        val announcement = when {
            progress.arrived && lastAnnouncement != "arrived:${progress.routeKey}" -> {
                lastAnnouncement = "arrived:${progress.routeKey}"
                "Você chegou ao destino."
            }
            progress.arrived -> null
            key != lastAnnouncement -> {
                lastAnnouncement = key
                if (near) nearAnnouncement = key
                instruction(progress)
            }
            near && nearAnnouncement != key -> {
                nearAnnouncement = key
                instruction(progress)
            }
            else -> null
        }
        if (announcement != null) tts?.speak(announcement, TextToSpeech.QUEUE_FLUSH, null, "atlas-maneuver")
    }

    private fun instruction(progress: NavigationProgress): String = if (progress.distanceToManeuverMeters < 10)
        progress.instruction else "Em ${distance(progress.distanceToManeuverMeters)}, ${progress.instruction}"

    private fun distance(meters: Double): String = if (meters >= 1000)
        String.format(Locale.forLanguageTag("pt-BR"), "%.1f quilômetros", meters / 1000)
        else "${(meters / 10).roundToInt() * 10} metros"

    override fun onDestroy() {
        destroyed = true
        cancelRecalculation()
        scope.cancel()
        tracker.stop()
        tts?.stop()
        tts?.shutdown()
        tts = null
        NavigationSession.serviceStopped(sessionId)
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "dev.atlas.navigation.START"
        const val ACTION_STOP = "dev.atlas.navigation.STOP"
        const val EXTRA_SESSION_ID = "dev.atlas.navigation.SESSION_ID"
        private const val CHANNEL = "atlas_navigation"
        private const val NOTIFICATION_ID = 501
        private const val RECALCULATION_COOLDOWN_MILLIS = 25_000L
    }
}
