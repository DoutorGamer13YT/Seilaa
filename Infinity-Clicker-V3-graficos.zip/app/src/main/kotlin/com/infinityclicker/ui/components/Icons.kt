package com.infinityclicker.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ícones desenhados em vetor numa grade 24×24, no lugar de caracteres de texto (✦ ◈ ≋ ♪ ↻ ...).
 * Caracteres dependem da fonte do aparelho: em alguns viram emoji colorido, em outros um quadradinho vazio,
 * e o tamanho muda de um para o outro. Desenhados, ficam iguais em qualquer celular e na cor certa.
 */
private val GLYPHS = setOf(
    "●", "■", "▲", "◆", "★", "✦", "✧", "◈", "◎", "◉", "◐", "◑", "≋", "Σ", "×", "%", "↑", "↓", "↻", "♪", "♫", "✕", "⚠"
)

fun hasGlyphIcon(symbol: String): Boolean = symbol in GLYPHS

/** Ícone de [symbol] com o lado dado; símbolos desconhecidos não desenham nada (use [hasGlyphIcon] antes). */
@Composable
fun GlyphIcon(symbol: String, color: Color, size: Dp) {
    Canvas(Modifier.size(size)) { drawGlyph(symbol, color) }
}

fun DrawScope.drawGlyph(symbol: String, color: Color) {
    val k = this.size.minDimension / 24f
    val line = Stroke(2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val thin = Stroke(1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    withTransform({ scale(k, k, Offset.Zero) }) {
        when (symbol) {
            "●" -> drawCircle(color, 7.5f, Offset(12f, 12f))
            "■" -> drawRoundRect(color, Offset(5f, 5f), Size(14f, 14f), CornerRadius(3f))
            "▲" -> {
                val p = polygon(12f, 4.5f, 20.5f, 19f, 3.5f, 19f)
                drawPath(p, color); drawPath(p, color, style = Stroke(1.6f, join = StrokeJoin.Round))
            }
            "◆" -> {
                val p = polygon(12f, 3f, 21f, 12f, 12f, 21f, 3f, 12f)
                drawPath(p, color); drawPath(p, color, style = Stroke(1.2f, join = StrokeJoin.Round))
            }
            "★" -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.2f
                    val a = (-PI / 2 + i * PI / 5).toFloat()
                    val x = 12f + cos(a) * r; val y = 12.4f + sin(a) * r
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, color); drawPath(p, color, style = Stroke(1.2f, join = StrokeJoin.Round))
            }
            "✦" -> drawPath(sparkle(), color)
            "✧" -> drawPath(sparkle(), color, style = line)
            "◈" -> {
                drawPath(polygon(12f, 2.5f, 21.5f, 12f, 12f, 21.5f, 2.5f, 12f), color, style = line)
                drawPath(polygon(12f, 7.5f, 16.5f, 12f, 12f, 16.5f, 7.5f, 12f), color)
            }
            "◎" -> {
                drawCircle(color, 8.5f, Offset(12f, 12f), style = line)
                drawCircle(color, 3.6f, Offset(12f, 12f))
            }
            "◉" -> {
                drawCircle(color, 9f, Offset(12f, 12f), style = line)
                drawCircle(color, 5.2f, Offset(12f, 12f))
            }
            "◐", "◑" -> {
                drawCircle(color, 8.8f, Offset(12f, 12f), style = line)
                drawArc(color, if (symbol == "◐") 90f else -90f, 180f, true, Offset(4f, 4f), Size(16f, 16f))
            }
            "≋" -> for (y in floatArrayOf(7.5f, 12f, 16.5f)) {
                val w = Path().apply {
                    moveTo(3.5f, y); cubicTo(6.5f, y - 3.2f, 9.5f, y - 3.2f, 12f, y); cubicTo(14.5f, y + 3.2f, 17.5f, y + 3.2f, 20.5f, y)
                }
                drawPath(w, color, style = thin)
            }
            "Σ" -> drawPath(Path().apply {
                moveTo(18f, 5f); lineTo(6f, 5f); lineTo(13f, 12f); lineTo(6f, 19f); lineTo(18f, 19f)
            }, color, style = Stroke(2.3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            "×", "✕" -> {
                val s = Stroke(2.5f, cap = StrokeCap.Round)
                drawLine(color, Offset(6.5f, 6.5f), Offset(17.5f, 17.5f), s.width, StrokeCap.Round)
                drawLine(color, Offset(17.5f, 6.5f), Offset(6.5f, 17.5f), s.width, StrokeCap.Round)
            }
            "%" -> {
                drawLine(color, Offset(17.5f, 5.5f), Offset(6.5f, 18.5f), 2.2f, StrokeCap.Round)
                drawCircle(color, 3f, Offset(7.5f, 7.5f), style = thin)
                drawCircle(color, 3f, Offset(16.5f, 16.5f), style = thin)
            }
            "↑", "↓" -> {
                val up = symbol == "↑"
                val y0 = if (up) 19f else 5f; val y1 = if (up) 5f else 19f; val d = if (up) 6.5f else -6.5f
                drawLine(color, Offset(12f, y0), Offset(12f, y1), 2.3f, StrokeCap.Round)
                drawPath(Path().apply { moveTo(5.5f, y1 + d); lineTo(12f, y1); lineTo(18.5f, y1 + d) }, color, style = Stroke(2.3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            "↻" -> {
                drawArc(color, -50f, 280f, false, Offset(4.5f, 4.5f), Size(15f, 15f), style = line)
                // Ponta da seta no fim do arco (sentido horário).
                val a = Math.toRadians(230.0).toFloat()
                val ex = 12f + cos(a) * 7.5f; val ey = 12f + sin(a) * 7.5f
                val tx = -sin(a); val ty = cos(a)       // tangente
                val nx = cos(a); val ny = sin(a)        // normal
                drawPath(Path().apply {
                    moveTo(ex + tx * 4f, ey + ty * 4f)
                    lineTo(ex + nx * 3.4f, ey + ny * 3.4f)
                    lineTo(ex - nx * 3.4f, ey - ny * 3.4f)
                    close()
                }, color)
            }
            "⚠" -> {
                drawPath(polygon(12f, 3.4f, 21.4f, 19.8f, 2.6f, 19.8f), color, style = Stroke(2.1f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(color, Offset(12f, 9.6f), Offset(12f, 14.2f), 2.2f, StrokeCap.Round)
                drawCircle(color, 1.2f, Offset(12f, 17.0f))
            }
            "♪" -> {
                drawOval(color, Offset(5.5f, 14.5f), Size(8f, 6f))
                drawLine(color, Offset(13f, 17f), Offset(13f, 4.5f), 2.1f, StrokeCap.Round)
                drawPath(Path().apply { moveTo(13f, 4.5f); cubicTo(14f, 9f, 18.5f, 9f, 18.5f, 13f) }, color, style = Stroke(2.1f, cap = StrokeCap.Round))
            }
            "♫" -> {
                drawOval(color, Offset(3.5f, 14.5f), Size(7.5f, 5.6f))
                drawOval(color, Offset(12.5f, 12.5f), Size(7.5f, 5.6f))
                drawLine(color, Offset(10.4f, 17f), Offset(10.4f, 6f), 2f, StrokeCap.Round)
                drawLine(color, Offset(19.4f, 15f), Offset(19.4f, 4f), 2f, StrokeCap.Round)
                drawLine(color, Offset(10.4f, 6.2f), Offset(19.4f, 4.2f), 2.6f, StrokeCap.Round)
            }
        }
    }
}

/** Cadeado para nós/itens bloqueados (no lugar do emoji 🔒, que muda de aparência em cada aparelho). */
fun DrawScope.drawPadlock(color: Color) {
    val k = size.minDimension / 24f
    withTransform({ scale(k, k, Offset.Zero) }) {
        drawPath(Path().apply { moveTo(7.5f, 11f); lineTo(7.5f, 8f); cubicTo(7.5f, 2.5f, 16.5f, 2.5f, 16.5f, 8f); lineTo(16.5f, 11f) },
            color, style = Stroke(2.3f, cap = StrokeCap.Round))
        drawRoundRect(color, Offset(5f, 10.5f), Size(14f, 10.5f), CornerRadius(3f))
    }
}

private fun polygon(vararg v: Float): Path = Path().apply {
    moveTo(v[0], v[1])
    var i = 2
    while (i < v.size) { lineTo(v[i], v[i + 1]); i += 2 }
    close()
}

private fun sparkle(): Path = Path().apply {
    moveTo(12f, 2.5f)
    quadraticBezierTo(13f, 11f, 21.5f, 12f)
    quadraticBezierTo(13f, 13f, 12f, 21.5f)
    quadraticBezierTo(11f, 13f, 2.5f, 12f)
    quadraticBezierTo(11f, 11f, 12f, 2.5f)
    close()
}
