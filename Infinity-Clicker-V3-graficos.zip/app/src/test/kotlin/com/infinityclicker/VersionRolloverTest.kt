package com.infinityclicker

import com.infinityclicker.core.AppInfo
import org.junit.Assert.assertTrue
import org.junit.Test

/** Garante a regra de virada: depois do ponto só vai até 99 (3.99 -> 4.0, nunca 3.100). */
class VersionRolloverTest {
    private fun code(v: String): Int = v.split(".").map { it.toInt() }.let { p ->
        p[0] * 10000 + p.getOrElse(1) { 0 } * 100 + p.getOrElse(2) { 0 }
    }

    @Test
    fun versaoAtualRespeitaOLimiteDe99() {
        val parts = AppInfo.VERSION_NUMBER.split(".").map { it.toInt() }
        assertTrue("Use 4.0 em vez de 3.100", parts.drop(1).all { it <= 99 })
    }

    @Test
    fun versionCodeContinuaCrescendoNaVirada() {
        assertTrue(code("4.0") > code("3.99"))
        assertTrue(code("3.99") > code("3.98"))
    }
}
