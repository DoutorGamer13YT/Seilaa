package dev.atlas.ui.screens

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.atlas.core.*
import dev.atlas.location.NavigationSession
import dev.atlas.map.AtlasMap
import dev.atlas.ui.*
import dev.atlas.ui.components.*
import dev.atlas.ui.theme.AtlasMotion
import dev.atlas.ui.theme.LocalAtlasColors
import kotlin.math.roundToInt

@Composable
fun MapScreen(vm: AtlasViewModel, onLibrary: () -> Unit, onSettings: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val shortcuts by vm.shortcuts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val location by vm.location.state.collectAsStateWithLifecycle()
    val navigation by vm.navigation.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()
    val orientation by vm.orientation.collectAsStateWithLifecycle()
    val northUpNavigation by vm.navigationNorthUp.collectAsStateWithLifecycle()
    val bearing = remember { mutableFloatStateOf(0f) }
    val context = LocalContext.current
    val density = LocalDensity.current
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val haptics = LocalHapticFeedback.current
    val colors = LocalAtlasColors.current
    var sheet by rememberSaveable { mutableStateOf(SheetPosition.Peek) }
    val sheetHeight = remember { mutableFloatStateOf(0f) }
    var mapError by remember { mutableStateOf<String?>(null) }
    var mapGeneration by remember { mutableIntStateOf(0) }
    var tilted by rememberSaveable { mutableStateOf(false) }
    var locationRequested by rememberSaveable { mutableStateOf(false) }
    var permissionExplanation by rememberSaveable { mutableStateOf(false) }
    var locationAction by rememberSaveable { mutableStateOf("center") }
    var confirmEnd by remember { mutableStateOf(false) }
    var systemAnimations by remember { mutableStateOf(ValueAnimator.areAnimatorsEnabled()) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) { systemAnimations = ValueAnimator.areAnimatorsEnabled(); vm.refreshLocation() }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    val reducedMotion = settings.reduceMotion || !systemAnimations
    fun dismissKeyboard() { focus.clearFocus(); keyboard?.hide() }
    fun openSearch(target: SearchTarget) { vm.openSearch(target); sheet = SheetPosition.Expanded }
    fun selectPlace(place: Place) { dismissKeyboard(); vm.selectPlace(place); sheet = SheetPosition.Half }
    fun closePanel() { dismissKeyboard(); vm.closePanel(); sheet = SheetPosition.Peek }
    fun locationGrantedAction() {
        vm.refreshLocation()
        when (locationAction) { "origin" -> vm.useLocationOrigin(); "navigate" -> vm.startNavigation(); else -> vm.centerLocation() }
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.startNavigation() }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted.values.any { it }) locationGrantedAction()
        else vm.message("Você pode continuar pesquisando. Para mostrar sua posição, permita a localização nos Ajustes.")
    }
    fun requestLocation(action: String) {
        locationAction = action
        locationRequested = true
        val granted = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) permissionExplanation = true
        else if (action == "navigate" && Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else locationGrantedAction()
    }
    LaunchedEffect(state.panel, state.selectedPlace?.id) {
        when (state.panel) {
            PanelContent.PLACE, PanelContent.ROUTE -> sheet = SheetPosition.Half
            PanelContent.SEARCH -> if (state.category == null) sheet = SheetPosition.Expanded
            PanelContent.EXPLORE -> Unit
        }
    }
    LaunchedEffect(navigation.error, navigation.active) { if (!navigation.active) navigation.error?.let(vm::message) }
    BackHandler(enabled = navigation.active || state.panel != PanelContent.EXPLORE || sheet == SheetPosition.Expanded) {
        when { navigation.active -> confirmEnd = true; state.panel != PanelContent.EXPLORE -> closePanel(); else -> sheet = SheetPosition.Peek }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val landscape = maxWidth > maxHeight && maxWidth >= 600.dp
        val panelWidth = if (landscape) (maxWidth * .46f).coerceAtMost(420.dp) else maxWidth.coerceAtMost(600.dp)
        val visibleFix = if (navigation.active) navigation.fix.takeUnless { navigation.gpsLost }
            else location.fix.takeUnless { location.isStale }
        val navigationBarPx = WindowInsets.navigationBars.getBottom(density)
        val bottomPadding: () -> Float = {
            if (navigation.active) 210f
            else if (landscape) 0f
            else with(density) { sheetHeight.floatValue.toDp().value }.coerceAtMost(maxHeight.value * .80f)
        }
        val attributionLift: Density.() -> Int = {
            if (navigation.active) 214.dp.roundToPx() + navigationBarPx
            else if (landscape) navigationBarPx + 6.dp.roundToPx()
            else sheetHeight.floatValue.roundToInt() + 6.dp.roundToPx()
        }
        val selected = state.selectedPlace
        val visiblePlaces = remember(state.results, favorites, selected) {
            (state.results + favorites.map { it.place } + listOfNotNull(selected)).distinctBy { it.id }.take(250)
        }
        key(mapGeneration) {
            AtlasMap(modifier = Modifier.fillMaxSize(), dark = colors.isDark,
                places = visiblePlaces, selectedPlace = selected,
                route = if (navigation.active) navigation.route else state.route,
                location = visibleFix, cameraRequest = state.camera,
                bottomPaddingDp = bottomPadding,
                reduceMotion = reducedMotion,
                onPlaceClick = { if (!navigation.active) selectPlace(it) },
                onMapLongPress = { coordinate ->
                    if (!navigation.active) {
                        if (settings.haptics) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        dismissKeyboard(); vm.pin(coordinate); sheet = SheetPosition.Half
                    }
                },
                onCenterChanged = vm::mapMoved,
                onMapError = { mapError = it },
                onUserGesture = vm::mapGesture,
                orientation = orientation, compass = vm.compass.state, navigating = navigation.active,
                onBearingChanged = { bearing.floatValue = it },
                onUserRotated = vm::userRotatedMap,
                leftPaddingDp = if (landscape && !navigation.active) panelWidth.value else 0f,
            )
        }
        AnimatedVisibility(visible = navigation.active, modifier = Modifier.fillMaxSize(),
            enter = fadeIn(tween(AtlasMotion.Medium)) + scaleIn(tween(AtlasMotion.Medium, easing = AtlasMotion.Emphasized), initialScale = 0.97f),
            exit = fadeOut(tween(AtlasMotion.Short))) {
            NavigationOverlay(navigation, settings.units, navigation.recalculating, vm::stopNavigation,
                onMute = { NavigationSession.setMuted(!navigation.muted) }, onOverview = vm::showOverview, onRecenter = vm::centerLocation,
                northUp = northUpNavigation, bearing = { bearing.floatValue }, onToggleNorthUp = vm::toggleNavigationNorthUp)
        }
        AnimatedVisibility(visible = !navigation.active, modifier = Modifier.fillMaxSize(),
            enter = fadeIn(tween(AtlasMotion.Medium)), exit = fadeOut(tween(AtlasMotion.Short))) {
          Box(Modifier.fillMaxSize()) {
            Row(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 18.dp, top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(25.dp), color = colors.glass, border = BorderStroke(.8.dp, colors.glassBorder), shadowElevation = 5.dp) {
                    Row(Modifier.padding(horizontal = 17.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Explore, null, Modifier.size(19.dp), colors.accent)
                        Text("DMap", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                }
                if (!online) StatusPill("Sem conexão", Icons.Rounded.CloudOff)
            }
            Column(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 14.dp, end = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularMapButton(Icons.Rounded.Tune, "Ajustes e aparência", onSettings)
                CompassButton(orientation, { bearing.floatValue }, {
                    when (orientation) {
                        MapOrientation.NORTH -> if (vm.compass.available) { vm.setOrientation(MapOrientation.COMPASS); requestLocation("center") }
                            else vm.message("Este aparelho não tem sensores de bússola compatíveis.")
                        MapOrientation.FREE, MapOrientation.COMPASS -> { vm.setOrientation(MapOrientation.NORTH); vm.orient(tilted) }
                    }
                })
                CircularMapButton(Icons.Rounded.ViewInAr, if (tilted) "Ver mapa em 2D" else "Inclinar mapa em 3D", { tilted = !tilted; vm.orient(tilted) }, selected = tilted)
                CircularMapButton(Icons.Rounded.MyLocation, "Minha localização", { requestLocation("center") })
            }
            AnimatedVisibility(visible = state.areaMoved && state.category != null,
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 76.dp),
                enter = fadeIn(tween(AtlasMotion.Short)) + slideInVertically(tween(AtlasMotion.Medium, easing = AtlasMotion.Emphasized)) { -it / 2 },
                exit = fadeOut(tween(AtlasMotion.Short))) {
                FilledTonalButton(onClick = { state.category?.let(vm::searchCategory); sheet = SheetPosition.Half }, shape = RoundedCornerShape(24.dp),
                ) { Icon(Icons.Rounded.Search, null, Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)); Text("Pesquisar nesta área") }
            }
            if (mapError != null) {
                Surface(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 16.dp, top = 78.dp, end = 85.dp).widthIn(max = 330.dp), shape = RoundedCornerShape(20.dp), color = colors.glass) {
                    Column(Modifier.padding(14.dp)) {
                        Text(mapError ?: "O mapa não pôde ser carregado.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { mapError = null; mapGeneration++ }) { Text("Recarregar mapa") }
                    }
                }
            }
            AtlasBottomSheet(position = sheet, onPositionChange = { sheet = it; if (it != SheetPosition.Expanded) dismissKeyboard() },
                modifier = Modifier.align(if (landscape) Alignment.BottomStart else Alignment.BottomCenter).width(panelWidth).fillMaxHeight(),
                reduceMotion = reducedMotion, onHeightChanged = { sheetHeight.floatValue = it },
            ) {
                Column(Modifier.fillMaxSize()) {
                    if (state.panel == PanelContent.EXPLORE || state.panel == PanelContent.SEARCH) {
                        SearchField(value = state.query, onValueChange = {
                            if (state.panel != PanelContent.SEARCH) vm.openSearch()
                            vm.setQuery(it)
                        }, onSearch = { dismissKeyboard(); vm.submitSearch(); sheet = SheetPosition.Half },
                            onFocus = { if (state.panel != PanelContent.SEARCH) openSearch(SearchTarget.PLACE) },
                            onCancel = ::closePanel, active = state.panel == PanelContent.SEARCH,
                            modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 14.dp))
                    }
                    if (state.category != null && (state.panel == PanelContent.SEARCH || state.panel == PanelContent.EXPLORE)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(state.category?.label.orEmpty(), modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, color = colors.secondaryText)
                            TextButton(onClick = { vm.clearResults(); closePanel() }) { Text("Limpar filtro") }
                        }
                    } else if (state.panel == PanelContent.EXPLORE && state.results.isNotEmpty()) {
                        TextButton(onClick = vm::clearResults, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Limpar resultados do mapa") }
                    }
                    if (locationRequested && !location.permissionGranted && state.panel == PanelContent.EXPLORE) {
                        TextButton(onClick = onSettings, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Permitir localização nos Ajustes") }
                    } else if (locationRequested && location.permissionGranted && !location.providerEnabled && state.panel == PanelContent.EXPLORE) {
                        TextButton(onClick = {
                            runCatching { context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }.onFailure { vm.message("Abra as configurações do Android e ative a localização.") }
                        }, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Ativar localização do Android") }
                    }
                    AnimatedContent(targetState = state.panel, modifier = Modifier.weight(1f).fillMaxWidth(),
                        transitionSpec = { panelTransition(reducedMotion) }, label = "panel") { panel ->
                        when (panel) {
                            PanelContent.EXPLORE -> ExplorePanel(favorites, shortcuts, history,
                                onSelect = { dismissKeyboard(); vm.showPlace(it) }, onLibrary = onLibrary,
                                onSearch = { openSearch(SearchTarget.PLACE); vm.setQuery(it); vm.submitSearch() },
                                onCategory = { dismissKeyboard(); vm.searchCategory(it); sheet = SheetPosition.Half }, onRemoveHistory = vm::removeHistory)
                            PanelContent.SEARCH -> SearchResults(state, favorites, history, settings.units,
                                position = visibleFix?.coordinate, onSelect = ::selectPlace, onRetry = vm::retrySearch,
                                onHistory = { vm.setQuery(it); vm.submitSearch() }, onDeleteHistory = vm::removeHistory)
                            PanelContent.PLACE -> selected?.let { place ->
                                PlaceDetailPanel(place = place, saved = favorites.any { it.place.id == place.id }, loading = state.loadingDetails,
                                    error = state.detailError, distance = visibleFix?.coordinate?.let { "aprox. ${formatDistance(it.distanceTo(place.coordinate), settings.units)} em linha reta" },
                                    onClose = ::closePanel, onRoute = { dismissKeyboard(); vm.planRoute(place) }, onFavorite = { vm.toggleFavorite(place) },
                                    onCenter = { vm.focus(place.coordinate); sheet = SheetPosition.Peek }, onRetry = { vm.showPlace(place) },
                                    onShortcut = { vm.shortcut(it, place) }, onMessage = vm::message)
                            }
                            PanelContent.ROUTE -> RoutePanel(state, settings.units, vm.supportedModes, onClose = ::closePanel,
                                onSearch = ::openSearch, onUseLocation = { requestLocation("origin") }, onSwap = vm::swapRoute,
                                onRemoveStop = vm::removeStop, onMode = vm::selectMode, onSelectRoute = vm::selectRoute, onRetry = vm::calculateRoute,
                                onStart = { dismissKeyboard(); requestLocation("navigate") }, onMessage = vm::message)
                        }
                    }
                }
            }
          }
        }
        MapAttribution(Modifier.align(Alignment.BottomStart).offset { IntOffset(if (landscape && !navigation.active) panelWidth.roundToPx() + 10.dp.roundToPx() else 12.dp.roundToPx(), -attributionLift()) })
    }
    if (permissionExplanation) AlertDialog(onDismissRequest = { permissionExplanation = false },
        title = { Text("Sua localização no mapa") },
        text = { Text("O DMap usa sua posição para centralizar o mapa e calcular trajetos. Durante uma navegação iniciada por você, a localização continua ativa com uma notificação. A posição aproximada permite explorar; a precisa melhora as instruções.") },
        confirmButton = { TextButton(onClick = { permissionExplanation = false; permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) }) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = { permissionExplanation = false }) { Text("Agora não") } })
    if (confirmEnd) AlertDialog(onDismissRequest = { confirmEnd = false }, title = { Text("Encerrar navegação?") },
        confirmButton = { TextButton(onClick = { confirmEnd = false; vm.stopNavigation() }) { Text("Encerrar") } },
        dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Continuar") } })
}

@Composable private fun StatusPill(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val colors = LocalAtlasColors.current
    Surface(shape = RoundedCornerShape(22.dp), color = colors.glass) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(15.dp), colors.secondaryText)
            Text(text, style = MaterialTheme.typography.labelSmall)
        }
    }
}
