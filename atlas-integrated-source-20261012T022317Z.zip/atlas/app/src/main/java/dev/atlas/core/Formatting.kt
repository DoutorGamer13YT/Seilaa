package dev.atlas.core

import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToLong

private val portugueseBrazil = Locale.forLanguageTag("pt-BR")
private const val unavailable = "—"

/** Display estimates only: unavailable and invalid values never become a fictitious zero. */
fun formatDistance(meters: Double, units: Units): String {
    if (!meters.isFinite() || meters < 0) return unavailable
    return when (units) {
        Units.METRIC -> when {
            meters == 0.0 -> "0 m"
            meters < 1.0 -> "< 1 m"
            meters < 999.5 -> "${number(meters, 0)} m"
            meters < 10_000 -> "${number(meters / 1_000, 1)} km"
            else -> "${number(meters / 1_000, 0)} km"
        }
        Units.IMPERIAL -> {
            val feet = meters / 0.3048
            val miles = meters / 1_609.344
            when {
                meters == 0.0 -> "0 pés"
                feet < 1.0 -> "< 1 pé"
                miles < 0.1 -> {
                    val rounded = feet.roundToLong()
                    "${number(rounded.toDouble(), 0)} ${if (rounded == 1L) "pé" else "pés"}"
                }
                miles < 10 -> "${number(miles, 1)} mi"
                else -> "${number(miles, 0)} mi"
            }
        }
    }
}

/** Rounds travel estimates up to whole minutes, retaining a truthful subminute state. */
fun formatDuration(seconds: Double): String {
    if (!seconds.isFinite() || seconds < 0 || seconds / 60 >= Long.MAX_VALUE.toDouble()) return unavailable
    if (seconds == 0.0) return "0 min"
    if (seconds < 60.0) return "< 1 min"
    val minutes = ceil(seconds / 60.0).toLong()
    if (minutes < 60) return "$minutes min"
    val hours = minutes / 60
    val remainder = minutes % 60
    return if (remainder == 0L) "$hours h" else "$hours h $remainder min"
}

/** Arrival is an estimate in the device's local time zone; arithmetic overflow is rejected. */
fun formatArrival(seconds: Double, nowMillis: Long = System.currentTimeMillis()): String {
    if (!seconds.isFinite() || seconds < 0 || seconds >= Long.MAX_VALUE / 1_000.0) return unavailable
    return runCatching {
        val arrival = Math.addExact(nowMillis, (seconds * 1_000).roundToLong())
        Instant.ofEpochMilli(arrival).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("HH:mm", portugueseBrazil))
    }.getOrDefault(unavailable)
}

/** Decimal dots keep coordinate pairs unambiguous in links, copies, and technical details. */
fun coordinateLabel(c: Coordinate): String = String.format(Locale.ROOT, "%.6f, %.6f",
    if (abs(c.latitude) < 0.0000005) 0.0 else c.latitude,
    if (abs(c.longitude) < 0.0000005) 0.0 else c.longitude,
)

private fun number(value: Double, decimals: Int): String = NumberFormat.getNumberInstance(portugueseBrazil).apply {
    minimumFractionDigits = decimals
    maximumFractionDigits = decimals
    roundingMode = java.math.RoundingMode.HALF_UP
}.format(value)
