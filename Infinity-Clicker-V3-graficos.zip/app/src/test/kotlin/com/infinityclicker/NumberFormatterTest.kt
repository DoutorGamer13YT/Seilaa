package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class NumberFormatterTest {

    private fun f(v: Double, sci: Boolean = false) = NumberFormatter.format(BigNum.of(v), sci)

    @Test
    fun smallNumbers() {
        assertEquals("0", NumberFormatter.format(BigNum.ZERO))
        assertEquals("1", f(1.0))
        assertEquals("3.14", f(3.14159))
        assertEquals("42.5", f(42.5))
        assertEquals("999", f(999.0))
        assertEquals("0.5", f(0.5))
        assertEquals("0.05", f(0.05))
    }

    @Test
    fun abbreviations() {
        assertEquals("1K", f(1_000.0))
        assertEquals("1.5K", f(1_500.0))
        assertEquals("15K", f(15_000.0))
        assertEquals("150K", f(150_000.0))
        assertEquals("1.23M", f(1_234_567.0))
        assertEquals("2B", f(2e9))
        assertEquals("3T", f(3e12))
        assertEquals("4Qa", f(4e15))
        assertEquals("5Qi", f(5e18))
    }

    @Test
    fun roundingCarriesToNextGroup() {
        assertEquals("1M", f(999_999.0))
        assertEquals("1K", f(999.9))
    }

    @Test
    fun longerSuffixesAndLetterSuffixes() {
        assertEquals("1Dc", f(1e33))
        assertEquals("1Vg", f(1e63))
        // grupo 22 = "aa" (1e66), grupo 23 = "ab" (1e69)
        assertEquals("1aa", f(1e66))
        assertEquals("1ab", f(1e69))
        assertEquals("2.5ba", NumberFormatter.format(BigNum.of(2.5) * BigNum.of(10.0).pow(3.0 * (22 + 26 + 0))))
    }

    @Test
    fun scientificNotation() {
        assertEquals("1.50e3", f(1_500.0, sci = true))
        assertEquals("1.23e45", NumberFormatter.format(BigNum.of(1.234) * BigNum.of(10.0).pow(45.0), true))
        assertEquals("1.00e5000", NumberFormatter.format(BigNum.of(10.0).pow(5000.0), true))
    }

    @Test
    fun beyondLastSuffixFallsBackToScientific() {
        assertEquals("1.00e9999", NumberFormatter.format(BigNum.of(10.0).pow(9999.0)))
    }

    @Test
    fun durations() {
        assertEquals("45s", NumberFormatter.duration(45_000))
        assertEquals("3min 10s", NumberFormatter.duration(190_000))
        assertEquals("2h 05min", NumberFormatter.duration(2 * 3_600_000L + 5 * 60_000L))
        assertEquals("1d 2h 3min", NumberFormatter.duration(86_400_000L + 2 * 3_600_000L + 3 * 60_000L))
    }
}
