package com.w2a.nzuz

import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipFile

object PackageVerifier {
    private val safe = Regex("[A-Za-z0-9 _./@,-]+")
    fun resolve(root: File, path: String): File {
        require(path.length in 1..240 && safe.matches(path) && !path.startsWith("/") && path.split('/').none { it == ".." || it.isEmpty() }) { "Caminho inválido no pacote" }
        val file = File(root, path)
        require(file.canonicalPath.startsWith(root.canonicalPath + File.separator))
        return file
    }
    fun extract(zip: File, stage: File, p: MapPackage, check: () -> Unit) {
        stage.deleteRecursively(); require(stage.mkdirs())
        var total = 0L
        val names = mutableSetOf<String>()
        ZipFile(zip).use { z ->
            val entries = z.entries()
            while (entries.hasMoreElements()) {
                check()
                val entry = entries.nextElement()
                if (entry.isDirectory) continue
                require(names.add(entry.name) && names.size <= 10000) { "Entradas repetidas ou excessivas" }
                val target = resolve(stage, entry.name)
                target.parentFile!!.mkdirs()
                z.getInputStream(entry).use { input -> target.outputStream().buffered().use { out ->
                    val b = ByteArray(65536)
                    while (true) {
                        check(); val n = input.read(b); if (n < 0) break
                        total += n; require(total <= p.unpackedBytes) { "Pacote excede o tamanho declarado" }
                        out.write(b, 0, n)
                    }
                } }
            }
        }
        require(total == p.unpackedBytes) { "Tamanho descompactado divergente" }
        verify(stage, p, check)
    }
    fun verify(root: File, p: MapPackage, check: () -> Unit = {}, hashes: Boolean = true) {
        val manifestFile = File(root, "pack.json")
        require(manifestFile.length() in 2..2_000_000)
        val m = JSONObject(manifestFile.readText())
        require(m.getInt("schema") == 1 && m.getString("id") == p.id && m.getString("version") == p.version)
        val files = m.getJSONObject("files")
        require(files.length() in 4..9999)
        val actual = root.walkTopDown().filter { it.isFile && it != manifestFile }.map { it.relativeTo(root).invariantSeparatorsPath }.toSet()
        require(actual == files.keys().asSequence().toSet()) { "Arquivos não correspondem ao manifesto" }
        files.keys().forEach { path ->
            check()
            val f = resolve(root, path)
            val spec = files.getJSONObject(path)
            require(f.isFile && f.length() == spec.getLong("bytes") && (!hashes || digest(f, check) == spec.getString("sha256"))) { "Integridade inválida: $path" }
        }
        header(File(root, "map.pmtiles"), p)
        require(actual.any { it.startsWith("LICENSES/") }) { "Licenças ausentes" }
        listOf(false, true).forEach { style(root, it) }
        val fonts = m.getJSONArray("fonts")
        require(fonts.length() in 1..12)
        for (i in 0 until fonts.length()) for (start in 0..65280 step 256) {
            require(resolve(root, "fonts/${fonts.getString(i)}/$start-${start + 255}.pbf").isFile) { "Conjunto de fontes incompleto" }
        }
        listOf("light", "dark").forEach { theme -> listOf(".json", ".png", "@2x.json", "@2x.png").forEach { ext ->
            require(File(root, "sprites/$theme$ext").length() > 0) { "Sprites incompletos" }
        } }
    }
    fun header(file: File, p: MapPackage) {
        require(file.length() >= 127)
        val b = ByteArray(127)
        RandomAccessFile(file, "r").use { it.readFully(b) }
        require(String(b, 0, 7, Charsets.US_ASCII) == "PMTiles" && b[7].toInt() == 3 && b[99].toInt() == 1) { "Requer PMTiles v3 vetorial MVT" }
        val v = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        listOf(8 to 16, 24 to 32, 40 to 48, 56 to 64).forEach { (a, c) ->
            val offset = v.getLong(a); val length = v.getLong(c)
            require(offset >= 0 && length >= 0 && offset <= file.length() && length <= file.length() - offset) { "PMTiles truncado" }
        }
        require(b[100].toInt() <= p.minZoom && b[101].toInt() >= p.maxZoom) { "Níveis de zoom divergentes" }
    }
    fun style(root: File, dark: Boolean): String {
        val f = File(root, "styles/${if (dark) "dark" else "light"}.json")
        require(f.length() in 2..4_000_000)
        val j = JSONObject(f.readText())
        require(j.getInt("version") == 8 && !j.has("imports"))
        require(j.getString("glyphs") == "dmap://fonts/{fontstack}/{range}.pbf")
        val sprite = j.getString("sprite")
        require(sprite == "dmap://sprites/${if (dark) "dark" else "light"}")
        val sources = j.getJSONObject("sources")
        require(sources.length() == 1 && sources.has("protomaps"))
        val s = sources.getJSONObject("protomaps")
        require(s.getString("type") == "vector" && s.getString("url") == "dmap://map.pmtiles" && !s.has("tiles") && !s.has("data"))
        val raw = j.toString()
        require(!Regex("(?i)(https?:|asset:|file:|mapbox:|pmtiles:)").containsMatchIn(raw)) { "Estilo contém referência externa" }
        s.put("url", "pmtiles://${Uri.fromFile(File(root, "map.pmtiles"))}")
        j.put("glyphs", "${Uri.fromFile(File(root, "fonts"))}/{fontstack}/{range}.pbf")
        j.put("sprite", Uri.fromFile(File(root, "sprites/${if (dark) "dark" else "light"}")).toString())
        return j.toString()
    }
}
