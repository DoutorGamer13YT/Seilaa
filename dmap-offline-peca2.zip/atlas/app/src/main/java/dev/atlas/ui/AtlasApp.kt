package dev.atlas.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import dev.atlas.ui.screens.*
import dev.atlas.ui.theme.AtlasMotion
import dev.atlas.ui.theme.AtlasTheme

@Composable
fun AtlasApp(vm: AtlasViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val lists by vm.lists.collectAsStateWithLifecycle()
    val shortcuts by vm.shortcuts.collectAsStateWithLifecycle()
    val mapOpenRequest by vm.mapOpenRequests.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val context = LocalContext.current
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(backStackEntry?.destination?.route) {
        vm.setMapVisible(backStackEntry?.destination?.route.let { it == null || it == "map" })
    }
    LaunchedEffect(mapOpenRequest) {
        if (mapOpenRequest > 0L) nav.popBackStack("map", false)
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) vm.setForeground(true)
            if (event == Lifecycle.Event.ON_STOP) vm.setForeground(false)
        }
        lifecycle.addObserver(observer)
        vm.setForeground(lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
        onDispose { lifecycle.removeObserver(observer); vm.setForeground(false) }
    }
    LaunchedEffect(vm) { vm.messages.collect { snackbar.showSnackbar(it) } }
    AtlasTheme(mode = settings.theme, reduceMotion = settings.reduceMotion) {
        Box(Modifier.fillMaxSize()) {
            val reduce = settings.reduceMotion
            val pushIn: () -> EnterTransition = {
                if (reduce) fadeIn(tween(AtlasMotion.Short))
                else slideInHorizontally(tween(AtlasMotion.Long, easing = AtlasMotion.Emphasized)) { it } + fadeIn(tween(AtlasMotion.Medium))
            }
            val pushOut: () -> ExitTransition = {
                if (reduce) fadeOut(tween(AtlasMotion.Short))
                else slideOutHorizontally(tween(AtlasMotion.Long, easing = AtlasMotion.Emphasized)) { -it / 5 } + fadeOut(tween(AtlasMotion.Medium))
            }
            val popIn: () -> EnterTransition = {
                if (reduce) fadeIn(tween(AtlasMotion.Short))
                else slideInHorizontally(tween(AtlasMotion.Long, easing = AtlasMotion.Emphasized)) { -it / 5 } + fadeIn(tween(AtlasMotion.Medium))
            }
            val popOut: () -> ExitTransition = {
                if (reduce) fadeOut(tween(AtlasMotion.Short))
                else slideOutHorizontally(tween(AtlasMotion.Long, easing = AtlasMotion.Emphasized)) { it } + fadeOut(tween(AtlasMotion.Medium))
            }
            NavHost(navController = nav, startDestination = "map",
                enterTransition = { pushIn() }, exitTransition = { pushOut() },
                popEnterTransition = { popIn() }, popExitTransition = { popOut() }) {
                composable("map") { MapScreen(vm, onLibrary = { nav.navigate("library") }, onSettings = { nav.navigate("settings") }) }
                composable("library") {
                    LibraryScreen(favorites, lists, shortcuts, settings.units,
                        onBack = { nav.popBackStack() },
                        onSelect = { vm.showPlace(it); nav.popBackStack("map", false) },
                        onRemove = vm::toggleFavorite, onCreateList = vm::createList,
                        onRenameList = vm::renameList, onDeleteList = vm::deleteList,
                        onMoveList = vm::moveList, onSetLists = vm::setLists, onSetShortcut = vm::shortcut)
                }
                composable("settings") {
                    SettingsScreen(settings, vm::updateSettings, { nav.popBackStack() }, vm::clearHistory,
                        onOpenLibrary = { nav.navigate("library") },
                        onOpenOffline = { nav.navigate("offline") },
                        onOpenPermissions = { runCatching { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }.onFailure { vm.message("Abra as configurações do Android e escolha DMap para alterar as permissões.") } },
                        onOpenLocationSettings = { runCatching { context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }.onFailure { vm.message("Abra as configurações do Android para ativar a localização.") } })
                }
                composable("offline") {
                    val offlineState by vm.offline.state.collectAsStateWithLifecycle()
                    val online by vm.online.collectAsStateWithLifecycle()
                    val mapState by vm.state.collectAsStateWithLifecycle()
                    LaunchedEffect(Unit) { vm.offline.refresh() }
                    OfflineMapsScreen(offlineState, mapState.center, online,
                        onBack = { nav.popBackStack() }, onDownload = vm::downloadOffline,
                        onPause = vm.offline::pause, onResume = vm.offline::resume,
                        onDelete = vm.offline::delete, onDismissError = vm.offline::dismissError)
                }
            }
            SnackbarHost(snackbar, Modifier.align(androidx.compose.ui.Alignment.BottomCenter).navigationBarsPadding().imePadding().padding(16.dp))
        }
    }
}
