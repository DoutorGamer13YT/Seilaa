package dev.atlas.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import dev.atlas.core.Coordinate
import dev.atlas.core.Place

@Entity(tableName = "places")
internal data class PlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val category: String,
    val phone: String?,
    val website: String?,
    val openingHours: String?,
    val source: String,
) {
    fun toPlace() = Place(id, name, Coordinate(latitude, longitude), address, category,
        phone, website, openingHours, source)

    companion object {
        fun from(place: Place) = PlaceEntity(place.id, place.name, place.coordinate.latitude,
            place.coordinate.longitude, place.address, place.category, place.phone,
            place.website, place.openingHours, place.source)
    }
}

@Entity(tableName = "favorites", foreignKeys = [ForeignKey(
    entity = PlaceEntity::class, parentColumns = ["id"], childColumns = ["placeId"],
    onDelete = ForeignKey.CASCADE,
)])
internal data class FavoriteEntity(@PrimaryKey val placeId: String, val savedAt: Long)

@Entity(tableName = "saved_lists", indices = [Index(value = ["normalizedName"], unique = true)])
internal data class SavedListEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val normalizedName: String,
    val position: Int,
)

@Entity(tableName = "list_memberships", primaryKeys = ["placeId", "listId"],
    foreignKeys = [
        ForeignKey(entity = FavoriteEntity::class, parentColumns = ["placeId"],
            childColumns = ["placeId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = SavedListEntity::class, parentColumns = ["id"],
            childColumns = ["listId"], onDelete = ForeignKey.CASCADE),
    ], indices = [Index("listId")])
internal data class ListMembershipEntity(val placeId: String, val listId: Long)

internal data class FavoriteWithRelations(
    @Embedded val favorite: FavoriteEntity,
    @Relation(parentColumn = "placeId", entityColumn = "id") val place: PlaceEntity,
    @Relation(parentColumn = "placeId", entityColumn = "placeId")
    val memberships: List<ListMembershipEntity>,
)

@Entity(tableName = "search_history", indices = [Index("timestampMillis")])
internal data class SearchHistoryEntity(
    @PrimaryKey val normalizedQuery: String,
    val query: String,
    val timestampMillis: Long,
)

@Entity(tableName = "shortcuts", foreignKeys = [ForeignKey(
    entity = PlaceEntity::class, parentColumns = ["id"], childColumns = ["placeId"],
    onDelete = ForeignKey.CASCADE,
)], indices = [Index("placeId")])
internal data class ShortcutEntity(@PrimaryKey val kind: String, val placeId: String)

internal data class ShortcutWithPlace(
    @Embedded val shortcut: ShortcutEntity,
    @Relation(parentColumn = "placeId", entityColumn = "id") val place: PlaceEntity,
)
