package dev.atlas.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.tan

object OfflineTiles {
    const val MIN_ZOOM = 5
    const val MAX_ZOOM = 14
    const val MAX_REGIONS = 8
    val radiiKm = listOf(10, 25, 50)

    data class Box(val south: Double, val west: Double, val north: Double, val east: Double)

    fun box(center: Coordinate, radiusKm: Int): Box {
        require(radiusKm > 0)
        val latitudeDelta = radiusKm / 111.32
        val lonScale = cos(Math.toRadians(center.latitude.coerceIn(-85.0, 85.0))).coerceAtLeast(0.05)
        val longitudeDelta = (radiusKm / (111.32 * lonScale)).coerceAtMost(180.0)
        return Box(
            south = (center.latitude - latitudeDelta).coerceAtLeast(-85.0),
            west = (center.longitude - longitudeDelta).coerceAtLeast(-180.0),
            north = (center.latitude + latitudeDelta).coerceAtMost(85.0),
            east = (center.longitude + longitudeDelta).coerceAtMost(180.0),
        )
    }

    fun tileCount(box: Box, minZoom: Int = MIN_ZOOM, maxZoom: Int = MAX_ZOOM): Long {
        var total = 0L
        for (zoom in minZoom..maxZoom) {
            val columns = tileX(box.east, zoom) - tileX(box.west, zoom) + 1
            val rows = tileY(box.south, zoom) - tileY(box.north, zoom) + 1
            total += columns.toLong() * rows
        }
        return total
    }

    private fun tileX(longitude: Double, zoom: Int): Int {
        val size = 1 shl zoom
        return floor((longitude + 180.0) / 360.0 * size).toInt().coerceIn(0, size - 1)
    }

    private fun tileY(latitude: Double, zoom: Int): Int {
        val size = 1 shl zoom
        val radians = Math.toRadians(latitude.coerceIn(-85.05, 85.05))
        return floor((1.0 - ln(tan(radians) + 1.0 / cos(radians)) / PI) / 2.0 * size).toInt().coerceIn(0, size - 1)
    }
}
