package dev.atlas.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.emptyPreferences
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.atlas.core.AppException
import dev.atlas.core.AppSettings
import dev.atlas.core.Coordinate
import dev.atlas.core.ErrorKind
import dev.atlas.core.Place
import dev.atlas.core.ThemeMode
import dev.atlas.core.Units
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StorageRepositoryTest {
    private lateinit var database: AtlasDatabase
    private lateinit var repository: LocalRepository
    private lateinit var preferencesFile: File
    private lateinit var storeJob: kotlinx.coroutines.Job
    private val place = Place("osm/node/123", "Café de teste", Coordinate(-23.55, -46.63),
        "Endereço de teste", "Café", "+551100000000", "https://example.org",
        "Mo-Fr 09:00-17:00", "OpenStreetMap · dados de teste")

    @Before fun openDatabase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AtlasDatabase::class.java).build()
        preferencesFile = File(context.cacheDir, "storage-${UUID.randomUUID()}.preferences_pb")
        storeJob = SupervisorJob()
        val settings = PreferenceDataStoreFactory.create(
            scope = CoroutineScope(Dispatchers.IO + storeJob), produceFile = { preferencesFile })
        repository = LocalRepository(database, settings)
    }

    @After fun closeDatabase() = runBlocking {
        storeJob.cancelAndJoin()
        database.close()
        preferencesFile.delete()
        Unit
    }

    @Test fun favoriteMetadataAndMultipleListsSurviveUpdates() = runBlocking {
        repository.createList("Viagem")
        repository.createList("Cafés")
        val ids = repository.lists.first().map { it.id }.toSet()
        repository.setPlaceLists(place, ids)
        val original = repository.favorites.first().single()
        assertEquals(place, original.place)
        assertEquals(ids, original.listIds.toSet())
        assertTrue(original.savedAt > 0L)

        val updated = place.copy(phone = "+551199999999", address = "Endereço atualizado")
        repository.savePlace(updated)
        val result = repository.favorites.first().single()
        assertEquals(updated, result.place)
        assertEquals(ids, result.listIds.toSet())
        assertEquals(original.savedAt, result.savedAt)
    }

    @Test fun deletingListRemovesOnlyMembershipAndCompactsPositions() = runBlocking {
        repository.createList("Primeira")
        repository.createList("Segunda")
        val lists = repository.lists.first()
        repository.setPlaceLists(place, lists.map { it.id }.toSet())
        repository.deleteList(lists.first().id)
        assertEquals(listOf(lists.last().id), repository.favorites.first().single().listIds)
        assertEquals(0, repository.lists.first().single().position)
        repository.deleteList(lists.last().id)
        assertEquals(place, repository.favorites.first().single().place)
        assertTrue(repository.favorites.first().single().listIds.isEmpty())
    }

    @Test fun invalidListSelectionRollsBackPlaceAndMembershipChanges() = runBlocking {
        repository.createList("Existente")
        val listId = repository.lists.first().single().id
        repository.setPlaceLists(place, setOf(listId))
        var captured: AppException? = null
        try {
            repository.setPlaceLists(place.copy(name = "Não deve persistir"), setOf(listId, Long.MAX_VALUE))
        } catch (error: AppException) { captured = error }
        assertEquals(ErrorKind.INVALID_INPUT, captured?.kind)
        val stored = repository.favorites.first().single()
        assertEquals(place, stored.place)
        assertEquals(listOf(listId), stored.listIds)
    }

    @Test fun historyIsUniqueBoundedAndCanBeRemovedIndividually() = runBlocking {
        repeat(35) { repository.recordSearch("Local $it") }
        assertEquals(30, repository.history.first().size)
        assertEquals("Local 34", repository.history.first().first().query)
        assertFalse(repository.history.first().any { it.query == "Local 0" })
        repository.recordSearch("  LOCAL   34 ")
        assertEquals(30, repository.history.first().size)
        assertEquals(1, repository.history.first().count { it.query.equals("Local 34", true) })
        repository.removeHistory("local 34")
        assertEquals(29, repository.history.first().size)
        repository.clearHistory()
        assertTrue(repository.history.first().isEmpty())
    }

    @Test fun shortcutsRemainAfterFavoriteRemovalAndCanBeReplaced() = runBlocking {
        repository.savePlace(place)
        repository.setShortcut("home", place)
        repository.removePlace(place.id)
        assertTrue(repository.favorites.first().isEmpty())
        assertEquals(place, repository.shortcuts.first().single().place)
        val replacement = place.copy(id = "osm/node/456", name = "Outro local")
        repository.setShortcut("home", replacement)
        assertEquals(replacement, repository.shortcuts.first().single().place)
        repository.setShortcut("work", replacement)
        repository.setShortcut("home", null)
        assertEquals("work", repository.shortcuts.first().single().kind)
        repository.setShortcut("work", null)
        assertTrue(repository.shortcuts.first().isEmpty())
    }

    @Test fun listReorderingAndRenamingAreValidated() = runBlocking {
        listOf("A", "B", "C").forEach { repository.createList(it) }
        val lists = repository.lists.first()
        repository.moveList(lists.first().id, Int.MAX_VALUE)
        assertEquals(listOf("B", "C", "A"), repository.lists.first().map { it.name })
        assertEquals(listOf(0, 1, 2), repository.lists.first().map { it.position })
        repository.moveList(lists.first().id, Int.MIN_VALUE)
        assertEquals(listOf("A", "B", "C"), repository.lists.first().map { it.name })
        repository.renameList(lists.first().id, "  Viagem ")
        assertEquals("Viagem", repository.lists.first().first().name)
        var duplicateRejected = false
        try { repository.createList(" viagem ") } catch (error: AppException) {
            duplicateRejected = error.kind == ErrorKind.INVALID_INPUT
        }
        assertTrue(duplicateRejected)
        assertEquals(3, repository.lists.first().size)
    }

    @Test fun settingsWritesEveryPreference() = runBlocking {
        val expected = AppSettings(ThemeMode.DARK, Units.IMPERIAL, voice = false,
            reduceMotion = true, haptics = false)
        repository.updateSettings(expected)
        assertEquals(expected, repository.settings.first())
    }

    @Test fun transientReadErrorIsReportedAndCanRecoverWithoutDiscardingData() = runBlocking {
        val reads = AtomicInteger()
        val failingStore = object : DataStore<Preferences> {
            override val data = flow {
                if (reads.getAndIncrement() == 0) throw IOException("Test disk temporarily unavailable")
                emit(emptyPreferences())
            }
            override suspend fun updateData(transform: suspend (Preferences) -> Preferences): Preferences =
                throw IOException("Test disk temporarily unavailable")
        }
        val recovering = LocalRepository(database, failingStore)
        recovering.savePlace(place)
        withTimeout(5_000) {
            coroutineScope {
                val errorEvent = async(start = CoroutineStart.UNDISPATCHED) { recovering.errors.first() }
                assertEquals(AppSettings(), recovering.settings.first())
                assertEquals(ErrorKind.STORAGE, errorEvent.await().kind)
            }
        }
        assertEquals(place, recovering.favorites.first().single().place)
        var writeError: AppException? = null
        try { recovering.updateSettings(AppSettings()) } catch (error: AppException) { writeError = error }
        assertEquals(ErrorKind.STORAGE, writeError?.kind)
    }

    @Test fun coroutineCancellationIsNotPresentedAsStorageFailure() = runBlocking {
        val cancelledStore = object : DataStore<Preferences> {
            override val data = flow { emit(emptyPreferences()) }
            override suspend fun updateData(transform: suspend (Preferences) -> Preferences): Preferences =
                throw CancellationException("Test cancellation")
        }
        var cancellationPropagated = false
        try {
            LocalRepository(database, cancelledStore).updateSettings(AppSettings())
        } catch (cancelled: CancellationException) { cancellationPropagated = true }
        assertTrue(cancellationPropagated)
    }
}
