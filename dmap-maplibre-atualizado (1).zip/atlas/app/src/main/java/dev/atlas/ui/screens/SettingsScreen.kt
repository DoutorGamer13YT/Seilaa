package dev.atlas.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.BrightnessAuto
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.atlas.ui.theme.LocalAtlasColors
import dev.atlas.ui.components.MapCreditsDialog
import dev.atlas.BuildConfig
import dev.atlas.core.*

@Composable
fun SettingsScreen(
    settings: AppSettings, onSettingsChange: (AppSettings) -> Unit, onBack: () -> Unit,
    onClearHistory: () -> Unit, onOpenLibrary: () -> Unit, onOpenPermissions: () -> Unit,
    onOpenLocationSettings: () -> Unit,
) {
    val context = LocalContext.current
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    var showCredits by rememberSaveable { mutableStateOf(false) }
    fun openLink(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrEmpty()) return
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { context.startActivity(intent) }
        catch (_: ActivityNotFoundException) { Toast.makeText(context, "Nenhum aplicativo disponível para abrir o link.", Toast.LENGTH_LONG).show() }
        catch (_: SecurityException) { Toast.makeText(context, "Não foi possível abrir este link.", Toast.LENGTH_LONG).show() }
    }
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 36.dp),
            modifier = Modifier.fillMaxSize().safeDrawingPadding(), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            item { CollectionHeader("Ajustes", onBack) }
            item {
                SettingsSection("Aparência") {
                    val options = listOf(
                        ThemeOption(ThemeMode.SYSTEM, "Automático", "Acompanha o tema do sistema.", Icons.Rounded.BrightnessAuto, Color(0xFF3A3A3F), Color.White),
                        ThemeOption(ThemeMode.LIGHT, "Claro", "Superfícies claras para uso diurno.", Icons.Rounded.LightMode, Color(0xFFF2F2F7), Color(0xFF111114)),
                        ThemeOption(ThemeMode.DARK, "Escuro", "Tema escuro convencional.", Icons.Rounded.DarkMode, Color(0xFF232326), Color.White),
                    )
                    options.forEachIndexed { index, option ->
                        ThemeChoiceRow(option, settings.theme == option.mode) { onSettingsChange(settings.copy(theme = option.mode)) }
                        if (index < options.lastIndex) SettingsDivider()
                    }
                }
            }
            item {
                SettingsSection("Distâncias") {
                    ChoiceRow("Quilômetros", settings.units == Units.METRIC) { onSettingsChange(settings.copy(units = Units.METRIC)) }
                    SettingsDivider()
                    ChoiceRow("Milhas", settings.units == Units.IMPERIAL) { onSettingsChange(settings.copy(units = Units.IMPERIAL)) }
                }
            }
            item {
                SettingsSection("Navegação e interação") {
                    ToggleRow("Instruções de voz", "Ouvir as próximas manobras durante a navegação.", settings.voice) {
                        onSettingsChange(settings.copy(voice = it)) }
                    SettingsDivider()
                    ToggleRow("Reduzir movimento", "Usar transições mais discretas.", settings.reduceMotion) {
                        onSettingsChange(settings.copy(reduceMotion = it)) }
                    SettingsDivider()
                    ToggleRow("Feedback tátil", "Vibração breve nas interações compatíveis.", settings.haptics) {
                        onSettingsChange(settings.copy(haptics = it)) }
                }
            }
            item {
                SettingsSection("Seus dados") {
                    ActionRow("Biblioteca", "Gerenciar lugares salvos, listas, Casa e Trabalho.", onClick = onOpenLibrary)
                    SettingsDivider()
                    ActionRow("Limpar histórico de pesquisas", onClick = { confirmClear = true })
                }
            }
            item {
                SettingsSection("Localização") {
                    ActionRow("Permissões do aplicativo", "Gerenciar acesso à localização no Android.", onClick = onOpenPermissions)
                    SettingsDivider()
                    ActionRow("Serviços de localização", "Abrir os ajustes de GPS do dispositivo.", onClick = onOpenLocationSettings)
                }
            }
            item {
                SettingsSection("Privacidade") {
                    Text("Favoritos, listas, atalhos, histórico e ajustes ficam neste aparelho. Pesquisas e a região consultada são enviadas ao provedor de lugares; origem, destino e paradas são enviados ao serviço de rotas. O provedor de mapas recebe a área visualizada.",
                        Modifier.padding(20.dp), style = MaterialTheme.typography.bodyMedium)
                    SettingsDivider()
                    Text("A localização é usada quando você solicita sua posição ou inicia a navegação. Durante uma navegação ativa, uma notificação permite acompanhá-la e encerrá-la. Não há conta nem sincronização em nuvem neste aplicativo.",
                        Modifier.padding(20.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
            item {
                SettingsSection("Sobre o Dmap") {
                    DeveloperHero(versionName = BuildConfig.VERSION_NAME, versionCode = BuildConfig.VERSION_CODE, debug = BuildConfig.DEBUG)
                    SettingsDivider()
                    InfoRow(Icons.Rounded.Code, "Desenvolvedor", "@vitinhjkjkk")
                    SettingsDivider()
                    ActionRow("Instagram", "@vitinhjkjkk", external = true) { openLink("https://www.instagram.com/vitinhjkjkk/") }
                    SettingsDivider()
                    ActionRow("Créditos e licenças", onClick = { showCredits = true })
                    SettingsDivider()
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Aplicativo independente inspirado em interfaces cartográficas do iPhone. Não é um produto da Apple e não tem associação com ela.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Lugares salvos ficam disponíveis sem rede. Mapas, pesquisas e novas rotas precisam de conexão. Não há informações de trânsito em tempo real.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    if (showCredits) MapCreditsDialog { showCredits = false }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Limpar histórico?") },
        text = { Text("Todas as pesquisas recentes serão apagadas deste aparelho. Seus favoritos serão mantidos.") },
        confirmButton = { TextButton(onClick = { onClearHistory(); confirmClear = false }) { Text("Limpar histórico") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } })
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        GlassGroup(content = content)
    }
}

@Composable
private fun SettingsDivider() = HorizontalDivider(Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))

private class ThemeOption(
    val mode: ThemeMode, val title: String, val description: String,
    val icon: ImageVector, val swatch: Color, val glyph: Color,
)

@Composable
private fun ThemeChoiceRow(option: ThemeOption, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).selectable(selected, role = Role.RadioButton, onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(option.swatch, CircleShape)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape), contentAlignment = Alignment.Center) {
            Icon(option.icon, null, Modifier.size(22.dp), option.glyph)
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(option.title)
            Text(option.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        RadioButton(selected, onClick = null)
    }
}

@Composable
private fun DeveloperHero(versionName: String, versionCode: Int, debug: Boolean) {
    val colors = LocalAtlasColors.current
    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(Modifier.size(64.dp).background(Brush.linearGradient(listOf(colors.accent, colors.positive)), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Map, null, Modifier.size(34.dp), colors.onAccent)
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Dmap", style = MaterialTheme.typography.headlineSmall)
            Text("Versão $versionName ($versionCode)${if (debug) " · debug" else ""}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, title: String, value: String) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(22.dp), MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f).padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value)
        }
    }
}

@Composable
private fun ChoiceRow(title: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).selectable(selected, role = Role.RadioButton, onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        RadioButton(selected, onClick = null)
    }
}

@Composable
private fun ToggleRow(title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().toggleable(checked, role = Role.Switch, onValueChange = onChange)
        .padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onCheckedChange = null)
    }
}

@Composable
private fun ActionRow(title: String, description: String? = null, external: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable(onClick = onClick)
        .padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = MaterialTheme.colorScheme.primary)
            description?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Icon(if (external) Icons.AutoMirrored.Rounded.OpenInNew else Icons.Rounded.ChevronRight, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}
