package com.infinityclicker.ui.components

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.composed
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import kotlin.math.max
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp

/**
 * Vidro líquido de baixo custo. A versão anterior usava `shadow(14.dp)` com cor própria em cada painel:
 * em superfícies translúcidas a sombra é recortada e redesenhada fora da forma, o que custava caro na
 * GPU do Galaxy A54 e era a principal causa de travadas na rolagem de listas com muitos cartões.
 *
 * Agora cada painel desenha, uma vez por tamanho (drawWithCache), só gradientes simples:
 * corpo translúcido, profundidade interna, reflexo prismático, halo de cor na borda de baixo
 * e borda com refração. Nenhum blur, nenhuma sombra de elevação.
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    borderAlpha: Float = 0.38f
): Modifier = this
    .clip(shape)
    .drawWithCache {
        val body = Brush.linearGradient(
            0f to Color.White.copy(alpha = (alpha * 0.32f + 0.05f).coerceAtMost(0.20f)),
            0.24f to tint.copy(alpha = (alpha + 0.10f).coerceAtMost(0.42f)),
            0.66f to tint.copy(alpha = (alpha * 0.46f).coerceAtMost(0.25f)),
            1f to Color(0xFF050616).copy(alpha = (alpha * 0.72f).coerceAtLeast(0.05f))
        )
        // Simula espessura sem blur ou sombra externa, mantendo a mesma área de rasterização do card.
        val innerDepth = Brush.verticalGradient(
            0f to Color.White.copy(alpha = (alpha * 0.12f + 0.018f).coerceAtMost(0.07f)),
            0.50f to Color.Transparent,
            1f to Color.Black.copy(alpha = (alpha * 0.55f + 0.04f).coerceAtMost(0.18f))
        )
        // Brilho especular: faixa clara que some em ~45% da altura, como luz sobre vidro curvo.
        val sheen = Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.13f),
            0.45f to Color.Transparent
        )
        val glow = Brush.verticalGradient(
            0.62f to Color.Transparent,
            1f to tint.copy(alpha = (alpha * 0.9f).coerceIn(0.03f, 0.22f))
        )
        val border = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = borderAlpha.coerceIn(0f, 0.9f)),
                Color.White.copy(alpha = 0.05f),
                tint.copy(alpha = (borderAlpha * 0.74f).coerceIn(0f, 0.8f))
            )
        )
        // Reflexo oblíquo holográfico. É estático em cada card para evitar animar listas inteiras.
        val prism = Brush.linearGradient(
            listOf(
                Color.Transparent,
                Color.White.copy(alpha = (alpha * 0.42f + 0.025f).coerceAtMost(0.11f)),
                tint.copy(alpha = (alpha * 0.46f + 0.02f).coerceAtMost(0.15f)),
                Color.Transparent
            ),
            start = Offset(size.width * 0.08f, 0f),
            end = Offset(size.width * 0.92f, size.height)
        )
        // Vazamento de luz no canto superior esquerdo: dá profundidade e uma "fonte" de luz consistente em todos os painéis.
        val leak = Brush.radialGradient(
            listOf(tint.copy(alpha = (alpha * 1.4f).coerceIn(0.05f, 0.28f)), Color.Transparent),
            Offset(size.width * 0.06f, 0f), size.maxDimension * 0.62f
        )
        // Geada muito fina no canto oposto: parece microtextura de vidro temperado e é criada só quando o card muda de tamanho.
        val frost = Brush.radialGradient(
            listOf(Color.White.copy(alpha = (alpha * 0.36f + 0.012f).coerceAtMost(0.065f)), Color.Transparent),
            Offset(size.width * 0.86f, size.height * 0.18f), size.minDimension * 0.42f
        )
        val stroke = Stroke(1.2.dp.toPx())
        // Fio de luz no topo (fica forte no centro e some nas pontas) e leve reflexo na borda de baixo.
        val edge = Brush.horizontalGradient(
            0f to Color.Transparent, 0.5f to Color.White.copy(alpha = 0.42f), 1f to Color.Transparent
        )
        val neonEdge = Brush.horizontalGradient(
            0f to Color.Transparent,
            0.28f to tint.copy(alpha = (borderAlpha * 0.42f).coerceAtMost(0.30f)),
            0.66f to Color.White.copy(alpha = (borderAlpha * 0.36f).coerceAtMost(0.22f)),
            1f to Color.Transparent
        )
        val topLine = 1.dp.toPx()
        onDrawBehind {
            drawRect(brush = body)
            drawRect(brush = innerDepth)
            drawRect(brush = glow)
            drawRect(brush = leak)
            drawRect(brush = prism)
            drawRect(brush = sheen)
            drawRect(brush = frost)
            // Dois riscos extremamente sutis quebram a superfície lisa sem animar ou rasterizar um bitmap por cartão.
            drawLine(Color.White.copy(alpha = 0.040f), Offset(size.width * 0.64f, size.height * 0.10f), Offset(size.width * 0.91f, size.height * 0.22f), 0.7f)
            drawLine(tint.copy(alpha = (alpha * 0.22f).coerceAtMost(0.060f)), Offset(size.width * 0.70f, size.height * 0.76f), Offset(size.width * 0.94f, size.height * 0.64f), 0.7f)
            drawRect(brush = border, style = stroke)
            drawRect(brush = edge, topLeft = Offset(size.width * 0.08f, 0f), size = Size(size.width * 0.84f, topLine))
            drawRect(brush = neonEdge, topLeft = Offset(size.width * 0.08f, size.height - topLine), size = Size(size.width * 0.84f, topLine))
        }
    }

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    alpha: Float = 0.10f,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier.glass(tint = tint, alpha = alpha).padding(14.dp),
        content = content
    )
}

/**
 * Clique com resposta física: o elemento afunda ao toque e volta com uma mola levemente elástica.
 * Deve vir ANTES de `.glass(...)` na cadeia, para o vidro inteiro escalar junto.
 */
private val PressSpring = spring<Float>(dampingRatio = 1f, stiffness = 1000f)
private val ReleaseSpring = spring<Float>(dampingRatio = 0.52f, stiffness = 420f)

fun Modifier.bouncyClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val down = pressed && enabled
    // Afunda rápido e sem quique (como o iOS); ao soltar volta com uma mola levemente elástica.
    val scale = animateFloatAsState(
        targetValue = if (down) 0.955f else 1f,
        animationSpec = if (down) PressSpring else ReleaseSpring,
        label = "bounce"
    )
    // Lido só na fase de camada: o toque anima sem recompor nada.
    this.graphicsLayer { val s = scale.value; scaleX = s; scaleY = s }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

/**
 * Barra de progresso com mola, degradê, brilho no topo e ponto luminoso na ponta.
 * Mesmos parâmetros do LinearProgressIndicator (progress em lambda), então troca direta.
 */
@Composable
fun GlowBar(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    trackColor: Color = Color.White.copy(alpha = 0.12f)
) {
    val p by animateFloatAsState(progress().coerceIn(0f, 1f), spring(dampingRatio = 0.85f, stiffness = 220f), label = "glowBar")
    val ticker = LocalFrameTicker.current
    val motion = LocalMotionEnabled.current
    // Gradiente em espaço unitário (0..1): é só esticado e movido por transformação, sem criar shader por quadro.
    // Sem fim explícito o degradê ocupa a largura do retângulo desenhado: acompanha o preenchimento e o shader só é refeito se a largura mudar.
    val fillBrush = remember(color) {
        Brush.horizontalGradient(listOf(color.copy(alpha = 0.55f), color, Color.White.copy(alpha = 0.85f).compositeOver(color)))
    }
    val sweep = remember { Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.50f), Color.Transparent), 0f, 1f) }
    Canvas(modifier.height(6.dp)) {
        val radius = CornerRadius(size.height / 2f)
        drawRoundRect(trackColor, cornerRadius = radius)
        val w = size.width * p
        if (w > 0.5f) {
            val fillW = max(w, size.height)
            drawRoundRect(fillBrush, size = Size(fillW, size.height), cornerRadius = radius)
            drawRoundRect(Color.White.copy(alpha = 0.22f), topLeft = Offset(size.height * 0.4f, size.height * 0.12f),
                size = Size((fillW - size.height * 0.8f).coerceAtLeast(0f), size.height * 0.30f), cornerRadius = CornerRadius(size.height * 0.15f))
            drawCircle(color.copy(alpha = 0.30f), size.height * 1.4f, Offset(fillW - size.height / 2f, size.height / 2f))
            // Reflexo que atravessa o preenchimento em laço, dando a sensação de energia correndo na barra.
            if (motion && fillW > size.height * 3f) {
                val sw = max(size.height * 6f, fillW * 0.30f)
                val ph = ((ticker.value / 1_000_000L) % 2_400L) / 2_400f
                val x = -sw + ph * (fillW + sw)
                clipRect(size.height / 2f, 0f, fillW - size.height / 2f, size.height) {
                    withTransform({ translate(x, 0f); scale(sw, 1f, Offset.Zero) }) {
                        drawRect(sweep, Offset.Zero, Size(1f, size.height))
                    }
                }
            }
        }
    }
}
