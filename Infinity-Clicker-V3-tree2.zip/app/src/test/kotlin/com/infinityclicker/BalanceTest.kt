package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.Formulas
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.UpgradeDefs
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/** Testes de economia: ritmo de progressão e garantia de que o jogador nunca fica travado. */
class BalanceTest {

    @Test
    fun firstPurchaseOfEveryGeneratorPaysBackInReasonableTime() {
        for (def in GeneratorDefs.all) {
            val paybackSeconds = (def.baseCost / def.baseProduction).toDouble()
            assertTrue("${def.name}: retorno em ${paybackSeconds}s", paybackSeconds in 25.0..2_200.0)
        }
    }

    @Test
    fun priceAndProductionEscalateAcrossTiers() {
        for (i in 1 until GeneratorDefs.count) {
            val prev = GeneratorDefs.byId(i - 1)
            val cur = GeneratorDefs.byId(i)
            assertTrue(cur.baseCost > prev.baseCost)
            assertTrue(cur.baseProduction > prev.baseProduction)
        }
    }

    @Test
    fun aFreshPlayerAlwaysHasPositiveClickIncome() {
        val e = GameEngine(GameState.new(), Random(1))
        val r = e.tap(0)
        assertTrue("clicar sempre rende energia", r.gain > BigNum.ZERO)
    }

    @Test
    fun everyUpgradeHasPositiveFiniteCostAndSaneLimits() {
        for (u in UpgradeDefs.all) {
            assertTrue(u.id, u.baseCost > BigNum.ZERO)
            assertTrue(u.id, u.growth > 1.0)
            assertTrue(u.id, u.maxLevel > 0)
            for (level in 0 until u.maxLevel) {
                assertTrue(u.id, Formulas.unitCost(u.baseCost, u.growth, level.toLong()) > BigNum.ZERO)
            }
            u.effectText(0); u.effectText(u.maxLevel)
        }
    }

    /**
     * Jogador simulado (3 cliques/s, compra gananciosa pelo melhor retorno).
     * Verifica pacing: primeira compra rápida, nenhum "deserto" longo sem compras, tiers sendo destravados.
     */
    @Test
    fun simulatedPlayerProgressesSmoothlyAndNeverStalls() {
        val e = GameEngine(GameState.new(), Random(11))
        var now = 0L
        var lastPurchaseAt = 0L
        var maxGapMs = 0L
        var firstPurchaseAt = -1L
        val checkpoints = mapOf(600L to 1, 1800L to 3, 3600L to 4) // V3: ritmo mais estratégico, sem deserto econômico

        var seconds = 0L
        while (seconds < 3600L) {
            // 3 cliques por segundo
            for (k in 0 until 3) {
                e.tap(now + k * 333L)
            }
            now += 1000L
            e.advance(1000L)
            seconds++

            var bought = true
            while (bought) {
                bought = buyBest(e)
                if (bought) {
                    if (firstPurchaseAt < 0) firstPurchaseAt = now
                    maxGapMs = maxOf(maxGapMs, now - lastPurchaseAt)
                    lastPurchaseAt = now
                }
            }
            checkpoints[seconds]?.let { minTier ->
                val highest = e.state.generators.indexOfLast { it > 0L }
                assertTrue("aos ${seconds}s o maior gerador era $highest (mínimo $minTier)", highest >= minTier)
            }
        }
        assertTrue("primeira compra em ${firstPurchaseAt / 1000}s", firstPurchaseAt in 1L..15_000L)
        assertTrue("maior intervalo sem comprar: ${maxGapMs / 1000}s", maxGapMs <= 420_000L)
        assertTrue(e.state.totalEnergy > BigNum.of(1e6))
    }

    private fun buyBest(e: GameEngine): Boolean {
        // 1) gerador desbloqueado com melhor produção/custo que dá para pagar
        var bestId = -1
        var bestScore = 0.0
        for (def in GeneratorDefs.all) {
            if (!e.isGeneratorUnlocked(def.id)) continue
            val plan = e.planGenerator(def, BuyMode.X1)
            if (!plan.affordable) continue
            val score = (def.baseProduction / plan.cost).toDouble()
            if (score > bestScore) { bestScore = score; bestId = def.id }
        }
        // 2) melhorias baratas (< 25% da energia) valem a pena
        for (u in UpgradeDefs.all) {
            if (!e.isUnlocked(u.requirement)) continue
            val plan = e.planUpgrade(u, BuyMode.X1)
            if (plan.count > 0 && plan.affordable && plan.cost * 4.0 <= e.state.energy) {
                if (e.buyUpgrade(u.id, BuyMode.X1)) return true
            }
        }
        if (bestId >= 0) return e.buyGenerator(bestId, BuyMode.X1)
        return false
    }
}
