package com.w2a.nzuz

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

 data class AppSettings(
    val automatic: Boolean = true,
    val offline: Boolean = false,
    val wifiOnly: Boolean = true,
    val theme: String = "system",
    val styleUrl: String = "",
    val attribution: String = "",
    val authorized: Boolean = false,
    val catalogUrl: String = "",
    val serviceUrl: String = "",
    val serviceToken: String = ""
)

class Preferences(context: Context) {
    private val disk = context.getSharedPreferences("dmaps", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(read())
    val state = mutable.asStateFlow()
    private fun read() = AppSettings(
        disk.getBoolean("automatic", true), disk.getBoolean("offline", false),
        disk.getBoolean("wifi", true), disk.getString("theme", "system")!!,
        disk.getString("style", "")!!, disk.getString("credit", "")!!,
        disk.getBoolean("authorized", false),
        disk.getString("catalog", "")!!, disk.getString("service", "")!!, disk.getString("serviceToken", "")!!
    )
    fun update(value: AppSettings) {
        disk.edit().putBoolean("automatic", value.automatic).putBoolean("offline", value.offline)
            .putBoolean("wifi", value.wifiOnly).putString("theme", value.theme)
            .putString("style", value.styleUrl).putString("credit", value.attribution)
            .putBoolean("authorized", value.authorized).putString("catalog", value.catalogUrl)
            .putString("service", value.serviceUrl).putString("serviceToken", value.serviceToken).apply()
        mutable.value = value
    }
    fun saveCamera(lat: Double, lon: Double, zoom: Double, bearing: Double) {
        disk.edit().putString("camera", "$lat,$lon,$zoom,$bearing").apply()
    }
    fun camera(): List<Double>? = disk.getString("camera", null)?.split(",")
        ?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.size == 4 && it.all(Double::isFinite) }
    fun setRegionMessage(id: Long, value: String) { disk.edit().putString("region_$id", value).apply() }
    fun regionMessage(id: Long) = disk.getString("region_$id", "Pausado")!!
    fun forget(id: Long) { disk.edit().remove("region_$id").apply() }
}

fun validateSource(url: String, credit: String, authorized: Boolean): String? {
    val uri = Uri.parse(url)
    val host = uri.host.orEmpty().lowercase()
    if (uri.scheme != "https" || host.isBlank() || uri.userInfo != null || uri.fragment != null)
        return "Informe uma URL HTTPS de estilo MapLibre."
    if (host == "apple.com" || host.endsWith(".apple.com") ||
        host == "openstreetmap.org" || host.endsWith(".openstreetmap.org"))
        return "Essa fonte não pode ser usada para baixar regiões."
    if (credit.isBlank()) return "Informe a fonte, atribuição e licença dos dados."
    if (!authorized) return "Confirme a autorização de download de tiles, fontes e ícones."
    return null
}
