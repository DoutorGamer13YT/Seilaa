package com.infinityclicker.ui.screens

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon

private const val INSTAGRAM_USER = "vitinhkjkk"
private const val INSTAGRAM_URL = "https://www.instagram.com/$INSTAGRAM_USER/"

/** Aba do desenvolvedor. A foto vem de res/drawable-nodpi/developer_photo.(jpg|png); sem ela, mostra a inicial. */
@Composable
fun DeveloperScreen(ui: UiState) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val photo = remember {
        val id = context.resources.getIdentifier("developer_photo", "drawable", context.packageName)
        if (id == 0) null else runCatching { BitmapFactory.decodeResource(context.resources, id)?.asImageBitmap() }.getOrNull()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("DESENVOLVEDOR", color = Neon.TextSecondary, fontSize = 11.sp, letterSpacing = 2.sp)
                Box(
                    Modifier.padding(top = 14.dp).size(132.dp).clip(CircleShape).border(2.dp, Neon.Cyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (photo != null) {
                        Image(photo, "Foto do desenvolvedor", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text("V", color = Neon.Cyan, fontSize = 56.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text("@$INSTAGRAM_USER", color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Criador do Infinity Clicker", color = Neon.TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
            }
        }

        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
            Text("Instagram", color = Neon.Pink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Toque na caixa para abrir o perfil.", color = Neon.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth()
                    .glass(RoundedCornerShape(16.dp), tint = Neon.Pink, alpha = 0.22f, borderAlpha = 0.6f)
                    .clickable { runCatching { uriHandler.openUri(INSTAGRAM_URL) } }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("@$INSTAGRAM_USER", color = Neon.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text("instagram.com/$INSTAGRAM_USER", color = Neon.Cyan, fontSize = 12.sp)
                }
                Text("↗", color = Neon.Pink, fontSize = 22.sp)
            }
        }
    }
}
