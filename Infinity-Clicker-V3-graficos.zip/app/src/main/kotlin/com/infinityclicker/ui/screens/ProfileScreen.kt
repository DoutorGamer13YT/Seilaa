package com.infinityclicker.ui.screens

import androidx.compose.foundation.Canvas
import com.infinityclicker.ui.components.GlowBar
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import com.infinityclicker.ui.components.SpaceBackground
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import com.infinityclicker.core.AppInfo
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.Formulas
import com.infinityclicker.game.PlayerRanks
import com.infinityclicker.ui.components.CloudSyncGroup
import com.infinityclicker.ui.components.DevBadge
import com.infinityclicker.ui.AbilityUi
import com.infinityclicker.ui.BackgroundUi
import com.infinityclicker.ui.SkillNodeUi
import com.infinityclicker.ui.UiState
import com.infinityclicker.ui.components.GlassCard
import com.infinityclicker.ui.components.SettingsChoice
import com.infinityclicker.ui.components.SettingsGroup
import com.infinityclicker.ui.components.SettingsRow
import com.infinityclicker.ui.components.SettingsSlider
import com.infinityclicker.ui.components.SettingsToggle
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import com.infinityclicker.game.SkillPath
import kotlin.math.roundToInt

@Composable
fun ProfileScreen(
    ui: UiState,
    onScientific: (Boolean) -> Unit,
    onQuality: (GraphicsQuality) -> Unit,
    onFrameRate: (Int) -> Unit,
    onSound: (Boolean) -> Unit,
    onMusic: (Boolean) -> Unit,
    fpsInfo: String,
    section: Int,
    onBatterySaver: (Boolean) -> Unit,
    onEffects: (Float) -> Unit,
    onPanelOpacity: (Float) -> Unit,
    onHaptics: (Boolean) -> Unit,
    onUpgradeAbility: (String) -> Unit,
    onBuySkill: (String) -> Unit,
    onEquipBackground: (Int) -> Unit,
    onExportSave: () -> Unit,
    onImportSave: () -> Unit,
    onPrestige: () -> Unit,
    onReset: () -> Unit
) {
    val sci = ui.settings.scientificNotation
    val s = ui.stats
    var confirmReset by remember { mutableStateOf(false) }
    var confirmPrestige by remember { mutableStateOf(false) }
    var showTree by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (section == 0) {
        ProfileHeader(ui)

        // O mínimo vem da própria fórmula (inclui a dificuldade), então o texto nunca diverge da regra real.
        val prestigeMin = NumberFormatter.format(Formulas.PRESTIGE_MIN_RUN_ENERGY, sci)
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Gold, alpha = ui.settings.panelOpacity) {
            Text("Renascimento Cósmico · ${ui.stats.prestigePoints} PP", color = Neon.Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Energia da corrida: ${NumberFormatter.format(ui.prestige.runEnergy, sci)}", color = Neon.TextSecondary, fontSize = 13.sp)
            Text(
                if (ui.prestige.available) "+${ui.prestige.points} pontos de prestígio · bônus permanente após: ×${"%.2f".format(ui.prestige.permanentMultiplierAfter)}"
                else "Produza $prestigeMin de energia nesta corrida para renascer.",
                color = if (ui.prestige.available) Neon.Gold else Neon.TextSecondary, fontSize = 13.sp
            )
            Button(
                onClick = { confirmPrestige = true }, enabled = ui.prestige.available,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon.Gold.copy(alpha = 0.86f), contentColor = Neon.Bg)
            ) { Text("Renascer", fontWeight = FontWeight.Bold) }
            Button(
                onClick = { showTree = true }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon.Violet.copy(alpha = 0.78f), contentColor = Neon.Bg)
            ) { Text("Árvore de habilidades · ${ui.skills.count { it.level > 0 }}/${ui.skills.size} nós", fontWeight = FontWeight.Bold) }
        }

        val panel = ui.settings.panelOpacity
        // ---- Visão geral: porcentagem do jogo concluída e quatro números de destaque.
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Cyan, alpha = panel) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Sua jornada", color = Neon.Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${(s.completionFraction * 100f).toInt()}% concluído", color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            GlowBar(progress = { s.completionFraction }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Neon.Cyan)
            Text(
                "${s.achievementsClaimed} de ${com.infinityclicker.game.AchievementDefs.all.size} conquistas resgatadas · ${s.prestigeCount} renascimentos",
                color = Neon.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Energia total", NumberFormatter.format(s.totalEnergy, sci), Neon.Cyan, panel, Modifier.weight(1f))
            StatTile("Tempo jogado", NumberFormatter.duration(s.playTimeMs), Neon.Violet, panel, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Cliques", s.totalClicks.toString(), Neon.Pink, panel, Modifier.weight(1f))
            StatTile("Maior produção/s", NumberFormatter.format(s.highestProduction, sci), Neon.Green, panel, Modifier.weight(1f))
        }

        // ---- Estatísticas agrupadas por assunto (antes era uma lista única de 21 linhas).
        SettingsGroup("Cliques", panel) {
            StatLine("●", Neon.Pink, "Cliques", s.totalClicks.toString())
            StatLine("≋", Neon.Cyan, "Cliques por segundo", s.clicksPerSecond.toString())
            StatLine("✦", Neon.Gold, "Cliques críticos", s.critClicks.toString())
            StatLine("◆", Neon.Violet, "Maior combo", s.maxCombo.toString())
            StatLine("×", Neon.Green, "Melhor multiplicador", "×${"%.2f".format(s.highestTapMultiplier)}", divider = false)
        }
        SettingsGroup("Energia", panel, footer = "Manual = vinda dos cliques. Automática = vinda dos geradores. Eficiência mostra quanto da energia total já é automática.") {
            StatLine("Σ", Neon.Cyan, "Energia total produzida", NumberFormatter.format(s.totalEnergy, sci))
            StatLine("●", Neon.Pink, "Energia manual", NumberFormatter.format(s.clickEnergy, sci))
            StatLine("◈", Neon.Violet, "Energia automática", NumberFormatter.format(s.productionEnergy, sci))
            StatLine("◐", Neon.Gold, "Ganha offline", NumberFormatter.format(s.offlineEarned, sci))
            StatLine("%", Neon.Green, "Eficiência automática", automationEfficiency(s))
            StatLine("▲", Neon.Cyan, "Maior produção/s", NumberFormatter.format(s.highestProduction, sci), divider = false)
        }
        SettingsGroup("Progresso", panel) {
            StatLine("■", Neon.Cyan, "Geradores comprados", s.generatorsBought.toString())
            StatLine("▲", Neon.Green, "Melhorias compradas", s.upgradeLevelsBought.toString())
            StatLine("✧", Neon.Violet, "Habilidades usadas", s.abilitiesUsed.toString())
            StatLine("◎", Neon.Pink, "Chefes derrotados", s.bossWins.toString())
            StatLine("✦", Neon.Gold, "Eventos cósmicos", s.eventsTriggered.toString())
            StatLine("◆", Neon.Cyan, "Desafios concluídos", s.challengeCompletions.toString())
            StatLine("★", Neon.Gold, "Conquistas", "${s.achievementsClaimed}/${com.infinityclicker.game.AchievementDefs.all.size}")
            StatLine("◉", Neon.Green, "Sequência de login", "${ui.loginStreak} dia(s)", divider = false)
        }
        SettingsGroup("Coleção", panel, footer = "Dimensões e cristais abrem com energia total; ambientes ficam na aba Ambientes.") {
            StatLine("◎", Neon.Cyan, "Dimensões abertas", "${ui.dimensions.count { it.unlocked }}/${ui.dimensions.size}")
            StatLine("◆", Neon.Violet, "Cristais", "${ui.crystals.count { it.unlocked }}/${ui.crystals.size}")
            StatLine("■", Neon.Pink, "Ambientes", "${ui.backgrounds.count { it.unlocked }}/${ui.backgrounds.size}")
            StatLine("✦", Neon.Gold, "Nós da árvore", "${ui.skills.count { it.level > 0 }}/${ui.skills.size}", divider = false)
        }

        // ---- Linha do tempo dos renascimentos.
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Gold, alpha = panel) {
            Text("Histórico de renascimentos", color = Neon.Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                "${s.prestigeCount} no total · ${s.prestigePoints} PP acumulados",
                color = Neon.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp)
            )
            if (ui.prestigeLog.isEmpty()) {
                Text(
                    "Nenhum renascimento ainda. Produza $prestigeMin de energia em uma corrida para renascer pela primeira vez.",
                    color = Neon.TextSecondary, fontSize = 13.sp
                )
            } else {
                val fmt = remember { java.text.SimpleDateFormat("dd/MM/yyyy · HH:mm", java.util.Locale("pt", "BR")) }
                ui.prestigeLog.forEachIndexed { i, entry ->
                    TimelineRow(
                        title = "Renascimento #${(s.prestigeCount - i).coerceAtLeast(1)}",
                        subtitle = fmt.format(java.util.Date(entry.atMs)) + " · energia ${NumberFormatter.format(entry.lifetimeEnergy, sci)}",
                        badge = "+${entry.points} PP",
                        tint = Neon.Gold,
                        last = i == ui.prestigeLog.lastIndex
                    )
                }
                if (s.prestigeCount > ui.prestigeLog.size) {
                    Text("Mostrando os ${ui.prestigeLog.size} mais recentes.", color = Neon.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity) {
            Text("Habilidades especiais", color = Neon.Violet, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Evoluções usam pontos de prestígio e mudam os valores aplicados no motor.", color = Neon.TextSecondary, fontSize = 12.sp)
            ui.abilities.forEach { ability -> AbilityUpgradeRow(ability, onUpgradeAbility) }
        }

        }
        if (section == 1) {
            val panel = ui.settings.panelOpacity
            val fps = listOf(30, 60, 90, 120)
            val q = ui.settings.graphicsQuality
            val qualityShort = listOf("Auto", "Eco", "Médio", "Alto", "Ultra")
            val qualityOrder = listOf(GraphicsQuality.AUTO, GraphicsQuality.LOW, GraphicsQuality.MEDIUM, GraphicsQuality.HIGH, GraphicsQuality.ULTRA)
            val qualityHint = when (q) {
                GraphicsQuality.AUTO -> "Escolhe sozinho: alta qualidade, ou econômica se a economia de bateria estiver ligada."
                GraphicsQuality.LOW -> "Poucas partículas e estrelas. Gasta menos bateria e esquenta menos."
                GraphicsQuality.MEDIUM -> "Meio-termo entre beleza e consumo."
                GraphicsQuality.HIGH -> "Visual completo, recomendado para a maioria dos aparelhos."
                GraphicsQuality.ULTRA -> "Máximo de partículas e detalhes. Pode esquentar o aparelho."
            }
            SettingsGroup("Aparência", panel) {
                SettingsToggle("Σ", Neon.Violet, "Notação científica", sci, onScientific, subtitle = if (sci) "Exemplo: 1.23e45" else "Exemplo: 1.23Dc")
                SettingsSlider("◑", Neon.Cyan, "Transparência dos painéis", "${(ui.settings.panelOpacity * 100).roundToInt()}%",
                    ui.settings.panelOpacity, 0.06f..0.30f, onPanelOpacity)
                SettingsSlider("✦", Neon.Pink, "Intensidade dos efeitos", "${(ui.settings.effectsIntensity * 100).roundToInt()}%",
                    ui.settings.effectsIntensity, 0.25f..1.5f, onEffects, divider = false)
            }
            SettingsGroup(
                "Desempenho", panel,
                footer = if (fpsInfo.isNotEmpty()) "$fpsInfo. O limite vira um divisor da taxa real da tela para o movimento ficar uniforme. No Samsung, deixe Configurações › Tela › Movimento suave em Adaptável (ou Alto) para liberar 120 Hz."
                else "No Samsung, deixe Configurações › Tela › Movimento suave em Adaptável (ou Alto) para liberar 120 Hz."
            ) {
                SettingsChoice("◈", Neon.Green, "Qualidade visual", q.label, qualityShort, qualityOrder.indexOf(q).coerceAtLeast(0),
                    { onQuality(qualityOrder[it]) }, caption = qualityHint)
                SettingsChoice("◎", Neon.Gold, "Limite de FPS", "${ui.settings.frameRateCap} fps", fps.map { "$it" },
                    fps.indexOf(ui.settings.frameRateCap).coerceAtLeast(1), { onFrameRate(fps[it]) })
                SettingsToggle("◐", Neon.Green, "Economia de bateria", ui.settings.batterySaver, onBatterySaver,
                    subtitle = "Limita a 30 fps e reduz efeitos", divider = false)
            }
            SettingsGroup("Som e toque", panel) {
                SettingsToggle("♪", Neon.Pink, "Efeitos sonoros", ui.settings.soundEnabled, onSound)
                SettingsToggle("♫", Neon.Violet, "Música de fundo", ui.settings.musicEnabled, onMusic)
                SettingsToggle("≋", Neon.Cyan, "Feedback tátil", ui.settings.hapticsEnabled, onHaptics, subtitle = "Vibração leve ao tocar", divider = false)
            }
        }
        if (section == 2) {
        GlassCard(Modifier.fillMaxWidth(), tint = Neon.Pink, alpha = ui.settings.panelOpacity) {
            Text("Ambientes", color = Neon.Pink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Cada ambiente troca a renderização do fundo; nenhum item é somente decorativo.", color = Neon.TextSecondary, fontSize = 12.sp)
            ui.backgrounds.forEach { background -> BackgroundRow(background, onEquipBackground) }
        }

        }
        if (section == 1) {
            val panel = ui.settings.panelOpacity
            CloudSyncGroup(panel)
            SettingsGroup(
                "Dados", panel,
                footer = "Exportar cria um arquivo com checksum. Importar valida o arquivo e guarda o save atual como backup antes da troca."
            ) {
                SettingsRow("↑", Neon.Green, "Exportar save", subtitle = "Salvar uma cópia do progresso", onClick = onExportSave) {
                    Text("›", color = Neon.TextSecondary, fontSize = 22.sp)
                }
                SettingsRow("↓", Neon.Cyan, "Importar save", subtitle = "Restaurar de um arquivo", divider = false, onClick = onImportSave) {
                    Text("›", color = Neon.TextSecondary, fontSize = 22.sp)
                }
            }
            if (ui.recoveredFromBackup) {
                Text("O save principal estava corrompido; o backup anterior foi restaurado.", color = Neon.Gold, fontSize = 13.sp)
            }
            SettingsGroup("Zona de perigo", panel) {
                SettingsRow("✕", Neon.Pink, "Apagar progresso local", subtitle = "Não pode ser desfeito", divider = false,
                    titleColor = Neon.Pink, onClick = { confirmReset = true })
            }
        }
    }

    if (confirmPrestige) {
        AlertDialog(
            onDismissRequest = { confirmPrestige = false },
            title = { Text("Confirmar renascimento?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Você receberá ${ui.prestige.points} ponto(s) de prestígio.")
                    Text("Será reiniciado: energia atual, geradores, melhorias normais, combo, habilidade ativa e chefe.")
                    Text("Será preservado: energia total, estatísticas, pontos e árvore de prestígio, cristais, dimensões, fragmentos, missões e conquistas.")
                }
            },
            confirmButton = { TextButton(onClick = { confirmPrestige = false; onPrestige() }) { Text("Renascer") } },
            dismissButton = { TextButton(onClick = { confirmPrestige = false }) { Text("Cancelar") } }
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Apagar tudo?") },
            text = { Text("O progresso local será apagado. Esta ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }
    if (showTree) SkillTreeDialog(ui.skills, ui.stats.prestigePoints, onBuySkill) { showTree = false }
}

@Composable
private fun AbilityUpgradeRow(ability: AbilityUi, onUpgrade: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${ability.def.name} · Nv. ${ability.level}/${ability.def.maxLevel}", color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(ability.def.effectText(ability.level), color = Neon.TextSecondary, fontSize = 11.sp)
        }
        Button(
            onClick = { onUpgrade(ability.def.id) }, enabled = ability.canUpgrade,
            colors = ButtonDefaults.buttonColors(containerColor = Neon.Violet.copy(alpha = 0.80f), contentColor = Neon.Bg)
        ) { Text("${ability.def.upgradeCost(ability.level)} PP", fontSize = 10.sp) }
    }
}

/**
 * Cabeçalho do perfil: patente (derivada da energia total), progresso até a próxima, versão e atalhos de status.
 * A patente nunca cai, porque a energia total só aumenta.
 */
@Composable
private fun ProfileHeader(ui: UiState) {
    val s = ui.stats
    val progress = remember(s.totalEnergy) { PlayerRanks.forEnergy(s.totalEnergy) }
    GlassCard(Modifier.fillMaxWidth(), tint = Neon.Violet, alpha = ui.settings.panelOpacity + 0.04f) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(64.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Neon.Violet.copy(alpha = 0.80f), Neon.Cyan.copy(alpha = 0.60f)))),
                contentAlignment = Alignment.Center
            ) { Text("${progress.rank.index + 1}", color = Neon.Bg, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text("PATENTE", color = Neon.TextSecondary, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(progress.rank.name, color = Neon.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                DevBadge(AppInfo.VERSION_LABEL, Neon.Cyan, Modifier.padding(top = 4.dp))
            }
        }
        GlowBar(progress = { progress.fraction }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), color = Neon.Violet)
        Text(
            progress.next?.let { "Próxima patente: ${it.name} · ${(progress.fraction * 100f).toInt()}%" } ?: "Patente máxima alcançada",
            color = Neon.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
        )
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProfileChip("${s.prestigePoints} PP", Neon.Gold)
            ProfileChip("${s.prestigeCount} renasc.", Neon.Pink)
            ProfileChip("${ui.loginStreak} dia(s) seguidos", Neon.Green)
        }
    }
}

@Composable
private fun ProfileChip(text: String, tint: Color) {
    Text(
        text, color = tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.glass(RoundedCornerShape(50), tint = tint, alpha = 0.14f, borderAlpha = 0.40f).padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
private fun BackgroundRow(background: BackgroundUi, onEquip: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(background.def.name, color = Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(if (background.unlocked) background.def.subtitle else "Desbloqueia em ${NumberFormatter.format(background.def.unlockAt)} de energia total", color = Neon.TextSecondary, fontSize = 10.sp)
        }
        Button(
            onClick = { onEquip(background.def.id) },
            enabled = background.unlocked && !background.equipped,
            colors = ButtonDefaults.buttonColors(containerColor = background.def.tintColor.copy(alpha = .82f), contentColor = Neon.Bg)
        ) { Text(if (background.equipped) "Ativo" else "Usar", fontSize = 10.sp) }
    }
}

private fun automationEfficiency(s: com.infinityclicker.ui.StatsUi): String {
    if (s.totalEnergy.isZero) return "0%"
    return "${"%.1f".format((s.productionEnergy / s.totalEnergy).toDouble().coerceIn(0.0, 1.0) * 100)}%"
}

@Composable
private fun SkillTreeDialog(nodes: List<SkillNodeUi>, prestigePoints: Int, onBuy: (String) -> Unit, onDismiss: () -> Unit) {
    // Tela cheia própria (janela separada, sem a largura reduzida do diálogo padrão).
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().background(Neon.Bg)) {
            SpaceBackground(tint = Neon.Violet, modifier = Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Árvore de Habilidades", color = Neon.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                        Text("$prestigePoints PP disponíveis · deslize para explorar.", color = Neon.TextSecondary, fontSize = 11.sp)
                    }
                    TextButton(onClick = onDismiss) { Text("Fechar") }
                }
                SkillTreeMap(nodes, onBuy, Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun SkillTreeMap(nodes: List<SkillNodeUi>, onBuy: (String) -> Unit, modifier: Modifier = Modifier) {
    val paths = SkillPath.entries
    val pathColors = listOf(Neon.Cyan, Neon.Green, Neon.Pink, Neon.Gold, Neon.Violet)
    // Rolagem nativa nos dois eixos (inércia estilo iOS) com colunas largas e cartões grandes.
    Box(modifier.horizontalScroll(rememberScrollState()).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            paths.forEachIndexed { column, path ->
                val color = pathColors[column % pathColors.size]
                val pathNodes = nodes.filter { it.def.path == path }
                Column(Modifier.width(212.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    SkillPathHeader(path.label, color, pathNodes.count { it.level > 0 }, pathNodes.size)
                    pathNodes.forEachIndexed { i, node ->
                        if (i > 0) {
                            val lit = pathNodes[i - 1].level > 0
                            Box(
                                Modifier.width(3.dp).height(18.dp).clip(RoundedCornerShape(2.dp))
                                    .background(color.copy(alpha = if (lit) 0.85f else 0.22f))
                            )
                        }
                        SkillNodeCard(node, color, onBuy)
                    }
                    androidx.compose.foundation.layout.Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun SkillPathHeader(label: String, color: Color, owned: Int, total: Int) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .glass(RoundedCornerShape(22.dp), tint = color, alpha = 0.20f, borderAlpha = 0.55f).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(label, color = Neon.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("$owned de $total desbloqueadas", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        GlowBar(
            progress = { if (total == 0) 0f else owned.toFloat() / total },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(5.dp).clip(RoundedCornerShape(3.dp)),
            color = color, trackColor = Color.White.copy(alpha = 0.12f)
        )
    }
}

@Composable
private fun SkillNodeCard(node: SkillNodeUi, pathColor: Color, onBuy: (String) -> Unit) {
    val maxed = node.level >= node.def.maxLevel
    val owned = node.level > 0
    val accent = when {
        maxed -> Neon.Gold
        owned -> pathColor
        node.requirementsMet -> pathColor.copy(alpha = 0.85f)
        else -> Neon.TextSecondary
    }
    val progress by androidx.compose.animation.core.animateFloatAsState(
        targetValue = node.level.toFloat() / node.def.maxLevel.coerceAtLeast(1),
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.8f, stiffness = 180f), label = "skillRing"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth()
            .glass(shape, tint = accent, alpha = if (owned) 0.24f else if (node.requirementsMet) 0.14f else 0.06f, borderAlpha = if (owned) 0.6f else 0.3f)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 5.dp.toPx()
                    val inset = stroke / 2f
                    val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
                    drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, Offset(inset, inset), arcSize,
                        style = Stroke(stroke))
                    if (progress > 0f) drawArc(accent, -90f, 360f * progress, false, Offset(inset, inset), arcSize,
                        style = Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                Text(if (node.requirementsMet || owned) "${node.level}" else "🔒", color = Neon.TextPrimary, fontSize = if (node.requirementsMet || owned) 18.sp else 15.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(node.def.name, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp)
                Text("Nível ${node.level}/${node.def.maxLevel}", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
        Text(node.def.description, color = Neon.TextSecondary, fontSize = 12.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 10.dp))
        Text(
            if (owned) "Atual: ${node.def.effectText(node.level)}" else "Efeito: ${node.def.effectText(1)}",
            color = Neon.TextPrimary.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp)
        )
        val actionShape = RoundedCornerShape(50)
        when {
            maxed -> Text("Nível máximo", color = Neon.Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 10.dp))
            node.canBuy -> Box(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(actionShape).background(accent)
                    .clickable { onBuy(node.def.id) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Text("Evoluir · ${node.def.costAt(node.level)} PP", color = Neon.Bg, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            node.requirementsMet -> Text("Precisa de ${node.def.costAt(node.level)} PP", color = Neon.TextSecondary, fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp))
            else -> Text("Desbloqueie a habilidade anterior", color = Neon.TextSecondary, fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}

/** Número grande com legenda: os destaques do topo do resumo. */
@Composable
private fun StatTile(label: String, value: String, tint: Color, panelAlpha: Float, modifier: Modifier = Modifier) {
    GlassCard(modifier, tint = tint, alpha = panelAlpha) {
        Text(label, color = Neon.TextSecondary, fontSize = 12.sp, maxLines = 1)
        Text(value, color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Linha de estatística: ícone colorido, nome e valor alinhado à direita. */
@Composable
private fun StatLine(symbol: String, tint: Color, label: String, value: String, divider: Boolean = true) {
    SettingsRow(symbol, tint, label, divider = divider) {
        Text(value, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Item de linha do tempo: marcador, fio ligando ao próximo, título, data e selo à direita. */
@Composable
private fun TimelineRow(title: String, subtitle: String, badge: String, tint: Color, last: Boolean) {
    Row(Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
        Box(
            Modifier.width(20.dp).fillMaxHeight().drawBehind {
                val cx = size.width / 2f
                if (!last) drawLine(Color.White.copy(alpha = 0.16f), Offset(cx, 16.dp.toPx()), Offset(cx, size.height), 1.5.dp.toPx())
                drawCircle(tint.copy(alpha = 0.25f), 8.dp.toPx(), Offset(cx, 11.dp.toPx()))
                drawCircle(tint, 4.5.dp.toPx(), Offset(cx, 11.dp.toPx()))
            }
        )
        Column(Modifier.weight(1f).padding(start = 8.dp, bottom = 14.dp)) {
            Text(title, color = Neon.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Neon.TextSecondary, fontSize = 12.sp)
        }
        Text(badge, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
