#!/usr/bin/env python3
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
from urllib.parse import urlparse
import zipfile

LIMIT = 8 * 1024 ** 3
ATTRIBUTION = '© OpenStreetMap contributors · Protomaps · Natural Earth'


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def bounds(value):
    b = [float(x) for x in value]
    if len(b) != 4 or not all(math.isfinite(x) for x in b):
        raise ValueError('bounds must have four finite coordinates')
    w, s, e, n = b
    if not (-180 <= w < e <= 180 and -85 <= s < n <= 85 and e - w <= 15 and n - s <= 15):
        raise ValueError('area must be within Mercator limits, at most 15 degrees per side, no antimeridian crossing')
    return b


def https(value):
    u = urlparse(value)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.fragment:
        raise ValueError('a final HTTPS URL is required')
    return value.rstrip('/')


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    os.replace(tmp, path)


def make_package(*, source, output, public_base, assets, styles, region_id, version, name, kind, bbox, zoom):
    bbox = bounds(bbox)
    if not 8 <= zoom <= 15 or kind not in ('city', 'state', 'custom'):
        raise ValueError('unsupported zoom or kind')
    if not name.strip() or len(name) > 120:
        raise ValueError('invalid name')
    for value in (region_id, version):
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', value):
            raise ValueError('unsafe identifier')
    https(source)
    public_base = https(public_base)
    if urlparse(public_base).hostname == 'maps.protomaps.com':
        raise ValueError('own distribution is required')
    output, assets, styles = Path(output), Path(assets), Path(styles)
    output.mkdir(parents=True, exist_ok=True)
    basename = f'{region_id}.{version}'
    target = output / f'{basename}.zip'
    metadata_path = output / f'{basename}.json'
    if target.exists() and metadata_path.exists():
        old = json.loads(metadata_path.read_text())
        if old['bounds'] == bbox and old['maxZoom'] == zoom and old['name'] == name and old['kind'] == kind and sha256(target) == old['sha256']:
            return old
        raise ValueError('immutable version already exists; use a new version')
    with tempfile.TemporaryDirectory(prefix='region-', dir=output) as work:
        root = Path(work)
        tilefile = root / 'map.pmtiles'
        subprocess.run(['pmtiles', 'extract', source, str(tilefile), '--bbox=' + ','.join(map(str, bbox)), '--maxzoom=' + str(zoom)], check=True, timeout=3600)
        subprocess.run(['pmtiles', 'verify', str(tilefile)], check=True, timeout=600)
        with tilefile.open('rb') as f:
            header = f.read(127)
        if len(header) != 127 or header[:8] != b'PMTiles\x03' or header[99] != 1:
            raise ValueError('expected PMTiles v3 MVT')
        if tilefile.stat().st_size > LIMIT:
            raise ValueError('region exceeds app limit')
        if header[101] < zoom:
            raise ValueError('source lacks requested detail')
        (root / 'styles').mkdir()
        font_sets = set()
        for theme in ('light', 'dark'):
            style = json.loads((styles / f'{theme}.json').read_text())
            if style.get('glyphs') != 'dmap://fonts/{fontstack}/{range}.pbf' or style.get('sprite') != f'dmap://sprites/{theme}':
                raise ValueError('generate offline styles first')
            if set(style['sources']) != {'protomaps'} or style['sources']['protomaps']['url'] != 'dmap://map.pmtiles':
                raise ValueError('external sources forbidden')
            def collect_fonts(value):
                if isinstance(value, dict):
                    for child in value.values():
                        collect_fonts(child)
                elif isinstance(value, list):
                    if value and all(isinstance(x, str) and x.startswith('Noto Sans') for x in value):
                        font_sets.add(','.join(value))
                    else:
                        for child in value:
                            collect_fonts(child)
            collect_fonts(style)
            shutil.copyfile(styles / f'{theme}.json', root / 'styles' / f'{theme}.json')
        if not font_sets:
            raise ValueError('no text fonts discovered')
        for stack in sorted(font_sets):
            if not re.fullmatch(r'[A-Za-z0-9 ,_-]+', stack):
                raise ValueError('unsafe font stack')
            directory = assets / 'fonts' / stack
            for start in range(0, 65536, 256):
                source_font = directory / f'{start}-{start + 255}.pbf'
                if not source_font.is_file():
                    raise ValueError(f'missing glyph range: {source_font}; provide a complete authorized font stack')
                dest = root / 'fonts' / stack / source_font.name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source_font, dest)
        (root / 'sprites').mkdir()
        for theme in ('light', 'dark'):
            for suffix in ('.json', '.png', '@2x.json', '@2x.png'):
                shutil.copyfile(assets / 'sprites' / 'v4' / f'{theme}{suffix}', root / 'sprites' / f'{theme}{suffix}')
        licenses = root / 'LICENSES'
        licenses.mkdir()
        shutil.copyfile(assets / 'fonts' / 'OFL.txt', licenses / 'Noto-OFL.txt')
        sprite_license = assets / 'sprites' / 'LICENSE.txt'
        if not sprite_license.exists():
            sprite_license = assets / 'sprites' / 'LICENSE.md'
        if not sprite_license.exists():
            raise ValueError('place the original MIT icon license at assets/sprites/LICENSE.txt')
        shutil.copyfile(sprite_license, licenses / 'Icons-MIT.txt')
        for license_name in ('Protomaps-BSD-3-Clause.txt', 'ODbL-1.0.txt', 'CC0-1.0.txt', 'Protomaps-DATA.txt'):
            shutil.copyfile(Path(__file__).parent / 'licenses' / license_name, licenses / license_name)
        (licenses / 'ATTRIBUTION.txt').write_text(ATTRIBUTION + '\nhttps://www.openstreetmap.org/copyright\nhttps://protomaps.com\nNatural Earth: public domain\nSource build: ' + source + '\n', encoding='utf-8')
        files = {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': sha256(p)} for p in sorted(root.rglob('*')) if p.is_file()}
        atomic_json(root / 'pack.json', {'schema': 1, 'id': region_id, 'version': version, 'fonts': sorted(font_sets), 'files': files})
        unpacked = sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
        if unpacked > LIMIT:
            raise ValueError('unpacked size exceeds app limit')
        temporary_zip = output / f'{basename}.zip.tmp'
        with zipfile.ZipFile(temporary_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    archive.write(path, path.relative_to(root).as_posix(), compress_type=zipfile.ZIP_STORED if path.suffix == '.pmtiles' else zipfile.ZIP_DEFLATED)
        if temporary_zip.stat().st_size > LIMIT:
            temporary_zip.unlink()
            raise ValueError('archive exceeds app limit')
        metadata = {'id': region_id, 'version': version, 'name': name, 'kind': kind, 'provider': 'protomaps', 'license': 'ODbL-1.0', 'attribution': ATTRIBUTION,
                    'bounds': bbox, 'minZoom': header[100], 'maxZoom': zoom, 'bytes': temporary_zip.stat().st_size, 'unpackedBytes': unpacked,
                    'sha256': sha256(temporary_zip), 'url': f'{public_base}/{basename}.zip'}
        os.replace(temporary_zip, target)
        atomic_json(metadata_path, metadata)
        return metadata


def main():
    p = argparse.ArgumentParser(description='Extract a regional Protomaps PMTiles package; never downloads the planet as a file')
    for arg in ('source', 'output', 'public-base', 'assets', 'styles', 'id', 'version', 'name'):
        p.add_argument('--' + arg, required=True)
    p.add_argument('--kind', choices=('city', 'state', 'custom'), required=True)
    p.add_argument('--bbox', required=True, help='west,south,east,north')
    p.add_argument('--zoom', type=int, default=14)
    args = p.parse_args()
    result = make_package(source=args.source, output=args.output, public_base=args.public_base, assets=args.assets, styles=args.styles,
                          region_id=args.id, version=args.version, name=args.name, kind=args.kind, bbox=args.bbox.split(','), zoom=args.zoom)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
