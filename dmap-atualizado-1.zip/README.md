# Dmap 2.1 — @vitinhjkjkk

Continuação do projeto Android existente. Apple Maps permanece como mapa principal online na WebView. MapLibre Native renderiza os mapas offline regionais Protomaps. O pacote técnico `com.w2a.nzuz` e a estrutura existente foram preservados.

**Não compilado. Gradle, APK, Actions e publicação não foram executados.** Os checks realizados são estáticos; veja `docs/STATIC_CHECK_REPORT.txt` e `docs/VALIDACAO.md`.

## Implementado no código

- WebView online preservada, com navegação/pesquisa/rotas que o site disponibilizar. A instância é mantida entre abas; timers e ciclo de vida acompanham a visibilidade.
- Modo automático: offline após perda de rede validada por 2 segundos e retorno ao Apple Maps após 8 segundos de estabilidade. Modo manual continua disponível. Erro da Apple com internet exibe opções de tentar novamente/offline.
- Catálogo configurável de cidades/estados Protomaps, busca local de nomes, prévia de limites e tamanho exato do pacote. Recorte personalizado selecionado no mapa, nível de detalhe e preparação pelo servidor opcional incluído.
- Downloads de arquivos reais por WorkManager, progresso por bytes, pausa, retomada HTTP Range/If-Range, cancelamento, verificação de espaço, hash SHA-256 e instalação atômica. Sem progressos simulados.
- PMTiles v3 MVT local, dois estilos, fontes e sprites locais. Seleção de regiões por usuário, GPS ou câmera; integridade verificável e exclusão de arquivos persistentes. Atualizações usam versões separadas, preservando a anterior até exclusão manual.
- GPS Android, precisão e idade da posição, norte fixo, orientação livre e acompanhamento por bússola com animação nativa. Nenhum roteamento offline é anunciado.
- Configurações funcionais, superfícies opacas nos painéis, transições ajustadas, temas claro/escuro/sistema, créditos fora da lista principal. Downloads de fontes anteriores permanecem na seção avançada.

## O que falta configurar

**O app não tem um servidor regional habilitado.** Para baixar mapas, é necessário preparar/publicar os pacotes em hospedagem HTTPS própria e configurar a URL do catálogo no app. Para áreas personalizadas, também é necessário executar o serviço de recortes e informar seu endereço/token. Os scripts e passos estão em `docs/DISTRIBUICAO_PROTOMAPS.md`.

Fonte inicial: Protomaps Basemaps, dados OSM sob ODbL. Estilos CC0, código Protomaps BSD-3-Clause, fontes Noto SIL OFL, sprites MIT. A prévia mundial de limites usa Natural Earth em domínio público. Não há mapas Apple extraídos nem planetas incorporados no projeto.

## Limites atuais

- Sem hospedagem configurada, nenhum download de região pode ser iniciado. `catalog.empty.json` é deliberadamente vazio.
- Pesquisa de endereços e cálculo de rotas offline não implementados. As interfaces de extensão foram mantidas em `OfflineCapabilities.kt`.
- A câmera online só pode ser lida quando o site publica centro/zoom na URL. A sincronização é aproximada; não há introspecção privada do Apple Maps. Rotas/pesquisas da WebView são preservadas quando identificáveis pela URL.
- Apple Maps decide compatibilidade e recursos da WebView; não há contorno de restrições, UA falso ou garantia de paridade com iOS.
- Prévia de download mostra contornos e limites, não ruas antes de baixar. Cidades/estados dependem do conteúdo do catálogo; recortes são retangulares, limitados a 15° por lado, zoom 15, até 8 GiB por pacote. Regiões sobrepostas podem repetir dados; o mesmo ID/versão não é baixado duas vezes.
- Arquivos de fontes se repetem entre pacotes para garantir autonomia; não são carregados inteiros em RAM. Verificação de hash usa leitura em blocos.
- Geração de recorte no servidor tem fila/consulta persistente; não há cancelamento da extração já iniciada. Downloads de pacotes no telefone podem ser pausados/cancelados.
- Android pode adiar/parar trabalhos em segundo plano. Retomar preserva os dados parciais; há backoff e limite de tentativas automáticas. Force-stop exige reabrir o app.
- GPS e bússola dependem de permissões, sinal e sensores. Precisam de teste real, incluindo calibração e consumo.

## Compilação posterior

Projeto para JDK 17, SDK Android 36, minSdk 26/targetSdk 35, AGP 8.13.2, Kotlin/Compose 2.3.20, wrapper Gradle 8.13, MapLibre Native 13.6.1. As dependências detalhadas estão nos arquivos Gradle. Nenhuma chave privada é necessária para o Apple Maps WebView ou para arquivos locais. O token opcional é fornecido pelo operador e armazenado nas preferências privadas; backup está desabilitado.

Importe a raiz que contém `settings.gradle.kts` em um ambiente de build posteriormente. Não foi acrescentado nem alterado workflow de compilação. A compatibilidade de tipos e o build Android ainda precisam ser verificados nesse momento.
