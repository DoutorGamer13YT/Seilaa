package com.infinityclicker.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import com.infinityclicker.ui.components.bouncyClick
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.abs
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.infinityclicker.audio.Sfx
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.ui.components.LocalFrameTicker
import com.infinityclicker.ui.components.SpaceBackground
import com.infinityclicker.ui.components.applyFrameRate
import com.infinityclicker.ui.components.planFrameRate
import com.infinityclicker.ui.components.rememberFrameTicker
import com.infinityclicker.ui.components.glass
import com.infinityclicker.ui.screens.DeveloperScreen
import com.infinityclicker.ui.screens.DimensionsScreen
import com.infinityclicker.ui.screens.HomeScreen
import com.infinityclicker.ui.screens.MissionsScreen
import com.infinityclicker.ui.screens.ProfileScreen
import com.infinityclicker.ui.screens.ShopScreen
import com.infinityclicker.ui.theme.InfinityTheme
import com.infinityclicker.ui.theme.Neon
import com.infinityclicker.ui.theme.tintColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val tabs = listOf("Início", "Loja", "Dimensões", "Missões")
private val tabIcons = listOf("✦", "◈", "◎", "✧")
private const val HUB_TAB = 4
private val hubSections = listOf("Resumo", "Ajustes", "Ambientes", "Dev")

@Composable
fun GameApp(vm: GameViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var hubSection by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val background = ui.backgrounds.firstOrNull { it.equipped }?.def
    val currentTint = background?.tintColor ?: ui.dimensions.firstOrNull { it.current }?.def?.tintColor ?: Neon.Cyan
    val effectiveQuality = ui.settings.graphicsQuality.resolvedFor(ui.settings.batterySaver)
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.exportSaveText()
            if (text != null) {
                scope.launch {
                    val success = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
                                ?: error("Fluxo de saída indisponível")
                        }.isSuccess
                    }
                    vm.reportExportResult(success)
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (text == null) vm.reportImportReadFailure() else vm.importSaveText(text)
            }
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }
    LaunchedEffect(tab) { vm.setActiveTab(tab) }
    val effectiveFps = if (ui.settings.batterySaver) 30 else ui.settings.frameRateCap
    val frameTicker = rememberFrameTicker(effectiveFps)
    var fpsInfo by remember { mutableStateOf("") }
    LaunchedEffect(effectiveFps) {
        // Pede à tela o modo que melhor entrega o limite escolhido; o FrameTicker ajusta as
        // animações como divisor inteiro da taxa real, então os quadros ficam uniformes.
        val activity = context as? Activity ?: return@LaunchedEffect
        val display = activity.window.decorView.display ?: @Suppress("DEPRECATION") activity.windowManager.defaultDisplay
        val plan = planFrameRate(display, effectiveFps) ?: return@LaunchedEffect
        activity.applyFrameRate(plan)
        fpsInfo = "Tela em ${"%.0f".format(plan.displayHz)} Hz · animações a ${"%.0f".format(plan.animationFps)} fps" +
            if (kotlin.math.abs(plan.animationFps - effectiveFps) > 2f) " (esta tela não tem modo de $effectiveFps Hz)" else ""
    }
    LaunchedEffect(ui.notice) {
        ui.notice?.let {
            snackbar.showSnackbar(it)
            vm.dismissNotice()
        }
    }

    InfinityTheme {
      CompositionLocalProvider(LocalFrameTicker provides frameTicker) {
        Box(Modifier.fillMaxSize()) {
            SpaceBackground(
                tint = currentTint,
                style = background?.style,
                quality = effectiveQuality,
                motionEnabled = !ui.settings.batterySaver
            )
            if (ui.loaded) {
                Box(Modifier.fillMaxSize().statusBarsPadding().padding(bottom = 88.dp)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            // Transição curta e só de opacidade/deslocamento (barata para a GPU); molas
                            // lentas mantinham duas telas pesadas compostas ao mesmo tempo por ~1 s.
                            val dir = if (targetState > initialState) 1 else -1
                            (fadeIn(tween(220, delayMillis = 40, easing = FastOutSlowInEasing)) +
                                slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { dir * it / 14 }) togetherWith
                                (fadeOut(tween(120)) + slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -dir * it / 18 })
                        }, label = "tabTransition"
                    ) { screen ->
                        when (screen) {
                            0 -> HomeScreen(ui, vm::tap, vm::useAbility)
                            1 -> ShopScreen(ui, vm::setBuyMode, vm::buyGenerator, vm::buyUpgrade)
                            2 -> DimensionsScreen(ui, vm::unlockDimension, vm::travelDimension, vm::buyResonance, vm::startBoss, vm::equipCrystal)
                            3 -> MissionsScreen(ui, vm::claimDaily, vm::claimLogin, vm::claimAchievement, vm::startChallenge, vm::abandonChallenge)
                            else -> Column(Modifier.fillMaxSize()) {
                                HubHeader(hubSection, { SoundFx.play(Sfx.NAV); hubSection = it }, { SoundFx.play(Sfx.NAV); tab = 0 })
                                Box(Modifier.weight(1f).fillMaxWidth()) {
                                if (hubSection == 3) DeveloperScreen(ui) else ProfileScreen(
                                ui = ui,
                                onScientific = vm::setScientific,
                                onQuality = vm::setGraphicsQuality,
                                onFrameRate = vm::setFrameRate,
                                onSound = vm::setSound,
                                onMusic = vm::setMusic,
                                fpsInfo = fpsInfo,
                                section = hubSection,
                                onBatterySaver = vm::setBatterySaver,
                                onEffects = vm::setEffectsIntensity,
                                onPanelOpacity = vm::setPanelOpacity,
                                onHaptics = vm::setHaptics,
                                onUpgradeAbility = vm::upgradeAbility,
                                onBuySkill = vm::buySkill,
                                onEquipBackground = vm::equipBackground,
                                onExportSave = { exportLauncher.launch("InfinityClicker-V3.ic-save") },
                                onImportSave = { importLauncher.launch(arrayOf("text/plain", "application/octet-stream")) },
                                onPrestige = vm::prestige,
                                onReset = vm::hardReset
                            )
                                }
                            }
                        }
                    }
                }
            }
            SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp))
            BottomBar(tab, { if (it != tab) SoundFx.play(Sfx.NAV); tab = it }, Modifier.align(Alignment.BottomCenter))
            if (ui.loaded && tab != HUB_TAB) ProfileBubble(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 14.dp)) { SoundFx.play(Sfx.NAV); tab = HUB_TAB }
        }

        ui.offlineReport?.let { r ->
            val sci = ui.settings.scientificNotation
            AlertDialog(
                onDismissRequest = vm::dismissOfflineReport,
                title = { Text("Bem-vindo de volta!") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Tempo ausente: ${NumberFormatter.duration(r.elapsedMs)}")
                        Text("Tempo creditado: ${NumberFormatter.duration(r.creditedMs)}" + if (r.elapsedMs > r.capMs) " (limite de ${NumberFormatter.duration(r.capMs)})" else "")
                        Text("Eficiência offline: ${"%.0f".format(r.efficiency * 100)}%")
                        Text("Multiplicador global: ×${NumberFormatter.format(r.globalMultiplier, sci)}")
                        Text("Produção: ${NumberFormatter.format(r.productionPerSecond, sci)}/s")
                        Text("Energia recebida: ${NumberFormatter.format(r.gain, sci)}", fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = { TextButton(onClick = vm::dismissOfflineReport) { Text("Coletar") } }
            )
        }
      }
    }
}

private val BarInk = Color(0xFF14151A)

/**
 * Barra de navegação no estilo "Liquid Glass" do iOS 26: cápsula de vidro claro e fosco, reflexo de luz
 * seguindo a aba ativa, ícones escuros desenhados (contorno; cheios quando ativos) e um indicador cinza
 * em forma de lente que estica enquanto desliza e volta ao tamanho com uma mola.
 */
@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val hubOpen = selected > tabs.lastIndex
    val target = selected.coerceIn(0, tabs.lastIndex).toFloat()
    val pos = animateFloatAsState(target, spring(dampingRatio = 0.58f, stiffness = 280f), label = "tabPos")
    val vis = animateFloatAsState(if (hubOpen) 0f else 1f, tween(220), label = "tabVis")
    val pad = 6.dp
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp).fillMaxWidth()
            .drawBehind {
                // Sombra suave em camadas (sem elevação do sistema, que é cara com transparência).
                val r = CornerRadius(size.height / 2f)
                for (i in 0 until 4) {
                    val grow = (3 + i * 4).dp.toPx()
                    drawRoundRect(Color.Black.copy(alpha = 0.10f - i * 0.02f), Offset(-grow / 2f, 4.dp.toPx() - grow / 2f),
                        Size(size.width + grow, size.height + grow), CornerRadius(size.height / 2f + grow / 2f))
                }
                // Corpo de vidro fosco: claro, translúcido, mais denso embaixo.
                drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.90f), Color(0xFFD7D9E0).copy(alpha = 0.80f))), cornerRadius = r)
                // Reflexo de luz que acompanha a aba ativa (como a refração de uma lente).
                val itemW = (size.width - pad.toPx() * 2f) / tabs.size
                val cx = pad.toPx() + (pos.value + 0.5f) * itemW
                drawRoundRect(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.75f), Color.Transparent), Offset(cx, size.height * 0.30f), size.height * 1.5f), cornerRadius = r)
                // Borda: brilho forte no topo/esquerda, quase some no canto oposto.
                drawRoundRect(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.98f), Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.75f))),
                    cornerRadius = r, style = Stroke(1.6.dp.toPx()))
                drawRoundRect(Color.Black.copy(alpha = 0.07f), Offset(0f, size.height * 0.5f), Size(size.width, size.height * 0.5f), r, style = Stroke(1.dp.toPx()))
            }
            .padding(pad)
            .drawBehind {
                // Indicador em lente: cinza translúcido, estica na direção do movimento.
                val a = vis.value
                if (a > 0.01f) {
                    val itemW = size.width / tabs.size
                    val moving = abs(target - pos.value)
                    val width = itemW * (0.90f + (moving * 0.55f).coerceAtMost(0.55f))
                    val cx = (pos.value + 0.5f) * itemW
                    val h = size.height
                    val left = cx - width / 2f
                    val corner = CornerRadius(h / 2f)
                    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF5E616C).copy(alpha = 0.34f * a), Color(0xFF9396A2).copy(alpha = 0.26f * a))), Offset(left, 0f), Size(width, h), corner)
                    drawRoundRect(Color.White.copy(alpha = 0.55f * a), Offset(left, 0f), Size(width, h), corner, style = Stroke(1.dp.toPx()))
                    drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.40f * a), Color.Transparent), 0f, h * 0.5f),
                        Offset(left + 2.dp.toPx(), 1.dp.toPx()), Size(width - 4.dp.toPx(), h * 0.5f), CornerRadius(h / 4f))
                }
            },
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        tabs.forEachIndexed { index, label ->
            val active = index == selected
            val fill by animateFloatAsState(if (active) 1f else 0f, tween(240), label = "tabFill")
            val lift by animateFloatAsState(if (active) 1.08f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "tabLift")
            val ink = BarInk.copy(alpha = if (active) 0.96f else 0.62f)
            Column(
                Modifier.weight(1f).bouncyClick { onSelect(index) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Canvas(Modifier.size(25.dp).graphicsLayer { scaleX = lift; scaleY = lift }) { drawNavIcon(index, ink, fill) }
                Text(label, fontSize = 10.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium, color = ink, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

/** Ícones de contorno desenhados em uma grade 24×24; `fill` (0..1) preenche a forma principal da aba ativa. */
private fun DrawScope.drawNavIcon(index: Int, color: Color, fill: Float) {
    val k = size.minDimension / 24f
    val stroke = Stroke(1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    withTransform({ scale(k, k, Offset.Zero) }) {
        when (index) {
            0 -> { // casa
                val house = Path().apply {
                    moveTo(12f, 3.5f); lineTo(21f, 11.4f); lineTo(19f, 11.4f); lineTo(19f, 20f); lineTo(14.5f, 20f)
                    lineTo(14.5f, 14.5f); lineTo(9.5f, 14.5f); lineTo(9.5f, 20f); lineTo(5f, 20f); lineTo(5f, 11.4f); lineTo(3f, 11.4f); close()
                }
                drawPath(house, color.copy(alpha = color.alpha * fill))
                drawPath(house, color, style = stroke)
            }
            1 -> { // sacola
                val bag = Path().apply { moveTo(5.5f, 8f); lineTo(18.5f, 8f); lineTo(19.5f, 20.5f); lineTo(4.5f, 20.5f); close() }
                drawPath(bag, color.copy(alpha = color.alpha * fill))
                drawPath(bag, color, style = stroke)
                drawPath(Path().apply { moveTo(9f, 8f); cubicTo(9f, 3.8f, 15f, 3.8f, 15f, 8f) }, color, style = stroke)
            }
            2 -> { // planeta com anel
                drawCircle(color.copy(alpha = color.alpha * fill), 5.8f, Offset(12f, 12f))
                drawCircle(color, 5.8f, Offset(12f, 12f), style = stroke)
                rotate(-24f, Offset(12f, 12f)) { drawOval(color, Offset(1.6f, 9.5f), Size(20.8f, 5f), style = stroke) }
            }
            else -> { // alvo
                drawCircle(color, 9f, Offset(12f, 12f), style = stroke)
                drawCircle(color.copy(alpha = color.alpha * fill), 4.8f, Offset(12f, 12f))
                drawCircle(color, 4.8f, Offset(12f, 12f), style = stroke)
                drawCircle(color, 1.8f, Offset(12f, 12f))
            }
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.White

/** Bolinha de perfil: abre o painel com perfil, ajustes, ambientes e desenvolvedor. Usa a foto do dev se existir. */
@Composable
private fun ProfileBubble(modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val photo = remember {
        val id = context.resources.getIdentifier("developer_photo", "drawable", context.packageName)
        if (id == 0) null else runCatching { android.graphics.BitmapFactory.decodeResource(context.resources, id)?.asImageBitmap() }.getOrNull()
    }
    Box(
        modifier.bouncyClick(onClick = onClick).size(44.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Neon.Violet.copy(alpha = 0.55f), Neon.Cyan.copy(alpha = 0.40f))))
            .border(1.5.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.75f), Neon.Cyan.copy(alpha = 0.35f))), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (photo != null) Image(photo, "Perfil", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("◉", color = Neon.TextPrimary, fontSize = 22.sp)
    }
}

@Composable
private fun HubHeader(selected: Int, onSelect: (Int) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.bouncyClick(onClick = onBack).size(40.dp).glass(CircleShape, tint = Neon.Cyan, alpha = 0.18f, borderAlpha = 0.5f),
                contentAlignment = Alignment.Center
            ) { Text("‹", color = Neon.TextPrimary, fontSize = 26.sp) }
            Text("Perfil", color = Neon.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            hubSections.forEachIndexed { i, label ->
                val on = i == selected
                Text(
                    label, color = if (on) Neon.Bg else Neon.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.bouncyClick { onSelect(i) }
                        .glass(RoundedCornerShape(50), tint = if (on) Neon.Cyan else Color.White, alpha = if (on) 0.85f else 0.10f)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}
