package com.infinityclicker

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.infinityclicker.ui.components.CrystalBody
import com.infinityclicker.ui.components.ParticleField
import com.infinityclicker.ui.components.fleetSizeFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsTest {
    @Test
    fun crystalBodyWobblesAndSettles() {
        val body = CrystalBody()
        body.stepTo(0L)
        body.kick(1f, 0f, 250f, 3f)
        var peak = 0f
        var nanos = 0L
        repeat(60) { // 1 s a 60 fps
            nanos += 16_666_667L
            body.stepTo(nanos)
            peak = maxOf(peak, kotlin.math.abs(body.ox))
        }
        assertTrue("o chute precisa deslocar o cristal", peak > 5f)
        repeat(240) { nanos += 16_666_667L; body.stepTo(nanos) } // mais 4 s
        assertTrue("a mola precisa assentar", kotlin.math.abs(body.ox) < 0.5f && kotlin.math.abs(body.angle) < 0.01f)
    }

    @Test
    fun particlesRespectCapAndDieOut() {
        val field = ParticleField(80)
        field.setBounds(400f, 600f)
        repeat(30) { field.burst(Offset(200f, 300f), Color.Cyan, 20, crit = it % 2 == 0) }
        assertTrue(field.count <= 80)
        var nanos = 0L
        field.stepTo(nanos)
        repeat(300) { nanos += 16_666_667L; field.stepTo(nanos) } // 5 s
        assertEquals(0, field.count)
    }

    @Test
    fun fleetGrowsLogarithmically() {
        assertEquals(0, fleetSizeFor(0))
        assertTrue(fleetSizeFor(10) in 1..28)
        assertTrue(fleetSizeFor(1_000_000) <= 28)
    }
}
