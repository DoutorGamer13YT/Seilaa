package dev.atlas.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.*
import dev.atlas.ui.components.pressScale
import dev.atlas.ui.theme.LocalAtlasColors
import dev.atlas.ui.MapScreenState
import dev.atlas.ui.SearchTarget

@Composable
fun RoutePanel(state: MapScreenState, units: Units, modes: Set<TransportMode>,
    onClose: () -> Unit, onSearch: (SearchTarget) -> Unit, onUseLocation: () -> Unit,
    onSwap: () -> Unit, onRemoveStop: (Int) -> Unit, onMode: (TransportMode) -> Unit,
    onSelectRoute: (Int) -> Unit, onRetry: () -> Unit, onStart: () -> Unit, onMessage: (String) -> Unit,
) {
    val context = LocalContext.current
    var showSteps by remember(state.route?.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Trajeto", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Fechar trajeto") }
        }
        Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                RouteEndpoint("De", state.origin?.name ?: "Escolher origem", Icons.Rounded.TripOrigin) { onSearch(SearchTarget.ORIGIN) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .2f))
                state.stops.forEachIndexed { index, place ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", Modifier.padding(end = 12.dp), color = MaterialTheme.colorScheme.primary)
                        Text(place.name, Modifier.weight(1f), maxLines = 2)
                        IconButton(onClick = { onRemoveStop(index) }) { Icon(Icons.Rounded.RemoveCircleOutline, "Remover parada ${place.name}") }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .2f))
                }
                RouteEndpoint("Para", state.destination?.name ?: "Escolher destino", Icons.Rounded.Place) { onSearch(SearchTarget.DESTINATION) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onUseLocation) { Icon(Icons.Rounded.MyLocation, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Minha localização") }
            IconButton(onClick = onSwap, enabled = state.origin != null && state.destination != null) { Icon(Icons.Rounded.SwapVert, "Inverter origem e destino") }
            IconButton(onClick = { onSearch(SearchTarget.STOP) }, enabled = state.stops.size < 6) { Icon(Icons.Rounded.Add, "Adicionar parada") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            modes.forEach { mode ->
                FilterChip(selected = state.mode == mode, onClick = { onMode(mode) }, label = { Text(mode.label) }, leadingIcon = { Icon(transportIcon(mode), null, Modifier.size(18.dp)) }, shape = RoundedCornerShape(24.dp))
            }
        }
        if (state.origin == null || state.destination == null) {
            Text("Escolha uma origem e um destino para calcular o trajeto.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (state.routing) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            Text("Encontrando o melhor caminho…")
        }
        state.routeError?.let { ErrorCard(it, onRetry) }
        state.routes.forEachIndexed { index, route ->
            val selected = state.routeIndex == index
            val routeInteraction = remember { MutableInteractionSource() }
            Surface(onClick = { onSelectRoute(index) }, interactionSource = routeInteraction, modifier = Modifier.pressScale(routeInteraction, 0.98f), shape = RoundedCornerShape(24.dp),
                color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .09f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = .25f)),
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(formatDuration(route.durationSeconds), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("${formatDistance(route.distanceMeters, units)} · chegada estimada ${formatArrival(route.durationSeconds)}", style = MaterialTheme.typography.bodyMedium)
                        Text(route.summary.ifBlank { if (index == 0) "Rota sugerida" else "Alternativa ${index + 1}" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    if (selected) Icon(Icons.Rounded.CheckCircle, "Rota selecionada", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
        state.route?.let { route ->
            Button(onClick = onStart, Modifier.fillMaxWidth().heightIn(min = 56.dp), shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = LocalAtlasColors.current.positive, contentColor = LocalAtlasColors.current.onPositive)) {
                Icon(Icons.Rounded.Navigation, null); Spacer(Modifier.width(10.dp)); Text("Iniciar", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { showSteps = !showSteps }) { Text(if (showSteps) "Ocultar instruções" else "Ver instruções") }
                TextButton(onClick = {
                    val points = route.waypoints.ifEmpty { listOfNotNull(route.geometry.firstOrNull(), route.geometry.lastOrNull()) }
                    val itinerary = points.mapIndexed { index, point -> "${index + 1}. ${coordinateLabel(point)}" }.joinToString("\n")
                    val text = "Trajeto no DMap\n$itinerary\n${formatDistance(route.distanceMeters, units)} · ${formatDuration(route.durationSeconds)} (estimativa)\nFonte: ${route.source}"
                    try { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartilhar trajeto")) }
                    catch (_: android.content.ActivityNotFoundException) { onMessage("Nenhum aplicativo disponível para compartilhar.") }
                    catch (_: SecurityException) { onMessage("Não foi possível abrir o compartilhamento.") }
                }) { Icon(Icons.Rounded.IosShare, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Compartilhar") }
            }
            if (showSteps) route.steps.forEachIndexed { index, step ->
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(maneuverIcon(step.maneuver), null, Modifier.size(26.dp), MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f)) {
                        Text(step.instruction, style = MaterialTheme.typography.bodyLarge)
                        if (step.street.isNotBlank()) Text(step.street, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text(formatDistance(step.distanceMeters, units), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (index < route.steps.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .2f))
            }
            Text("Estimativas de ${route.source}. Sem informação de trânsito em tempo real.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RouteEndpoint(prefix: String, name: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color.Transparent) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, Modifier.size(20.dp), MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(prefix, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(name, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
            }
            Icon(Icons.Rounded.ChevronRight, null, Modifier.size(18.dp), MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
fun transportIcon(mode: TransportMode): ImageVector = when (mode) {
    TransportMode.CAR -> Icons.Rounded.DirectionsCar
    TransportMode.WALK -> Icons.AutoMirrored.Rounded.DirectionsWalk
    TransportMode.BIKE -> Icons.Rounded.DirectionsBike
}
fun maneuverIcon(maneuver: String): ImageVector = when {
    "uturn" in maneuver || "u-turn" in maneuver -> Icons.Rounded.UTurnLeft
    "left" in maneuver -> Icons.Rounded.TurnLeft
    "right" in maneuver -> Icons.Rounded.TurnRight
    "roundabout" in maneuver -> Icons.Rounded.RoundaboutRight
    "arrive" in maneuver -> Icons.Rounded.Flag
    else -> Icons.Rounded.Straight
}
