package com.infinityclicker.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.ui.theme.Neon
import kotlin.math.PI

/**
 * Gráficos no mesmo estilo do vidro do app: anel com brilho, pontas arredondadas e animação de mola.
 * Tudo é desenhado em Canvas (sem bitmap e sem biblioteca externa).
 */

/** Anel de duas fatias ([manual] e [auto], frações de 0 a 1 do total). O conteúdo de [center] fica no meio do anel. */
@Composable
fun EnergyDonut(
    manual: Float,
    auto: Float,
    manualColor: Color,
    autoColor: Color,
    modifier: Modifier = Modifier,
    center: @Composable () -> Unit = {}
) {
    val manualClamped = manual.coerceIn(0f, 1f)
    val autoClamped = auto.coerceIn(0f, 1f - manualClamped)
    val spec = spring<Float>(dampingRatio = 0.85f, stiffness = 90f)
    val m by animateFloatAsState(manualClamped, spec, label = "donutManual")
    val a by animateFloatAsState(autoClamped, spec, label = "donutAuto")
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val side = size.minDimension
            val stroke = side * 0.13f
            val inset = stroke / 2f + side * 0.035f
            val topLeft = Offset(inset, inset)
            val arcSize = Size(side - inset * 2f, side - inset * 2f)
            val c = Offset(side / 2f, side / 2f)
            // Trilho e aro interno fino, para o anel parecer um vidro com espessura.
            drawArc(Color.White.copy(alpha = 0.07f), 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
            drawCircle(Color.White.copy(alpha = 0.06f), arcSize.width / 2f - stroke * 0.95f, c, style = Stroke(1.2f))
            drawCircle(Color.White.copy(alpha = 0.05f), arcSize.width / 2f + stroke * 0.95f, c, style = Stroke(1.2f))
            val radius = arcSize.width / 2f
            donutSegment(-90f, m * 360f, manualColor, topLeft, arcSize, stroke, radius)
            donutSegment(-90f + m * 360f, a * 360f, autoColor, topLeft, arcSize, stroke, radius)
        }
        center()
    }
}

/** Uma fatia: brilho largo por baixo, corpo colorido com pontas redondas e um fio de luz na borda externa. */
private fun DrawScope.donutSegment(
    start: Float, sweep: Float, color: Color, topLeft: Offset, arcSize: Size, stroke: Float, radius: Float
) {
    // As pontas redondas avançam meia espessura: descontamos isso (e um respiro) para as fatias não se encostarem.
    val capDeg = (stroke / 2f / radius) * (180f / PI.toFloat())
    val s = start + capDeg + 1.2f
    val w = sweep - 2f * capDeg - 2.4f
    if (w <= 0.4f) return
    drawArc(color.copy(alpha = 0.16f), s, w, false, topLeft - Offset(stroke * 0.35f, stroke * 0.35f),
        Size(arcSize.width + stroke * 0.70f, arcSize.height + stroke * 0.70f), style = Stroke(stroke * 1.7f, cap = StrokeCap.Round))
    drawArc(color.copy(alpha = 0.92f), s, w, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
    val d = stroke * 0.30f
    drawArc(Color.White.copy(alpha = 0.34f), s, w, false, topLeft - Offset(d, d),
        Size(arcSize.width + d * 2f, arcSize.height + d * 2f), style = Stroke(stroke * 0.12f, cap = StrokeCap.Round))
}

/** Cartão com o anel de energia manual x automática e a legenda ao lado. */
@Composable
fun EnergyBreakdownCard(
    title: String,
    panelAlpha: Float,
    manualFraction: Float,
    autoFraction: Float,
    manualLabel: String,
    manualValue: String,
    autoLabel: String,
    autoValue: String,
    manualColor: Color,
    autoColor: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier, tint = autoColor, alpha = panelAlpha) {
        Text(title, color = autoColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            EnergyDonut(manualFraction, autoFraction, manualColor, autoColor, Modifier.size(118.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(autoFraction.coerceIn(0f, 1f) * 100f).toInt()}%", color = Neon.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("automático", color = Neon.TextSecondary, fontSize = 10.sp, letterSpacing = 0.5.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ChartLegend(manualColor, manualLabel, manualValue)
                ChartLegend(autoColor, autoLabel, autoValue)
            }
        }
    }
}

@Composable
private fun ChartLegend(color: Color, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Column(Modifier.padding(start = 10.dp)) {
            Text(label, color = Neon.TextSecondary, fontSize = 11.sp, maxLines = 1)
            Text(value, color = Neon.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/**
 * Barras com degradê, topo iluminado e entrada escalonada (uma após a outra). A última barra é a mais recente
 * e fica em destaque. Valores vazios não desenham nada.
 */
@Composable
fun PointsBars(values: List<Int>, tint: Color, modifier: Modifier = Modifier) {
    if (values.isEmpty()) return
    val grow = remember { Animatable(0f) }
    LaunchedEffect(values) {
        grow.snapTo(0f)
        grow.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    Canvas(modifier.fillMaxWidth().height(78.dp)) {
        val n = values.size
        val maxV = (values.maxOrNull() ?: 1).coerceAtLeast(1)
        val gap = 7.dp.toPx()
        val barW = ((size.width - gap * (n - 1)) / n).coerceIn(4.dp.toPx(), 28.dp.toPx())
        val total = barW * n + gap * (n - 1)
        val x0 = (size.width - total) / 2f
        val floor = size.height - 1.dp.toPx()
        val usable = size.height - 8.dp.toPx()
        drawLine(Color.White.copy(alpha = 0.10f), Offset(0f, floor), Offset(size.width, floor), 1.dp.toPx())
        for (i in 0 until n) {
            val last = i == n - 1
            // Cada barra começa um pouco depois da anterior.
            val p = ((grow.value * (n + 3) - i) / 3f).coerceIn(0f, 1f)
            val h = (usable * (values[i].toFloat() / maxV).coerceIn(0.07f, 1f) * p).coerceAtLeast(0f)
            if (h < 0.5f) continue
            val x = x0 + i * (barW + gap)
            val y = floor - h
            val radius = CornerRadius(barW * 0.34f)
            drawRoundRect(
                Brush.verticalGradient(
                    listOf(tint.copy(alpha = if (last) 1f else 0.74f), tint.copy(alpha = if (last) 0.30f else 0.16f)),
                    startY = y, endY = floor
                ),
                Offset(x, y), Size(barW, h), radius
            )
            drawRoundRect(
                Color.White.copy(alpha = if (last) 0.60f else 0.24f),
                Offset(x, y), Size(barW, minOf(2.dp.toPx(), h)), radius
            )
            if (last) drawCircle(tint.copy(alpha = 0.22f * p), barW * 1.1f, Offset(x + barW / 2f, y))
        }
    }
}
