# Dmap

Aplicativo Android Kotlin/Jetpack Compose de @vitinhjkjkk. Esta entrega é uma **base executável em código, ainda não validada por compilação**; não é um produto pronto para distribuição. Conforme solicitado, nenhum APK foi gerado e Gradle não foi executado.

## Implementado nesta versão

- Projeto Android nativo com Compose/Material 3, tema escuro inicial e opção claro persistida em DataStore.
- Tela principal em camadas com controles Dmap, painel inferior com quatro alturas por gesto, sugestões de categorias e acessibilidade básica.
- Pesquisa real de endereços via Geoapify Autocomplete, debounce, erros explícitos e resultados sem dados inventados; requer chave externa.
- Seleção de lugar e centralização de câmera onde o mapa configurado permite.
- Favoritos locais persistentes e opção de limpar.
- Solicitação de localização aproximada/precisa e centralização pontual via APIs Android; não é navegação contínua.
- Adaptador MapLibre Native para um style URL HTTPS configurado.
- Adaptador opcional de MapKit JS oficial em WebView: só é ativado quando se configuram endpoint de token HTTPS e origem própria.
- Alternativa de rota externa `geo:` do Android; não é roteamento nem navegação turn-by-turn dentro do Dmap.
- Controles de modo Automático/Online/Offline persistidos; os estados sem configuração avisam claramente que não há região offline.

## Não implementado (não anunciar como concluído)

Downloads e gerenciamento de regiões offline; leitura/renderização de PMTiles locais; catálogo regional; roteamento interno e navegação curva a curva; localização contínua; bússola e rotação da câmera; histórico; listas de favoritos; detalhes enriquecidos (telefone/horários/fotos/avaliações); sincronização automática de conectividade; política de privacidade/termos para publicação; testes instrumentados e validação em aparelhos.

O seletor Offline é um estado honesto de indisponibilidade, não uma simulação de mapa offline. O suporte PMTiles no MapLibre Android não equivale a downloads offline: a documentação do projeto informa que fontes PMTiles não usam downloads de offline packs nem cache próprio. Para dados offline, é necessário escolher e validar uma fonte autorizada e uma estratégia suportada (por exemplo, packs OfflineManager de um style/servidor compatível, ou serviço regional PMTiles com integração nativa testada).

## Configuração local

1. Instale Android Studio/JDK 17 e copie `local.properties.example` para `local.properties` (preservando `sdk.dir` local, se necessário).
2. Informe `GEOAPIFY_API_KEY` para pesquisa. Configure restrições/limites da chave no painel do provedor; chaves incluídas em apps móveis podem ser extraídas.
3. Para o mapa de fundo MapLibre, configure `MAP_STYLE_URL` com um style JSON HTTPS de provedor que permita uso em aplicativo e cache conforme seus termos. O style, tiles, fontes e sprites devem ter licenças/atribuições adequadas.
4. Para Apple, a integração usa **MapKit JS** (não endpoints privados nem a página `maps.apple.com`). Configure uma conta/Map ID e um serviço HTTPS próprio para emitir JWTs curtos; informe `MAPKIT_TOKEN_URL` que retorne `{"token":"..."}` e `MAPKIT_WEB_ORIGIN` com a origem web autorizada. O segredo de assinatura da Apple fica somente no backend. Configure CORS, limites, rotação e monitoramento. Esta adaptação WebView/origem local deve ser verificada no dispositivo e com as condições atuais de Apple antes de distribuição; não está ativa sem essas configurações.
5. Nunca comite `local.properties`, tokens ou chaves privadas.

Exemplo de configuração (não são credenciais):

```properties
GEOAPIFY_API_KEY=COLOQUE_SUA_CHAVE
MAP_STYLE_URL=https://seu-provedor.example/style.json
MAPKIT_TOKEN_URL=https://api.seu-dominio.example/mapkit-token
MAPKIT_WEB_ORIGIN=https://seu-dominio.example
```

## Privacidade e atribuição

A consulta de pesquisa é enviada a Geoapify quando configurado. Favoritos e tema ficam no armazenamento local; este código não transmite localização atual para a pesquisa. O mapa pode transmitir requisições e telemetria ao provedor selecionado. Reveja os termos/licenças dos serviços, os créditos cartográficos exigidos e publique política de privacidade e termos reais antes de distribuir.

## Verificação

- Arquivos fonte e Manifest foram criados.
- Não rodei Gradle, não compilei, não testei em dispositivo/emulador, não validei integração com Apple nem com chaves de provedores.
- Dependências e APIs devem ser confirmadas no ambiente de build antes de lançamento.

## Referências técnicas

- Apple MapKit JS e suporte multiplataforma: https://developer.apple.com/documentation/mapkitjs
- Termos Apple Maps: https://www.apple.com/legal/internet-services/maps/terms-en.html
- MapLibre Native Android: https://maplibre.org/maplibre-native/android/api/
- Limitação PMTiles/Offline packs: https://maplibre.org/maplibre-native/android/examples/data/PMTiles/
- Geoapify Geocoding API: https://apidocs.geoapify.com/docs/geocoding/
