# Novidades V3.2

## Física
- **Partículas** (`ui/components/Physics.kt`): gravidade, arrasto do ar, quique no chão e nas paredes com atrito,
  3 tipos (faíscas com rastro, estilhaços de cristal que giram e quicam, brasas que sobem). A onda de choque de cada
  toque empurra o que já está voando. Objetos reciclados (pool): sem alocação por toque.
- **Cristal com corpo-mola** (`CrystalBody`): cada toque dá um chute para longe do dedo e um torque conforme o lado
  tocado; o cristal balança 2–3 vezes e assenta. Os tiros das naves também o empurram de leve.
- **Textos flutuantes**: sobem com arrasto, deriva lateral e "pop" elástico de entrada.

## Naves (`ui/components/Fleet.kt`)
- 3 modelos desenhados em Path (caça, interceptador, canhoneira): casco com luz de cima, asas, cabine de vidro,
  canhões, luzes de navegação piscando, chama dos motores proporcional à velocidade.
- Física própria: mola amortecida com antecipação, inércia, giro suave do nariz, inclinação nas curvas, coice ao
  atirar, entrada em "warp" vinda de fora.
- Tiros são projéteis reais (saem do nariz e viajam até a borda do cristal); o impacto solta faíscas na física
  de partículas.

## Áudio dinâmico (`audio/SoundFx.kt`)
- **Camadas em tempo real** (AudioTrack em streaming, sincronizado): ar filtrado que abre com a intensidade,
  pulso rítmico + bumbo suave, drone grave no chefe, cintilações pentatônicas com eco ping-pong.
  A intensidade vem do combo, das habilidades ativas, do ritmo dos toques e do chefe.
- **Diretor**: fade de entrada/saída da música (sem corte seco) e *ducking* quando toca um efeito grande.
- **Efeitos**: o toque sobe uma escala pentatônica com o combo (vira melodia), variação aleatória de tom e volume,
  suporte a pan, e novos sons (relatório offline e tique de contagem).
- **Laço sem emenda**: a faixa de fundo terminava em ~1,3 s de silêncio; foi refeita com crossfade de 3 s.

## Tela de ganhos offline (`ui/components/OfflineDialog.kt`)
- Cena animada no lugar do alerta: anel de aproveitamento do limite com uma nave na ponta, energia contando
  com sons, chips de eficiência/multiplicador/produção em cascata, aviso de limite atingido, partículas de energia
  em laço e botão pulsante.

## Animações e laços
- Fundo: as estrelas tinham velocidade fracionária e davam um "pulo" a cada volta de 52 s. Agora são inteiras
  (laço perfeito) e ganharam paralaxe em 3 camadas, estrelas quentes e uma segunda estrela cadente.
- Anéis de energia que nascem no cristal, em laço contínuo.


# 3.2 Developer Version

## Dificuldade +15%
- `Formulas.DIFFICULTY = 1.15` é o único ponto de ajuste (1.0 volta ao balanceamento anterior).
- Ficam 15% mais caros: geradores e melhorias. Ficam 15% mais difíceis: vida dos chefes, energia para abrir dimensões,
  energia mínima para renascer (1,6M → 1,84M, com a curva de pontos deslocada) e metas dos desafios (60 → 69 cliques etc.).
- Recompensas não foram multiplicadas. Cristais e ambientes (cosméticos) mantêm seus limiares.

## Bugs corrigidos
- Gastar PP na árvore ou em habilidades reduzia o multiplicador permanente do prestígio; agora PP gastos continuam contando
  (o teste `skillsAndCrystalModifyActualClickCalculation` já falhava por isso).
- Link do Instagram da aba Dev apontava para `vitinhkjkk`; o correto é `vitinhjkjkk`.
- Texto do renascimento dizia "1M" quando o mínimo real era 1,6M; agora é calculado pela própria regra.
- Aviso de desafio concluído só aparecia no próximo toque quando o desafio terminava ao comprar gerador ou usar habilidade.
- "Produção local" das dimensões ignorava o bônus de ressonância da árvore; agora mostra o valor real aplicado.
- Divisão por zero teórica ao calcular o multiplicador do toque quando o clique-base era zero.

## Otimizações
- Efeitos da árvore (100 nós) são somados uma vez por recálculo, em vez de a cada consulta (eram milhares por publicação da loja).
- `refreshTimedEffects` (chamado a cada toque e 30×/s) não aloca mais listas.
- Um toque comum não reconstrói dimensões, cristais e ambientes; a árvore e o histórico do perfil só são remontados quando mudam.
- Removidos 4 componentes de tela sem uso.

## Perfil
- Cabeçalho com patente (8 níveis por energia total), progresso até a próxima, versão e atalhos (PP, renascimentos, login).
- Novas seções: Coleção (dimensões, cristais, ambientes, nós da árvore) e sequência de login.
- Cartão **Nuvem · em desenvolvimento** em Ajustes e selo de versão na aba Dev.
