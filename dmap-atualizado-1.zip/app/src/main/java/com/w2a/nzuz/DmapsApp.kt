package com.w2a.nzuz

import android.app.Application
import org.maplibre.android.MapLibre

class DmapsApp : Application() {
    lateinit var prefs: Preferences
    lateinit var offline: OfflineRepository
    lateinit var packages: PackageStore
    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
        prefs = Preferences(this)
        offline = OfflineRepository(this, prefs)
        packages = PackageStore(this, prefs)
    }
}
