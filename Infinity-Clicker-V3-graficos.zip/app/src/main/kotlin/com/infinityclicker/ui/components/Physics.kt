package com.infinityclicker.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.infinityclicker.ui.theme.Neon
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Tipos de partícula: cada um tem gravidade, arrasto e quique próprios. */
internal const val P_SPARK = 0   // faísca: rápida, deixa rastro, quica pouco
internal const val P_SHARD = 1   // estilhaço: gira, pesado, quica no chão e nas paredes
internal const val P_EMBER = 2   // brasa: lenta, flutua para cima

internal class Particle {
    var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
    var px = 0f; var py = 0f            // posição anterior (rastro das faíscas)
    var life = 0f; var maxLife = 1f
    var size = 1f
    var color = Color.White
    var kind = P_SPARK
    var angle = 0f; var spin = 0f
    var bounces = 0
}

private class Shockwave(val x: Float, val y: Float, var life: Float, val maxLife: Float, val color: Color, val critical: Boolean)
private class FloatText(
    var x: Float, var y: Float, val text: String, val color: Color,
    var life: Float, val maxLife: Float, val big: Boolean, var vx: Float, var vy: Float
)

/**
 * Simulação de partículas com física de verdade: gravidade, arrasto do ar, quique no chão e nas paredes
 * com atrito, impulso radial das ondas de choque sobre o que já está voando e estilhaços que giram.
 * Objetos reciclados (pool) e limites fixos: sem alocação por toque e sem crescimento em autoclickers.
 */
internal class ParticleField(private val maxParticles: Int, private val rnd: Random = Random(5)) {
    private val particles = ArrayList<Particle>()
    private val free = ArrayList<Particle>()
    private val waves = ArrayList<Shockwave>()
    private val texts = ArrayList<FloatText>()
    private val shard = Path()

    private var floorY = 1e9f
    private var wallW = 1e9f

    /** Limites da cena (px): o chão fica um pouco acima da base da área do cristal. */
    fun setBounds(width: Float, height: Float) {
        wallW = width
        floorY = height - 10f
    }

    val count: Int get() = particles.size

    private fun obtain(): Particle {
        if (particles.size >= maxParticles) recycle(0)
        val p = if (free.isNotEmpty()) free.removeAt(free.lastIndex) else Particle()
        p.bounces = 0
        particles += p
        return p
    }

    private fun recycle(index: Int) {
        val last = particles.lastIndex
        val p = particles[index]
        particles[index] = particles[last]
        particles.removeAt(last)
        if (free.size < 160) free += p
    }

    private fun spawn(kind: Int, x: Float, y: Float, vx: Float, vy: Float, life: Float, size: Float, color: Color) {
        val p = obtain()
        p.kind = kind
        p.x = x; p.y = y; p.px = x; p.py = y
        p.vx = vx; p.vy = vy
        p.life = life; p.maxLife = life
        p.size = size; p.color = color
        p.angle = rnd.nextFloat() * 6.2832f
        p.spin = (rnd.nextFloat() - 0.5f) * 18f
    }

    fun burst(origin: Offset, color: Color, count: Int, crit: Boolean) {
        val n = (if (crit) count * 2 else count).coerceAtMost(60)
        for (k in 0 until n) {
            val angle = rnd.nextFloat() * 2f * PI.toFloat()
            val c = if (crit && rnd.nextBoolean()) Neon.Gold else color
            val roll = rnd.nextFloat()
            when {
                roll < 0.55f -> { // faísca rápida
                    val speed = (if (crit) 620f else 400f) * (0.35f + rnd.nextFloat())
                    spawn(P_SPARK, origin.x, origin.y, cos(angle) * speed, sin(angle) * speed - 90f,
                        0.38f + rnd.nextFloat() * 0.42f, 1.6f + rnd.nextFloat() * (if (crit) 3.2f else 2.2f), c)
                }
                roll < 0.82f -> { // estilhaço de cristal: gira e quica
                    val speed = (if (crit) 420f else 280f) * (0.4f + rnd.nextFloat() * 0.8f)
                    spawn(P_SHARD, origin.x, origin.y, cos(angle) * speed, sin(angle) * speed - 160f,
                        0.9f + rnd.nextFloat() * 0.8f, 3.2f + rnd.nextFloat() * (if (crit) 5.5f else 3.5f), c)
                }
                else -> { // brasa que sobe devagar
                    val speed = 90f * (0.3f + rnd.nextFloat())
                    spawn(P_EMBER, origin.x, origin.y, cos(angle) * speed, sin(angle) * speed - 40f,
                        0.8f + rnd.nextFloat() * 0.9f, 1.8f + rnd.nextFloat() * 2.2f, c)
                }
            }
        }
        // A onda de choque empurra o que já está no ar: impulso radial com queda pela distância.
        val reach = if (crit) 260f else 170f
        val kick = if (crit) 420f else 220f
        for (p in particles) {
            val dx = p.x - origin.x
            val dy = p.y - origin.y
            val d = hypot(dx, dy)
            if (d in 2f..reach) {
                val f = (1f - d / reach) * kick / d
                p.vx += dx * f
                p.vy += dy * f
            }
        }
        if (waves.size >= MAX_WAVES) waves.removeAt(0)
        waves += Shockwave(origin.x, origin.y, if (crit) 0.62f else 0.44f, if (crit) 0.62f else 0.44f, color, crit)
    }

    /** Faíscas direcionais (impacto de tiro): saem na direção [dx],[dy] com abertura em leque. Respeita um teto próprio. */
    fun sparks(origin: Offset, dx: Float, dy: Float, color: Color, count: Int) {
        if (particles.size > maxParticles * 3 / 4) return
        val base = kotlin.math.atan2(dy, dx)
        for (k in 0 until count) {
            val a = base + (rnd.nextFloat() - 0.5f) * 1.7f
            val speed = 120f + rnd.nextFloat() * 210f
            val c = if (rnd.nextInt(3) == 0) Color.White else color
            spawn(P_SPARK, origin.x, origin.y, cos(a) * speed, sin(a) * speed,
                0.22f + rnd.nextFloat() * 0.28f, 1.2f + rnd.nextFloat() * 1.4f, c)
        }
    }

    fun floatText(origin: Offset, text: String, color: Color, big: Boolean) {
        if (texts.size >= MAX_TEXTS) texts.removeAt(0)
        texts += FloatText(
            origin.x + (rnd.nextFloat() - 0.5f) * 40f, origin.y, text, color, 1.0f, 1.0f, big,
            (rnd.nextFloat() - 0.5f) * 70f, if (big) -250f else -190f
        )
    }

    fun step(dt: Float) {
        val d = min(dt, 0.033f)
        if (d <= 0f) return
        for (i in particles.lastIndex downTo 0) {
            val p = particles[i]
            p.life -= d
            if (p.life <= 0f) { recycle(i); continue }
            p.px = p.x; p.py = p.y
            when (p.kind) {
                P_SPARK -> { p.vy += 640f * d; drag(p, 1.7f, d) }
                P_SHARD -> { p.vy += 1150f * d; drag(p, 0.55f, d); p.angle += p.spin * d }
                else -> { p.vy -= 70f * d; drag(p, 2.4f, d) }
            }
            p.x += p.vx * d
            p.y += p.vy * d
            // Paredes: quique com perda de energia.
            if (p.x < 0f) { p.x = 0f; p.vx = -p.vx * 0.6f } else if (p.x > wallW) { p.x = wallW; p.vx = -p.vx * 0.6f }
            // Chão: quique + atrito; estilhaços quicam mais, e depois de alguns quiques somem.
            if (p.y > floorY && p.kind != P_EMBER) {
                p.y = floorY
                val rest = if (p.kind == P_SHARD) 0.5f else 0.28f
                p.vy = -p.vy * rest
                p.vx *= 0.8f
                p.spin *= 0.7f
                p.bounces++
                if (p.bounces > 3) p.life = min(p.life, 0.12f)
            }
        }
        for (i in waves.lastIndex downTo 0) {
            val wave = waves[i]
            wave.life -= d
            if (wave.life <= 0f) waves.removeAt(i)
        }
        for (i in texts.lastIndex downTo 0) {
            val t = texts[i]
            t.life -= d
            if (t.life <= 0f) { texts.removeAt(i); continue }
            // Sobe com desaceleração (arrasto) e uma leve deriva lateral.
            val k = exp(-3.2f * d)
            t.vx *= k; t.vy *= k
            t.x += t.vx * d; t.y += t.vy * d
        }
    }

    private fun drag(p: Particle, k: Float, d: Float) {
        val f = exp(-k * d)
        p.vx *= f; p.vy *= f
    }

    fun clear() { while (particles.isNotEmpty()) recycle(particles.lastIndex); waves.clear(); texts.clear(); lastNanos = -1L }

    private var lastNanos = -1L

    /** Avança a simulação até [nanos] (relógio do ticker): partículas andam na mesma cadência do desenho. */
    fun stepTo(nanos: Long) {
        if (lastNanos >= 0L && nanos > lastNanos) {
            // Subpassos de no máximo ~16 ms: a física fica estável mesmo com quadros longos ou limite de 30 fps.
            var left = (nanos - lastNanos) / 1_000_000_000f
            while (left > 0f) {
                val s = min(left, 0.0167f)
                step(s)
                left -= s
            }
        }
        lastNanos = nanos
    }

    fun draw(scope: DrawScope) {
        for (wave in waves) {
            val progress = 1f - wave.life / wave.maxLife
            val ease = 1f - (1f - progress) * (1f - progress)
            val a = (1f - progress)
            val reach = if (wave.critical) 190f else 125f
            scope.drawCircle(wave.color.copy(alpha = a * if (wave.critical) 0.70f else 0.45f),
                radius = 36f + ease * reach, center = Offset(wave.x, wave.y), style = Stroke(width = (if (wave.critical) 5f else 3f) * (1f - progress * 0.6f)))
            scope.drawCircle(Color.White.copy(alpha = a * a * 0.35f),
                radius = 28f + ease * reach * 0.72f, center = Offset(wave.x, wave.y), style = Stroke(width = 1.4f))
        }
        val glow = particles.size < 140
        for (p in particles) {
            val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            when (p.kind) {
                P_SPARK -> {
                    // Rastro: segmento da posição anterior até a atual, esticado pela velocidade.
                    val ox = p.x - p.vx * 0.018f
                    val oy = p.y - p.vy * 0.018f
                    if (glow) scope.drawCircle(p.color.copy(alpha = alpha * 0.20f), p.size * 2.8f, Offset(p.x, p.y))
                    scope.drawLine(p.color.copy(alpha = alpha * 0.8f), Offset(ox, oy), Offset(p.x, p.y), p.size * (0.5f + 0.5f * alpha), StrokeCap.Round)
                    scope.drawCircle(Color.White.copy(alpha = alpha * 0.9f), p.size * 0.45f, Offset(p.x, p.y))
                }
                P_SHARD -> {
                    val s = p.size * (0.6f + 0.4f * alpha)
                    val ca = cos(p.angle); val sa = sin(p.angle)
                    shard.rewind()
                    shard.moveTo(p.x + ca * s * 1.5f, p.y + sa * s * 1.5f)
                    shard.lineTo(p.x - sa * s * 0.7f, p.y + ca * s * 0.7f)
                    shard.lineTo(p.x - ca * s * 1.1f, p.y - sa * s * 1.1f)
                    shard.lineTo(p.x + sa * s * 0.7f, p.y - ca * s * 0.7f)
                    shard.close()
                    if (glow) scope.drawCircle(p.color.copy(alpha = alpha * 0.16f), s * 2.6f, Offset(p.x, p.y))
                    scope.drawPath(shard, p.color.copy(alpha = alpha))
                    // Brilho do gume: a face "pega luz" conforme gira.
                    val glint = (0.5f + 0.5f * sin(p.angle * 2f)) * alpha
                    scope.drawPath(shard, Color.White.copy(alpha = glint * 0.55f), style = Stroke(width = 1f))
                }
                else -> {
                    val r = p.size * (0.4f + 0.6f * alpha)
                    if (glow) scope.drawCircle(p.color.copy(alpha = alpha * 0.18f), r * 3.2f, Offset(p.x, p.y))
                    scope.drawCircle(p.color.copy(alpha = alpha * 0.85f), r, Offset(p.x, p.y))
                }
            }
        }
    }

    /** (x, y, texto, cor, alfa, grande, escala): a escala dá o "pop" elástico de entrada. */
    fun forEachText(block: (Float, Float, String, Color, Float, Boolean, Float) -> Unit) {
        for (t in texts) {
            val age = 1f - (t.life / t.maxLife).coerceIn(0f, 1f)
            val fade = if (age > 0.6f) ((1f - age) / 0.4f).coerceIn(0f, 1f) else 1f
            // Pop: sobe rápido passando de 1 (overshoot) e assenta.
            val pop = if (age < 0.16f) {
                val u = age / 0.16f
                0.4f + 0.85f * u
            } else if (age < 0.30f) {
                1.25f - 0.25f * ((age - 0.16f) / 0.14f)
            } else 1f
            block(t.x, t.y, t.text, t.color, fade, t.big, pop)
        }
    }

    private companion object {
        const val MAX_WAVES = 12
        const val MAX_TEXTS = 14
    }
}

/**
 * Corpo rígido simplificado do cristal: deslocamento e rotação presos por molas subamortecidas.
 * Um toque dá um chute (impulso) na direção oposta ao dedo e um torque; o cristal balança e assenta sozinho.
 */
internal class CrystalBody {
    var ox = 0f; var oy = 0f
    private var vx = 0f; private var vy = 0f
    var angle = 0f
    private var angV = 0f
    private var lastNanos = -1L

    /** [dx],[dy]: direção normalizada do empurrão; [torque] gira o cristal (rad/s). */
    fun kick(dx: Float, dy: Float, speed: Float, torque: Float) {
        vx += dx * speed
        vy += dy * speed
        angV += torque
    }

    fun stepTo(nanos: Long) {
        if (lastNanos >= 0L && nanos > lastNanos) {
            var left = ((nanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.1f)
            while (left > 0f) {
                val h = min(left, 0.004f)
                // a = -k·x - c·v  (ζ ≈ 0.33: balança 2–3 vezes antes de assentar)
                vx += (-190f * ox - 9f * vx) * h
                vy += (-190f * oy - 9f * vy) * h
                angV += (-95f * angle - 5.2f * angV) * h
                ox += vx * h; oy += vy * h; angle += angV * h
                left -= h
            }
        }
        lastNanos = nanos
    }

    fun reset() { ox = 0f; oy = 0f; vx = 0f; vy = 0f; angle = 0f; angV = 0f; lastNanos = -1L }
}
