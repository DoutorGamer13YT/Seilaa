package com.vitinhjkjkk.dmap

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vitinhjkjkk.dmap.data.DmapRepository
import com.vitinhjkjkk.dmap.data.GeoapifySearchRepository
import com.vitinhjkjkk.dmap.data.Place
import com.vitinhjkjkk.dmap.data.ProviderNotConfiguredException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DmapViewModel(
    private val repository: DmapRepository,
    private val searchRepository: GeoapifySearchRepository = GeoapifySearchRepository(),
) : ViewModel() {
    val darkTheme = repository.darkTheme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val mapMode = repository.mapMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "AUTO")
    val favorites = repository.favorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()
    private val _results = MutableStateFlow<List<Place>>(emptyList())
    val results = _results.asStateFlow()
    private val _searching = MutableStateFlow(false)
    val searching = _searching.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    private val _selectedPlace = MutableStateFlow<Place?>(null)
    val selectedPlace = _selectedPlace.asStateFlow()

    init { observeSearch() }

    @OptIn(FlowPreview::class)
    private fun observeSearch() {
        viewModelScope.launch {
            query.debounce(450).distinctUntilChanged().collect { term ->
                if (term.trim().length < 3) {
                    _results.value = emptyList()
                    _message.value = null
                    _searching.value = false
                    return@collect
                }
                _searching.value = true
                _message.value = null
                try {
                    _results.value = searchRepository.search(term.trim())
                    if (_results.value.isEmpty()) _message.value = "Nenhum resultado encontrado."
                } catch (_: ProviderNotConfiguredException) {
                    _results.value = emptyList()
                    _message.value = "Configure GEOAPIFY_API_KEY em local.properties para pesquisar."
                } catch (_: Exception) {
                    _results.value = emptyList()
                    _message.value = "Não foi possível pesquisar agora. Verifique a conexão e tente novamente."
                } finally {
                    _searching.value = false
                }
            }
        }
    }

    fun setQuery(value: String) { _query.value = value }
    fun selectPlace(place: Place) { _selectedPlace.value = place }
    fun clearSelection() { _selectedPlace.value = null }
    fun setDarkTheme(enabled: Boolean) { viewModelScope.launch { repository.setDarkTheme(enabled) } }
    fun setMapMode(value: String) { viewModelScope.launch { repository.setMapMode(value) } }
    fun toggleFavorite(place: Place) { viewModelScope.launch { repository.toggleFavorite(place) } }
    fun clearFavorites() { viewModelScope.launch { repository.clearFavorites() } }

    class Factory(context: Context) : ViewModelProvider.Factory {
        private val appContext = context.applicationContext
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(DmapViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class")
            }
            return DmapViewModel(DmapRepository(appContext)) as T
        }
    }
}
