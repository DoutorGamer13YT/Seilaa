package com.infinityclicker

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.ProgressionFormulas
import com.infinityclicker.generators.GeneratorDefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.pow

/** Guardas de regressão para a curva V3: mais longa, porém sem bloqueio matemático. */
class V3BalanceTest {

    @Test
    fun lateGeneratorEntryEffortIsRoughlySixtyPercentHigherThanV2() {
        val ratios = (3..9).map { index ->
            val legacyCost = BigNum.of(15.0 * 12.0.pow(index))
            (GeneratorDefs.byId(index).baseCost / legacyCost).toDouble()
        }
        val average = ratios.average()
        assertTrue("média V3=$average", average in 1.40..1.85)
        assertTrue(ratios.all { it > 1.0 })
    }

    @Test
    fun firstPrestigeIsLaterButTwoMillionEnergyStillWorks() {
        assertEquals(0, ProgressionFormulas.prestigeGain(BigNum.of(1.5e6), 0))
        assertTrue(ProgressionFormulas.prestigeGain(BigNum.of(2e6), 0) >= 1)
        assertTrue(ProgressionFormulas.prestigeGain(BigNum.of(1e20), 0) > ProgressionFormulas.prestigeGain(BigNum.of(2e6), 0))
    }
}
