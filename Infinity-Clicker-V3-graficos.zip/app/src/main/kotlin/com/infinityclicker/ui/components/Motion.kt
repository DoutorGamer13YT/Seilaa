package com.infinityclicker.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclicker.ui.theme.Neon
import kotlin.math.PI
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * Peças de movimento compartilhadas pelas telas. Tudo que anima por quadro é lido só na fase de camada/desenho
 * (graphicsLayer, drawBehind), então nenhuma delas recompõe a tela, e tudo respeita o modo economia de bateria
 * (LocalMotionEnabled) e o limite de FPS do FrameTicker.
 */

/** Falso no modo economia de bateria: as animações decorativas ficam paradas e só as de resposta ao toque rodam. */
val LocalMotionEnabled = staticCompositionLocalOf { true }

private val EnterSpec = tween<Float>(380, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))
private val FastEnterSpec = tween<Float>(220, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))
private val BumpSpring = spring<Float>(dampingRatio = 0.42f, stiffness = 520f)

object Motion {
    /** Desacelera forte no fim: entra rápido e assenta suave (curva "emphasized decelerate"). */
    val Emphasized = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
}

/**
 * Entrada escalonada: o item sobe, cresce de 96% a 100% e aparece, com atraso crescente pelo [index].
 * Só toca uma vez por item enquanto ele existir na lista (o estado é salvo), então rolar de volta não repete.
 */
fun Modifier.enterAnimation(index: Int = 0, rise: Dp = 18.dp): Modifier = composed {
    val enabled = LocalMotionEnabled.current
    var played by rememberSaveable { mutableStateOf(false) }
    val p = remember { Animatable(if (played || !enabled) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!played && enabled) {
            if (index in 1..6) delay(index * 38L)
            // Itens fundos da lista (rolagem rápida) entram mais curtos: nada fica "apagado" esperando a animação.
            p.animateTo(1f, if (index > 6) FastEnterSpec else EnterSpec)
        }
        played = true
    }
    this.graphicsLayer {
        val v = p.value
        // Itens fundos entram durante a rolagem: começam já meio visíveis em vez de aparecerem do nada (menos "pipoco").
        alpha = if (index > 6) 0.4f + 0.6f * v else v
        translationY = (1f - v) * (if (index > 6) minOf(rise, 10.dp) else rise).toPx()
        val s = 0.96f + 0.04f * v
        scaleX = s
        scaleY = s
    }
}

/** Dá um "pulinho" elástico no elemento sempre que [key] muda (contadores, nível, combo). */
fun Modifier.bumpOnChange(key: Any?, peak: Float = 1.16f): Modifier = composed {
    val enabled = LocalMotionEnabled.current
    val s = remember { Animatable(1f) }
    val first = remember { booleanArrayOf(true) }
    LaunchedEffect(key) {
        if (first[0]) {
            first[0] = false
        } else if (enabled) {
            s.snapTo(peak)
            s.animateTo(1f, BumpSpring)
        }
    }
    this.graphicsLayer { scaleX = s.value; scaleY = s.value }
}

/**
 * Clarão curto de confirmação por cima do cartão sempre que [key] muda (ex.: compra feita): sobe de uma vez e some em
 * ~0,5 s. Vai na cadeia ANTES do vidro (no `modifier` que o cartão recebe); [corner] deve igualar o canto do vidro.
 * A opacidade é lida só no desenho, então não recompõe nada. Parado no modo economia de bateria.
 */
fun Modifier.flashOnChange(key: Any?, color: Color, corner: Dp = 22.dp): Modifier = composed {
    val enabled = LocalMotionEnabled.current
    val a = remember { Animatable(0f) }
    val first = remember { booleanArrayOf(true) }
    LaunchedEffect(key) {
        if (first[0]) {
            first[0] = false
        } else if (enabled) {
            a.snapTo(1f)
            a.animateTo(0f, tween(560, easing = LinearOutSlowInEasing))
        }
    }
    this.drawWithContent {
        drawContent()
        val v = a.value
        if (v > 0.01f) drawRoundRect(color.copy(alpha = 0.24f * v), cornerRadius = CornerRadius(corner.toPx()))
    }
}

/** Brilho que respira por cima do vidro (use DEPOIS de `.glass(...)`, para ficar recortado na forma). */
@Composable
fun Modifier.pulseOverlay(color: Color, corner: Dp = 20.dp, periodMs: Long = 1_400L, strength: Float = 1f): Modifier {
    val ticker = LocalFrameTicker.current
    if (!LocalMotionEnabled.current) return this
    return this.drawBehind {
        val k = 0.5f + 0.5f * sin(phaseOf(ticker.value, periodMs))
        drawRoundRect(color.copy(alpha = (0.05f + 0.13f * k) * strength), cornerRadius = CornerRadius(corner.toPx()))
    }
}

/** Bolinha de aviso com um anel que se expande e some em laço, para chamar o olho sem piscar. */
@Composable
fun PulseDot(color: Color, modifier: Modifier = Modifier, dotSize: Dp = 8.dp) {
    val ticker = LocalFrameTicker.current
    val enabled = LocalMotionEnabled.current
    Canvas(modifier.size(dotSize)) {
        val r = this.size.minDimension / 2f
        if (enabled) {
            val t = phaseOf(ticker.value, 1_600L) / (2f * PI.toFloat())
            drawCircle(color.copy(alpha = 0.50f * (1f - t)), r * (1f + 1.3f * t), center, style = Stroke(1.5f))
        }
        drawCircle(color, r, center)
        drawCircle(Color.White.copy(alpha = 0.55f), r * 0.35f, Offset(center.x - r * 0.2f, center.y - r * 0.25f))
    }
}

/**
 * Pílula de seleção em vidro: a cor da seleção entra por fade (uma segunda camada de vidro sobe de 0 a 100%)
 * e o texto troca de cor junto, em vez de saltar de um estado para o outro.
 */
@Composable
fun GlassChip(
    label: String,
    selected: Boolean,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    idleTint: Color = Color.White,
    fontSize: TextUnit = 13.sp,
    fontWeight: FontWeight = FontWeight.SemiBold,
    horizontalPadding: Dp = 16.dp,
    verticalPadding: Dp = 9.dp,
    badge: Boolean = false
) {
    val shape = RoundedCornerShape(50)
    val sel = animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = 520f), label = "chipSel")
    val ink by animateColorAsState(if (selected) Neon.Bg else Neon.TextPrimary, tween(220), label = "chipInk")
    Box(modifier.bouncyClick(onClick = onClick)) {
        Box(Modifier.matchParentSize().glass(shape, tint = idleTint, alpha = 0.10f))
        Box(Modifier.matchParentSize().graphicsLayer { alpha = sel.value }.glass(shape, tint = tint, alpha = 0.85f))
        Row(
            Modifier.padding(horizontal = horizontalPadding, vertical = verticalPadding),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(label, color = ink, fontSize = fontSize, fontWeight = fontWeight, maxLines = 1)
            if (badge) PulseDot(Neon.Green)
        }
    }
}
