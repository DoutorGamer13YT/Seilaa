package com.w2a.nzuz

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds

class MapViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as DmapsApp
    val prefs = app.prefs
    val repo = app.offline
    val packages = app.packages
    val selectedPackage = MutableStateFlow<String?>(null)
    val packageItems = packages.items
    val catalog = packages.catalog
    val connection = Connectivity(app)
    val gps = GpsTracker(app)
    val settings = prefs.state
    val regions = repo.regions
    val webFailure = MutableStateFlow<String?>(null)
    val selectedId = MutableStateFlow<Long?>(null)
    val notice = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)
    private val stableNetwork = MutableStateFlow(connection.usable.value)
    val modeOffline = combine(settings, stableNetwork) { s, net ->
        s.offline || (s.automatic && !net)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, settings.value.offline || !connection.usable.value)

    init {
        action { repo.load(); repo.refreshStatuses(); packages.load() }
        viewModelScope.launch {
            connection.usable.collectLatest { available ->
                kotlinx.coroutines.delay(if (available) 8_000 else 2_000)
                stableNetwork.value = available
            }
        }
    }
    fun bestPackage(location: Location?): MapPackage? {
        val ready = packageItems.value.filter { it.installed }.map { it.pack }
        ready.firstOrNull { it.key == selectedPackage.value }?.let { return it }
        location?.let { fix -> ready.firstOrNull { it.bounds.contains(LatLng(fix.latitude, fix.longitude)) }?.let { return it } }
        prefs.camera()?.let { c -> ready.firstOrNull { it.bounds.contains(LatLng(c[0], c[1])) }?.let { return it } }
        return ready.firstOrNull()
    }

    fun action(block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block() } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { notice.value = e.message ?: "Não foi possível concluir a operação." }
        }
    }
    fun setMode(offline: Boolean) {
        action {
            if (offline) regions.value.filterNot { it.complete }.forEach { repo.pause(it.id) }
            webFailure.value = null
            prefs.update(settings.value.copy(offline = offline))
        }
    }
    fun retryOnline() {
        webFailure.value = null
        prefs.update(settings.value.copy(offline = false))
    }
    fun bestRegion(location: Location?): RegionItem? {
        val completed = regions.value.filter { it.complete }
        selectedId.value?.let { id -> completed.firstOrNull { it.id == id }?.let { return it } }
        location?.let { fix -> completed.firstOrNull { it.definition.bounds?.contains(LatLng(fix.latitude, fix.longitude)) == true }?.let { return it } }
        prefs.camera()?.let { camera -> completed.firstOrNull { it.definition.bounds?.contains(LatLng(camera[0], camera[1])) == true }?.let { return it } }
        return completed.firstOrNull()
    }
    fun create(name: String, bounds: LatLngBounds, zoom: Int, done: () -> Unit) {
        if (busy.value) return
        busy.value = true
        action {
            try {
                val id = repo.create(name, bounds, zoom)
                repo.resume(id)
                notice.value = "Região salva; download agendado."
                done()
            } finally { busy.value = false }
        }
    }
    override fun onCleared() { connection.close(); gps.stop() }
}
