package com.infinityclicker.core

/** Identificação da versão exibida no perfil e na aba do desenvolvedor. */
object AppInfo {
    const val VERSION_NUMBER = "3.2"
    const val CHANNEL = "Developer Version"

    /** Texto único mostrado ao jogador: "3.2 Developer Version". */
    const val VERSION_LABEL = "$VERSION_NUMBER $CHANNEL"
}
