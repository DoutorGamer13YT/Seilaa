package com.infinityclicker.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclicker.core.BigNum
import com.infinityclicker.core.NumberFormatter
import com.infinityclicker.data.DeviceClock
import com.infinityclicker.data.DevicePerformance
import com.infinityclicker.data.GameRepository
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.data.StateSerializer
import com.infinityclicker.data.UserSettings
import com.infinityclicker.data.resolvedFor
import com.infinityclicker.game.AbilityDefs
import com.infinityclicker.game.AchievementDefs
import com.infinityclicker.game.BackgroundDefs
import com.infinityclicker.game.BuyMode
import com.infinityclicker.game.ChallengeDefs
import com.infinityclicker.game.CrystalDefs
import com.infinityclicker.game.CosmicEventDefs
import com.infinityclicker.game.DailyMissionDefs
import com.infinityclicker.game.DimensionDefs
import com.infinityclicker.game.GameEngine
import com.infinityclicker.game.GameState
import com.infinityclicker.game.SkillTree
import com.infinityclicker.game.TapResult
import com.infinityclicker.audio.Sfx
import com.infinityclicker.audio.SoundFx
import com.infinityclicker.generators.GeneratorDefs
import com.infinityclicker.upgrades.ShopCategory
import com.infinityclicker.upgrades.UpgradeDefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/** Ponte sincronizada entre o motor puro, persistência local e Compose. */
class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = GameRepository(app)
    private val lock = Any()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    /** Monta o estado da UI (e serializa o save) fora da thread principal: toque, troca de aba e compra não esperam por isso. */
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val publishQueued = AtomicBoolean(false)
    private val wantShop = AtomicBoolean(false)
    private val wantFull = AtomicBoolean(false)
    private val wantSave = AtomicBoolean(false)

    private var engine: GameEngine? = null
    @Volatile private var settings = UserSettings()

    /** Números dos avisos seguem a notação escolhida (antes saía o texto cru do BigNum, tipo 1.0e2). */
    private fun fmt(n: BigNum): String = NumberFormatter.format(n, settings.scientificNotation)
    private var recovered = false
    @Volatile private var buyMode = BuyMode.X1
    /** Hora do celular sincronizada automaticamente (rede/país). Reavaliada sempre que o app volta ao primeiro plano. */
    @Volatile private var timeSynced = true
    @Volatile private var offlineToShow: com.infinityclicker.game.OfflineReport? = null
    @Volatile private var notice: String? = null

    @Volatile private var activeTab = 0
    private var foreground = false
    private var loopJob: Job? = null
    private var settingsJob: Job? = null
    private val tapHistory = ArrayDeque<Long>()
    @Volatile private var liveClicksPerSecond = 0
    @Volatile private var lastPublishAt = 0L
    /** Chaves (sob [lock]) que dizem quando a árvore e o histórico do perfil precisam ser remontados. */
    private var lastSkillsKey = Long.MIN_VALUE
    private var lastLogKey = Long.MIN_VALUE

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()
    private val _shell = MutableStateFlow(ShellState())
    val shell: StateFlow<ShellState> = _shell.asStateFlow()

    init {
        viewModelScope.launch {
            val loaded = repo.load()
            synchronized(lock) {
                engine = GameEngine(loaded.state).also { it.enableAurora() }
                // A preferência continua sendo do jogador; só o perfil usado pelo modo Automático é recalculado
                // ao abrir, porque pode mudar depois de trocar de aparelho ou restaurar um save.
                settings = loaded.settings.copy(deviceQuality = DevicePerformance.recommendedGraphicsQuality(app))
                recovered = loaded.recoveredFromBackup
            }
            SoundFx.configure(settings.soundEnabled, settings.musicEnabled)
            beginSessionIfReady()
        }
    }

    // ------------------------------------------------------------ ciclo de vida

    fun onForeground() {
        foreground = true
        timeSynced = DeviceClock.isAutoSynced(getApplication<Application>())
        beginSessionIfReady()
    }

    fun onBackground() {
        foreground = false
        loopJob?.cancel()
        loopJob = null
        flushSettings()
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
    }

    private fun beginSessionIfReady() {
        if (!foreground || loopJob != null) return
        val text = synchronized(lock) {
            val e = engine ?: return
            val now = System.currentTimeMillis()
            // Hora manual: o relógio não é confiável, então o ganho offline fica pausado (a marca da sessão avança igual).
            e.clockTrusted = timeSynced
            val report = if (timeSynced) e.applyOffline(now) else { e.touchSession(now); null }
            if (!timeSynced) notice = "Ative \"Data e hora automáticas\" no Android: missões diárias, login e ganho offline estão pausados."
            e.refreshDaily(now)
            if (report != null && report.creditedMs >= MIN_OFFLINE_REPORT_MS) offlineToShow = report
            serializeLocked(e, now)
        }
        ioScope.launch { repo.saveText(text) }
        publish(includeShop = true)
        startLoop()
    }

    private fun startLoop() {
        loopJob = viewModelScope.launch(Dispatchers.Default) {
            var last = SystemClock.elapsedRealtime()
            var sinceSave = 0L
            var sincePublish = 0L
            var publishes = 0
            var loopErrors = 0
            while (isActive) {
                delay(ENGINE_TICK_MS)
                // Rede de segurança: um erro raro no motor (conta estourada, estado inesperado) não pode fechar o jogo
                // no meio da partida. O quadro com falha é descartado e o laço continua no próximo.
                try {
                val nowElapsed = SystemClock.elapsedRealtime()
                val dt = nowElapsed - last
                last = nowElapsed
                val wall = System.currentTimeMillis()
                synchronized(lock) {
                    engine?.advance(dt, wall)
                    engine?.decayCombo(nowElapsed)
                }
                sinceSave += dt
                if (sinceSave >= AUTOSAVE_MS) {
                    sinceSave = 0L
                    saveNow()
                }
                // O motor é baseado em tempo (dt), então não precisa rodar na taxa da tela. Os números
                // só são publicados na cadência abaixo: publicar a cada 8–17 ms recompunha a tela inteira
                // 60–120×/s e era o que travava a rolagem. As animações (Canvas) têm relógio próprio.
                sincePublish += dt
                if (sincePublish >= currentPublishMs()) {
                    sincePublish = 0L
                    publishes++
                    publish(includeShop = activeTab == 1 && publishes % 3 == 0, full = activeTab == 2 || publishes % 15 == 0)
                }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    last = SystemClock.elapsedRealtime()
                    if (loopErrors++ == 0) notice = "Erro interno recuperado. O jogo continua normalmente."
                }
            }
        }
    }

    /** Intervalo entre publicações do estado: mais rápido onde há números mudando à vista. */
    private fun currentPublishMs(): Long {
        val renderQuality = settings.graphicsQuality.resolvedFor(settings.batterySaver, settings.deviceQuality)
        return when {
        settings.batterySaver -> 250L
        // O cristal e o fundo já usam o relógio de frame próprio. Aqui ficam número, combo e disponibilidade de
        // compra: em aparelhos bons atualizar a 30 fps elimina o degrau visual sem reconstruir a tela a 120 fps.
        activeTab == 0 -> when (renderQuality) {
            GraphicsQuality.ULTRA -> 33L
            GraphicsQuality.HIGH -> 40L
            GraphicsQuality.MEDIUM -> 50L
            else -> 66L
        }
        activeTab == 1 -> when (renderQuality) {
            GraphicsQuality.ULTRA, GraphicsQuality.HIGH -> 66L
            GraphicsQuality.MEDIUM -> 83L
            else -> 100L
        }
        // Árvore e perfil/ajustes não mostram números que mudam por segundo: publicar menos evita recompor telas pesadas.
        activeTab == 4 || activeTab == 5 -> 450L
        else -> 200L
        }
    }

    // ------------------------------------------------------------ ações econômicas

    /** Chamado na thread principal a cada toque; todos os toques válidos chegam ao motor. */
    fun tap(): TapResult? {
        val nowElapsed = SystemClock.elapsedRealtime()
        val result = synchronized(lock) {
            val outcome = try { engine?.tap(nowElapsed, System.currentTimeMillis()) } catch (e: Exception) { null }
            tapHistory.addLast(nowElapsed)
            while (tapHistory.isNotEmpty() && nowElapsed - tapHistory.first() > 1_000L) tapHistory.removeFirst()
            liveClicksPerSecond = tapHistory.size
            drainChallengeNoticeLocked()
            outcome
        }
        if (result != null) {
            when {
                result.bossDefeated -> SoundFx.play(Sfx.BOSS_DOWN)
                result.crit -> SoundFx.play(Sfx.CRIT)
                // O tom sobe com o combo: tocar rápido soa cada vez mais agudo e recompensador.
                else -> SoundFx.play(Sfx.TAP, rate = SoundFx.tapRate(result.combo), volume = 0.8f)
            }
        }
        if (result?.bossDefeated == true) notice = "Chefe derrotado! +${fmt(result.bossReward)} de energia e fragmentos."
        // Toques muito rápidos (autoclicker) não reconstroem a UI a cada toque: o laço publica em seguida.
        // Um toque comum só muda energia, combo e estatísticas: dimensões, cristais e fundos (que só mudam por
        // ações do jogador ou desbloqueios revalidados pelo laço) são reaproveitados em vez de reconstruídos.
        if (result?.bossDefeated == true) publishAsync(includeShop = false, full = true)
        else if (nowElapsed - lastPublishAt > MIN_TAP_PUBLISH_GAP_MS) publishAsync(includeShop = false, full = false)
        return result
    }

    fun setActiveTab(tab: Int) {
        activeTab = tab.coerceIn(0, 5)
        publishAsync(includeShop = activeTab == 1)
    }

    fun setBuyMode(mode: BuyMode) {
        buyMode = mode
        publishAsync(includeShop = true)
    }

    fun buyGenerator(id: Int) {
        val ok = synchronized(lock) { engine?.buyGenerator(id, buyMode, System.currentTimeMillis()) == true }
        SoundFx.play(if (ok) Sfx.BUY else Sfx.ERROR)
        if (ok) saveAndPublish(shop = true)
    }

    fun buyUpgrade(id: String) {
        val ok = synchronized(lock) { engine?.buyUpgrade(id, buyMode, System.currentTimeMillis()) == true }
        SoundFx.play(if (ok) Sfx.BUY else Sfx.ERROR)
        if (ok) saveAndPublish(shop = true)
    }

    fun useAbility(id: String) {
        val result = synchronized(lock) { engine?.useAbility(id, System.currentTimeMillis()) }
        if (result?.used == true) {
            SoundFx.play(Sfx.ABILITY)
            // Se a habilidade concluiu um desafio, esse aviso (mais importante) é mostrado pelo publish().
            notice = if (result.gain > BigNum.ZERO) "Explosão Cósmica: +${fmt(result.gain)}" else "${AbilityDefs.byId[id]?.name ?: "Habilidade"} ativada."
            saveAndPublish()
        }
    }

    fun upgradeAbility(id: String) {
        val ok = synchronized(lock) { engine?.upgradeAbility(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun buySkill(id: String) {
        val ok = synchronized(lock) { engine?.buySkill(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun unlockDimension(id: Int) {
        val ok = synchronized(lock) { engine?.unlockDimension(id) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Dimensão desbloqueada."
            saveAndPublish()
        }
    }

    fun travelDimension(id: Int) {
        val ok = synchronized(lock) { engine?.travelDimension(id, System.currentTimeMillis()) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Viagem dimensional concluída."
            saveAndPublish()
        }
    }

    fun buyResonance(id: Int) {
        val ok = synchronized(lock) { engine?.buyResonance(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.BUY)
        if (ok) saveAndPublish()
    }

    fun startBoss() {
        val result = synchronized(lock) { engine?.startBoss(System.currentTimeMillis()) }
        if (result?.started == true) {
            SoundFx.play(Sfx.BOSS_START)
            notice = "Chefe manifestado. Seus cliques agora causam dano."
            saveAndPublish()
        }
    }

    fun equipCrystal(id: Int) {
        val ok = synchronized(lock) { engine?.equipCrystal(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.UNLOCK)
        if (ok) saveAndPublish()
    }

    fun equipBackground(id: Int) {
        val ok = synchronized(lock) { engine?.equipBackground(id, System.currentTimeMillis()) == true }
        if (ok) SoundFx.play(Sfx.UNLOCK)
        if (ok) saveAndPublish()
    }

    fun startChallenge(id: String) {
        val ok = synchronized(lock) { engine?.startChallenge(id, System.currentTimeMillis()) == true }
        if (ok) {
            SoundFx.play(Sfx.UNLOCK)
            notice = "Desafio iniciado. O prazo continua válido mesmo se você sair do app."
            saveAndPublish()
        }
    }

    fun abandonChallenge() {
        val ok = synchronized(lock) { engine?.abandonChallenge() == true }
        if (ok) saveAndPublish()
    }

    fun claimDaily(index: Int) {
        if (!requireSyncedTime()) return
        val reward = synchronized(lock) { engine?.claimDaily(index, System.currentTimeMillis()) }
        if (reward != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Missão concluída: +${fmt(reward)} de energia."
            saveAndPublish()
        }
    }

    fun claimLogin() {
        if (!requireSyncedTime()) return
        val reward = synchronized(lock) { engine?.claimLogin(System.currentTimeMillis()) }
        if (reward != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Recompensa de login recebida: +${fmt(reward)}."
            saveAndPublish()
        }
    }

    fun claimAchievement(id: String) {
        val points = synchronized(lock) { engine?.claimAchievement(id, System.currentTimeMillis()) }
        if (points != null) {
            SoundFx.play(Sfx.CLAIM)
            notice = "Conquista resgatada: +$points pontos de prestígio."
            saveAndPublish()
        }
    }

    fun prestige() {
        val result = synchronized(lock) { engine?.prestige(System.currentTimeMillis()) }
        if (result != null) {
            SoundFx.play(Sfx.PRESTIGE)
            notice = "Renascimento completo: +${result.pointsGained} pontos de prestígio."
            saveAndPublish(shop = true)
        }
    }

    /** O guia pode ser revisto sem apagar ou reiniciar a partida. */
    fun restartTutorial() {
        val restarted = synchronized(lock) { engine?.restartTutorial() == true }
        notice = if (restarted) "Guia inicial reiniciado. Vamos revisar o básico." else "O guia já está no primeiro passo."
        if (restarted) saveAndPublish() else publishAsync(includeShop = false)
    }

    // ------------------------------------------------------------ preferências e recuperação

    fun dismissOfflineReport() {
        offlineToShow = null
        publishAsync(includeShop = false)
    }

    fun dismissNotice() {
        notice = null
        publishAsync(includeShop = false)
    }

    fun setScientific(enabled: Boolean) = updateSettings { it.copy(scientificNotation = enabled) }
    fun setGraphicsQuality(quality: GraphicsQuality) = updateSettings { it.copy(graphicsQuality = quality) }
    fun setFrameRate(cap: Int) = updateSettings {
        it.copy(frameRateCap = if (cap in setOf(30, 60, 90, 120)) cap else 60)
    }
    fun setBatterySaver(enabled: Boolean) = updateSettings { it.copy(batterySaver = enabled) }
    fun setEffectsIntensity(value: Float) = updateSettings { it.copy(effectsIntensity = value.coerceIn(0.25f, 1.5f)) }
    fun setPanelOpacity(value: Float) = updateSettings { it.copy(panelOpacity = value.coerceIn(0.06f, 0.30f)) }
    fun setMotion(enabled: Boolean) = updateSettings { it.copy(motionEnabled = enabled) }
    fun setHaptics(enabled: Boolean) = updateSettings { it.copy(hapticsEnabled = enabled) }
    fun setSound(enabled: Boolean) = updateSettings { it.copy(soundEnabled = enabled) }
    fun setMusic(enabled: Boolean) = updateSettings { it.copy(musicEnabled = enabled) }

    private fun updateSettings(transform: (UserSettings) -> UserSettings) {
        settings = transform(settings)
        val snapshot = settings
        SoundFx.configure(snapshot.soundEnabled, snapshot.musicEnabled)
        // Deslizar um controle gera dezenas de mudanças por segundo: grava só quando o dedo para.
        settingsJob?.cancel()
        settingsJob = ioScope.launch { delay(400L); repo.saveSettings(snapshot) }
        publishAsync(includeShop = false)
    }

    /** Grava na hora as preferências pendentes (ao sair do app). Antes do carregamento não grava, para não sobrescrever com padrões. */
    private fun flushSettings() {
        if (synchronized(lock) { engine == null }) return
        settingsJob?.cancel()
        val snapshot = settings
        settingsJob = ioScope.launch { repo.saveSettings(snapshot) }
    }

    /** Apaga o save local somente depois da confirmação feita pela tela. */
    fun hardReset() {
        val text = synchronized(lock) {
            val fresh = GameState.new()
            // Revisão acima da atual: gravações antigas ainda na fila não conseguem ressuscitar o progresso apagado.
            fresh.saveRevision = (engine?.state?.saveRevision ?: 0L) + 1L
            fresh.lastSessionMs = System.currentTimeMillis()
            val freshEngine = GameEngine(fresh).also { it.enableAurora() }
            engine = freshEngine
            serializeLocked(freshEngine, System.currentTimeMillis())
        }
        offlineToShow = null
        notice = "Novo universo criado."
        ioScope.launch { repo.replaceAll(text) }
        publish(includeShop = true)
    }

    /** Texto assinado por checksum que pode ser salvo pelo seletor de arquivos do Android. */
    fun exportSaveText(): String? = snapshotForSave()

    /** Importa apenas textos que passam no checksum/versionamento; o save atual vira backup local. */
    fun importSaveText(text: String) {
        val imported = StateSerializer.deserialize(text)
        if (imported == null) {
            notice = "Arquivo inválido ou corrompido; seu progresso atual foi preservado."
            publishAsync(includeShop = false)
            return
        }
        val serialized = synchronized(lock) {
            imported.saveRevision = maxOf(imported.saveRevision, engine?.state?.saveRevision ?: 0L) + 1L
            val restored = GameEngine(imported).also { it.enableAurora() }
            engine = restored
            offlineToShow = null
            recovered = false
            serializeLocked(restored, System.currentTimeMillis())
        }
        ioScope.launch { repo.importText(serialized) }
        notice = "Progresso importado com segurança. O save anterior ficou no backup local."
        publishAsync(includeShop = activeTab == 1)
    }

    fun reportExportResult(success: Boolean) {
        notice = if (success) "Backup exportado com sucesso." else "Não foi possível exportar o backup; seu save local continua intacto."
        publishAsync(includeShop = false)
    }

    fun reportImportReadFailure() {
        notice = "Não foi possível ler o arquivo selecionado; seu progresso atual foi preservado."
        publishAsync(includeShop = false)
    }

    // ------------------------------------------------------------ internos

    /** Converte um desafio concluído em aviso. Deve ser chamado com o [lock] em mãos. */
    private fun drainChallengeNoticeLocked() {
        if (engine?.consumeAuroraTrigger() == true) {
            notice = "✦ AURORA ETERNA! Evento raríssimo: tudo está mais forte por 90 s."
            SoundFx.play(Sfx.UNLOCK)
        }
        engine?.consumeChallengeCompletion()?.let { completion ->
            notice = "Desafio concluído: ${completion.name} · +${fmt(completion.energy)} e +${completion.prestigePoints} PP."
        }
    }

    /** Salvamento e publicação saem da thread principal e se fundem quando chegam várias ações seguidas (compras em sequência). */
    private fun saveAndPublish(shop: Boolean = false) {
        publishAsync(includeShop = shop || activeTab == 1, save = true)
    }

    /**
     * Pede uma publicação do estado na thread de trabalho. Pedidos que chegam antes de a anterior começar viram um só
     * (as flags são somadas), então rajadas de toques/ajustes não enfileiram trabalho nem seguram a thread principal.
     */
    private fun publishAsync(includeShop: Boolean, full: Boolean = true, save: Boolean = false) {
        if (includeShop) wantShop.set(true)
        if (full) wantFull.set(true)
        if (save) wantSave.set(true)
        if (!publishQueued.compareAndSet(false, true)) return
        workScope.launch {
            publishQueued.set(false)
            try {
                if (wantSave.getAndSet(false)) saveNow()
                publish(includeShop = wantShop.getAndSet(false), full = wantFull.getAndSet(false))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // Um quadro de estado perdido é recuperado na próxima publicação do laço.
            }
        }
    }

    private fun saveNow() {
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
    }

    /** Reavalia a hora automática; se estiver desligada, avisa e devolve false (resgates por data ficam pausados). */
    private fun requireSyncedTime(): Boolean {
        timeSynced = DeviceClock.isAutoSynced(getApplication<Application>())
        synchronized(lock) { engine?.clockTrusted = timeSynced }
        if (!timeSynced) {
            notice = "Ative \"Data e hora automáticas\" no Android para resgatar recompensas por dia."
            publish(includeShop = false)
        }
        return timeSynced
    }

    private fun snapshotForSave(): String? = synchronized(lock) {
        val e = engine ?: return@synchronized null
        serializeLocked(e, System.currentTimeMillis())
    }

    private fun serializeLocked(e: GameEngine, now: Long): String {
        e.touchSession(now)
        e.state.lastModifiedMs = now
        e.state.saveRevision++
        return StateSerializer.serialize(e.state)
    }

    /**
     * [full] = false (usado pelo laço de 66 ms) reaproveita dimensões, cristais e fundos do estado anterior:
     * eles só mudam por ações do jogador (que publicam com full = true), por desbloqueios automáticos
     * (revalidados a cada ~1 s) ou enquanto a aba que os mostra está aberta.
     */
    private fun publish(includeShop: Boolean, full: Boolean = true) {
        lastPublishAt = SystemClock.elapsedRealtime()
        synchronized(lock) {
            val e = engine ?: return
            val s = e.state
            val now = System.currentTimeMillis()
            e.refreshTimedEffects(now)
            e.refreshDaily(now)
            // Desafios também terminam ao comprar gerador ou usar habilidade: o aviso não pode esperar o próximo toque.
            drainChallengeNoticeLocked()
            val previous = _ui.value
            // Cliques por segundo: esvazia o histórico mesmo sem novos toques (antes o valor ficava congelado).
            val nowTick = SystemClock.elapsedRealtime()
            while (tapHistory.isNotEmpty() && nowTick - tapHistory.first() > 1_000L) tapHistory.removeFirst()
            liveClicksPerSecond = tapHistory.size
            val showMissions = activeTab == 3
            val showProfile = activeTab == 5
            val showSkills = activeTab == 4 || showProfile
            // Com 110 geradores e ~230 melhorias, a loja só monta o que importa: tudo que já está liberado
            // e os próximos itens bloqueados (preview). Isso mantém a lista curta e o laço leve.
            val generators = if (includeShop) {
                val shownGenerators = (s.generators.indexOfLast { it > 0L } + 3).coerceIn(4, GeneratorDefs.count)
                val bestId = e.bestGeneratorId()
                val prevRows = previous.generators
                val built = GeneratorDefs.all.take(shownGenerators).mapIndexed { index, def ->
                    val owned = s.generators[def.id]
                    val unit = e.unitProduction(def)
                    val rowPlan = e.planGenerator(def, buyMode)
                    val row = GeneratorRow(
                        def = def,
                        owned = owned,
                        plan = rowPlan,
                        unitProduction = unit,
                        totalProduction = unit * BigNum.of(owned),
                        unlocked = e.isGeneratorUnlocked(def.id),
                        nextMilestone = (owned / e.milestoneStep() + 1) * e.milestoneStep(),
                        isBest = def.id == bestId,
                        etaSeconds = if (rowPlan.count > 0L && !rowPlan.affordable) e.secondsUntilAffordable(rowPlan.cost) else null
                    )
                    // Linha idêntica à anterior: reaproveita a mesma instância, então o cartão da loja pula a recomposição.
                    prevRows.getOrNull(index)?.takeIf { it.def.id == def.id && it == row } ?: row
                }
                sameOrNew(prevRows, built)
            } else previous.generators
            val upgrades = if (includeShop) {
                val lockedShown = HashMap<ShopCategory, Int>()
                val prevById = HashMap<String, UpgradeRow>(previous.upgrades.size * 2)
                for (old in previous.upgrades) prevById[old.def.id] = old
                val builtUpgrades = UpgradeDefs.all.mapNotNull { def ->
                    val level = s.level(def.id)
                    val unlocked = e.isUnlocked(def.requirement)
                    if (!unlocked) {
                        val shown = lockedShown[def.category] ?: 0
                        if (shown >= 2) return@mapNotNull null
                        lockedShown[def.category] = shown + 1
                    }
                    val row = UpgradeRow(def, level, unlocked, level >= def.maxLevel, e.planUpgrade(def, buyMode))
                    prevById[def.id]?.takeIf { it == row } ?: row
                }
                sameOrNew(previous.upgrades, builtUpgrades)
            } else previous.upgrades

            // A árvore (100 nós) e a galeria (250 itens) só são reconstruídas quando visíveis.
            // Isso impede trabalho de Compose a cada frame da tela inicial.
            // Com o perfil aberto o laço publica 5×/s; refazer 100 nós a cada vez era trabalho puro de desperdício.
            // A lista só é remontada quando níveis, PP ou o universo (save importado/novo) realmente mudaram.
            val skillsKey = s.prestigePoints * 1_000_003L + s.skillLevels.hashCode() + System.identityHashCode(s)
            val skills = if (showSkills && (previous.skills.isEmpty() || skillsKey != lastSkillsKey)) {
                lastSkillsKey = skillsKey
                SkillTree.all.map { def ->
                    SkillNodeUi(def, s.skillLevel(def.id), e.canBuySkill(def.id), def.prerequisites.all { s.skillLevel(it) > 0 })
                }
            } else previous.skills
            val logKey = s.prestigeCount * 100L + s.prestigeHistory.size + System.identityHashCode(s)
            val prestigeLog = if (showProfile && (logKey != lastLogKey || (previous.prestigeLog.isEmpty() && s.prestigeHistory.isNotEmpty()))) {
                lastLogKey = logKey
                s.prestigeHistory.asReversed().toList()
            } else previous.prestigeLog
            val abilitiesNow = AbilityDefs.all.map { def ->
                AbilityUi(
                    def = def,
                    level = e.abilityLevel(def.id),
                    canUse = e.canUseAbility(def.id, now),
                    activeRemainingMs = (e.abilityActiveUntil(def.id) - now).coerceAtLeast(0L),
                    cooldownRemainingMs = (e.abilityCooldownUntil(def.id) - now).coerceAtLeast(0L),
                    canUpgrade = e.canUpgradeAbility(def.id)
                )
            }
            // Nada mudou (habilidades paradas): reaproveita a mesma lista, e a faixa de habilidades pula a recomposição.
            val abilities = if (abilitiesNow == previous.abilities) previous.abilities else abilitiesNow
            val dimensions = if (!full && previous.dimensions.isNotEmpty()) previous.dimensions else reuseRows(previous.dimensions, DimensionDefs.all.map { def ->
                DimensionUi(
                    def = def,
                    unlocked = s.dimensionUnlocked[def.id],
                    canUnlock = e.canUnlockDimension(def.id),
                    unlockRequirement = e.dimensionRequirement(def.id),
                    current = s.currentDimension == def.id,
                    shards = s.dimensionShards[def.id],
                    resonance = s.dimensionResonance[def.id],
                    resonanceCost = e.resonanceCost(def.id),
                    bossWins = s.bossWins[def.id],
                    localMultiplier = e.dimensionMultiplier(def.id),
                    bossHealth = e.bossMaxHealth(def.id)
                )
            })
            val crystals = if (!full && previous.crystals.isNotEmpty()) previous.crystals else reuseRows(previous.crystals, CrystalDefs.all.map { CrystalUi(it, s.crystalsUnlocked[it.id], s.equippedCrystal == it.id) })
            val backgrounds = if (!full && previous.backgrounds.isNotEmpty()) previous.backgrounds else reuseRows(previous.backgrounds, BackgroundDefs.all.map { BackgroundUi(it, s.backgroundsUnlocked[it.id], s.equippedBackground == it.id) })
            val boss = s.activeBoss?.takeIf { it.deadlineMs > now }?.let { active ->
                // A vida máxima vem do motor (inclui a dificuldade); a barra do chefe usa exatamente o mesmo valor.
                BossUi(active, e.bossMaxHealth(active.dimensionId), (active.deadlineMs - now).coerceAtLeast(0L))
            }
            val activeEvent = s.activeEvent?.takeIf { it.endsAtMs > now }?.let { active ->
                CosmicEventDefs.byId[active.eventId]?.let { CosmicEventUi(it, (active.endsAtMs - now).coerceAtLeast(0L)) }
            }
            val missions = if (showMissions) reuseRows(previous.dailyMissions, DailyMissionDefs.all.mapIndexed { index, def ->
                val progress = s.dailyProgress[index]
                DailyMissionUi(def, progress, s.dailyClaimed[index], !s.dailyClaimed[index] && progress >= def.target)
            }) else previous.dailyMissions
            val challenges = if (showMissions) reuseRows(previous.challenges, ChallengeDefs.all.mapIndexed { index, def ->
                val active = s.activeChallenge
                ChallengeUi(
                    def = def,
                    available = active == null && def.available(s),
                    active = active?.challengeId == def.id,
                    progress = if (active?.challengeId == def.id) active.progress else 0L,
                    remainingMs = if (active?.challengeId == def.id) (active.deadlineMs - now).coerceAtLeast(0L) else 0L,
                    wins = s.challengeWins[index]
                )
            }) else previous.challenges
            val achievements = if (showMissions) reuseRows(previous.achievements, AchievementDefs.all.map { def ->
                val unlocked = def.id in s.achievementsUnlockedAt || def.achieved(s)
                AchievementUi(
                    def = def,
                    unlocked = unlocked,
                    claimed = def.id in s.achievementsClaimed,
                    canClaim = e.canClaimAchievement(def.id),
                    progress = def.progress(s),
                    unlockedAtMs = s.achievementsUnlockedAt[def.id]
                )
            }) else previous.achievements

            // Publicar dentro do lock: dois publicadores (toque e laço) não trocam mais a ordem e deixam estado velho na tela.
            _ui.value = UiState(
                loaded = true,
                energy = s.energy,
                production = e.production,
                clickGain = e.baseClickGain(),
                critChance = e.critChance,
                critMultiplier = e.critMultiplier,
                combo = e.comboCount,
                maxCombo = e.maxCombo,
                comboMultiplier = e.comboMultiplier(),
                buyMode = buyMode,
                generators = generators,
                upgrades = upgrades,
                skills = skills,
                prestigeLog = prestigeLog,
                abilities = abilities,
                dimensions = dimensions,
                crystals = crystals,
                backgrounds = backgrounds,
                activeBoss = boss,
                activeEvent = activeEvent,
                challenges = challenges,
                dailyMissions = missions,
                achievements = achievements,
                loginReward = e.loginRewardPreview(now),
                loginStreak = s.loginStreak,
                prestige = e.prestigePreview(),
                stats = StatsUi(
                    totalClicks = s.totalClicks,
                    critClicks = s.critClicks,
                    maxCombo = s.maxCombo,
                    generatorsBought = s.generatorsBought,
                    upgradeLevelsBought = s.upgradeLevelsBought,
                    playTimeMs = s.playTimeMs,
                    totalEnergy = s.totalEnergy,
                    runEnergy = s.runEnergy,
                    offlineEarned = s.offlineEarned,
                    prestigePoints = s.prestigePoints,
                    prestigeCount = s.prestigeCount,
                    abilitiesUsed = s.abilitiesUsed,
                    bossWins = s.bossWins.sum(),
                    clicksPerSecond = liveClicksPerSecond,
                    highestTapMultiplier = s.highestTapMultiplier,
                    highestProduction = s.highestProduction,
                    clickEnergy = s.clickEnergy,
                    productionEnergy = s.productionEnergy,
                    eventsTriggered = s.eventsTriggered,
                    challengeCompletions = s.challengeCompletions,
                    achievementsUnlocked = s.achievementsUnlockedAt.size,
                    achievementsClaimed = s.achievementsClaimed.size,
                    completionFraction = s.achievementsClaimed.size.toFloat() / AchievementDefs.all.size.toFloat()
                ),
                tutorialStep = s.tutorialStep,
                settings = settings,
                offlineReport = offlineToShow,
                recoveredFromBackup = recovered,
                notice = notice,
                timeSynced = timeSynced
            )
            _shell.value = ShellState(
                loaded = true,
                settings = settings,
                background = backgrounds.firstOrNull { it.equipped }?.def,
                dimension = dimensions.firstOrNull { it.current }?.def,
                auroraOn = activeEvent?.def?.rare == true,
                notice = notice,
                offlineReport = offlineToShow
            )
        }
    }

    /** Lista de tamanho fixo e ordem fixa: itens iguais aos anteriores mantêm a instância; se todos mantiveram, devolve a lista antiga. */
    private fun <T> reuseRows(old: List<T>, fresh: List<T>): List<T> {
        if (old.size != fresh.size) return fresh
        val merged = ArrayList<T>(fresh.size)
        for (i in fresh.indices) merged += if (old[i] == fresh[i]) old[i] else fresh[i]
        return sameOrNew(old, merged)
    }

    /** Se [fresh] tem exatamente as mesmas instâncias de [old], devolve [old]: quem observa a lista não recompõe. */
    private fun <T> sameOrNew(old: List<T>, fresh: List<T>): List<T> {
        if (old.size != fresh.size) return fresh
        for (i in fresh.indices) if (old[i] !== fresh[i]) return fresh
        return old
    }

    override fun onCleared() {
        workScope.coroutineContext[Job]?.cancel()
        flushSettings()
        snapshotForSave()?.let { text -> ioScope.launch { repo.saveText(text) } }
        super.onCleared()
    }

    private companion object {
        const val AUTOSAVE_MS = 10_000L
        const val ENGINE_TICK_MS = 33L
        const val MIN_TAP_PUBLISH_GAP_MS = 45L
        const val MIN_OFFLINE_REPORT_MS = 60_000L
    }
}
