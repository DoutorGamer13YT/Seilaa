package com.infinityclicker.game

import com.infinityclicker.core.BigNum
import kotlin.math.floor
import kotlin.math.log10

/** Todas as constantes e fórmulas da economia. Nada aqui depende de interface ou Android. */
object Formulas {
    const val COMBO_WINDOW_MS = 1_000L
    const val COMBO_STEP = 0.02
    const val BASE_COMBO_MAX = 30
    const val BASE_CRIT_CHANCE = 0.03
    const val BASE_CRIT_MULT = 5.0
    const val MAX_CRIT_CHANCE = 0.75
    /** Fração da produção/s somada ao clique por nível do Sifão Cósmico (0,05%). Pequena de propósito:
     *  combo e crítico multiplicam este termo, e valores maiores criam um laço exponencial de compras. */
    const val CLICK_PS_PER_LEVEL = 0.0005
    const val BASE_OFFLINE_HOURS = 8
    const val BASE_OFFLINE_EFFICIENCY = 0.5
    const val MILESTONE_STEP = 25L
    /** Maior passo de simulação aceito de uma vez (protege contra pausas longas do processo). */
    const val MAX_STEP_MS = 5_000L
    /** Limite de segurança para quantidades possuídas (evita estouro de Long). */
    const val MAX_OWNED = 1_000_000_000_000L

    /** Dificuldade que já existia antes do ajuste de duração desta versão. */
    const val BASE_DIFFICULTY = 1.15
    /** A progressão agora leva 120% a mais de tempo: custos, requisitos, chefes e metas viram 2,2× maiores. */
    const val PROGRESSION_TIME_MULTIPLIER = 2.20
    /**
     * Dificuldade global da economia. Aplicada a preços de geradores/melhorias, vida dos chefes, requisitos das
     * dimensões, energia mínima para renascer e metas dos desafios. Recompensas NÃO são multiplicadas.
     */
    const val DIFFICULTY = BASE_DIFFICULTY * PROGRESSION_TIME_MULTIPLIER

    /** Energia mínima produzida numa corrida para poder renascer (1,6M originais × dificuldade). */
    val PRESTIGE_MIN_RUN_ENERGY: BigNum = BigNum.of(1.6e6 * DIFFICULTY)

    /** Preço de UMA unidade quando já se possui [owned]. */
    fun unitCost(base: BigNum, growth: Double, owned: Long): BigNum =
        base * BigNum.of(growth).pow(owned.toDouble())

    /**
     * Preço total para comprar [n] unidades seguidas começando em [owned]:
     * base · g^owned · (g^n − 1) / (g − 1)
     */
    fun bulkCost(base: BigNum, growth: Double, owned: Long, n: Long): BigNum {
        if (n <= 0L) return BigNum.ZERO
        val first = unitCost(base, growth, owned)
        if (n == 1L) return first
        val gn = BigNum.of(growth).pow(n.toDouble())
        return first * (gn - BigNum.ONE) / BigNum.of(growth - 1.0)
    }

    /** Maior quantidade (até [limit]) que cabe no orçamento [budget]. */
    fun maxAffordable(
        base: BigNum,
        growth: Double,
        owned: Long,
        budget: BigNum,
        limit: Long = Long.MAX_VALUE
    ): Long {
        if (limit <= 0L) return 0L
        val first = unitCost(base, growth, owned)
        if (budget < first) return 0L
        val x = budget * BigNum.of(growth - 1.0) / first + BigNum.ONE
        val estimate = x.log10() / log10(growth)
        var n = if (estimate >= 1e15) 1_000_000_000_000_000L else floor(estimate).toLong()
        n = n.coerceIn(1L, limit)
        var guard = 0
        while (n > 1L && bulkCost(base, growth, owned, n) > budget && guard++ < 8) n--
        guard = 0
        while (n < limit && bulkCost(base, growth, owned, n + 1) <= budget && guard++ < 8) n++
        return n
    }

    /** A cada [MILESTONE_STEP] unidades possuídas, a produção do gerador dobra. */
    fun milestoneMultiplier(owned: Long): BigNum =
        BigNum.of(2.0).pow((owned / MILESTONE_STEP).toDouble())
}
