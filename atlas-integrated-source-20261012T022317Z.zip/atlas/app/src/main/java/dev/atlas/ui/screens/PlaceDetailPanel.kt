package dev.atlas.ui.screens

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.atlas.core.Place
import dev.atlas.ui.theme.AtlasDimens
import dev.atlas.ui.theme.LocalAtlasColors
import java.net.URI
import java.util.Locale

@Composable
fun PlaceDetailPanel(
    place: Place,
    saved: Boolean,
    loading: Boolean,
    error: String?,
    distance: String?,
    onClose: () -> Unit,
    onRoute: () -> Unit,
    onFavorite: () -> Unit,
    onCenter: () -> Unit,
    onRetry: () -> Unit,
    onShortcut: (String) -> Unit,
    onMessage: (String) -> Unit,
) {
    val colors = LocalAtlasColors.current
    val context = LocalContext.current
    var menuOpen by remember(place.id) { mutableStateOf(false) }
    var shortcut by rememberSaveable(place.id) { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f).padding(top = 4.dp, end = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    place.name, modifier = Modifier.semantics { heading() }, color = colors.text,
                    style = MaterialTheme.typography.headlineMedium.copy(fontSize = 28.sp, lineHeight = 33.sp),
                )
                Text(
                    listOfNotNull(place.category.takeIf(String::isNotBlank), distance?.takeIf(String::isNotBlank)).joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = colors.secondaryText,
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(AtlasDimens.TouchTarget)) {
                Surface(shape = CircleShape, color = colors.secondarySurface, modifier = Modifier.size(30.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, "Fechar detalhes", modifier = Modifier.size(18.dp), tint = colors.secondaryText)
                    }
                }
            }
        }

        Button(
            onClick = onRoute, shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 14.dp),
        ) {
            Icon(Icons.Rounded.Directions, null, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(10.dp))
            Text("Como chegar", style = MaterialTheme.typography.labelLarge)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DetailAction(
                icon = if (saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                label = if (saved) "Salvo" else "Salvar", accessibilityLabel = if (saved) "Remover dos favoritos" else "Salvar nos favoritos",
                selected = saved, modifier = Modifier.weight(1f), onClick = onFavorite,
            )
            DetailAction(Icons.Rounded.IosShare, "Compartilhar", "Compartilhar lugar", Modifier.weight(1f)) {
                PlaceActions.sharePlace(context, place, onMessage)
            }
            Box(Modifier.weight(1f)) {
                DetailAction(Icons.Rounded.MoreHoriz, "Mais", "Mais ações para este lugar", Modifier.fillMaxWidth()) { menuOpen = true }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Centralizar no mapa") }, leadingIcon = { Icon(Icons.Rounded.MyLocation, null) }, onClick = { menuOpen = false; onCenter() })
                    DropdownMenuItem(text = { Text(if (place.address.isBlank()) "Copiar coordenadas" else "Copiar endereço") }, leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) }, onClick = { menuOpen = false; PlaceActions.copyAddress(context, place, onMessage) })
                    DropdownMenuItem(text = { Text("Definir como Casa") }, leadingIcon = { Icon(Icons.Rounded.Home, null) }, onClick = { menuOpen = false; shortcut = "home" })
                    DropdownMenuItem(text = { Text("Definir como Trabalho") }, leadingIcon = { Icon(Icons.Rounded.Work, null) }, onClick = { menuOpen = false; shortcut = "work" })
                    DropdownMenuItem(text = { Text("Ver no OpenStreetMap") }, leadingIcon = { Icon(Icons.Rounded.OpenInNew, null) }, onClick = { menuOpen = false; PlaceActions.openWebsite(context, PlaceActions.mapLink(place), onMessage) })
                }
            }
        }

        if (loading) Row(
            Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
            Text("Buscando informações do lugar…", style = MaterialTheme.typography.bodySmall, color = colors.secondaryText)
        }
        if (error != null) Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(AtlasDimens.CardRadius)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text(error, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = onRetry) { Text("Tentar novamente") }
            }
        }

        Surface(
            color = colors.surface, shape = RoundedCornerShape(AtlasDimens.CardRadius),
            border = BorderStroke(0.7.dp, colors.glassBorder),
        ) {
            Column {
                DetailField(
                    icon = Icons.Rounded.Place, label = if (place.address.isBlank()) "Coordenadas" else "Endereço",
                    value = place.address.ifBlank { PlaceActions.coordinates(place) },
                    actionLabel = if (place.address.isBlank()) "Copiar coordenadas" else "Copiar endereço",
                    onClick = { PlaceActions.copyAddress(context, place, onMessage) },
                )
                place.phone?.takeIf(String::isNotBlank)?.let { phone ->
                    DetailDivider()
                    DetailField(Icons.Rounded.Call, "Telefone", phone, "Abrir telefone no discador") { PlaceActions.dial(context, phone, onMessage) }
                }
                place.website?.takeIf(String::isNotBlank)?.let { website ->
                    DetailDivider()
                    DetailField(Icons.Rounded.Language, "Site", website, "Abrir site no navegador") { PlaceActions.openWebsite(context, website, onMessage) }
                }
                place.openingHours?.takeIf(String::isNotBlank)?.let { hours ->
                    DetailDivider()
                    DetailField(Icons.Rounded.Schedule, "Horários informados no OpenStreetMap", hours)
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Sobre este lugar", style = MaterialTheme.typography.titleSmall, color = colors.text, modifier = Modifier.semantics { heading() })
            Text(place.source, style = MaterialTheme.typography.bodySmall, color = colors.secondaryText)
            if (place.address.isNotBlank()) Text(PlaceActions.coordinates(place), style = MaterialTheme.typography.bodySmall, color = colors.secondaryText)
            if (place.openingHours != null) Text("Os horários são os dados cadastrados no mapa. Confirme com o estabelecimento.", style = MaterialTheme.typography.bodySmall, color = colors.secondaryText)
            TextButton(onClick = { PlaceActions.openWebsite(context, PlaceActions.mapLink(place), onMessage) }, contentPadding = PaddingValues(0.dp)) {
                Text("Consultar dados no OpenStreetMap", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    shortcut?.let { kind ->
        val label = if (kind == "home") "Casa" else "Trabalho"
        AlertDialog(
            onDismissRequest = { shortcut = null },
            title = { Text("Definir $label") },
            text = { Text("Usar ${place.name} como seu endereço de $label? Um endereço anterior deste atalho será substituído.") },
            confirmButton = { TextButton(onClick = { shortcut = null; onShortcut(kind) }) { Text("Definir endereço") } },
            dismissButton = { TextButton(onClick = { shortcut = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun DetailAction(
    icon: ImageVector, label: String, accessibilityLabel: String, modifier: Modifier,
    selected: Boolean = false, onClick: () -> Unit,
) {
    val colors = LocalAtlasColors.current
    Surface(
        onClick = onClick, modifier = modifier.heightIn(min = 78.dp), shape = RoundedCornerShape(18.dp),
        color = if (selected) colors.accent.copy(alpha = 0.12f) else colors.secondarySurface.copy(alpha = 0.62f),
        contentColor = colors.accent,
    ) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, accessibilityLabel, Modifier.size(23.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun DetailDivider() {
    HorizontalDivider(Modifier.padding(start = 54.dp), thickness = 0.7.dp, color = LocalAtlasColors.current.separator)
}

@Composable
private fun DetailField(icon: ImageVector, label: String, value: String, actionLabel: String? = null, onClick: (() -> Unit)? = null) {
    val colors = LocalAtlasColors.current
    val content: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().heightIn(min = 76.dp).padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, actionLabel, Modifier.padding(top = 3.dp).size(23.dp), tint = colors.accent)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(label, style = MaterialTheme.typography.bodySmall, color = colors.secondaryText)
                Text(value, style = MaterialTheme.typography.bodyMedium, color = if (onClick == null) colors.text else colors.accent)
            }
        }
    }
    if (onClick != null) Surface(onClick = onClick, color = colors.surface, content = content)
    else content()
}

/** Launches only explicit, validated intent schemes; never places calls or interprets provider text as HTML. */
object PlaceActions {
    fun coordinates(place: Place): String = String.format(Locale.ROOT, "%.6f, %.6f", place.coordinate.latitude, place.coordinate.longitude)

    fun mapLink(place: Place): String {
        val match = Regex("(node|way|relation):([1-9][0-9]{0,18})").matchEntire(place.id)
        return if (match != null && match.groupValues[2].toLongOrNull() != null)
            "https://www.openstreetmap.org/${match.groupValues[1]}/${match.groupValues[2]}"
        else "https://www.openstreetmap.org/?mlat=${place.coordinate.latitude}&mlon=${place.coordinate.longitude}#map=18/${place.coordinate.latitude}/${place.coordinate.longitude}"
    }

    fun sharePlace(context: Context, place: Place, onMessage: (String) -> Unit) {
        val text = listOf(place.name, place.address, coordinates(place), mapLink(place)).filter(String::isNotBlank).joinToString("\n")
        shareText(context, "Compartilhar lugar", text, onMessage)
    }

    fun shareText(context: Context, title: String, text: String, onMessage: (String) -> Unit) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).putExtra(Intent.EXTRA_TITLE, title)
        launch(context, Intent.createChooser(send, title), onMessage)
    }

    fun copyAddress(context: Context, place: Place, onMessage: (String) -> Unit) {
        try {
            val clipboard = context.getSystemService(ClipboardManager::class.java)
            if (clipboard == null) { onMessage("A área de transferência não está disponível."); return }
            clipboard.setPrimaryClip(ClipData.newPlainText(place.name, place.address.ifBlank { coordinates(place) }))
            onMessage(if (place.address.isBlank()) "Coordenadas copiadas." else "Endereço copiado.")
        } catch (_: RuntimeException) { onMessage("Não foi possível copiar. Tente novamente.") }
    }

    fun dial(context: Context, phone: String, onMessage: (String) -> Unit) {
        val normalized = phone.trim()
        if (!Regex("^\\+?[0-9][0-9 ()\\-.]{2,49}$").matches(normalized)) {
            onMessage("Este telefone não está em um formato compatível com o discador.")
            return
        }
        val digits = normalized.filter { it.isDigit() || it == '+' }
        launch(context, Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", digits, null)), onMessage)
    }

    fun openWebsite(context: Context, website: String, onMessage: (String) -> Unit) {
        val parsed = runCatching { URI(website.trim()) }.getOrNull()
        if (website.length > 2048 || parsed == null || parsed.scheme?.lowercase(Locale.ROOT) !in setOf("https", "http") || parsed.host.isNullOrBlank() || parsed.userInfo != null) {
            onMessage("O endereço deste site é inválido.")
            return
        }
        launch(context, Intent(Intent.ACTION_VIEW, Uri.parse(parsed.toASCIIString())), onMessage)
    }

    private fun launch(context: Context, intent: Intent, onMessage: (String) -> Unit) {
        try { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: ActivityNotFoundException) { onMessage("Nenhum aplicativo compatível foi encontrado.") }
        catch (_: SecurityException) { onMessage("O Android não permitiu abrir esta ação.") }
        catch (_: IllegalArgumentException) { onMessage("Não foi possível abrir esta informação.") }
    }
}
