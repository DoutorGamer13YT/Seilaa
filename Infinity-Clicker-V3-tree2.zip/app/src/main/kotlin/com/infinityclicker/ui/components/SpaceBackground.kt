package com.infinityclicker.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.infinityclicker.data.GraphicsQuality
import com.infinityclicker.game.BackgroundStyle
import com.infinityclicker.ui.theme.Neon
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Star(val x: Float, val y: Float, val r: Float, val phase: Float, val speed: Float, val hue: Float)

/** Fundo por cenário, com custo escalado pela qualidade e listas de estrelas estáveis em memória. */
@Composable
fun SpaceBackground(
    tint: Color = Neon.Cyan,
    style: BackgroundStyle? = null,
    quality: GraphicsQuality = GraphicsQuality.AUTO,
    motionEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val scene = style ?: BackgroundStyle.DEEP_SPACE
    val stars = remember(quality) {
        val rnd = Random(7)
        List(quality.starCount) {
            Star(
                x = rnd.nextFloat(), y = rnd.nextFloat(), r = 0.55f + rnd.nextFloat() * 1.75f,
                phase = rnd.nextFloat() * (2f * PI.toFloat()), speed = 0.5f + rnd.nextFloat() * 1.5f,
                hue = rnd.nextFloat()
            )
        }
    }
    val ticker = LocalFrameTicker.current
    val periodMs = if (quality == GraphicsQuality.LOW) 90_000L else 52_000L
    val detail = quality.detail

    Canvas(modifier = modifier.fillMaxSize()) {
        // Lido só na fase de desenho: o fundo redesenha no ritmo do limite de FPS, sem recompor.
        val t = if (motionEnabled) phaseOf(ticker.value, periodMs) else 0f
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Neon.BgMid, Neon.Bg, Color(0xFF010208))))
        val c1 = Offset(w * (0.25f + 0.08f * cos(t)), h * (0.20f + 0.05f * sin(t)))
        val c2 = Offset(w * (0.80f + 0.06f * sin(t * 2f)), h * (0.70f + 0.05f * cos(t * 2f)))
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = 0.26f), Color.Transparent), c1, w * 0.77f),
            radius = w * 0.77f, center = c1
        )
        if (detail >= 1) drawCircle(
            Brush.radialGradient(listOf(Neon.Violet.copy(alpha = 0.22f), Color.Transparent), c2, w * 0.68f),
            radius = w * 0.68f, center = c2
        )
        drawSceneAccent(scene, tint, t, w, h, quality)
        if (detail >= 1) {
            val orbitCenter = Offset(w * 0.5f, h * 0.52f)
            drawCircle(tint.copy(alpha = 0.07f), radius = w * 0.36f + sin(t) * 12f, center = orbitCenter,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.4f))
            drawCircle(Neon.Violet.copy(alpha = 0.05f), radius = w * 0.48f - sin(t) * 9f, center = orbitCenter,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f))
        }
        for (star in stars) {
            val alpha = if (detail == 0) 0.55f else 0.28f + 0.62f * (0.5f + 0.5f * sin(t * 8f * star.speed + star.phase))
            val color = if (star.hue > 0.72f) tint else Color.White
            val x = star.x * w + if (motionEnabled) sin(t * star.speed + star.phase) * 2.5f else 0f
            if (detail >= 2 && star.r > 1.6f) drawCircle(color.copy(alpha = alpha * 0.18f), radius = star.r * 3.2f, center = Offset(x, star.y * h))
            drawCircle(color.copy(alpha = alpha), radius = star.r, center = Offset(x, star.y * h))
        }
    }
}

/** A base estrelada é compartilhada; cada cenário adiciona só algumas primitivas baratas por quadro. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSceneAccent(
    style: BackgroundStyle,
    tint: Color,
    t: Float,
    w: Float,
    h: Float,
    quality: GraphicsQuality
) {
    val center = Offset(w * .5f, h * .48f)
    when (style) {
        BackgroundStyle.DEEP_SPACE -> Unit
        BackgroundStyle.NEBULA -> {
            drawCircle(Brush.radialGradient(listOf(Neon.Pink.copy(alpha = .18f), Color.Transparent), Offset(w * .7f, h * .28f), w * .5f), w * .5f, Offset(w * .7f, h * .28f))
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = .16f), Color.Transparent), Offset(w * .22f, h * .72f), w * .42f), w * .42f, Offset(w * .22f, h * .72f))
        }
        BackgroundStyle.SPIRAL_GALAXY -> repeat(5) { arm ->
            val radius = w * (.12f + arm * .07f)
            drawArc(tint.copy(alpha = .18f - arm * .02f), t * 48f + arm * 67f, 150f, false,
                Offset(center.x - radius, center.y - radius * .55f), androidx.compose.ui.geometry.Size(radius * 2f, radius * 1.1f), androidx.compose.ui.graphics.drawscope.Stroke(1.5f))
        }
        BackgroundStyle.BLACK_HOLE -> {
            drawCircle(Color(0xFF000008).copy(alpha = .88f), w * .18f, center)
            repeat(4) { ring ->
                val r = w * (.20f + ring * .045f)
                drawArc(tint.copy(alpha = .44f - ring * .07f), -70f + t * 55f + ring * 13f, 250f, false,
                    Offset(center.x - r, center.y - r * .48f), androidx.compose.ui.geometry.Size(r * 2f, r * .96f), androidx.compose.ui.graphics.drawscope.Stroke(2f - ring * .22f))
            }
        }
        BackgroundStyle.QUANTUM -> if (quality != GraphicsQuality.LOW) {
            val step = w / 8f
            repeat(9) { i ->
                val x = i * step + sin(t + i.toFloat()) * 4f
                drawLine(tint.copy(alpha = .09f), Offset(x, 0f), Offset(x, h), 1f)
                val y = i * h / 8f + cos(t * 1.7f + i.toFloat()) * 3f
                drawLine(Neon.Green.copy(alpha = .08f), Offset(0f, y), Offset(w, y), 1f)
            }
        }
        BackgroundStyle.TEMPORAL -> repeat(4) { ring ->
            val r = w * (.16f + ring * .09f)
            drawArc(Neon.Gold.copy(alpha = .18f - ring * .025f), t * 65f + ring * 90f, 210f, false,
                Offset(center.x - r, center.y - r), androidx.compose.ui.geometry.Size(r * 2f, r * 2f), androidx.compose.ui.graphics.drawscope.Stroke(1.3f))
        }
        BackgroundStyle.INFINITE_REALM -> {
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = .13f), tint.copy(alpha = .08f), Color.Transparent), center, w * .68f), w * .68f, center)
            if (quality == GraphicsQuality.ULTRA) repeat(3) { i ->
                drawCircle(tint.copy(alpha = .10f), w * (.18f + i * .12f + sin(t + i.toFloat()) * .01f), center, androidx.compose.ui.graphics.drawscope.Stroke(1f))
            }
        }
        BackgroundStyle.TRANSCENDENTAL_REALITY -> {
            drawCircle(Brush.radialGradient(listOf(Neon.Pink.copy(alpha = .22f), Color.Transparent), Offset(w * .28f, h * .34f), w * .45f), w * .45f, Offset(w * .28f, h * .34f))
            drawCircle(Brush.radialGradient(listOf(Neon.Gold.copy(alpha = .18f), Color.Transparent), Offset(w * .73f, h * .66f), w * .42f), w * .42f, Offset(w * .73f, h * .66f))
            drawCircle(Color.White.copy(alpha = .22f), w * (.025f + sin(t * 2f) * .006f), center)
        }
    }
}
