package com.infinityclicker.game

import com.infinityclicker.core.BigNum
import com.infinityclicker.game.Formulas.MILESTONE_STEP
import com.infinityclicker.game.Formulas.MAX_CRIT_CHANCE
import kotlin.math.log10
import kotlin.math.min

/** Caminhos da árvore; o motor aplica os efeitos, portanto não há nós decorativos. */
enum class SkillPath(val label: String, val subtitle: String) {
    POWER("Poder", "cliques e combos"),
    AUTOMATION("Automação", "produção e offline"),
    LUCK("Sorte", "eventos e críticos"),
    COSMIC("Cósmico", "prestígio e dimensão"),
    TEMPORAL("Temporal", "habilidades e velocidade")
}

/** Efeitos econômicos aplicados no motor. Todo nó V3 usa pelo menos um deles. */
enum class SkillEffect {
    CLICK_MULTIPLIER,
    CLICK_FLAT,
    CLICK_FROM_PRODUCTION,
    CRIT_CHANCE,
    CRIT_POWER,
    COMBO_CAP,
    COMBO_STEP,
    BOSS_DAMAGE,
    PRODUCTION_MULTIPLIER,
    OFFLINE_HOURS,
    OFFLINE_EFFICIENCY,
    MILESTONE_REDUCTION,
    GENERATOR_DISCOUNT,
    UPGRADE_DISCOUNT,
    PRESTIGE_GAIN,
    PRESTIGE_PERMANENT,
    DIMENSION_REDUCTION,
    SHARD_REWARD,
    RESONANCE_POWER,
    CRYSTAL_POWER,
    EVENT_CHANCE,
    EVENT_POWER,
    ACHIEVEMENT_REWARD,
    ABILITY_DURATION,
    ABILITY_COOLDOWN,
    ABILITY_POWER,
    BOSS_DURATION
}

data class SkillNodeDef(
    val id: String,
    val path: SkillPath,
    val name: String,
    val description: String,
    val maxLevel: Int,
    val baseCost: Int,
    val prerequisites: List<String> = emptyList(),
    val effectText: (Int) -> String,
    val effect: SkillEffect? = null,
    val effectPerLevel: Double = 0.0
) {
    fun costAt(level: Int): Int = baseCost * (level + 1)
}

object SkillTree {
    const val POWER_CORE = "power_core"
    const val POWER_CRIT = "power_crit"
    const val POWER_COMBO = "power_combo"
    const val AUTO_CORE = "auto_core"
    const val AUTO_MILESTONE = "auto_milestone"
    const val AUTO_OFFLINE = "auto_offline"
    const val TRANS_CORE = "trans_core"
    const val TRANS_PRESTIGE = "trans_prestige"
    const val TRANS_DIMENSION = "trans_dimension"

    /** Cem nós: nove legados e noventa e um novos. IDs antigos continuam estáveis no save. */
    val all: List<SkillNodeDef> = V3SkillTree.nodes
    val byId = all.associateBy { it.id }

    fun effectValue(state: GameState, effect: SkillEffect): Double =
        all.sumOf { node -> if (node.effect == effect) state.skillLevel(node.id) * node.effectPerLevel else 0.0 }
}

data class AbilityDef(
    val id: String,
    val name: String,
    val description: String,
    val baseCost: Int,
    val maxLevel: Int,
    val baseDurationMs: Long,
    val baseCooldownMs: Long,
    /** Se > 0, a recarga é exatamente este valor (ignora nível e reduções da árvore). */
    val fixedCooldownMs: Long = 0L,
    val effectText: (Int) -> String
) {
    fun upgradeCost(level: Int) = baseCost * (level + 1)
    fun durationMs(level: Int) = baseDurationMs + level.coerceAtLeast(1) * 1_000L
    fun cooldownMs(level: Int) = if (fixedCooldownMs > 0L) fixedCooldownMs else (baseCooldownMs - level.coerceAtLeast(1) * 1_500L).coerceAtLeast(7_000L)
}

object AbilityDefs {
    const val SUPER_CLICK = "super_click"
    const val TEMPORAL_RUSH = "temporal_rush"
    const val COSMIC_BURST = "cosmic_burst"
    const val QUANTUM_OVERLOAD = "quantum_overload"
    val all = listOf(
        AbilityDef(SUPER_CLICK, "Super Clique", "Amplifica cliques por alguns segundos.", 1, 8, 8_000L, 32_000L,
            effectText = { "×${"%.1f".format(2.0 + it * 0.5)} clique por ${8 + it}s" }),
        AbilityDef(TEMPORAL_RUSH, "Aceleração Temporal", "Acelera os geradores temporariamente.", 2, 8, 10_000L, 38_000L,
            effectText = { "×${"%.1f".format(2.0 + it * 0.4)} produção por ${10 + it}s" }),
        AbilityDef(COSMIC_BURST, "Explosão Cósmica", "Recebe produção instantânea real.", 2, 8, 0L, 360_000L, fixedCooldownMs = 360_000L,
            effectText = { "${20 + it * 10}s de produção instantânea" }),
        AbilityDef(QUANTUM_OVERLOAD, "Sobrecarga Quântica", "Eleva a chance crítica temporariamente.", 3, 8, 8_000L, 40_000L,
            effectText = { "+${30 + it * 5}% chance crítica por ${8 + it}s" })
    )
    val count get() = all.size
    val byId = all.associateBy { it.id }
}

data class DimensionDef(
    val id: Int,
    val name: String,
    val description: String,
    val unlockEnergy: BigNum,
    val tintArgb: Int,
    val bossName: String,
    val bossHealth: BigNum,
    val bossDurationMs: Long,
    val shardReward: Long,
    val productionMultiplier: Double
)

object DimensionDefs {
    val all = listOf(
        DimensionDef(0, "Primordial", "Onde a primeira centelha acorda.", BigNum.ZERO, 0xFF52E5FF.toInt(), "Sentinela de Éter", BigNum.of(250.0), 60_000L, 1, 1.0),
        DimensionDef(1, "Estelar", "Sóis jovens alimentam a matriz.", BigNum.of(1.5e5), 0xFFFFD36B.toInt(), "Draco Solar", BigNum.of(7.0e5), 75_000L, 2, 1.20),
        DimensionDef(2, "Nebulosa", "Nuvens coloridas comprimem energia.", BigNum.of(1.6e8), 0xFFFF5FD2.toInt(), "Mãe Nebular", BigNum.of(8.0e8), 90_000L, 3, 1.45),
        DimensionDef(3, "Galáctica", "Espiras antigas guardam matéria escura.", BigNum.of(1.7e12), 0xFFB07CFF.toInt(), "Arconte Espiral", BigNum.of(1.3e13), 105_000L, 5, 1.75),
        DimensionDef(4, "Quântica", "A probabilidade se torna combustível.", BigNum.of(1.75e17), 0xFF6BFFB0.toInt(), "Paradoxo Vivo", BigNum.of(1.7e18), 120_000L, 8, 2.15)
    )
    val count get() = all.size
    fun byId(id: Int) = all.getOrElse(id) { all.first() }
}

data class CrystalDef(
    val id: Int,
    val name: String,
    val unlockAt: BigNum,
    val tintArgb: Int,
    val clickMultiplier: Double,
    val detail: String
)

object CrystalDefs {
    val all = listOf(
        CrystalDef(0, "Éter Azul", BigNum.ZERO, 0xFF52E5FF.toInt(), 1.0, "Equilíbrio primordial"),
        CrystalDef(1, "Aurora Solar", BigNum.of(1.0e5), 0xFFFFD36B.toInt(), 1.10, "+10% por clique"),
        CrystalDef(2, "Nebulosa Rosa", BigNum.of(1.0e8), 0xFFFF5FD2.toInt(), 1.22, "+22% por clique"),
        CrystalDef(3, "Vórtice Violeta", BigNum.of(1.0e12), 0xFFB07CFF.toInt(), 1.38, "+38% por clique"),
        CrystalDef(4, "Singularidade", BigNum.of(1.0e17), 0xFFFFFFFF.toInt(), 1.60, "+60% por clique")
    )
    val count get() = all.size
    fun byId(id: Int) = all.getOrElse(id) { all.first() }
}

enum class DailyMetric { CLICKS, PURCHASES, ABILITIES }
data class DailyMissionDef(val id: String, val title: String, val metric: DailyMetric, val target: Long, val reward: BigNum)
object DailyMissionDefs {
    val all = listOf(
        DailyMissionDef("daily_clicks", "Fagulhas rápidas", DailyMetric.CLICKS, 50, BigNum.of(150.0)),
        DailyMissionDef("daily_buys", "Construtor cósmico", DailyMetric.PURCHASES, 3, BigNum.of(300.0)),
        DailyMissionDef("daily_abilities", "Canalize o infinito", DailyMetric.ABILITIES, 2, BigNum.of(500.0))
    )
    val count get() = all.size
}

/** Funções de progressão que também são usadas pelo motor e pelos testes. */
object ProgressionFormulas {
    fun prestigeGain(runEnergy: BigNum, bonusLevel: Int): Int {
        // V3: o primeiro renascimento chega mais tarde que na V2, mas a curva posterior é suave.
        // Não é um simples ×1,6 de custo: o limiar usa logaritmo e cada década adicional abre pontos.
        if (runEnergy < Formulas.PRESTIGE_MIN_RUN_ENERGY) return 0
        // A dificuldade desloca a curva inteira: cada ponto de prestígio exige DIFFICULTY× mais energia.
        val raw = ((runEnergy.log10() - log10(Formulas.DIFFICULTY) - 6.15) * 1.12).toInt().coerceAtLeast(1)
        return (raw * (1.0 + bonusLevel * 0.25)).toInt().coerceAtLeast(1)
    }

    fun dimensionRequirement(def: DimensionDef, reductionLevel: Int, additionalReduction: Double = 0.0): BigNum =
        def.unlockEnergy * (1.0 - min(0.62, reductionLevel * 0.10 + additionalReduction)) * Formulas.DIFFICULTY

    /** Vida do próximo chefe da dimensão: cresce 35% por vitória e já inclui a dificuldade global. */
    fun bossHealth(def: DimensionDef, wins: Int): BigNum =
        def.bossHealth * ((1.0 + wins * 0.35) * Formulas.DIFFICULTY)

    fun cappedCrit(base: Double, overloadLevel: Int, overloadActive: Boolean): Double =
        min(MAX_CRIT_CHANCE, base + if (overloadActive) 0.30 + overloadLevel * 0.05 else 0.0)
}
