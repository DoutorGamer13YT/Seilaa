package dev.atlas.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.atlas.core.*
import java.text.Normalizer
import java.util.Locale

@Suppress("UNUSED_PARAMETER")
@Composable
fun LibraryScreen(
    favorites: List<SavedPlace>, lists: List<SavedList>, shortcuts: List<Shortcut>, units: Units,
    onBack: () -> Unit, onSelect: (Place) -> Unit, onRemove: (Place) -> Unit,
    onCreateList: (String) -> Unit, onRenameList: (Long, String) -> Unit,
    onDeleteList: (Long) -> Unit, onMoveList: (Long, Int) -> Unit,
    onSetLists: (Place, Set<Long>) -> Unit, onSetShortcut: (String, Place?) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf<Long?>(null) }
    var editListId by rememberSaveable { mutableStateOf<Long?>(null) }
    var editorOpen by rememberSaveable { mutableStateOf(false) }
    var listName by rememberSaveable { mutableStateOf("") }
    var deleteListId by rememberSaveable { mutableStateOf<Long?>(null) }
    var removePlaceId by rememberSaveable { mutableStateOf<String?>(null) }
    var assignmentId by rememberSaveable { mutableStateOf<String?>(null) }
    var shortcutKind by rememberSaveable { mutableStateOf<String?>(null) }
    val activeFilter = filter?.takeIf { id -> lists.any { it.id == id } }
    val visible = remember(favorites, query, activeFilter) {
        favorites.filter { saved -> (activeFilter == null || activeFilter in saved.listIds) &&
            (query.isBlank() || "${saved.place.name} ${saved.place.address} ${saved.place.category}"
                .contains(query.trim(), ignoreCase = true)) }
    }
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
            modifier = Modifier.fillMaxSize().safeDrawingPadding().imePadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { CollectionHeader("Biblioteca", onBack) }
            item { Text("Seus lugares, sempre por perto.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                OutlinedTextField(value = query, onValueChange = { query = it.take(200) }, singleLine = true,
                    label = { Text("Buscar nos lugares salvos") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Rounded.Close, "Limpar pesquisa") } },
                    shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth())
            }
            item {
                GlassGroup {
                    listOf("home" to "Casa", "work" to "Trabalho").forEachIndexed { index, (kind, title) ->
                        val saved = shortcuts.firstOrNull { it.kind == kind }
                        Row(Modifier.fillMaxWidth().heightIn(min = 76.dp).clickable {
                            saved?.let { onSelect(it.place) } ?: run { shortcutKind = kind }
                        }.padding(start = 18.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (kind == "home") Icons.Rounded.Home else Icons.Rounded.Work, null,
                                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                            Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 14.dp)) {
                                Text(title, fontWeight = FontWeight.SemiBold)
                                Text(saved?.place?.name ?: "Adicionar endereço", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                            }
                            IconButton(onClick = { shortcutKind = kind }) {
                                Icon(Icons.Rounded.Edit, "Editar $title", modifier = Modifier.size(20.dp))
                            }
                        }
                        if (index == 0) HorizontalDivider(Modifier.padding(start = 58.dp))
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Listas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    TextButton(onClick = { editListId = null; listName = ""; editorOpen = true }) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Nova lista")
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = activeFilter == null, onClick = { filter = null }, label = { Text("Todos") }) }
                    items(lists, key = { it.id }) { list ->
                        FilterChip(selected = activeFilter == list.id, onClick = { filter = list.id }, label = { Text(list.name) })
                    }
                }
                lists.firstOrNull { it.id == activeFilter }?.let { selected ->
                    var menu by remember(selected.id) { mutableStateOf(false) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${visible.size} ${if (visible.size == 1) "lugar" else "lugares"}", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Box {
                            TextButton(onClick = { menu = true }) { Text("Editar lista") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Renomear") }, onClick = {
                                    menu = false; editListId = selected.id; listName = selected.name; editorOpen = true })
                                DropdownMenuItem(text = { Text("Mover para a esquerda") }, enabled = lists.firstOrNull()?.id != selected.id,
                                    onClick = { menu = false; onMoveList(selected.id, -1) })
                                DropdownMenuItem(text = { Text("Mover para a direita") }, enabled = lists.lastOrNull()?.id != selected.id,
                                    onClick = { menu = false; onMoveList(selected.id, 1) })
                                DropdownMenuItem(text = { Text("Excluir lista", color = MaterialTheme.colorScheme.error) },
                                    onClick = { menu = false; deleteListId = selected.id })
                            }
                        }
                    }
                }
            }
            if (visible.isEmpty()) item {
                GlassGroup {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.BookmarkBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                        Text(if (query.isNotBlank()) "Nenhum lugar encontrado" else if (activeFilter != null)
                            "Nenhum lugar nesta lista" else "Guarde seus lugares preferidos",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(if (query.isNotBlank()) "Tente outro nome ou endereço." else if (activeFilter != null)
                            "Abra as opções de um lugar salvo e escolha Organizar em listas." else
                            "Abra um lugar no mapa e toque em Salvar. Seus lugares ficam disponíveis aqui, mesmo sem internet.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            items(visible, key = { it.place.id }) { saved ->
                var menu by remember { mutableStateOf(false) }
                GlassGroup {
                    Row(Modifier.fillMaxWidth().clickable { onSelect(saved.place) }.padding(start = 18.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Place, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 18.dp)) {
                            Text(saved.place.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(saved.place.address.ifBlank { saved.place.category }, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (saved.listIds.isNotEmpty()) Text(lists.filter { it.id in saved.listIds }.joinToString(" · ") { it.name },
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 2)
                        }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreHoriz, "Opções de ${saved.place.name}") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Organizar em listas") }, onClick = { menu = false; assignmentId = saved.place.id })
                                DropdownMenuItem(text = { Text("Remover dos salvos", color = MaterialTheme.colorScheme.error) },
                                    onClick = { menu = false; removePlaceId = saved.place.id })
                            }
                        }
                    }
                }
            }
        }
    }
    if (editorOpen) {
        val cleanName = listName.trim().replace(Regex("\\s+"), " ")
        val normalizedName = Normalizer.normalize(cleanName, Normalizer.Form.NFC).lowercase(Locale.ROOT)
        val duplicate = lists.any { it.id != editListId &&
            Normalizer.normalize(it.name, Normalizer.Form.NFC).lowercase(Locale.ROOT) == normalizedName }
        val invalidCharacters = cleanName.any(Char::isISOControl)
        AlertDialog(onDismissRequest = { editorOpen = false }, title = { Text(if (editListId == null) "Nova lista" else "Renomear lista") },
            text = { OutlinedTextField(listName, { listName = it.take(80) }, label = { Text("Nome da lista") }, singleLine = true,
                isError = duplicate || invalidCharacters, supportingText = {
                    if (duplicate) Text("Já existe uma lista com esse nome.")
                    else if (invalidCharacters) Text("Remova os caracteres especiais de controle.")
                }) },
            confirmButton = { TextButton(enabled = cleanName.isNotEmpty() && !duplicate && !invalidCharacters, onClick = {
                editListId?.let { onRenameList(it, cleanName) } ?: onCreateList(cleanName); editorOpen = false
            }) { Text("Salvar") } }, dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("Cancelar") } })
    }
    lists.firstOrNull { it.id == deleteListId }?.let { list ->
        AlertDialog(onDismissRequest = { deleteListId = null }, title = { Text("Excluir ${list.name}?") },
            text = { Text("Os lugares continuarão nos seus salvos e nas outras listas.") },
            confirmButton = { TextButton(onClick = { onDeleteList(list.id); deleteListId = null; filter = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { deleteListId = null }) { Text("Cancelar") } })
    }
    favorites.firstOrNull { it.place.id == removePlaceId }?.let { saved ->
        AlertDialog(onDismissRequest = { removePlaceId = null }, title = { Text("Remover ${saved.place.name}?") },
            text = { Text("O lugar será removido dos salvos e de todas as listas. Atalhos de Casa e Trabalho serão mantidos.") },
            confirmButton = { TextButton(onClick = { onRemove(saved.place); removePlaceId = null }) { Text("Remover") } },
            dismissButton = { TextButton(onClick = { removePlaceId = null }) { Text("Cancelar") } })
    }
    favorites.firstOrNull { it.place.id == assignmentId }?.let { saved ->
        var selectedIds by rememberSaveable(saved.place.id) { mutableStateOf(saved.listIds.toLongArray()) }
        val selected = selectedIds.toSet()
        AlertDialog(onDismissRequest = { assignmentId = null }, title = { Text("Organizar em listas") }, text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                if (lists.isEmpty()) item { Text("Crie uma lista na Biblioteca para organizar este lugar.") }
                items(lists, key = { it.id }) { list ->
                    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).toggleable(value = list.id in selected, role = Role.Checkbox,
                        onValueChange = { selectedIds = (if (it) selected + list.id else selected - list.id).toLongArray() }), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = list.id in selected, onCheckedChange = null)
                        Text(list.name, Modifier.padding(start = 12.dp))
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = {
            onSetLists(saved.place, selected.intersect(lists.map { it.id }.toSet())); assignmentId = null
        }) { Text("Salvar") } },
            dismissButton = { TextButton(onClick = { assignmentId = null }) { Text("Cancelar") } })
    }
    shortcutKind?.let { kind ->
        AlertDialog(onDismissRequest = { shortcutKind = null }, title = { Text(if (kind == "home") "Endereço de Casa" else "Endereço do Trabalho") },
            text = { LazyColumn(Modifier.heightIn(max = 360.dp)) {
                item { Text("Escolha um lugar salvo.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                if (favorites.isEmpty()) item { Text("Salve um lugar no mapa para definir este atalho.", Modifier.padding(top = 12.dp)) }
                items(favorites, key = { it.place.id }) { saved ->
                    Column(Modifier.fillMaxWidth().clickable { onSetShortcut(kind, saved.place); shortcutKind = null }.padding(vertical = 16.dp)) {
                        Text(saved.place.name, fontWeight = FontWeight.SemiBold)
                        Text(saved.place.address.ifBlank { saved.place.category }, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            } }, confirmButton = { TextButton(onClick = { shortcutKind = null }) { Text("Fechar") } }, dismissButton = {
                if (shortcuts.any { it.kind == kind }) TextButton(onClick = { onSetShortcut(kind, null); shortcutKind = null }) { Text("Remover atalho") }
            })
    }
}

@Composable
internal fun CollectionHeader(title: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = .90f), tonalElevation = 2.dp) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar", tint = MaterialTheme.colorScheme.primary) }
        }
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun GlassGroup(content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .93f), shadowElevation = 1.dp,
        border = BorderStroke(.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .42f))) {
        Column(content = content)
    }
}
